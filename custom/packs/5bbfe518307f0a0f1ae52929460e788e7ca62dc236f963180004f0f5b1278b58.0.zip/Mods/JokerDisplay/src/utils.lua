--- UTILITY FUNCTIONS

JokerDisplay.current_hand = {}
JokerDisplay.current_hand_info = {
    text = "Unknown",
    poker_hands = {},
    scoring_hand = {}
}

--- Splits text by a separator.
---@param str string String to split.
---@param sep string? Separator. Defaults to whitespace.
---@return table split_text
function JokerDisplay.strsplit(str, sep)
    if sep == nil then
        sep = "%s"
    end
    local t = {}
    for substr in string.gmatch(str, "([^" .. sep .. "]+)") do
        table.insert(t, substr)
    end
    return t
end

--- Deep copies a table.
---@param orig table Table to copy.
---@return table? copy
function JokerDisplay.deepcopy(orig)
    local copy
    if type(orig) == 'table' then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[JokerDisplay.deepcopy(orig_key)] = JokerDisplay.deepcopy(orig_value)
        end
        setmetatable(copy, JokerDisplay.deepcopy(getmetatable(orig)))
    else
        copy = orig
    end
    return copy
end

--- NUMBER FORMATTING

-- Talisman compat
if not _G["to_big"] then
    to_big = function(x)
        return x
    end
end

-- function taken from smods

round_number = round_number or function(num, precision)
    precision = 10 ^ (precision or 0)

    return math.floor(num * precision + 0.4999999999999994) / precision
end

---Formats number.
---@see number_format
---@param num any Number to format. Accepts Talisman's bignum/omeganum.
---@param e_switch_point number? Number from where to switch to scientic notation. Defaults to 1000000.
---@param places number? Maximum decimal places. Defaults to 2.
---@param signed boolean|string|table?
---@return any # The formatted string or `num` if it's not a number.
function JokerDisplay.number_format(num, e_switch_point, places, signed)
    if not num then return num or '' end
    if type(num) == "function" then num = num() end
    if (type(num) ~= 'number' and type(num) ~= 'table' and type(num) ~= 'cdata') then return num or '' end
    -- Amulet compat. Copied from Talisman with some changes :)
    local plus = ""
    local minus = "-"
    if signed then
        local typesigned = type(signed)
        if typesigned == "table" then
            plus = signed.plus or plus
            minus = signed.minus or minus
        elseif typesigned == "string" then
            plus = signed == "$" and "+" .. localize('$') or signed
            minus = signed == "$" and "-" .. localize('$') or (signed .. minus)
        else
            plus = "+"
        end
    end
    local sign = (__octopus_ge(num, 0) and plus) or minus
    if type(num) == 'table' or type(num) == "cdata" then
        local big_num = math.abs(to_big(num))
        if __octopus_ge(big_num, to_big(e_switch_point or 1000000)) then
            return sign .. Notations.Balatro:format(big_num, places or 2)
        end
        num = num:to_number()
    end
    -- Copied from smods.. with some changes :)
    num = math.abs(num)
    if __octopus_ge(num, e_switch_point or 1000000) then
        local x = string.format("%.4g", num)
        local fac = math.floor(math.log(tonumber(x), 10))
        if __octopus_eq(num, math.huge) then
            return sign .. "naneinf"
        end

        local mantissa = round_number(x / (10 ^ fac), 3)
        if __octopus_ge(mantissa, 10) then
            mantissa = mantissa / 10
            fac = fac + 1
        end
        return sign ..
            (string.format(__octopus_ge(fac, 100) and "%.1fe%i" or __octopus_ge(fac, 10) and "%.2fe%i" or "%." .. (places or 2) .. "fe%i", mantissa, fac))
    end
    local formatted
    if __octopus_ne(num, math.floor(num)) and __octopus_lt(num, 100) then
        formatted = string.format(__octopus_ge(num, 10) and "%.1f" or "%.2f", num)
        if formatted:sub(-1) == "0" then
            formatted = formatted:gsub("%.?0+$", "")
        end
        -- Return already to avoid comas being added
        if __octopus_lt(num, 0.01) then return tostring(num) end
    else
        formatted = string.format("%.0f", num)
    end
    return sign .. (formatted:reverse():gsub("(%d%d%d)", "%1,"):gsub(",$", ""):reverse())
end

function JokerDisplay.should_display()
    return (G.jokers or G.jokerdisplay_config_card_area) and true or false
end

---Get all areas available for JokerDisplay \
---Hook to add more areas
---@return table
function JokerDisplay.get_display_areas()
    return { G.jokers, G.jokerdisplay_config_card_area }
end

---Checks if a value is in a table. Used as a drop in replacement to SMODS.in_scoring
---@param card any
---@param scoring_hand any
---@return boolean?
function JokerDisplay.in_scoring(card, scoring_hand)
    for _, _card in pairs(scoring_hand) do
        if __octopus_eq(card, _card) then return true end
    end
end
