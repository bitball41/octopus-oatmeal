
local function ensure_profile_directory(profile_num)
    local profile_directory = (profile_num or 1)..''
    if not love.mod_filesystem.getInfo(profile_directory) then
        love.mod_filesystem.createDirectory(profile_directory)
    end
    return profile_directory..'/'
end

function saveAction (request)
    --Saves progress for settings, unlocks, alerts and discoveries
    if request.type == 'save_progress' then
        local prefix_profile = ensure_profile_directory(request.save_progress.SETTINGS.profile)

        compress_and_save(prefix_profile..'meta.jkr', request.save_progress.META)
        compress_and_save('settings.jkr', request.save_progress.SETTINGS)
        compress_and_save(prefix_profile..'profile.jkr', request.save_progress.PROFILE)
    --Saves the empty profile
    elseif request.type == 'empty_profile' then 
        local prefix_profile = ensure_profile_directory(request.profile_num)
        compress_and_save('settings.jkr', request.save_settings)
        compress_and_save(prefix_profile..'profile.jkr', request.save_profile)
    --Saves the settings file
    elseif request.type == 'save_settings' then 
        local prefix_profile = ensure_profile_directory(request.profile_num)
        compress_and_save('settings.jkr', request.save_settings)
        compress_and_save(prefix_profile..'profile.jkr', request.save_profile)
    --Saves any notifications
    elseif request.type == 'save_notify' then 
        local prefix_profile = (request.profile_num or 1)..''
        if not love.mod_filesystem.getInfo(prefix_profile) then love.mod_filesystem.createDirectory( prefix_profile ) end
        prefix_profile = prefix_profile..'/'

        --if not love.mod_filesystem.getInfo(prefix_profile..'unlock_notify.jkr') then love.mod_filesystem.append( prefix_profile..'unlock_notify.jkr', '') end
        local unlock_notify = get_compressed(prefix_profile..'unlock_notify.jkr') or ''

        if request.save_notify and not string.find(unlock_notify, request.save_notify) then 
            compress_and_save( prefix_profile..'unlock_notify.jkr', unlock_notify..request.save_notify..'\n')
        end

    --Saves the run
    elseif request.type == 'save_run' then 
        local prefix_profile = (request.profile_num or 1)..''
        if not love.mod_filesystem.getInfo(prefix_profile) then love.mod_filesystem.createDirectory( prefix_profile ) end
        prefix_profile = prefix_profile..'/'

        compress_and_save(prefix_profile..'save.jkr', request.save_table)
    end

end
