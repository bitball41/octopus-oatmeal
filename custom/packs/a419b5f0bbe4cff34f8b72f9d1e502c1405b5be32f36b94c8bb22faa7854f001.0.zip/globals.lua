VERSION = '1.0.1o'
VERSION = VERSION..'-FULL'
VERSION = VERSION..' [M]'
--check_version

--Globals

function printTable(tbl, indent)
    indent = indent or 0
    local indentStr = string.rep("  ", indent)

    for key, value in pairs(tbl) do
        if type(value) == "table" then
            print(indentStr .. key .. ":")
            printTable(value, indent + 1)  -- 递归打印嵌套表
        else
            print(indentStr .. key .. " = " .. tostring(value))
        end
    end
end
function Game:set_globals()
    self.VERSION = VERSION

    --||||||||||||||||||||||||||||||
    --         Feature Flags
    --||||||||||||||||||||||||||||||
    self.F_QUIT_BUTTON = true               --Include the main menu 'Quit' button
    self.F_SKIP_TUTORIAL = false            --Completely skip the tutorial on fresh save
    self.F_BASIC_CREDITS = false            --Remove references to Daniel Linssens itch.io
    self.F_EXTERNAL_LINKS = true            --Remove all references to any external links (mainly for console)
    self.F_ENABLE_PERF_OVERLAY = false      --Disable debugging tool for performance of each frame
    self.F_NO_SAVING = false                --Disables all 'run' saving
    self.F_MUTE = false                     --Force mute all sounds
    self.F_SOUND_THREAD = true              --Have sound in a separate thread entirely - if not sounds will run on main thread
    self.F_VIDEO_SETTINGS = true            --Let the player change their video settings
    self.F_CTA = false                      --Call to Action video for the Demo - keep this as false
    self.F_VERBOSE = true                   --Extra debug information on screen and in the console
    self.F_HTTP_SCORES = false              --Include HTTP scores to fetch/set high scores
    self.F_RUMBLE = nil                     --Add rumble to the primary controller - adjust this for amount of rumble
    self.F_CRASH_REPORTS = false            --Send Crash reports over the internet
    self.F_NO_ERROR_HAND = false            --Hard crash without error message screen
    self.F_SWAP_AB_PIPS = false             --Swapping button pips for A and B buttons (mainly for switch)
    self.F_SWAP_AB_BUTTONS = false          --Swapping button function for A and B buttons (mainly for switch)
    self.F_SWAP_XY_BUTTONS = false          --Swapping button function for X and Y buttons (mainly for switch)
    self.F_NO_ACHIEVEMENTS = false          --Disable achievements
    self.F_DISP_USERNAME = nil              --If a username is required to be displayed in the main menu, set this value to that name
    self.F_ENGLISH_ONLY = nil               --Disable language selection - only in english
    self.F_GUIDE = false                    --Replace back/select button with 'guide' button
    self.F_JAN_CTA = false                  --Call to action for Jan demo
    self.F_HIDE_BG = false                  --Hiding the game objects when paused
    self.F_TROPHIES = false                 --use 'trophy' terminology instead of 'achievemnt'
    self.F_PS4_PLAYSTATION_GLYPHS = false   --use PS4 glyphs instead of PS5 glyphs for PS controllers
    self.F_LOCAL_CLIPBOARD = false
    self.F_SAVE_TIMER = 30
    self.F_MOBILE_UI = false
    self.F_HIDE_BETA_LANGS = nil
    self.F_TOUCH_MOUSE = nil
    self.F_HIDE_LOADING_BAR = nil
    self.F_BABYNAMES = nil                  --use if platform needs name change for collabs

    if love.system.getOS() == 'Windows' then
        self.F_DISCORD = true
        self.F_SAVE_TIMER = 5
        self.F_ENGLISH_ONLY = false
        self.F_CRASH_REPORTS = false

        self.F_MOBILE = true

        self.F_LINKTREE = true

        self.F_RUMBLE = 1
    end

    if love.system.getOS() == 'Android' or love.system.getOS() == 'iOS' then
    	self.F_SAVE_TIMER = 5
    	self.F_DISCORD = true
    	self.F_NO_ACHIEVEMENTS = true
    	self.F_CRASH_REPORTS = false
    	self.F_SOUND_THREAD = true
    	self.F_VIDEO_SETTINGS = false
    	self.F_ENGLISH_ONLY = false
    	self.F_QUIT_BUTTON = false
        self.F_MOBILE_UI = true
    end
    if love.system.getOS() == 'OS X' then
        self.F_SAVE_TIMER = 5
        self.F_DISCORD = true
        self.F_ENGLISH_ONLY = false
        self.F_CRASH_REPORTS = false
        self.F_LINKTREE = true
    end

    print("os.."..love.system.getOS())
    -- local mode = love.window.getMode()
    -- -- 提取窗口的宽度和高度
    -- local width = mode.width
    -- local height = mode.height
    local width, height = love.graphics.getPixelDimensions()  -- 或者使用 love.window.getMode()
    print("width.."..width..".."..height)
    -- 判断设备类型
    if __octopus_lt(width, 1024) then
        print("Mobile device detected!")
    else
        print("PC device detected!")
    end
    if love.system.getOS() == "Web" then
        self.F_SAVE_TIMER = 10
        self.F_DISCORD = nil;
        self.F_ENGLISH_ONLY = true
        self.F_SOUND_THREAD = false
        self.F_RUMBLE = nil
        self.F_CRASH_REPORTS = false
        self.F_QUIT_BUTTON = false
        self.F_HIDE_LOADING_BAR = true
        self.F_VIDEO_SETTINGS = false
        if __octopus_lt(width, 1024) then
            self.F_MOBILE = true
        else
            self.F_MOBILE = false
        end
    end


    if love.system.getOS() == 'iOS' or love.system.getOS() == 'Android' then
        self.F_SAVE_TIMER = 10
        self.F_DISCORD = nil
        self.F_ENGLISH_ONLY = false

        if love.system.getPlatform and love.system.getPlatform() == "tvos" then
            self.F_RUMBLE = nil
        else
            self.F_RUMBLE = (love.system.getOS() ~= 'Android' and 1 or nil)
        end
        
        self.F_BABYNAMES = (love.system.getOS() == 'Android' and true or nil)
        self.F_CRASH_REPORTS = false
        self.F_SOUND_THREAD = false
        self.F_QUIT_BUTTON = false
        self.F_MOBILE = true
        self.F_LINKTREE = true
        self.F_HIDE_LOADING_BAR = true
        self.F_VIDEO_SETTINGS = false
    end

    if love.system.getPlatform and love.system.getPlatform() == 'tvos' then 
        self.F_CONTROLLER_REQUIRED = true
        self.F_LOCAL_CLIPBOARD = true
        self.F_LINKTREE = false
    end

    if love.system.getOS() == 'Nintendo Switch' then
        self.F_HIDE_BETA_LANGS = true
        self.F_BASIC_CREDITS = true
        self.F_NO_ERROR_HAND = true
        self.F_QUIT_BUTTON = false
        self.F_SKIP_TUTORIAL = false
        self.F_ENABLE_PERF_OVERLAY = false
        self.F_NO_SAVING = false
        self.F_MUTE = false
        self.F_SOUND_THREAD = true
        self.F_SWAP_AB_PIPS = true
        self.F_SWAP_AB_BUTTONS = false
        self.F_SWAP_XY_BUTTONS = true
        self.F_VIDEO_SETTINGS = false
        self.F_RUMBLE = 0.7
        self.F_CTA = false
        self.F_VERBOSE = false
        self.F_NO_ACHIEVEMENTS = true
        self.F_ENGLISH_ONLY = nil
        
        self.F_EXTERNAL_LINKS = false
        self.F_HIDE_BG = true
    end

    if love.system.getOS() == 'ps4' or love.system.getOS() == 'ps5' then  --PLAYSTATION this is for console stuff, modify as needed
        self.F_HIDE_BETA_LANGS = true
        self.F_NO_ERROR_HAND = true
        self.F_QUIT_BUTTON = false
        self.F_SKIP_TUTORIAL = false
        self.F_ENABLE_PERF_OVERLAY = false
        self.F_NO_SAVING = false
        self.F_MUTE = false
        self.F_SOUND_THREAD = true
        self.F_VIDEO_SETTINGS = false
        self.F_RUMBLE = 0.5
        self.F_CTA = false
        self.F_VERBOSE = false
        
        self.F_GUIDE = true
        self.F_PS4_PLAYSTATION_GLYPHS = false

        self.F_EXTERNAL_LINKS = false
        self.F_HIDE_BG = true
        --self.F_LOCAL_CLIPBOARD = true
    end

    if love.system.getOS() == 'xbox' then
        self.F_HIDE_BETA_LANGS = true
        self.F_NO_ERROR_HAND = true
        self.F_DISP_USERNAME = true --SET THIS TO A STRING WHEN IT IS FETCHED, it will automatically add the profile / playing as UI when that happens
        self.F_SKIP_TUTORIAL = false
        self.F_ENABLE_PERF_OVERLAY = false
        self.F_NO_SAVING = false
        self.F_MUTE = false
        self.F_SOUND_THREAD = true
        self.F_VIDEO_SETTINGS = false
        self.F_RUMBLE = 1.0
        self.F_CTA = false
        self.F_VERBOSE = false
        self.F_EXTERNAL_LINKS = false
        self.F_HIDE_BG = true
    end

    --||||||||||||||||||||||||||||||
    --             Time
    --||||||||||||||||||||||||||||||
    --self.FTP_LOCKED = true
    self.SEED = os.time()
    self.TIMERS = {
        TOTAL=0,
        REAL = 0,
        REAL_SHADER = 0,
        UPTIME = 0,
        BACKGROUND = 0
    }
    self.FRAMES = {
        DRAW = 0,
        MOVE = 0
    }
    self.exp_times = {xy = 0, scale = 0, r = 0}
    --||||||||||||||||||||||||||||||
    --           SETTINGS
    --||||||||||||||||||||||||||||||
    self.SETTINGS = {
        COMP = {
            name = '',
            prev_name = '',
            submission_name = nil,
            score = 0,
        },
        DEMO = {
            total_uptime = 0,
            timed_CTA_shown = false,
            win_CTA_shown = false,
            quit_CTA_shown = false
        },
        ACHIEVEMENTS_EARNED = {},
        crashreports = false,
        colourblind_option = false,
        language = 'en-us',
        screenshake = true,
        run_stake_stickers = false,
        rumble = self.F_RUMBLE,
        play_button_pos = 2,
        GAMESPEED = 1,
        paused = false,
        profile_counters = {0,0,0},
        SOUND = {
            volume = 50,
            music_volume = 100,
            game_sounds_volume = 100,
        },
        WINDOW = {
            screenmode = "Windowed", -- 'Borderless',
            vsync = 1,
            selected_display = 1,
            display_names = {'[NONE]'},
            DISPLAYS = {
                {
                    name = '[NONE]',
                    screen_res = {w = 1000, h = 650},
                }
            },
        },
        CUSTOM_DECK = {
            Collabs = {
                Spades = 'default',
                Hearts = 'default',
                Clubs = 'default',
                Diamonds = 'default',
            }
        },
        GRAPHICS = {
            texture_scaling = 2,
            shadows = 'On',
            -- crt = self.F_MOBILE and 30 or 70,
            crt = 0, -- 最前端条纹效果去掉
            bloom = 1
        },
    }
    printTable(love.window)
    if __octopus_lt(width, 1024) then
        self.SETTINGS.WINDOW.screenmode = "Borderless"
        -- love.window.setMode(width, height, {minwidth = width, minheight = height, highdpi = true})
    else
        width = 1100
        height = 620
        love.window.setMode(width, height, {minwidth = width, minheight = height})
    end

    self.COLLABS = {
        pos = { Jack = {x=0,y=0}, Queen = {x=1,y=0}, King = {x=2,y=0} },
        options = {
            Spades = {
                'default',
                'collab_TW',
                'collab_CYP',
                'collab_SK',
                'collab_DS',
                'collab_AC',
                'collab_STP',
           },
            Hearts = {
              'default',
              'collab_AU',
              'collab_TBoI',
              'collab_CL',
              'collab_D2',
              'collab_CR',
              'collab_BUG',
            },
            Clubs = {
              'default',
              'collab_VS',
              'collab_STS',
              'collab_PC',
              'collab_WF',
              'collab_FO',
              'collab_DBD'
            },
            Diamonds = {
              'default',
              'collab_DTD',
              'collab_SV',
              'collab_EG',
              'collab_XR',
              'collab_C7',
              'collab_R'
            }
          },
      }

    self.METRICS = {
        cards = {
            used = {},
            bought = {},
            appeared = {},
        },
        decks = {
            chosen = {},
            win = {},
            lose = {}
        },
        bosses = {
            faced = {},
            win = {},
            lose = {},
        }
    }

    --||||||||||||||||||||||||||||||
    --           PROFILES
    --||||||||||||||||||||||||||||||
    self.PROFILES = {
        {},
        {},
        {},
    }

    --||||||||||||||||||||||||||||||
    --        RENDER SCALE
    --||||||||||||||||||||||||||||||
    self.TILESIZE = 20
    self.TILESCALE = 3.65
    self.TILE_W = 21
    self.TILE_H = 11.2
    self.DRAW_HASH_BUFF = 2
    self.CARD_W = 2.4*35/41
    self.CARD_H = 2.4*47/41
    self.HIGHLIGHT_H = 0.2*self.CARD_H
    self.COLLISION_BUFFER = 0.05

    self.PITCH_MOD = 1

    --||||||||||||||||||||||||||||||
    --        GAMESTATES
    --||||||||||||||||||||||||||||||
    self.STATES = {    
        SMODS_BOOSTER_OPENED = 999,
        SMODS_REDEEM_VOUCHER = 998,
        SELECTING_HAND = 1,
        HAND_PLAYED = 2,
        DRAW_TO_HAND = 3,
        GAME_OVER = 4,
        SHOP = 5,
        PLAY_TAROT = 6,
        BLIND_SELECT = 7,
        ROUND_EVAL = 8,
        TAROT_PACK = 9,
        PLANET_PACK = 10,
        MENU = 11,
        TUTORIAL = 12,
        SPLASH = 13,--DO NOT CHANGE, this has a dependency in the SOUND_MANAGER
        SANDBOX = 14,
        SPECTRAL_PACK = 15,
        DEMO_CTA = 16,
        STANDARD_PACK = 17,
        BUFFOON_PACK = 18,
        NEW_ROUND = 19,
        ASYNC_WAIT = 20,
        ASYNC_OFFLINE = 21,
    }

    self.STAGES = {
        MAIN_MENU = 1,
        RUN = 2,
        SANDBOX = 3,
        ASYNC_LIMBO = 4
    }
    self.STAGE_OBJECTS = {
        {},{},{},{}
    }
    self.STAGE = self.STAGES.MAIN_MENU
    self.STATE = self.STATES.SPLASH
    self.TAROT_INTERRUPT = nil
    self.STATE_COMPLETE = false

    --||||||||||||||||||||||||||||||
    --          INSTANCES
    --||||||||||||||||||||||||||||||
    self.ARGS = {}
    self.FUNCS = {}
    self.I = {
        NODE = {},
        MOVEABLE = {},
        SPRITE = {},
        UIBOX = {},
        DROPDOWN = {},
        POPUP = {},
        CARD = {},
        CARDAREA = {},
        ALERT = {}
    }
    self.ANIMATION_ATLAS = {}
    self.ASSET_ATLAS = {}
    self.MOVEABLES = {}
    self.ANIMATIONS = {}
    self.DRAW_HASH = {}

    --||||||||||||||||||||||||||||||
    --        CONSTANTS
    --||||||||||||||||||||||||||||||
    self.MIN_CLICK_DIST = 0.9
    self.MIN_HOVER_TIME = 0.1
    self.DEBUG = false
    self.ANIMATION_FPS = 10
    self.VIBRATION = 0
    self.MOBILE_VIBRATION_QUEUE = 0
    self.CHALLENGE_WINS = 5

    --||||||||||||||||||||||||||||||
    --        COLOURS
    --||||||||||||||||||||||||||||||
    self.C = {
        MULT = HEX('FE5F55'),
        CHIPS = HEX("009dff"),
        MONEY = HEX('f3b958'),
        XMULT = HEX('FE5F55'),
        FILTER = HEX('ff9a00'),
        BLUE = HEX("009dff"),
        RED = HEX('FE5F55'),
        GREEN = HEX("4BC292"),
        PALE_GREEN = HEX("56a887"),
        ORANGE = HEX("fda200"),
        IMPORTANT = HEX("ff9a00"),
        GOLD = HEX('eac058'),
        YELLOW = {1,1,0,1},
        CLEAR = {0, 0, 0, 0}, 
        WHITE = {1,1,1,1},
        PURPLE = HEX('8867a5'),
        BLACK = HEX("374244"),--4f6367"),
        L_BLACK = HEX("4f6367"),
        GREY = HEX("5f7377"),
        CHANCE = HEX("4BC292"),
        JOKER_GREY = HEX('bfc7d5'),
        VOUCHER = HEX("cb724c"),
        BOOSTER = HEX("646eb7"),
        EDITION = {1,1,1,1},
        DARK_EDITION = {0,0,0,1},
        ETERNAL = HEX('c75985'),
        PERISHABLE = HEX('4f5da1'),
        RENTAL = HEX('b18f43'),
        BUNCO_VIRTUAL = HEX('69fa93'),
        BUNCO_VIRTUAL_DARK = HEX('4fb66f'),
        BUNCO_EXOTIC = HEX('ef9ae7'),
        BLIND_SIZE = HEX('ad5353'),
        DYN_UI = {
            MAIN = HEX('374244'),
            DARK = HEX('374244'),
            BOSS_MAIN = HEX('374244'),
            BOSS_DARK = HEX('374244'),
            BOSS_PALE = HEX('374244')
        },
        --For other high contrast suit colours
        SO_1 = {
            Hearts = HEX('f03464'),
            Diamonds = HEX('f06b3f'),
            Spades = HEX("403995"),
            Clubs = HEX("235955"),
        },
        SO_2 = {
            Hearts = HEX('f83b2f'),
            Diamonds = HEX('e29000'),
            Spades = HEX("4f31b9"),
            Clubs = HEX("008ee6"),
        },
        SUITS = {
            Hearts = HEX('FE5F55'),
            Diamonds = HEX('FE5F55'),
            Spades = HEX("374649"),
            Clubs = HEX("424e54"),
        },
        UI = {
            TEXT_LIGHT = {1,1,1,1},
            TEXT_DARK = HEX("4F6367"),
            TEXT_INACTIVE = HEX("88888899"),
            BACKGROUND_LIGHT = HEX("B8D8D8"),
            BACKGROUND_WHITE = {1,1,1,1},
            BACKGROUND_DARK = HEX("7A9E9F"),
            BACKGROUND_INACTIVE = HEX("666666FF"),
            OUTLINE_LIGHT = HEX("D8D8D8"),
            OUTLINE_LIGHT_TRANS = HEX("D8D8D866"),
            OUTLINE_DARK = HEX("7A9E9F"),
            TRANSPARENT_LIGHT = HEX("eeeeee22"),
            TRANSPARENT_DARK = HEX("22222222"),
            HOVER = HEX('00000055'),
        },
        SET = {
            Default = HEX("cdd9dc"),
            Enhanced = HEX("cdd9dc"),
            Joker = HEX('424e54'),
            Tarot = HEX('424e54'),--HEX('29adff'),
            Planet = HEX("424e54"),
            Spectral = HEX('424e54'),
            Voucher = HEX("424e54"),
        }, 
        SECONDARY_SET = {
            Default = HEX("9bb6bdFF"),
            Enhanced = HEX("8389DDFF"),
            Joker = HEX('708b91'),
            Tarot = HEX('a782d1'),--HEX('29adff'),
            Planet = HEX('13afce'),
            Spectral = HEX('4584fa'),
            Voucher = HEX("fd682b"),
            Edition = HEX("4ca893"),
        }, 
        RARITY = {
            HEX('009dff'),--HEX("708b91"),
            HEX("4BC292"),
            HEX('fe5f55'),
            HEX("b26cbb")
        },
        BLIND = {
            Small = HEX("50846e"),
            Big = HEX("50846e"),
            Boss = HEX("b44430"),
            won = HEX("4f6367")
        },
        HAND_LEVELS = {
            HEX("efefef"),
            HEX("95acff"),
            HEX("65efaf"),
            HEX('fae37e'), 
            HEX('ffc052'), 
            HEX('f87d75'),
            HEX('caa0ef')
        },
        BACKGROUND = {
            L = {1,1,0,1},
            D = HEX("374244"),
            C = HEX("374244"),
            contrast = 1
        }
    }
    G.C.HAND_LEVELS[0] = G.C.JOKER_GREY
    G.C.UI_CHIPS = copy_table(G.C.BLUE)
    G.C.UI_MULT = copy_table(G.C.RED)
    --||||||||||||||||||||||||||||||
    --        ENUMS
    --||||||||||||||||||||||||||||||
    self.UIT = {
        T=1, --text
        B=2, --box (can be rounded)
        C=3, --column
        R=4, --row
        O=5, --object - must be a Node
        ROOT=7,
        S=8, --slider
        I=9, --input text box
        padding = 0, --default padding
    }
    self.handlist = {
        "Flush Five",
        "Flush House",
        "Five of a Kind",
        "Straight Flush",
        "Four of a Kind",
        "Full House",
        "Flush",
        "Straight",
        "Three of a Kind",
        "Two Pair",
        "Pair",
        "High Card",
    }
    self.button_mapping = {
        a = G.F_SWAP_AB_BUTTONS and 'b' or nil,
        b = G.F_SWAP_AB_BUTTONS and 'a' or nil,
        y = G.F_SWAP_XY_BUTTONS and 'x' or nil,
        x = G.F_SWAP_XY_BUTTONS and 'y' or nil,
    }
    self.keybind_mapping = {{
        a = 'dpleft',
        d = 'dpright',
        w = 'dpup',
        s = 'dpdown',
        x = 'x',
        c = 'y',
        space = 'a',
        shift = 'b',
        esc = 'start',
        q = 'triggerleft',
        e = 'triggerright',
    }}
end

G = Game()
