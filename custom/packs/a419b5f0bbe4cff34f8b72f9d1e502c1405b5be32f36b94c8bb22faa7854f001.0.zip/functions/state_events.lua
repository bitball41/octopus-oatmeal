function win_game()
    if (not G.GAME.seeded and not G.GAME.challenge) or SMODS.config.seeded_unlocks then
        set_joker_win()
        set_deck_win()
        
        check_and_set_high_score('win_streak', G.PROFILES[G.SETTINGS.profile].high_scores.current_streak.amt+1)
        check_and_set_high_score('current_streak', G.PROFILES[G.SETTINGS.profile].high_scores.current_streak.amt+1)
        check_for_unlock({type = 'win_no_hand'})
        check_for_unlock({type = 'win_no'})
        check_for_unlock({type = 'win_custom'})
        check_for_unlock({type = 'win_deck'})
        check_for_unlock({type = 'win_stake'})
        check_for_unlock({type = 'win'})
        inc_career_stat('c_wins', 1)
    end

    set_profile_progress()

    if G.GAME.challenge then
        G.PROFILES[G.SETTINGS.profile].challenge_progress.completed[G.GAME.challenge] = true
        set_challenge_unlock()
        check_for_unlock({type = 'win_challenge'})
        G:save_settings()
    end

    G.E_MANAGER:add_event(Event({
        trigger = 'immediate',
        func = (function()
            for k, v in pairs(G.I.CARD) do
                v.sticker_run = nil
            end
            
            play_sound('win')
            G.SETTINGS.paused = true

            G.FUNCS.overlay_menu{
                definition = create_UIBox_win(),
                config = {no_esc = true}
            }
            local Jimbo = nil

            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 2.5,
                blocking = false,
                func = (function()
                    if G.OVERLAY_MENU and G.OVERLAY_MENU:get_UIE_by_ID('jimbo_spot') then 
                        local quip, extra = SMODS.quip("win")
                        extra.x = 0
                        extra.y = 5
                        Jimbo = Card_Character(extra)
                        local spot = G.OVERLAY_MENU:get_UIE_by_ID('jimbo_spot')
                        spot.config.object:remove()
                        spot.config.object = Jimbo
                        Jimbo.ui_object_updated = true
                        Jimbo:add_speech_bubble(quip, nil, {quip = true}, extra)
                        Jimbo:say_stuff((extra and extra.times) or 5, false, quip)
                        if G.F_JAN_CTA then 
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    Jimbo:add_button(localize('b_wishlist'), 'wishlist_steam', G.C.DARK_EDITION, nil, true, 1.6)
                                    return true
                                end}))
                        end
                        end
                    return true
                end)
            }))
            
            return true
        end)
    }))

    if (not G.GAME.seeded and not G.GAME.challenge) or SMODS.config.seeded_unlocks then
        G.PROFILES[G.SETTINGS.profile].stake = math.max(G.PROFILES[G.SETTINGS.profile].stake or 1, (G.GAME.stake or 1)+1)
    end
    G:save_progress()
    G.FILE_HANDLER.force = true
    G.E_MANAGER:add_event(Event({
        trigger = 'immediate',
        func = (function()
            if not G.SETTINGS.paused then
                G.GAME.current_round.round_text = 'Endless Round '
                return true
            end
        end)
    }))
end

function end_round()
if G.GAME.Shield == true then
    if type(G.GAME.chips) ~= 'table' then
        if __octopus_ge(G.GAME.chips - G.GAME.blind.chips, 0) then
            G.GAME.overscore = (G.GAME.overscore or 0) + G.GAME.chips - G.GAME.blind.chips
        end
    else
        if __octopus_ge(G.GAME.chips - G.GAME.blind.chips, to_big(0)) then
            G.GAME.overscore = (G.GAME.overscore or 0) + G.GAME.chips - G.GAME.blind.chips
        end
    end
end

if not G.GAME.blind.disabled then
    local locked_card

    for i = 1, #G.P_LOCKED do
        locked_card = G.P_LOCKED[i]

        if not locked_card.unlocked and locked_card.check_for_unlock and type(locked_card.check_for_unlock) == 'function' then
            locked_card:check_for_unlock({type = 'defeat_blind', blind = G.GAME.blind})
        end
    end
end

    G.E_MANAGER:add_event(Event({
      trigger = 'after',
      delay = 0.2,
      func = function()
        G.GAME.blind.in_blind = false
        local game_over = true
        local game_won = false
        G.RESET_BLIND_STATES = true
        G.RESET_JIGGLES = true
        if G.GAME.current_round.semicolon then
            game_over = false
        end
            if __octopus_ge(G.GAME.chips - G.GAME.blind.chips, 0) then
                game_over = false
            end
            -- context.end_of_round calculations
            SMODS.saved = false
            G.GAME.saved_text = nil
            SMODS.last_hand = SMODS.last_hand or {scoring_hand = {}, full_hand = {}}
            SMODS.calculate_context({end_of_round = true, game_over = game_over, beat_boss = G.GAME.blind.boss, scoring_hand = SMODS.last_hand.scoring_hand, scoring_name = SMODS.last_hand.scoring_name, full_hand = SMODS.last_hand.full_hand })
            if SMODS.saved then game_over = false end
            -- TARGET: main end_of_round evaluation

            if not G.FTP_LOCKED then 
                local i = 1
                while __octopus_le(i, #G.jokers.cards) do
                    local gone = G.jokers.cards[i]:calculate_banana()
                    if not gone then i = i + 1 end
                end
                if not G.GAME.won and __octopus_ge(G.GAME.round_resets.ante, G.GAME.win_ante) and G.GAME.blind_on_deck == 'Boss' then
                    game_won = true
                    G.GAME.won = true
                end
            else
                if __octopus_ge(G.GAME.round_resets.ante, 6) and G.GAME.blind:get_type() == 'Boss' then
                    game_won = true
                    G.GAME.won = true
                end
            end

    if game_over then
                G.STATE = G.STATES.GAME_OVER

                analytic_event('game_over',
                    'demo_flag', not G.FTP_LOCKED,
                    'deck', G.GAME.selected_back.name or 'error',
                    'stake', G.GAME.stake or 'error',
                    'language', G.SETTINGS.language or 'error',
                    'ante',  G.GAME.round_resets.ante or -1,
                    'run_won', not not G.GAME.won)

                if not G.GAME.won and not G.GAME.seeded and not G.GAME.challenge then 
                    G.PROFILES[G.SETTINGS.profile].high_scores.current_streak.amt = 0
                end
                G:save_settings()
                G.FILE_HANDLER.force = true
                G.STATE_COMPLETE = false
            else
                G.GAME.unused_discards = (G.GAME.unused_discards or 0) + G.GAME.current_round.discards_left
                if G.GAME.blind and G.GAME.blind.config.blind then 
                    discover_card(G.GAME.blind.config.blind)
                end

                if G.GAME.blind_on_deck == 'Boss' then
                    local _handname, _played, _order = 'High Card', -1, 100
                    for k, v in pairs(G.GAME.hands) do
                        if __octopus_gt(v.played, _played) or (__octopus_eq(v.played, _played) and __octopus_gt(_order, v.order)) then 
                            _played = v.played
                            _handname = k
                        end
                    end
                    
                    if G.GAME.played_ranks ~= nil then
                        local max_rank = nil
                        local max_count = -1
                    
                        for _, rank in ipairs(SMODS.Rank.obj_buffer) do
                            count = G.GAME.played_ranks[rank] or 0
                            -- tiebreak with highest rank
                            if __octopus_ge(count, max_count) then
                                max_count = count
                                max_rank = rank
                            end
                        end
                    
                        G.GAME.current_round.most_played_rank = max_rank
                    end
                    
                    
                    
                    local lowestValue = math.huge
                    local leastPlayedHand = ''
                    
                    for i = #G.handlist, 1, -1 do
                        local v = G.handlist[i]
                        local playedCount = G.GAME.hands and G.GAME.hands[v] and G.GAME.hands[v].played or 0
                        if (__octopus_lt(playedCount, lowestValue)) and G.GAME.hands[v].visible then
                            lowestValue = G.GAME.hands[v].visible and playedCount or lowestValue
                            leastPlayedHand = G.GAME.hands[v].visible and v or leastPlayedHand
                        end
                    end
                    
                    G.GAME.current_round.least_played_poker_hand = leastPlayedHand
                    
                    G.GAME.current_round.most_played_poker_hand = _handname
                end

                if G.GAME.blind:get_type() == 'Boss' and not G.GAME.seeded and not G.GAME.challenge  then
                    G.GAME.current_boss_streak = G.GAME.current_boss_streak + 1
                    check_and_set_high_score('boss_streak', G.GAME.current_boss_streak)
                end
                
                if __octopus_eq(G.GAME.current_round.hands_played, 1) then 
                    inc_career_stat('c_single_hand_round_streak', 1)
                else
                    if not G.GAME.seeded and not G.GAME.challenge  then
                        G.PROFILES[G.SETTINGS.profile].career_stats.c_single_hand_round_streak = 0
                        G:save_settings()
                    end
                end

                check_for_unlock({type = 'round_win'})
                set_joker_usage()
                if game_won and not G.GAME.win_notified then
                    G.GAME.win_notified = true
                    G.E_MANAGER:add_event(Event({
                        trigger = 'immediate',
                        blocking = false,
                        blockable = false,
                        func = (function()
                            if __octopus_eq(G.STATE, G.STATES.ROUND_EVAL) then 
                                win_game()
                                if G.FTP_LOCKED then 
                                    remove_save()
                                end
                                G.GAME.won = true
                                return true
                            end
                        end)
                    }))
                end
                for _,v in ipairs(SMODS.get_card_areas('playing_cards', 'end_of_round')) do
                    SMODS.calculate_end_of_round_effects({ cardarea = v, end_of_round = true, beat_boss = G.GAME.blind.boss })
                end



                local i = 1
                while __octopus_le(i, #G.hand.cards) do
                    local gone = G.hand.cards[i]:calculate_banana()
                    if not gone then i = i + 1 end
                end
                for i = 1, #G.discard.cards do
                    G.discard.cards[i]:calculate_perishable()
                end
                i = 1
                while __octopus_le(i, #G.deck.cards) do
                    G.deck.cards[i]:calculate_perishable()
                    local gone = G.deck.cards[i]:calculate_banana()
                    if not gone then i = i + 1 end
                end
                --[[
                if G.GAME.used_vouchers.v_cry_double_down then
                    local function update_dbl(area)
                        for i = 1, #area.cards do
                            if area.cards[i].ability.immutable and type(area.cards[i].ability.immutable.other_side) == "table" then
                                --tweak to do deck effects with on the flip side
                                if not G.P_CENTERS[area.cards[i].ability.immutable.other_side.key].immutable then
                                    if area.cards[i].ability.immutable.other_side and area.cards[i].edition.cry_double_sided then
                                        Cryptid.manipulate_table(
                                        area.cards[i],
                                        area.cards[i].ability.immutable,
                                        "other_side", 
                                        {
                                            value = 1.5, 
                                            type = "X",
                                            big = Cryptid.is_card_big({config = {center = G.P_CENTERS[area.cards[i].ability.immutable.other_side.key]}})
                                        }
                                        )
                                        card_eval_status_text(area.cards[i], "extra", nil, nil, nil, { message = localize("k_upgrade_ex") })
                                    end
                                end
                            end
                        end
                    end
                    update_dbl(G.jokers)
                    update_dbl(G.consumeables)
                    update_dbl(G.hand)
                    update_dbl(G.discard)
                    update_dbl(G.deck)
                end]]
                G.FUNCS.draw_from_hand_to_discard()
                if G.GAME.blind_on_deck == 'Boss' then
                    G.GAME.voucher_restock = nil
                    for k, v in pairs(G.GAME.hands) do
                        v.played_this_ante = 0
                    end
                    if G.GAME.modifiers.set_eternal_ante and (__octopus_eq(G.GAME.round_resets.ante, G.GAME.modifiers.set_eternal_ante)) then 
                        for k, v in ipairs(G.jokers.cards) do
                            v:set_eternal(true)
                        end
                    end
                    if G.GAME.modifiers.set_joker_slots_ante and (__octopus_eq(G.GAME.round_resets.ante, G.GAME.modifiers.set_joker_slots_ante)) then 
                        G.jokers.config.card_limit = 0
                    end
                    delay(0.4); SMODS.ante_end = true; ease_ante(1); SMODS.ante_end = nil; delay(0.4); check_for_unlock({type = 'ante_up', ante = G.GAME.round_resets.ante + 1})
                end
                G.FUNCS.draw_from_discard_to_deck()
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.3,
                    func = function()
                        if G.GAME.blind.config.blind.cry_before_cash and not G.GAME.blind.disabled then
                        	G.GAME.blind:cry_before_cash()
                        else
                        G.GAME.cry_make_a_decision = nil
                        
                        G.STATE = G.STATES.ROUND_EVAL
                        G.STATE_COMPLETE = false
                        end

                        if G.GAME.round_resets.blind and G.GAME.round_resets.blind.name == 'Small Blind' then
                            G.GAME.round_resets.blind_states.Small = 'Defeated'
                        elseif G.GAME.round_resets.blind and G.GAME.round_resets.blind.name == 'Big Blind' then
                            G.GAME.round_resets.blind_states.Big = 'Defeated'
                        else
                            if not (G.GAME.current_round.cry_voucher_stickers and G.GAME.current_round.cry_voucher_stickers.pinned) then
                            	G.GAME.current_round.voucher = SMODS.get_next_vouchers()
                            	G.GAME.current_round.cry_voucher_stickers = Cryptid.next_voucher_stickers()
                            	G.GAME.current_round.cry_voucher_edition = cry_get_next_voucher_edition()
                            	G.GAME.current_round.cry_bonusvouchers = {}
                            	G.GAME.cry_bonusvouchersused = {}	-- i'm not sure why i'm putting these in two separate tables but it doesn't matter much
                            	for i = 1, G.GAME.cry_bonusvouchercount do
                            		G.GAME.current_round.cry_bonusvouchers[i] = SMODS.get_next_vouchers()
                            	end
                            end
                            G.GAME.round_resets.blind_states.Boss = 'Defeated'
                            for k, v in ipairs(G.playing_cards) do
                                v.ability.played_this_ante = nil
                            end
                        end

                        if G.GAME.round_resets.temp_handsize then G.hand:change_size(-G.GAME.round_resets.temp_handsize); G.GAME.round_resets.temp_handsize = nil end
                        if G.GAME.round_resets.temp_reroll_cost then G.GAME.round_resets.temp_reroll_cost = nil; calculate_reroll_cost(true) end
                        for _, v in pairs(SMODS.find_card("j_cry_loopy")) do
                        	if __octopus_ne(v.ability.extra.retrigger, 0) then
                        		SMODS.reset_card(v, {
                                    ref_table = v.ability.extra,
                                    ref_value = "retrigger",
                                    reset_value = 0,
                                    message_colour = G.C.GREEN, --why is this green exactly
                                })
                        	end
                        end
                        for _, v in pairs(G.deck.cards) do
                        	v.sus = nil
                        end
                        if G.GAME.sus_cards then
                        	SMODS.calculate_context({ remove_playing_cards = true, removed = G.GAME.sus_cards })
                        	G.GAME.sus_cards = nil
                        end

                        reset_idol_card()
                        reset_mail_rank()
                        reset_ancient_card()
                        reset_castle_card()                        
                        for _, mod in ipairs(SMODS.mod_list) do
                        	if mod.reset_game_globals and type(mod.reset_game_globals) == 'function' then
                        		mod.reset_game_globals(false)
                        	end
                        end
                        for k, v in ipairs(G.playing_cards) do
                            v.ability.discarded = nil
                            v.ability.forced_selection = nil
                        end
                    return true
                    end
                }))
            end
        return true
      end
    }))
  end
  
function new_round()
    G.RESET_JIGGLES = nil
    delay(0.4)
    G.E_MANAGER:add_event(Event({
      trigger = 'immediate',
      func = function()
            
            local deck_size = 0
            
            G.GAME.last_deck_size = G.GAME.last_deck_size
            
            for k, v in pairs(G.playing_cards) do
                deck_size = deck_size + 1
            end
            
            if __octopus_ne(G.GAME.last_deck_size, deck_size) then
                local locked_card
                local difference = deck_size - G.GAME.last_deck_size
            
                for i = 1, #G.P_LOCKED do
                    locked_card = G.P_LOCKED[i]
            
                    if not locked_card.unlocked and locked_card.check_for_unlock and type(locked_card.check_for_unlock) == 'function' then
                        locked_card:check_for_unlock({type = 'round_deck_size', round_deck_size_diff = difference})
                    end
                end
            end
            
            G.GAME.last_deck_size = deck_size
            
            G.GAME.money_spend_this_round = 0
            G.GAME.current_round.discards_left = math.max(0, G.GAME.round_resets.discards + G.GAME.round_bonus.discards)
            G.GAME.current_round.hands_left = (math.max(1, G.GAME.round_resets.hands + G.GAME.round_bonus.next_hands))
            G.GAME.current_round.hands_played = 0
            G.GAME.current_round.discards_used = 0
            G.GAME.current_round.any_hand_drawn = nil
            G.GAME.current_round.reroll_cost_increase = 0
            G.GAME.current_round.used_packs = {}

            for k, v in pairs(G.GAME.hands) do 
                v.played_this_round = 0
            end

            for k, v in pairs(G.playing_cards) do
                v.ability.wheel_flipped = nil
            end

            G.GAME.current_round.free_rerolls = G.GAME.round_resets.free_rerolls
            calculate_reroll_cost(true)

            G.GAME.round_bonus.next_hands = 0
            G.GAME.round_bonus.discards = 0

            local blhash = ''
            if G.GAME.round_resets.blind and G.GAME.round_resets.blind.name == 'Small Blind' then
                G.GAME.round_resets.blind_states.Small = 'Current'
                G.GAME.current_boss_streak = 0
                blhash = 'S'
            elseif G.GAME.round_resets.blind and G.GAME.round_resets.blind.name == 'Big Blind' then
                G.GAME.round_resets.blind_states.Big = 'Current'
                G.GAME.current_boss_streak = 0
                blhash = 'B'
            else
                G.GAME.round_resets.blind_states.Boss = 'Current'
                blhash = 'L'
            end
            G.GAME.subhash = (G.GAME.round_resets.ante)..(blhash)

            G.GAME.blind:set_blind(G.GAME.round_resets.blind)
            if G.GAME.modifiers.cry_conveyor and #G.jokers.cards>0 then
                local duplicated_joker = copy_card(G.jokers.cards[#G.jokers.cards])
                duplicated_joker:add_to_deck()
                G.jokers:emplace(duplicated_joker)
                G.jokers.cards[1]:start_dissolve()
            elseif G.GAME.modifiers.cry_antimatter_conveyor and #G.jokers.cards > 0 then
                local duplicated_joker = copy_card(G.jokers.cards[#G.jokers.cards])
                duplicated_joker:add_to_deck()
                G.jokers:emplace(duplicated_joker)
            end
            
            SMODS.calculate_context({setting_blind = true, blind = G.GAME.round_resets.blind})
            
            -- TARGET: setting_blind effects
            delay(0.4)

            G.E_MANAGER:add_event(Event({
                trigger = 'immediate',
                func = function()
                    G.STATE = G.STATES.DRAW_TO_HAND
                    G.deck:shuffle('nr'..G.GAME.round_resets.ante)
                    G.deck:hard_set_T()
if Talisman.scoring_coroutine then return false end 
                    G.STATE_COMPLETE = false
                    return true
                end
            }))
            return true
            end
        }))
end

G.FUNCS.draw_from_hand_to_run = function(e)
	local hand_count = #G.hand.cards
	for i=1, hand_count do --draw cards from deck
		draw_card(G.hand, G.cry_runarea, i*100/hand_count,'down', nil, nil,  0.08)
	end
end
G.FUNCS.draw_from_deck_to_hand = function(e)
    if not (__octopus_eq(G.STATE, G.STATES.TAROT_PACK) or __octopus_eq(G.STATE, G.STATES.SPECTRAL_PACK) or __octopus_eq(G.STATE, G.STATES.SMODS_BOOSTER_OPENED)) and
        __octopus_le(G.hand.config.card_limit, 0) and #G.hand.cards == 0 and not G.PROFILES[G.SETTINGS.profile].cry_none then
        G.STATE = G.STATES.GAME_OVER; G.STATE_COMPLETE = false 
        return true
    end

    local hand_space = e
    local cards_to_draw = {}
    local space_taken = 0
    local limit = (G.hand.config.card_limit - #G.hand.cards - (SMODS.cards_to_draw or 0))
    local flags = SMODS.calculate_context({drawing_cards = true, amount = math.max(limit, 0)})
    limit = flags.cards_to_draw or flags.modify or limit
    local unfixed = not G.hand.config.fixed_limit
    local n = 0
    while __octopus_lt(n, #G.deck.cards) and __octopus_gt(limit, 0) do
        local card = G.deck.cards[#G.deck.cards-n]
        local mod = unfixed and (card.ability.card_limit - card.ability.extra_slots_used) or 0
        if __octopus_lt(limit - 1 + mod, 0) then
        else    
            limit = limit - 1 + mod
            table.insert(cards_to_draw, card)
            space_taken = space_taken + (1 - mod)
        end
        n = n + 1
    end
    hand_space = math.min(#cards_to_draw, #G.deck.cards)
    if G.GAME.blind.name == 'The Serpent' and
        __octopus_eq(G.STATE, G.STATES.DRAW_TO_HAND) and
        not G.GAME.blind.disabled and
        (__octopus_gt(G.GAME.current_round.hands_played, 0) or
        __octopus_gt(G.GAME.current_round.discards_used, 0)) then
            G.hand.config.card_limits.blind_restriction = hand_space - math.min(#G.deck.cards, 3)
            hand_space = math.min(#G.deck.cards, 3)
    end
    delay(0.3)
    SMODS.cards_to_draw = (SMODS.cards_to_draw or 0) + hand_space
    SMODS.drawn_cards = {}
    if not G.GAME.USING_RUN then
    for i=1, hand_space do --draw cards from deckL
        if __octopus_eq(G.STATE, G.STATES.TAROT_PACK) or __octopus_eq(G.STATE, G.STATES.SPECTRAL_PACK) then 
            if cards_to_draw[i] and cards_to_draw[i].ability and (cards_to_draw[i].ability.extra_slots_used or cards_to_draw[i].ability.card_limit) then
                SMODS.cards_to_draw = SMODS.cards_to_draw + (__octopus_lt(SMODS.cards_to_draw, #G.deck.cards) and (cards_to_draw[i].ability.extra_slots_used or 0) - (cards_to_draw[i].ability.card_limit or 0) or 0)
                G.E_MANAGER:add_event(Event({
                    trigger = 'immediate',
                    func = function()                
                        SMODS.cards_to_draw = SMODS.cards_to_draw - (cards_to_draw[i].ability.extra_slots_used or 0) + (cards_to_draw[i].ability.card_limit or 0)
                        return true
                    end
                }))
            end
            draw_card(G.deck,G.hand, i*100/hand_space,'up', true, cards_to_draw[i])
        else
            if cards_to_draw[i] and cards_to_draw[i].ability and (cards_to_draw[i].ability.extra_slots_used or cards_to_draw[i].ability.card_limit) then
                SMODS.cards_to_draw = SMODS.cards_to_draw + (__octopus_lt(SMODS.cards_to_draw, #G.deck.cards) and (cards_to_draw[i].ability.extra_slots_used or 0) - (cards_to_draw[i].ability.card_limit or 0) or 0)
                G.E_MANAGER:add_event(Event({
                    trigger = 'immediate',
                    func = function()                
                        SMODS.cards_to_draw = SMODS.cards_to_draw - (cards_to_draw[i].ability.extra_slots_used or 0) + (cards_to_draw[i].ability.card_limit or 0)
                        return true
                    end
                }))
            end
            draw_card(G.deck,G.hand, i*100/hand_space,'up', true, cards_to_draw[i])
        end
    end
    G.E_MANAGER:add_event(Event({
        trigger = 'immediate',
        func = function()                
            SMODS.cards_to_draw = SMODS.cards_to_draw - hand_space
            return true
        end
    }))
    G.E_MANAGER:add_event(Event({
        trigger = 'immediate',
        func = function()
            if #SMODS.drawn_cards > 0 then
                SMODS.calculate_context({first_hand_drawn = not G.GAME.current_round.any_hand_drawn and G.GAME.facing_blind,
                                        hand_drawn = G.GAME.facing_blind and SMODS.drawn_cards,
                                        other_drawn = not G.GAME.facing_blind and SMODS.drawn_cards})
                SMODS.drawn_cards = {}
                if G.GAME.facing_blind then G.GAME.current_round.any_hand_drawn = true end
            end
            return true
        end
    }))
else
	for i = 1, #G.cry_runarea.cards do
		draw_card(G.cry_runarea,G.hand, i*100/#G.cry_runarea.cards,'up', true)
	end
end
end

G.FUNCS.discard_cards_from_highlighted = function(e, hook)

G.hand.crackers_highlighted = {}
local crackers_in_hand = false

for i = 1, #G.hand.cards do
    if G.hand.cards[i] and G.hand.cards[i].highlighted
    and __octopus_eq(G.hand.cards[i].config.center, G.P_CENTERS.m_bunc_cracker)
    and not G.hand.cards[i].debuff then
        crackers_in_hand = true
        break
    end
end

for i = 1, #G.hand.cards do
    if G.hand.cards[i] and G.hand.cards[i].highlighted
    and (((__octopus_eq(G.hand.cards[i].config.center, G.P_CENTERS.m_bunc_cracker)) and not G.hand.cards[i].debuff) or (crackers_in_hand and #SMODS.find_card('j_bunc_pica', false) > 0)) then
        table.insert(G.hand.crackers_highlighted, G.hand.cards[i])
        G.hand:remove_from_highlighted(G.hand.cards[i], true)
    end
end


if G.GAME.blind and G.GAME.blind.name == 'bl_bunc_final_dagger' and not G.GAME.blind.disabled then
    G.GAME.blind:wiggle()
    G.GAME.blind.antiscore = true
    G.FUNCS.play_cards_from_highlighted()
    return
end


if G.GAME.blind and G.GAME.blind.name == 'bl_bunc_paling' and not G.GAME.blind.disabled then
    G.GAME.blind:wiggle()
    delay(0.7)
end

    stop_use()
    G.CONTROLLER.interrupt.focus = true
    G.CONTROLLER:save_cardarea_focus('hand')

    for k, v in ipairs(G.playing_cards) do
        v.ability.forced_selection = nil
    end

    if G.CONTROLLER.focused.target and __octopus_eq(G.CONTROLLER.focused.target.area, G.hand) then G.card_area_focus_reset = {area = G.hand, rank = G.CONTROLLER.focused.target.rank} end
    local highlighted_count = math.min(#G.hand.highlighted, G.discard.config.card_limit - #G.play.cards)
    if __octopus_gt(highlighted_count, 0) then 
        update_hand_text({immediate = true, nopulse = true, delay = 0}, {mult = 0, chips = 0, level = '', handname = ''})
        for name, parameter in pairs(SMODS.Scoring_Parameters) do
            update_hand_text({immediate = true, nopulse = true, delay = 0}, {[name] = parameter.default_value})
        end
        table.sort(G.hand.highlighted, function(a,b) return __octopus_lt(a.T.x, b.T.x) end)
        inc_career_stat('c_cards_discarded', highlighted_count)
        SMODS.calculate_context({pre_discard = true, full_hand = G.hand.highlighted, hook = hook})
        
        -- TARGET: pre_discard
        local cards = {}
        local destroyed_cards = {}
        
        if G.GAME.blind and G.GAME.blind.name == 'bl_bunc_paling' and not G.GAME.blind.disabled then
            for i=1, highlighted_count do
                G.E_MANAGER:add_event(Event({func = function()
                    if G.hand.highlighted[i] and not G.hand.highlighted[i].removed then
                        G.hand.highlighted[i]:juice_up()
                    end
                return true end }))
                ease_dollars(-1)
                delay(0.23)
            end
        end
        
        for i=1, highlighted_count do
            G.hand.highlighted[i]:calculate_seal({discard = true})
            local removed = false
            local effects = {}
            SMODS.calculate_context({discard = true, other_card =  G.hand.highlighted[i], full_hand = G.hand.highlighted, ignore_other_debuff = true}, effects)
            SMODS.trigger_effects(effects)
            for _, eval in pairs(effects) do
                if type(eval) == 'table' then
                    for key, eval2 in pairs(eval) do
                        if key == 'remove' or (type(eval2) == 'table' and eval2.remove) then removed = true end
                    end
                end
            end
            table.insert(cards, G.hand.highlighted[i])
            if removed then
                destroyed_cards[#destroyed_cards + 1] = G.hand.highlighted[i]
                if SMODS.shatters(G.hand.highlighted[i]) then
                    G.hand.highlighted[i]:shatter()
                else
                    G.hand.highlighted[i]:start_dissolve()
                end
            else 
                G.hand.highlighted[i].ability.discarded = true
                
                if G.GAME.blind and G.GAME.blind.name == 'bl_bunc_claw' and not G.GAME.blind.disabled then
                    draw_card(G.hand, G.deck, i*100/highlighted_count, 'down', false, G.hand.highlighted[i])
                    G.deck:shuffle('claw'..G.GAME.round_resets.ante)
                else
                    draw_card(G.hand, G.discard, i*100/highlighted_count, 'down', false, G.hand.highlighted[i])
                end
                
            end
        end

        -- context.remove_playing_cards from discard
        if destroyed_cards[1] then
            SMODS.calculate_context({remove_playing_cards = true, removed = destroyed_cards})
        end
        
        -- TARGET: effects after cards destroyed in discard

        G.GAME.round_scores.cards_discarded.amt = G.GAME.round_scores.cards_discarded.amt + #cards
        check_for_unlock({type = 'discard_custom', cards = cards})
        if not hook then
            if G.GAME.modifiers.discard_cost then
                ease_dollars(-G.GAME.modifiers.discard_cost)
            end
            ease_discard(-1)
            G.GAME.current_round.discards_used = G.GAME.current_round.discards_used + 1
            
            if G.hand.crackers_highlighted and #G.hand.crackers_highlighted >= 1 then
                for i = 1, #G.hand.crackers_highlighted do
                    if not G.hand.crackers_highlighted[i].highlighted then
                        G.hand:add_to_highlighted(G.hand.crackers_highlighted[i], true)
                    end
                    G.hand.crackers_highlighted[i].marked_cracker = true
                end
            
                G.E_MANAGER:add_event(Event({func = function()
                    G.GAME.ignore_hand_played = true
                    G.FUNCS.play_cards_from_highlighted()
                return true end}))
            
                return
            end
            
            
            if G.GAME.blind and G.GAME.blind.name == 'bl_bunc_swing' and not G.GAME.blind.disabled then
                G.E_MANAGER:add_event(Event({ func = function()
                    for k, v in ipairs(G.hand.cards) do
                        v:flip()
                    end
            
                    G.GAME.blind:wiggle()
                    G.GAME.blind.triggered = true
            
                    if G.GAME.Swing == true then
                        G.GAME.Swing = false
                    else
                        G.GAME.Swing = true
                    end
                return true end }))
            end
            
            G.STATE = G.STATES.DRAW_TO_HAND
            G.E_MANAGER:add_event(Event({
                trigger = 'immediate',
                func = function()
if Talisman.scoring_coroutine then return false end 
                    G.STATE_COMPLETE = false
                    return true
                end
            }))
        end
    end
if G.hand.crackers_highlighted and #G.hand.crackers_highlighted >= 1 then

    ease_discard(-1)

    for i = 1, #G.hand.crackers_highlighted do
        if not G.hand.crackers_highlighted[i].highlighted then
            G.hand:add_to_highlighted(G.hand.crackers_highlighted[i], true)
        end
        G.hand.crackers_highlighted[i].marked_cracker = true
    end

    if #G.play.cards ~= 0 then
        for i=1, #G.hand.highlighted do
            if G.hand.highlighted[i] and __octopus_eq(G.hand.highlighted[i].config.center, G.P_CENTERS.m_bunc_cracker) then
                if G.hand.highlighted[i]:is_face() then inc_career_stat('c_face_cards_played', 1) end
                G.hand.highlighted[i].base.times_played = G.hand.highlighted[i].base.times_played + 1
                G.hand.highlighted[i].ability.played_this_ante = true
                G.GAME.round_scores.cards_played.amt = G.GAME.round_scores.cards_played.amt + 1
                draw_card(G.hand, G.play, i*100/#G.hand.highlighted, 'up', nil, G.hand.highlighted[i])
            end
        end
    end

    G.E_MANAGER:add_event(Event({func = function()
        if #G.play.cards == 0 then
            G.GAME.ignore_hand_played = true
            G.FUNCS.play_cards_from_highlighted()
        end
    return true end}))

    return
end


end
  
G.FUNCS.play_cards_from_highlighted = function(e)
    if G.play and G.play.cards[1] then return end
    --check the hand first
    
    local unlock_all_flipped = true
    
    for i = 1, #G.hand.highlighted do
        if G.hand.highlighted[i].facing ~= 'back' then
            unlock_all_flipped = false
        end
    end
    
    if (not G.hand.highlighted) or (#G.hand.highlighted == 0) then unlock_all_flipped = false end
    
    if unlock_all_flipped and #G.hand.highlighted >= 5 then
        local locked_card
    
        for i = 1, #G.P_LOCKED do
            locked_card = G.P_LOCKED[i]
    
            if not locked_card.unlocked and locked_card.check_for_unlock and type(locked_card.check_for_unlock) == 'function' then
                locked_card:check_for_unlock({type = 'play_all_flipped'})
            end
        end
    end
    
    
    if G.jokers ~= nil then
        for _, v in ipairs(G.jokers.cards) do
            if v.config.center.key == 'j_bunc_vandalism' and not v.debuff then
                v:calculate_joker({play_cards = true})
            end
        end
    end
    

    stop_use()
    G.GAME.blind.triggered = false
    G.CONTROLLER.interrupt.focus = true
    G.CONTROLLER:save_cardarea_focus('hand')

    for k, v in ipairs(G.playing_cards) do
        v.ability.forced_selection = nil
    end
    
    table.sort(G.hand.highlighted, function(a,b) return __octopus_lt(a.T.x, b.T.x) end)

    G.E_MANAGER:add_event(Event({
        trigger = 'immediate',
        func = function()
            G.STATE = G.STATES.HAND_PLAYED
            G.STATE_COMPLETE = true
            return true
        end
    }))
    inc_career_stat('c_cards_played', #G.hand.highlighted)
    inc_career_stat('c_hands_played', 1)
    
    if G.GAME.blind and G.GAME.blind.name == 'bl_bunc_swing' and not G.GAME.blind.disabled then
        G.E_MANAGER:add_event(Event({ func = function()
            for k, v in ipairs(G.hand.cards) do
                if not (__octopus_eq(v.area, G.hand) and v.highlighted and v.facing == 'front') then
                    v:flip()
                end
            end
    
            G.GAME.blind:wiggle()
            G.GAME.blind.triggered = true
    
            if G.GAME.Swing == true then
                G.GAME.Swing = false
            else
                G.GAME.Swing = true
            end
        return true end }))
    end
    
    
    if G.GAME.blind and G.GAME.blind.name == 'bl_bunc_umbrella' and not G.GAME.blind.disabled then
        G.E_MANAGER:add_event(Event({func = function()
    
            for k, v in ipairs(G.hand.cards) do
                if v.facing == 'front' and not v.highlighted then
                    v:flip()
                end
            end
    
            G.GAME.blind:wiggle()
            G.GAME.blind.triggered = true
    
        return true end }))
    end
    
    
    if G.jokers ~= nil then
        for _, v in ipairs(G.jokers.cards) do
            if v.config.center.key == 'j_bunc_cellphone' and v.ability.extra.active and not v.debuff then
                v:calculate_joker({press_play = true})
                break
            end
        end
    end
    
    
    local function calculate_discard()
        for i = 1, #G.hand.cards do
            eval_card(G.hand.cards[i], {pre_discard = true, full_hand = G.hand.highlighted, hook = hook})
        end
        for j = 1, #G.jokers.cards do
            G.jokers.cards[j]:calculate_joker({pre_discard = true, full_hand = G.hand.highlighted, hook = hook})
        end
    end
    
    if not G.GAME.ignore_hand_played then
        if G.GAME.blind.antiscore then
            ease_discard(-1)
            calculate_discard()
        else
            ease_hands_played(-1)
        end
    else
        G.GAME.ignore_hand_played = nil
    end
    
    delay(0.4)

        for i=1, #G.hand.highlighted do
            if G.hand.highlighted[i]:is_face() then inc_career_stat('c_face_cards_played', 1) end
            G.hand.highlighted[i].base.times_played = G.hand.highlighted[i].base.times_played + 1
            -- removed by SMODS
            G.GAME.round_scores.cards_played.amt = G.GAME.round_scores.cards_played.amt + 1
            draw_card(G.hand, G.play, i*100/#G.hand.highlighted, 'up', nil, G.hand.highlighted[i])
        end

        check_for_unlock({type = 'run_card_replays'})

        if G.GAME.blind:press_play() then
            G.E_MANAGER:add_event(Event({
                trigger = 'immediate',
                func = (function()
                    SMODS.juice_up_blind()
                    G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.06*G.SETTINGS.GAMESPEED, blockable = false, blocking = false, func = function()
                        play_sound('tarot2', 0.76, 0.4);return true end}))
                    play_sound('tarot2', 1, 0.4)
                    return true
                end)
            }))
            delay(0.4)
        end

        G.E_MANAGER:add_event(Event({
            trigger = 'immediate',
            func = (function()
                check_for_unlock({type = 'hand_contents', cards = G.play.cards})

                G.E_MANAGER:add_event(Event({
                    trigger = 'immediate',
                    func = function()
                        G.FUNCS.evaluate_play()
                        
                        if G.GAME.blind.antiscore then
                            G.GAME.blind.antiscore = false
                        end
                        
                        return true
                    end
                }))

                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        if Talisman.scoring_coroutine then return false end 
                        check_for_unlock({type = 'play_all_hearts'})
                        G.FUNCS.draw_from_play_to_discard()
                        G.GAME.hands_played = G.GAME.hands_played + 1
                        G.GAME.current_round.hands_played = G.GAME.current_round.hands_played + 1
                        return true
                    end
                }))
                G.E_MANAGER:add_event(Event({
                    trigger = 'immediate',
                    func = function()
if Talisman.scoring_coroutine then return false end 
                        G.STATE_COMPLETE = false
                        return true
                    end
                }))
                return true
            end)
        }))
end

-- Function overridden by SMODS in src/overrides.lua
G.FUNCS.get_poker_hand_info = function(_cards)
    local poker_hands = evaluate_poker_hand(_cards)
    local scoring_hand = {}
    local text,disp_text,loc_disp_text = 'NULL','NULL', 'NULL'
    if next(poker_hands["Flush Five"]) then text = "Flush Five"; scoring_hand = poker_hands["Flush Five"][1]
    elseif next(poker_hands["Flush House"]) then text = "Flush House"; scoring_hand = poker_hands["Flush House"][1]
    elseif next(poker_hands["Five of a Kind"]) then text = "Five of a Kind"; scoring_hand = poker_hands["Five of a Kind"][1]
    elseif next(poker_hands["Straight Flush"]) then text = "Straight Flush"; scoring_hand = poker_hands["Straight Flush"][1]
    elseif next(poker_hands["Four of a Kind"]) then text = "Four of a Kind"; scoring_hand = poker_hands["Four of a Kind"][1]
    elseif next(poker_hands["Full House"]) then text = "Full House"; scoring_hand = poker_hands["Full House"][1]
    elseif next(poker_hands["Flush"]) then text = "Flush"; scoring_hand = poker_hands["Flush"][1]
    elseif next(poker_hands["Straight"]) then text = "Straight"; scoring_hand = poker_hands["Straight"][1]
    elseif next(poker_hands["Three of a Kind"]) then text = "Three of a Kind"; scoring_hand = poker_hands["Three of a Kind"][1]
    elseif next(poker_hands["Two Pair"]) then text = "Two Pair"; scoring_hand = poker_hands["Two Pair"][1]
    elseif next(poker_hands["Pair"]) then text = "Pair"; scoring_hand = poker_hands["Pair"][1]
    elseif next(poker_hands["High Card"]) then text = "High Card"; scoring_hand = poker_hands["High Card"][1] end

    disp_text = text
    if text =='Straight Flush' then
        local min = 10
        for j = 1, #scoring_hand do
            if __octopus_lt(scoring_hand[j]:get_id(), min) then min =scoring_hand[j]:get_id() end
        end
        if __octopus_ge(min, 10) then 
            disp_text = 'Royal Flush'
        end
    end
    loc_disp_text = localize(disp_text, 'poker_hands')
    return text, loc_disp_text, poker_hands, scoring_hand, disp_text
end
  
local lim = 7
G.FUNCS.evaluate_play = function(e)

local antiscore = G.GAME.blind.antiscore

	mult = 0
	hand_chips = 0
	if SMODS and SMODS.Scoring_Parameters then
		SMODS.Scoring_Parameters.mult.current = 0
		SMODS.Scoring_Parameters.chips.current = 0
	end

	local state
	local co = Talisman.scoring_coroutine

	if co then co.state = "intro" end
	state = {evaluate_play_intro()}
	if co then co.astate = state end

	if not G.GAME.blind:debuff_hand(G.play.cards, state[3], state[1]) then
		if co then co.state = "main" end
		state = {evaluate_play_main(unpack(state, 1, lim))}
		if co then co.astate = state end
	else
		if co then co.state = "debuff" end
		state = {evaluate_play_debuff(unpack(state, 1, lim))}
		if co then co.astate = state end
	end

	if co then co.state = "final_scoring" end
	state = {evaluate_play_final_scoring(unpack(state, 1, lim))}
	if co then co.astate = state end

	if co then co.state = "after" end
	evaluate_play_after(unpack(state, 1, lim))

	if co then co.state = nil end
end

function evaluate_play_intro()
    local text,disp_text,poker_hands,scoring_hand,non_loc_disp_text = G.FUNCS.get_poker_hand_info(G.play.cards)
    local tbl = {}
    for i, v in pairs(G.jokers.cards) do
    	if v.base.nominal and v.base.suit then
    		tbl[#tbl+1] = v
    	end
    end
    local text,disp_text,poker_hands,scoring_hand,non_loc_disp_text = G.FUNCS.get_poker_hand_info(Cryptid.table_merge(G.play.cards, tbl))
    
    local hand = (G.GAME.hands[text])
    if not hand then text = "cry_None"; disp_text = localize("cry_None", "poker_hands") end
    hand = G.GAME.hands[text]
    if text == "cry_None" then G.GAME.hands["cry_None"].visible = true end
    hand.played = hand.played + 1
    
    if text == 'bunc_Spectrum'
    or text == 'bunc_Straight Spectrum'
    or text == 'bunc_Spectrum House'
    or text == 'bunc_Spectrum Five' then
        enable_exotics()
        unlock_card(G.P_CENTERS.b_bunc_fairy)
    end
    
    if G.GAME.current_round.current_hand.cry_asc_num and (((Cryptid.is_big(G.GAME.current_round.current_hand.cry_asc_num) and G.GAME.current_round.current_hand.cry_asc_num:gt(to_big(G.GAME.cry_exploit_override and 1 or 0)) or __octopus_gt(G.GAME.current_round.current_hand.cry_asc_num, G.GAME.cry_exploit_override and 1 or 0)))) then
    	G.GAME.cry_asc_played = G.GAME.cry_asc_played and G.GAME.cry_asc_played+1 or 1
    end
    G.GAME.hands[text].played_this_round = G.GAME.hands[text].played_this_round + 1
    G.GAME.hands[text].played_this_ante = G.GAME.hands[text].played_this_ante + 1
    G.GAME.last_hand_played = text
    G.GAME.last_hand_played_cards = {}
    for i = 1, #G.play.cards do
    	G.GAME.last_hand_played_cards[i] = G.play.cards[i].sort_id
    end
    set_hand_usage(text)
    G.GAME.hands[text].visible = true

    local final_scoring_hand = {}
    for i=1, #G.play.cards do
        local splashed = SMODS.always_scores(G.play.cards[i]) or next(find_joker('Splash'))
        local unsplashed = SMODS.never_scores(G.play.cards[i])
        if not splashed then
            for _, card in pairs(scoring_hand) do
                if __octopus_eq(card, G.play.cards[i]) then splashed = true end
            end
        end
        local effects = {}
        SMODS.calculate_context({modify_scoring_hand = true, other_card =  G.play.cards[i], full_hand = G.play.cards, scoring_hand = scoring_hand, in_scoring = true, ignore_other_debuff = true}, effects)
        local flags = SMODS.trigger_effects(effects, G.play.cards[i])
        if flags.add_to_hand then splashed = true end
    	if flags.remove_from_hand then unsplashed = true end
        if splashed and not unsplashed then table.insert(final_scoring_hand, G.play.cards[i]) end
    end
    -- TARGET: adding to hand effects
    scoring_hand = final_scoring_hand
    delay(0.2)
    for i=1, #scoring_hand do
        --Highlight all the cards used in scoring and play a sound indicating highlight
        highlight_card(scoring_hand[i],(i-0.999)/5,'up')
        
        local played_rank = scoring_hand[i].base.value
        
        if G.GAME.played_ranks == nil then G.GAME.played_ranks = {} end
        
        if G.GAME.played_ranks[played_rank] then
            G.GAME.played_ranks[played_rank] = G.GAME.played_ranks[played_rank] + 1
        else
            G.GAME.played_ranks[played_rank] = 1
        end
        
    end

    percent = 0.3
    percent_delta = 0.08

    if __octopus_ne(G.GAME.current_round.current_hand.handname, disp_text) then delay(0.3) end
    update_hand_text({sound = __octopus_ne(G.GAME.current_round.current_hand.handname, disp_text) and 'button' or nil, volume = 0.4, immediate = true, nopulse = nil,
                                delay = __octopus_ne(G.GAME.current_round.current_hand.handname, disp_text) and 0.4 or 0}, {handname=disp_text, level=G.GAME.hands[text].level, mult = Cryptid.ascend(G.GAME.hands[text].mult), chips = Cryptid.ascend(G.GAME.hands[text].chips)})
    
for name, parameter in pairs(SMODS.Scoring_Parameters) do
    if name ~= 'chips' and name ~= 'mult' then update_hand_text({immediate = true}, {[name] = parameter.current}) end
end
SMODS.displayed_hand = text
SMODS.displaying_scoring = true

    return text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta
    end
    function evaluate_play_main(text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta)
                mult = mod_mult(Cryptid.ascend(G.GAME.hands[text].mult))
                hand_chips = mod_chips(Cryptid.ascend(G.GAME.hands[text].chips))

        check_for_unlock({type = 'hand', handname = text, disp_text = non_loc_disp_text, scoring_hand = scoring_hand, full_hand = G.play.cards})

        delay(0.4)

        if G.GAME.first_used_hand_level and __octopus_gt(G.GAME.first_used_hand_level, 0) then
            level_up_hand(G.deck.cards[1], text, nil, G.GAME.first_used_hand_level)
            G.GAME.first_used_hand_level = nil
        end

        local hand_text_set = false
        -- context.before calculations
        if SMODS.last_hand then
            for _, v in ipairs({'scoring_hand', 'full_hand'}) do
                for _, _c in ipairs(SMODS.last_hand[v]) do
                    _c.ability['SMODS_'..v] = nil
                end
            end
        end
        SMODS.last_hand = {scoring_hand = scoring_hand, scoring_name = text, full_hand = G.play.cards}
        SMODS.calculate_context({full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, before = true})
        
        -- TARGET: effects before scoring starts
        
        SMODS.displayed_hand = nil

                mult = mod_mult(Cryptid.ascend(G.GAME.hands[text].mult))
                hand_chips = mod_chips(Cryptid.ascend(G.GAME.hands[text].chips))

        
        for i = 1, #G.GAME.tags do
            G.GAME.tags[i]:apply_to_run({type = 'hand_played', before = true})
        end
        
        local modded = false

        mult, hand_chips, modded = G.GAME.blind:modify_hand(G.play.cards, poker_hands, text, mult, hand_chips, scoring_hand)
        mult, hand_chips = mod_mult(mult), mod_chips(hand_chips)
        if modded then update_hand_text({sound = 'chips2', modded = modded}, {chips = hand_chips, mult = mult}) end
        SMODS.calculate_context({initial_scoring_step = true, full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands})
        for _, v in ipairs(SMODS.get_card_areas('playing_cards')) do
            SMODS.calculate_main_scoring({cardarea = v, full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands}, __octopus_eq(v, G.play) and scoring_hand or nil)
        end
        delay(0.3)
        
        --+++++++++++++++++++++++++++++++++++++++++++++++++++++++++--
        --Joker Effects
        --+++++++++++++++++++++++++++++++++++++++++++++++++++++++++--
        percent = percent + percent_delta
        for _, area in ipairs(SMODS.get_card_areas('jokers')) do for _, _card in ipairs(area.cards) do
            local effects = {}
            -- remove base game joker edition calc
            local eval = eval_card(_card, {cardarea = G.jokers, full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, edition = true, pre_joker = true})
            if eval.edition then effects[#effects+1] = eval end
            

            -- Calculate context.joker_main
            local joker_eval, post = eval_card(_card, {cardarea = G.jokers, full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, joker_main = true})
            if next(joker_eval) then
                if joker_eval.edition then joker_eval.edition = {} end
                table.insert(effects, joker_eval)
                for _, v in ipairs(post) do effects[#effects+1] = v end
                if joker_eval.retriggers then
                    for rt = 1, #joker_eval.retriggers do
                        local rt_eval, rt_post = eval_card(_card, {cardarea = G.jokers, full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, joker_main = true, retrigger_joker = true})
                        if next(rt_eval) then
                            table.insert(effects, {retriggers = joker_eval.retriggers[rt]})
                            table.insert(effects, rt_eval)
                            for _, v in ipairs(rt_post) do effects[#effects+1] = v end
                        end
                    end
                end
            end

            -- Calculate context.other_joker effects
            for _, _area in ipairs(SMODS.get_card_areas('jokers')) do
                for _, _joker in ipairs(_area.cards) do
                    local other_key = 'other_unknown'
                    if _card.ability.set == 'Joker' then other_key = 'other_joker' end
                    if _card.ability.consumeable then other_key = 'other_consumeable' end
                    if _card.ability.set == 'Voucher' then other_key = 'other_voucher' end
                    -- TARGET: add context.other_something identifier to your cards
                    local joker_eval,post = eval_card(_joker, {full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, [other_key] = _card, other_main = _card })
                    if next(joker_eval) then
                        if joker_eval.edition then joker_eval.edition = {} end
                        joker_eval.jokers.juice_card = _joker
                        table.insert(effects, joker_eval)
                        for _, v in ipairs(post) do effects[#effects+1] = v end
                        if joker_eval.retriggers then
                            for rt = 1, #joker_eval.retriggers do
                                local rt_eval, rt_post = eval_card(_joker, {full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, [other_key] = _card, retrigger_joker = true})
                                if next(rt_eval) then
                                    table.insert(effects, {retriggers = joker_eval.retriggers[rt]})
                                    table.insert(effects, rt_eval)
                                    for _, v in ipairs(rt_post) do effects[#effects+1] = v end
                                end
                            end
                        end
                    end
                end
            end
            for _, _area in ipairs(SMODS.get_card_areas('individual')) do
                local other_key = 'other_unknown'
                if _card.ability.set == 'Joker' then other_key = 'other_joker' end
                if _card.ability.consumeable then other_key = 'other_consumeable' end
                if _card.ability.set == 'Voucher' then other_key = 'other_voucher' end
                -- TARGET: add context.other_something identifier to your cards
                local _eval,post = SMODS.eval_individual(_area, {full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, [other_key] = _card, other_main = _card })
                if next(_eval) then
                    _eval.individual.juice_card = _area.scored_card
                    table.insert(effects, _eval)
                    for _, v in ipairs(post) do effects[#effects+1] = v end
                    if _eval.retriggers then
                        for rt = 1, #_eval.retriggers do
                            local rt_eval, rt_post = SMODS.eval_individual(_area, {full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, [other_key] = _card, retrigger_joker = true})
                            if next(rt_eval) then
                                table.insert(effects, {_eval.retriggers[rt]})
                                table.insert(effects, rt_eval)
                                for _, v in ipairs(rt_post) do effects[#effects+1] = v end
                            end
                        end
                    end
                end
            end

            -- calculate edition multipliers
            local eval = eval_card(_card, {cardarea = G.jokers, full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, edition = true, post_joker = true})
            if eval.edition then effects[#effects+1] = eval end

            SMODS.trigger_effects(effects, _card)
        end end

        --- context.main_scoring for individual area calculations
        for _, _area in ipairs(SMODS.get_card_areas('individual')) do
            local effects = {}
            -- Calculate context.main_scoring for individual areas
            local _eval, post = SMODS.eval_individual(_area, { full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, main_scoring = true })
            if next(_eval) then
                table.insert(effects, _eval)
                _eval.individual.juice_card = _area.scored_card
                for _, v in ipairs(post) do effects[#effects + 1] = v end
                if _eval.retriggers then
                    for rt = 1, #_eval.retriggers do
                        local rt_eval, rt_post = SMODS.eval_individual(_area, {full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, main_scoring = true, retrigger_joker = true})
                        if next(rt_eval) then
                            table.insert(effects, {_eval.retriggers[rt]})
                            table.insert(effects, rt_eval)
                            for _, v in ipairs(rt_post) do effects[#effects+1] = v end
                        end
                    end
                end
            end
        
            SMODS.trigger_effects(effects, _area.scored_card)
        end
        
        
        -- context.final_scoring_step calculations
        SMODS.calculate_context({full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, final_scoring_step = true})
        
        
        if G.GAME.blind and G.GAME.blind.name == 'bl_bunc_blade' and not G.GAME.blind.disabled then
        
            local overscore = G.GAME.blind.chips * 1.5
        
            if type(hand_chips) == 'table' then overscore = to_big(overscore) end
        
            if (__octopus_lt(overscore, math.floor(hand_chips*mult) + G.GAME.chips)) then
        
                mult = mod_mult(0)
                hand_chips = mod_chips(0)
        
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    func = (function()
                        G.GAME.blind:disable()
                        return true
                    end)
                }))
        
                local blade_message = G.localization.misc.dictionary.bunc_exceeded_score
                play_area_status_text(blade_message)
        
            end
        end
        
        
        for i = 1, #G.GAME.tags do
            G.GAME.tags[i]:apply_to_run({type = 'hand_played', after = true})
        end
        
        -- TARGET: effects before deck final_scoring_step
        
        for i=1, BUNCOMOD and BUNCOMOD.vars and BUNCOMOD.vars.jokerlike_consumable_editions and 0 or #G.consumeables.cards do
            local _card = G.consumeables.cards[i]
            local effects = {}
            -- remove base game joker edition calc
            local eval = eval_card(_card, {cardarea = G.jokers, full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, edition = true, pre_joker = true})
        
            -- Calculate context.joker_main
            local joker_eval, post = eval_card(_card, {cardarea = G.jokers, full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, joker_main = true})
            if next(joker_eval) then
                table.insert(effects, joker_eval)
                for _, v in ipairs(post) do effects[#effects+1] = v end
                if joker_eval.retriggers then
                    for rt = 1, #joker_eval.retriggers do
                        local rt_eval, rt_post = eval_card(_card, {cardarea = G.jokers, full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, joker_main = true, retrigger_joker = true})
                        table.insert(effects, {joker_eval.retriggers[rt]})
                        table.insert(effects, rt_eval)
                        for _, v in ipairs(rt_post) do effects[#effects+1] = v end
                    end
                end
            end
        
            -- Calculate context.other_joker effects
            for _, _area in ipairs(SMODS.get_card_areas('jokers')) do
                for _, _joker in ipairs(_area.cards) do
                    local other_key = 'other_unknown'
                    if _card.ability.set == 'Joker' then other_key = 'other_joker' end
                    if _card.ability.consumeable then other_key = 'other_consumeable' end
                    if _card.ability.set == 'Voucher' then other_key = 'other_voucher' end
                    -- TARGET: add context.other_something identifier to your cards
                    local joker_eval,post = eval_card(_joker, {full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, [other_key] = _card, other_main = _card })
                    if next(joker_eval) then
                        joker_eval.jokers.juice_card = _joker
                        table.insert(effects, joker_eval)
                        for _, v in ipairs(post) do effects[#effects+1] = v end
                        if joker_eval.retriggers then
                            for rt = 1, #joker_eval.retriggers do
                                local rt_eval, rt_post = eval_card(_card, {full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, [other_key] = _card, retrigger_joker = true})
                                table.insert(effects, {joker_eval.retriggers[rt]})
                                table.insert(effects, rt_eval)
                                for _, v in ipairs(rt_post) do effects[#effects+1] = v end
                            end
                        end
                    end
                end
            end
        
            SMODS.trigger_effects(effects, _card)
            local deck_effect = G.GAME.selected_back:trigger_effect({full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, other_joker = _card.ability.set == 'Joker' and _card or false, other_consumeable = _card.ability.set ~= 'Joker' and _card or false})
            if deck_effect then SMODS.calculate_effect(deck_effect, G.deck.cards[1] or G.deck) end
        end
        
        local nu_chip, nu_mult = G.GAME.selected_back:trigger_effect{context = 'final_scoring_step', chips = hand_chips, mult = mult}
        mult = mod_mult(nu_mult or mult)
        hand_chips = mod_chips(nu_chip or hand_chips)

        local cards_destroyed = {}
        for _,v in ipairs(SMODS.get_card_areas('playing_cards', 'destroying_cards')) do
            SMODS.calculate_destroying_cards({ full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, cardarea = v }, cards_destroyed, __octopus_eq(v, G.play) and scoring_hand or nil)
        end
        
        -- context.remove_playing_cards calculations
        if cards_destroyed[1] then
            SMODS.calculate_context({scoring_hand = scoring_hand, remove_playing_cards = true, removed = cards_destroyed})
        end
        
        -- TARGET: effects when cards are removed
        


        local glass_shattered = {}
        for k, v in ipairs(cards_destroyed) do
            if v.shattered then glass_shattered[#glass_shattered+1] = v end
        end

        check_for_unlock{type = 'shatter', shattered = glass_shattered}
        
        for i=1, #cards_destroyed do
            G.E_MANAGER:add_event(Event({
                func = function()
                    if cards_destroyed[i].shattered then
                        cards_destroyed[i]:shatter()
                    else
                        cards_destroyed[i]:start_dissolve()
                    end
                  return true
                end
              }))
        end
    return text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta
    end
    function evaluate_play_debuff(text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta)
    	mult = mod_mult(0)
        hand_chips = mod_chips(0)
        SMODS.displayed_hand = nil
        G.E_MANAGER:add_event(Event({
            trigger = 'immediate',
            func = (function()
                if SMODS.hand_debuff_source then SMODS.hand_debuff_source:juice_up(0.3,0) else SMODS.juice_up_blind() end
                G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.06*G.SETTINGS.GAMESPEED, blockable = false, blocking = false, func = function()
                    play_sound('tarot2', 0.76, 0.4);return true end}))
                play_sound('tarot2', 1, 0.4)
                return true
            end)
        }))

        play_area_status_text("Not Allowed!")--localize('k_not_allowed_ex'), true)
        --+++++++++++++++++++++++++++++++++++++++++++++++++++++++++--
        --Joker Debuff Effects
        --+++++++++++++++++++++++++++++++++++++++++++++++++++++++++--
        -- context.debuffed_hand calculations
        SMODS.calculate_context({full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, debuffed_hand = true})
        
        -- TARGET: effects after hand debuffed by blind
    return text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta
    end
    function evaluate_play_final_scoring(text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta)
    G.E_MANAGER:add_event(Event({
    	trigger = 'after',delay = 0.4,
        func = (function()  update_hand_text({delay = 0, immediate = true}, {mult = 0, chips = 0, chip_total = math.floor( SMODS.calculate_round_score() ), level = '', handname = ''});play_sound('button', 0.9, 0.6);return true end)
      }))
      for name, parameter in pairs(SMODS.Scoring_Parameters) do
          update_hand_text({delay = 0}, {[name] = parameter.default_value})
      end
          G.E_MANAGER:add_event(Event({
            trigger = 'immediate',
            func = (function() G.GAME.current_round.current_hand.cry_asc_num = 0;G.GAME.current_round.current_hand.cry_asc_num_text = '';return true end)
          }))
      check_and_set_high_score('hand',  SMODS.calculate_round_score() )

      check_for_unlock({type = 'chip_score', chips = math.floor( SMODS.calculate_round_score() )})
   
    Handy.scoring_hold.create_hold_event()
    if  __octopus_gt(SMODS.calculate_round_score(), 0) then 
        delay(0.8)
        G.E_MANAGER:add_event(Event({
        trigger = 'immediate',
        func = (function() play_sound('chips2');return true end)
        }))
    end
    G.E_MANAGER:add_event(Event({
      trigger = 'ease',
      blocking = false,
      ref_table = G.GAME,
      ref_value = 'chips',
      ease_to = G.GAME.chips + math.floor( SMODS.calculate_round_score() ) * (antiscore and -1 or 1),
      delay =  0.5,
      func = (function(t) return math.floor(t) end)
    }))
    G.E_MANAGER:add_event(Event({
      trigger = 'ease',
      blocking = true,
      ref_table = G.GAME.current_round.current_hand,
      ref_value = 'chip_total',
      ease_to = 0,
      delay =  0.5,
      func = (function(t) return math.floor(t) end)
    }))
        G.E_MANAGER:add_event(Event({
          trigger = 'immediate',
          	func = (function()
                if text ~= "cry_None" or not G.GAME.hands["cry_None"].visible then
                    G.GAME.current_round.current_hand.handname = ''
                end
                return true end)
          }))
          delay(0.3)
    delay(0.3)
    if not next(SMODS.find_mod("Talisman")) then
        evaluate_play_after(text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta)
    end
    return text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta
    end
    function evaluate_play_after(text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta)
      return text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta
      end
      function evaluate_play_after(text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta)
    SMODS.last_hand_score = SMODS.calculate_round_score()
    SMODS.last_hand_oneshot = __octopus_ge(SMODS.last_hand_score, G.GAME.blind.chips)
    G.E_MANAGER:add_event(Event({
      trigger = 'immediate',
      func = (function() 
        for name, parameter in pairs(SMODS.Scoring_Parameters) do
            parameter.current = parameter.default_value
        end
        return true 
      end)
    }))
    
    SMODS.displaying_scoring = nil

    -- context.after calculations
    SMODS.calculate_context({full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, after = true})
    
    calculate_cracker_cards({full_hand = G.play.cards, scoring_hand = scoring_hand, scoring_name = text, poker_hands = poker_hands, after = true})
    
    
    -- set `ability.played_this_ante` on played cards
    for _,v in ipairs(G.play.cards) do
        G.E_MANAGER:add_event(Event({
            func = function()
                v.ability.played_this_ante = true
                return true
            end,
        }))
    end
    
    -- TARGET: effects after hand evaluation
    G.E_MANAGER:add_event(Event({
    	func = function()
    		G.GAME.cry_exploit_override = nil
    		return true
    	end
    }))

    G.E_MANAGER:add_event(Event({
        trigger = 'immediate',
        func = (function()     
            if G.GAME.modifiers.debuff_played_cards then 
                for k, v in ipairs(scoring_hand) do v.ability.perma_debuff = true end
            end
        return true end)
      }))

  end
  
  G.FUNCS.draw_from_play_to_discard = function(e)
    local play_count = #G.play.cards
    local it = 1
    for k, v in ipairs(G.play.cards) do
        if (not v.shattered) and (not v.destroyed) then 
            
            local cards_to_hand = {}
            
            if G.jokers ~= nil then
                for _, joker in ipairs(G.jokers.cards) do
                    if joker.config.center.key == 'j_bunc_cellphone' and joker.ability.extra.active and not joker.debuff then
                        for __, card in ipairs(joker.ability.extra.cards_to_hand) do
                            table.insert(cards_to_hand, card)
                        end
                        break
                    end
                end
            end
            
            if __octopus_ne(cards_to_hand, {}) then
                local condition = false
                for _, card_to_hand in ipairs(cards_to_hand) do
                    if __octopus_eq(v, card_to_hand) then
                        condition = true
                    end
                end
                if condition then
                    draw_card(G.play,G.hand, it*100/play_count,'up', true, v)
                else
                    draw_card(G.play,G.discard, it*100/play_count,'down', false, v)
                end
            else
                draw_card(G.play,G.discard, it*100/play_count,'down', false, v)
            end
            
            it = it + 1
        end
    end
  end

  G.FUNCS.draw_from_play_to_hand = function(cards)
    local gold_count = #cards
    for i=1, gold_count do --draw cards from play
        if not cards[i].shattered and not cards[i].destroyed then
            draw_card(G.play,G.hand, i*100/gold_count,'up', true, cards[i])
        end
    end
  end
  
  G.FUNCS.draw_from_discard_to_deck = function(e)
    G.E_MANAGER:add_event(Event({
        trigger = 'immediate',
        func = function()
            local discard_count = #G.discard.cards
            for i=1, discard_count do --draw cards from deck
                draw_card(G.discard, G.deck, i*100/discard_count,'up', nil ,nil, 0.005, __octopus_eq(i%2, 0), nil, math.max((21-i)/20,0.7))
            end
            return true
        end
      }))
  end

  G.FUNCS.draw_from_hand_to_deck = function(e)
    local hand_count = #G.hand.cards
    for i=1, hand_count do --draw cards from deck
        draw_card(G.hand, G.deck, i*100/hand_count,'down', nil, nil,  0.08)
    end
  end
  
  G.FUNCS.draw_from_hand_to_discard = function(e)
    local hand_count = #G.hand.cards
    for i=1, hand_count do
        draw_card(G.hand,G.discard, i*100/hand_count,'down', nil, nil, 0.07)
    end
end

G.FUNCS.evaluate_round = function()
    total_cashout_rows = 0
    local pitch = 0.95
    local dollars = 0

    if __octopus_ge(G.GAME.chips - G.GAME.blind.chips, 0) then
        add_round_eval_row({dollars = G.GAME.blind.dollars, name='blind1', pitch = pitch})
        pitch = pitch + 0.06
        dollars = dollars + G.GAME.blind.dollars
    else
        add_round_eval_row({dollars = 0, name='blind1', pitch = pitch, saved = true})
        pitch = pitch + 0.06
    end

    G.E_MANAGER:add_event(Event({
        trigger = 'before',
        delay = 1.3*math.min(G.GAME.blind.dollars+2, 7)/2*0.15 + 0.5,
        func = function()
          G.GAME.blind:defeat()
          return true
        end
      }))
    delay(0.2)
    G.E_MANAGER:add_event(Event({
        func = function()
            ease_background_colour_blind(G.STATES.ROUND_EVAL, '')
            return true
        end
    }))
    SMODS.calculate_context{round_eval = true}
    G.GAME.selected_back:trigger_effect({context = 'eval'})

    if __octopus_gt(G.GAME.current_round.hands_left, 0) and not G.GAME.modifiers.no_extra_hand_money then
        add_round_eval_row({dollars = G.GAME.current_round.hands_left*(G.GAME.modifiers.money_per_hand or 1), disp = G.GAME.current_round.hands_left, bonus = true, name='hands', pitch = pitch})
        pitch = pitch + 0.06
        dollars = dollars + G.GAME.current_round.hands_left*(G.GAME.modifiers.money_per_hand or 1)
    end
    if __octopus_gt(G.GAME.current_round.discards_left, 0) and G.GAME.modifiers.money_per_discard then
        add_round_eval_row({dollars = G.GAME.current_round.discards_left*(G.GAME.modifiers.money_per_discard), disp = G.GAME.current_round.discards_left, bonus = true, name='discards', pitch = pitch})
        pitch = pitch + 0.06
        dollars = dollars +  G.GAME.current_round.discards_left*(G.GAME.modifiers.money_per_discard)
    end
    local i = 0
    for _, area in ipairs(SMODS.get_card_areas('jokers')) do
        for _, _card in ipairs(area.cards) do
            local ret, ret_opts = _card:calculate_dollar_bonus()
            ret_opts = ret_opts or {}
    
            -- TARGET: calc_dollar_bonus per card
            if ret then
                if not ret_opts.no_eval_row then
                    i = i+1
                    add_round_eval_row({dollars = ret, bonus = true, name='joker'..i, pitch = pitch, card = _card, loc_opts = ret_opts})
                    pitch = pitch + 0.06
                end
                dollars = dollars + ret
            end
        end
    end
    i = 0
    for _, target in ipairs(SMODS.get_card_areas('individual', 'calc_dollar_bonus')) do
        if type(target.object.calc_dollar_bonus) == 'function' then
            local ret, ret_opts = target.object:calc_dollar_bonus()
            ret_opts = ret_opts or {}
            local name
            
            -- TARGET: calc_dollar_bonus per individual object
            if ret then
                if not ret_opts.no_eval_row then
                    if ret_opts.text then
                        name = ret_opts.text
                    elseif (ret_opts.set or target.set) and (ret_opts.key or target.key) then
                        if ret_opts.set == "Challenge" or (not ret_opts.set and target.set == "Challenge") then
                            name = localize(ret_opts.key or target.key, 'challenge_names')
                        elseif (ret_opts.set == "Mod" or (not ret_opts.set and target.set == "Mod")) and not (G.localization.descriptions.Mod or {})[ret_opts.key or target.key] then
                            name = (SMODS.Mods[ret_opts.key or target.key] or {}).name
                        else
                            name = localize{type = 'name_text', set = ret_opts.set or target.set, key = ret_opts.key or target.key}
                        end
                    end
                    i = i+1
                    add_round_eval_row({dollars = ret, bonus = true, name='custom_individual'..i, pitch = pitch, text_colour = ret_opts.text_colour or G.C.FILTER, text = name or 'ERROR', text_scale = ret_opts.scale or 0.6})
                    pitch = pitch + 0.06
                end
                dollars = dollars + ret
            end
        end
    end
    for i = 1, #G.GAME.tags do
        local ret = G.GAME.tags[i]:apply_to_run({type = 'eval'})
        if ret then
            add_round_eval_row({dollars = ret.dollars, bonus = true, name='tag'..i, pitch = pitch, condition = ret.condition, pos = ret.pos, tag = ret.tag})
            pitch = pitch + 0.06
            dollars = dollars + ret.dollars
        end
    end
    if __octopus_ge(G.GAME.dollars, 5) and not G.GAME.modifiers.no_interest and G.GAME.cry_payload then
        add_round_eval_row({bonus = true, payload = G.GAME.cry_payload, name='interest_payload', pitch = pitch, dollars = G.GAME.interest_amount*G.GAME.cry_payload*math.min(math.floor(G.GAME.dollars/5), G.GAME.interest_cap/5)})
        pitch = pitch + 0.06
        if not G.GAME.seeded and not G.GAME.challenge then
            if __octopus_eq(G.GAME.interest_amount*math.min(math.floor(G.GAME.dollars/5), G.GAME.interest_cap/5), G.GAME.interest_amount*G.GAME.interest_cap/5) then
                G.PROFILES[G.SETTINGS.profile].career_stats.c_round_interest_cap_streak = G.PROFILES[G.SETTINGS.profile].career_stats.c_round_interest_cap_streak + 1
            else
                G.PROFILES[G.SETTINGS.profile].career_stats.c_round_interest_cap_streak = 0
            end
        end
        check_for_unlock({type = 'interest_streak'})
        dollars = dollars + G.GAME.interest_amount*G.GAME.cry_payload*math.min(math.floor(G.GAME.dollars/5), G.GAME.interest_cap/5)
        G.GAME.cry_payload = nil
    elseif __octopus_ge(G.GAME.dollars, 5) and not G.GAME.modifiers.no_interest then
        add_round_eval_row({bonus = true, name='interest', pitch = pitch, dollars = G.GAME.interest_amount*math.min(math.floor(G.GAME.dollars/5), G.GAME.interest_cap/5)})
        pitch = pitch + 0.06
        if (not G.GAME.seeded and not G.GAME.challenge) or SMODS.config.seeded_unlocks then
            if __octopus_eq(G.GAME.interest_amount*math.min(math.floor(G.GAME.dollars/5), G.GAME.interest_cap/5), G.GAME.interest_amount*G.GAME.interest_cap/5) then 
                G.PROFILES[G.SETTINGS.profile].career_stats.c_round_interest_cap_streak = G.PROFILES[G.SETTINGS.profile].career_stats.c_round_interest_cap_streak + 1
            else
                G.PROFILES[G.SETTINGS.profile].career_stats.c_round_interest_cap_streak = 0
            end
        end
        check_for_unlock({type = 'interest_streak'})
        dollars = dollars + G.GAME.interest_amount*math.min(math.floor(G.GAME.dollars/5), G.GAME.interest_cap/5)
    end

    SMODS.cashout_pitch = pitch; SMODS.cashout_index = i; SMODS.cashout_dollars = dollars
    SMODS.calculate_context({modify_final_cashout = true, amount = dollars})
    dollars = SMODS.cashout_dollars
    SMODS.cashout_pitch = nil; SMODS.cashout_index = nil; SMODS.cashout_dollars = nil

    pitch = pitch + 0.06

    if __octopus_gt(total_cashout_rows, 7) then
        local total_hidden = total_cashout_rows - 7
    
        G.E_MANAGER:add_event(Event({
            trigger = 'before',delay = 0.38,
            func = function()
                local hidden = {n=G.UIT.R, config={align = "cm"}, nodes={
                    {n=G.UIT.O, config={object = DynaText({
                        string = {localize{type = 'variable', key = 'cashout_hidden', vars = {total_hidden}}}, 
                        colours = {G.C.WHITE}, shadow = true, float = false, 
                        scale = 0.45,
                        font = G.LANGUAGES['en-us'].font, pop_in = 0
                    })}}
                }}
    
                G.round_eval:add_child(hidden, G.round_eval:get_UIE_by_ID('bonus_round_eval'))
                return true
            end
        }))
    end
    add_round_eval_row({name = 'bottom', dollars = dollars})
    Talisman.dollars = dollars
end

G.FUNCS.tutorial_controller = function()
    if G.F_SKIP_TUTORIAL then
        G.SETTINGS.tutorial_complete = true
        G.SETTINGS.tutorial_progress = nil
        return
    end
    G.SETTINGS.tutorial_progress = G.SETTINGS.tutorial_progress or 
    {
        forced_shop = {'j_joker', 'c_empress'},
        forced_voucher = 'v_grabber',
        forced_tags = {'tag_handy', 'tag_garbage'},
        hold_parts = {},
        completed_parts = {},
    }
    if not G.SETTINGS.paused and (not G.SETTINGS.tutorial_complete) then
        if __octopus_eq(G.STATE, G.STATES.BLIND_SELECT) and G.blind_select and not G.SETTINGS.tutorial_progress.completed_parts['small_blind'] then
            G.SETTINGS.tutorial_progress.section = 'small_blind'
            G.FUNCS.tutorial_part('small_blind')
            G.SETTINGS.tutorial_progress.completed_parts['small_blind']  = true
            G:save_progress()
        end
        if __octopus_eq(G.STATE, G.STATES.BLIND_SELECT) and G.blind_select and not G.SETTINGS.tutorial_progress.completed_parts['big_blind'] and __octopus_gt(G.GAME.round, 0) then
            G.SETTINGS.tutorial_progress.section = 'big_blind'
            G.FUNCS.tutorial_part('big_blind')
            G.SETTINGS.tutorial_progress.completed_parts['big_blind']  = true
            G.SETTINGS.tutorial_progress.forced_tags = nil
            G:save_progress()
        end
        if __octopus_eq(G.STATE, G.STATES.SELECTING_HAND) and not G.SETTINGS.tutorial_progress.completed_parts['second_hand'] and G.SETTINGS.tutorial_progress.hold_parts['big_blind'] then
            G.SETTINGS.tutorial_progress.section = 'second_hand'
            G.FUNCS.tutorial_part('second_hand')
            G.SETTINGS.tutorial_progress.completed_parts['second_hand']  = true
            G:save_progress()
        end
        if G.SETTINGS.tutorial_progress.hold_parts['second_hand'] then
            set_cloud_flag('tutorial_complete')
        end
        if not G.SETTINGS.tutorial_progress.completed_parts['first_hand_section'] then 
            if __octopus_eq(G.STATE, G.STATES.SELECTING_HAND) and not G.SETTINGS.tutorial_progress.completed_parts['first_hand'] then
                G.SETTINGS.tutorial_progress.section = 'first_hand'
                G.FUNCS.tutorial_part('first_hand')
                G.SETTINGS.tutorial_progress.completed_parts['first_hand']  = true
                G:save_progress()
            end
            if __octopus_eq(G.STATE, G.STATES.SELECTING_HAND) and not G.SETTINGS.tutorial_progress.completed_parts['first_hand_2'] and G.SETTINGS.tutorial_progress.hold_parts['first_hand']  then
                G.FUNCS.tutorial_part('first_hand_2')
                G.SETTINGS.tutorial_progress.completed_parts['first_hand_2']  = true
                G:save_progress()
            end
            if __octopus_eq(G.STATE, G.STATES.SELECTING_HAND) and not G.SETTINGS.tutorial_progress.completed_parts['first_hand_3'] and G.SETTINGS.tutorial_progress.hold_parts['first_hand_2']  then
                G.FUNCS.tutorial_part('first_hand_3')
                G.SETTINGS.tutorial_progress.completed_parts['first_hand_3']  = true
                G:save_progress()
            end
            if __octopus_eq(G.STATE, G.STATES.SELECTING_HAND) and not G.SETTINGS.tutorial_progress.completed_parts['first_hand_4'] and G.SETTINGS.tutorial_progress.hold_parts['first_hand_3']  then
                G.FUNCS.tutorial_part('first_hand_4')
                G.SETTINGS.tutorial_progress.completed_parts['first_hand_4']  = true
                G.SETTINGS.tutorial_progress.completed_parts['first_hand_section']  = true
                G:save_progress()
            end
        end
         if __octopus_eq(G.STATE, G.STATES.SHOP) and G.shop and __octopus_lt(G.shop.VT.y, 5) and not G.SETTINGS.tutorial_progress.completed_parts['shop_1'] then
            G.SETTINGS.tutorial_progress.section = 'shop'
            G.FUNCS.tutorial_part('shop_1')
            G.SETTINGS.tutorial_progress.completed_parts['shop_1']  = true
            G.SETTINGS.tutorial_progress.forced_voucher = nil
            G:save_progress()
        end
    end
end

G.FUNCS.tutorial_part = function(_part)
    analytic_event('tutorial_step',
        'demo_flag', not G.FTP_LOCKED,
        'current_step', _part or 'error',
        'language', G.SETTINGS.language or 'error')
    
    local step = 1
    --G.SETTINGS.paused = true
    if _part == 'small_blind' then 
        step = tutorial_info({
            text_key = 'sb_1',
            attach = {major = G.ROOM_ATTACH, type = 'cm', offset = {x = 0, y = 0}},
            step = step,
        })
        step = tutorial_info({
            text_key = 'sb_2',
            attach = {major = G.ROOM_ATTACH, type = 'cm', offset = {x = 0, y = 0}},
            step = step,
        })
        step = tutorial_info({
            text_key = 'sb_3',
            highlight = {
                G.blind_select.UIRoot.children[1].children[1].config.object:get_UIE_by_ID('blind_name'),
                G.blind_select.UIRoot.children[1].children[1].config.object:get_UIE_by_ID('blind_desc'),
            },
            attach = {major =  G.blind_select.UIRoot.children[1].children[1], type = 'tr', offset = {x = 2, y = 4}},
            step = step,
        })
        step = tutorial_info({
            text_key = 'sb_4',
            highlight = {
                G.blind_select.UIRoot.children[1].children[1]
            },
            snap_to = function() 
                if G.blind_select and G.blind_select.UIRoot and G.blind_select.UIRoot.children[1] and G.blind_select.UIRoot.children[1].children[1] and G.blind_select.UIRoot.children[1].children[1].config.object then 
                    return G.blind_select.UIRoot.children[1].children[1].config.object:get_UIE_by_ID('select_blind_button') end
                end,
            attach = {major =  G.blind_select.UIRoot.children[1].children[1], type = 'tr', offset = {x = 2, y = 4}},
            step = step,
            no_button = true,
            button_listen = 'select_blind'
        })
    elseif _part == 'big_blind' then 
        step = tutorial_info({
            text_key = 'bb_1',
            highlight = {
                G.blind_select.UIRoot.children[1].children[2].config.object:get_UIE_by_ID('blind_name'),
                G.blind_select.UIRoot.children[1].children[2].config.object:get_UIE_by_ID('blind_desc'),
            },
            hard_set = true,
            attach = {major =  G.HUD, type = 'cm', offset = {x = 0.7, y = -0.5}},
            step = step,
        })
        step = tutorial_info({
            text_key = 'bb_2',
            highlight = {
                G.blind_select.UIRoot.children[1].children[2].config.object:get_UIE_by_ID('blind_name'),
                G.blind_select.UIRoot.children[1].children[2].config.object:get_UIE_by_ID('tag_desc').parent,
            },
            disabled_buttons = {'skip_blind'},
            attach = {major =  G.HUD, type = 'cm', offset = {x = 0.7, y = -0.5}},
            step = step,
        })
        step = tutorial_info({
            text_key = 'bb_3',
            highlight = {
                G.blind_select.UIRoot.children[1].children[3].config.object:get_UIE_by_ID('blind_name'),
                G.blind_select.UIRoot.children[1].children[3].config.object:get_UIE_by_ID('blind_desc'),
            },
            attach = {major =  G.HUD, type = 'cm', offset = {x = 0.7, y = -0.5}},
            step = step,
        })
        step = tutorial_info({
            text_key = 'bb_4',
            highlight = {
                G.blind_select.UIRoot.children[1].children[3].config.object:get_UIE_by_ID('blind_name'),
                G.blind_select.UIRoot.children[1].children[3].config.object:get_UIE_by_ID('blind_desc'),
                G.blind_select.UIRoot.children[1].children[3].config.object:get_UIE_by_ID('blind_extras'),
                G.HUD:get_UIE_by_ID('hud_ante')
            },
            attach = {major =  G.HUD, type = 'cm', offset = {x = 0.7, y = -0.5}},
            step = step,
        })
        step = tutorial_info({
            text_key = 'bb_5',
            loc_vars = {G.GAME.win_ante},
            highlight = {
                G.blind_select,
                G.HUD:get_UIE_by_ID('hud_ante')
            },
            attach = {major =  G.HUD, type = 'cm', offset = {x = 0.7, y = -0.5}},
            step = step,
            no_button = true,
            snap_to = function() 
                if G.blind_select and G.blind_select.UIRoot and G.blind_select.UIRoot.children[1] and G.blind_select.UIRoot.children[1].children[2] and
                G.blind_select.UIRoot.children[1].children[2].config.object then 
                    return G.blind_select.UIRoot.children[1].children[2].config.object:get_UIE_by_ID('select_blind_button') end
                end,
            button_listen = 'select_blind'
        })
    elseif _part == 'first_hand' then
        step = tutorial_info({
            text_key = 'fh_1',
            attach = {major = G.ROOM_ATTACH, type = 'cm', offset = {x = 0, y = 0}},
            step = step,
        })
        step = tutorial_info({
            text_key = 'fh_2',
            highlight = {
                G.HUD:get_UIE_by_ID('hand_text_area')
            },
            attach = {major = G.ROOM_ATTACH, type = 'cm', offset = {x = 0, y = 0}},
            step = step,
        })
        step = tutorial_info({
            text_key = 'fh_3',
            attach = {major = G.ROOM_ATTACH, type = 'cm', offset = {x = 0, y = 0}},
            highlight = {
                G.HUD:get_UIE_by_ID('run_info_button')
            },
            no_button = true,
            button_listen = 'run_info',
            snap_to = function() return G.HUD:get_UIE_by_ID('run_info_button') end,
            step = step,
        })
    elseif _part == 'first_hand_2' then
        step = tutorial_info({
            hard_set = true,
            text_key = 'fh_4',
            highlight = {
                G.hand,
                G.HUD:get_UIE_by_ID('run_info_button')
            },
            attach = {major = G.hand, type = 'cl', offset = {x = -1, y = -0.3}},
            snap_to = function() return G.hand.cards[1] end,
            step = step,
        })
        step = tutorial_info({
            text_key = 'fh_5',
            highlight = {
                G.hand,
                G.buttons:get_UIE_by_ID('play_button'),
                G.HUD:get_UIE_by_ID('run_info_button')
            },
            attach = {major = G.hand, type = 'cl', offset = {x = -1, y = -0.3}},
            no_button = true,
            button_listen = 'play_cards_from_highlighted',
            step = step,
        })
    elseif _part == 'first_hand_3' then
        step = tutorial_info({
            hard_set = true,
            text_key = 'fh_6',
            highlight = {
                G.hand,
                G.buttons:get_UIE_by_ID('discard_button'),
                G.HUD:get_UIE_by_ID('run_info_button')
            },
            attach = {major = G.hand, type = 'cl', offset = {x = -1, y = -0.3}},
            no_button = true,
            button_listen = 'discard_cards_from_highlighted',
            step = step,
        })
    elseif _part == 'first_hand_4' then
        step = tutorial_info({
            hard_set = true,
            text_key = 'fh_7',
            highlight = {
                G.HUD:get_UIE_by_ID('hud_hands').parent,
            },
            attach = {major = G.ROOM_ATTACH, type = 'cm', offset = {x = 0, y = 0}},
            step = step,
        })
        step = tutorial_info({
            text_key = 'fh_8',
            highlight = {
                G.HUD:get_UIE_by_ID('hud_hands').parent,
                G.HUD:get_UIE_by_ID('row_dollars_chips'),
                G.HUD_blind
            },
            attach = {major = G.ROOM_ATTACH, type = 'cm', offset = {x = 0, y = 0}},
            step = step,
        })
    elseif _part == 'second_hand' then
        step = tutorial_info({
            text_key = 'sh_1',
            hard_set = true,
            highlight = {
                G.jokers
            },
            attach = {major =  G.HUD, type = 'cm', offset = {x = 0.7, y = -0.5}},
            step = step,
        })
        local empress = find_joker('The Empress')[1]
        if empress then 
            step = tutorial_info({
                text_key = 'sh_2',
                highlight = {
                    empress
                },
                attach = {major =  G.HUD, type = 'cm', offset = {x = 0.7, y = -0.5}},
                step = step,
            })
            step = tutorial_info({
                text_key = 'sh_3',
                attach = {major =  G.HUD, type = 'cm', offset = {x = 0.7, y = -0.5}},
                highlight = {
                    empress,
                    G.hand
                },
                no_button = true,
                button_listen = 'use_card',
                snap_to = function() return G.hand.cards[1] end,
                step = step,
            })
        end
    elseif _part == 'shop_1' then
        step = tutorial_info({
            hard_set = true,
            text_key = 's_1',
            highlight = {
                G.SHOP_SIGN,
                G.HUD:get_UIE_by_ID('dollar_text_UI').parent.parent.parent
            },
            attach = {major = G.shop, type = 'tm', offset = {x = 0, y = 4}},
            step = step,
        })
        step = tutorial_info({
            text_key = 's_2',
            highlight = function() return {
                G.SHOP_SIGN,
                G.HUD:get_UIE_by_ID('dollar_text_UI').parent.parent.parent,
                G.shop_jokers.cards[2],
            } end,
            snap_to = function() return G.shop_jokers.cards[2] end,
            attach = {major = G.shop, type = 'tr', offset = {x = -0.5, y = 5}},
            no_button = true,
            button_listen = 'buy_from_shop',
            step = step,
        })
        step = tutorial_info({
            text_key = 's_3',
            loc_vars = {#G.P_CENTER_POOLS.Joker},
            highlight = function() return {
                G.SHOP_SIGN,
                G.HUD:get_UIE_by_ID('dollar_text_UI').parent.parent.parent,
                G.jokers.cards[1],
            } end,
            attach = {major = G.shop, type = 'tm', offset = {x = 0, y = 6}},
            step = step,
        })
        step = tutorial_info({
            text_key = 's_4',
            highlight = function() return {
                G.SHOP_SIGN,
                G.HUD:get_UIE_by_ID('dollar_text_UI').parent.parent.parent,
                G.jokers.cards[1],
            } end,
            attach = {major = G.shop, type = 'tm', offset = {x = 0, y = 6}},
            step = step,
        })
        step = tutorial_info({
            text_key = 's_5',
            highlight = function() return {
                G.SHOP_SIGN,
                G.HUD:get_UIE_by_ID('dollar_text_UI').parent.parent.parent,
                G.jokers,
            } end,
            attach = {major = G.shop, type = 'tm', offset = {x = 0, y = 6}},
            step = step,
        })
        step = tutorial_info({
            text_key = 's_6',
            highlight = function() return {
                G.SHOP_SIGN,
                G.HUD:get_UIE_by_ID('dollar_text_UI').parent.parent.parent,
                G.shop_jokers.cards[1],
            } end,
            snap_to = function() return G.shop_jokers.cards[1] end,
            no_button = true,
            button_listen = 'buy_from_shop',
            attach = {major = G.shop, type = 'tr', offset = {x = -0.5, y = 5}},
            step = step,
        })
        step = tutorial_info({
            text_key = 's_7',
            highlight = function() return {
                G.SHOP_SIGN,
                G.HUD:get_UIE_by_ID('dollar_text_UI').parent.parent.parent,
                G.consumeables.cards[#G.consumeables.cards],
            } end,
            attach = {major = G.shop, type = 'tm', offset = {x = 0, y = 6}},
            step = step,
        })
        step = tutorial_info({
            text_key = 's_8',
            highlight = function() return {
                G.SHOP_SIGN,
                G.HUD:get_UIE_by_ID('dollar_text_UI').parent.parent.parent,
                G.consumeables
            } end,
            attach = {major = G.shop, type = 'tm', offset = {x = 0, y = 6}},
            step = step,
        })
        step = tutorial_info({
            text_key = 's_9',
            highlight = function() return {
                G.SHOP_SIGN,
                G.HUD:get_UIE_by_ID('dollar_text_UI').parent.parent.parent,
                G.shop_vouchers,
            } end,
            snap_to = function() return G.shop_vouchers.cards[1] end,
            attach = {major = G.shop, type = 'tr', offset = {x = -4, y = 5}},
            step = step,
        })
        step = tutorial_info({
            text_key = 's_10',
            highlight = function() return {
                G.SHOP_SIGN,
                G.HUD:get_UIE_by_ID('dollar_text_UI').parent.parent.parent,
                G.shop_vouchers,
            } end,
            attach = {major = G.shop, type = 'tr', offset = {x = -4, y = 5}},
            step = step,
        })
        step = tutorial_info({
            text_key = 's_11',
            highlight = function() return {
                G.SHOP_SIGN,
                G.HUD:get_UIE_by_ID('dollar_text_UI').parent.parent.parent,
                G.shop_booster,
            } end,
            snap_to = function() return G.shop_booster.cards[1] end,
            attach = {major = G.shop, type = 'tl', offset = {x = 3, y = 6}},
            step = step,
        })
        step = tutorial_info({
            text_key = 's_12',
            highlight = function() return {
                G.shop:get_UIE_by_ID('next_round_button'),
            } end,
            snap_to = function() if G.shop then return G.shop:get_UIE_by_ID('next_round_button') end end,
            no_button = true,
            button_listen = 'toggle_shop',
            attach = {major = G.shop, type = 'tm', offset = {x = 0, y = 6}},
            step = step,
        })
    end

    
    G.E_MANAGER:add_event(Event({
        blockable = false,
        timer = 'REAL',
        func = function()
            if (__octopus_eq(G.OVERLAY_TUTORIAL.step, step) and
            not G.OVERLAY_TUTORIAL.step_complete) or G.OVERLAY_TUTORIAL.skip_steps then
                if G.OVERLAY_TUTORIAL.Jimbo then G.OVERLAY_TUTORIAL.Jimbo:remove() end
                if G.OVERLAY_TUTORIAL.content then G.OVERLAY_TUTORIAL.content:remove() end
                G.OVERLAY_TUTORIAL:remove()
                G.OVERLAY_TUTORIAL = nil
                G.SETTINGS.tutorial_progress.hold_parts[_part]=true
                return true
            end
            return __octopus_gt(G.OVERLAY_TUTORIAL.step, step) or G.OVERLAY_TUTORIAL.skip_steps
        end
    }), 'tutorial') 
    G.SETTINGS.paused = false
end
