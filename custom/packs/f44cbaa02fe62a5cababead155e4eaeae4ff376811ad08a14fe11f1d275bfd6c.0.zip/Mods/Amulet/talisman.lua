-- Amulet modules are pre-mounted in the browser archive.
require("talisman.configinit")
require("talisman.effects")
require("talisman.globals")
require("talisman.localization")
require("talisman.configtab")
require("talisman.noanims")
require("talisman.gradients")
require("talisman.sanitizer")
require("talisman.debug")
if not Talisman.config_file.disable_omega then
    require("talisman.break_inf")
end
if not Talisman.F_NO_COROUTINE then
    require("talisman.coroutine")
end
