PB_UTIL.EGO_Gift {
  key = 'smokes_and_wires',
  config = {
    sin = 'wrath',
    xmult = (LiminalRandomizer and LiminalRandomizer.literal("Mods/paperback/content/ego_gift/smokes_and_wires.lua:91:xmult", 2) or 2),
  },
  atlas = 'ego_gift_atlas',
  pos = { x = 0, y = 2 },
  soul_pos = { x = 0, y = 5 },


  ego_gift_calc = function(self, card, context)
    if context.joker_main then
      if __octopus_eq(G.GAME.current_round.hands_left, 0) then
        return {
          xmult = card.ability.xmult
        }
      end
    end
  end,

  ego_loc_vars = function(self, info_queue, card)
    return { vars = {
      card.ability.xmult
    } }
  end,
}
