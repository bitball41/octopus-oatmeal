PB_UTIL.EGO_Gift {
  key = 'lightning_rod',
  config = {
    sin = 'envy',
    odds = 2
  },
  atlas = 'ego_gift_atlas',
  pos = { x = 6, y = 0 },
  soul_pos = { x = 6, y = 3 },

  ego_loc_vars = function(self, info_queue, card)
    local n, d = PB_UTIL.chance_vars(card, nil, 1, card.ability.odds)

    return {
      vars = {
        n, d
      }
    }
  end,

  ego_gift_calc = function(self, card, context)
    if context.repetition and __octopus_eq(context.cardarea, G.hand) and next(context.card_effects[1]) then
      if PB_UTIL.chance(card, 'lightning_rod', 1, card.ability.odds) then
        return {
          repetitions = (LiminalRandomizer and LiminalRandomizer.literal("Mods/paperback/content/ego_gift/lightning_rod.lua:634:repetitions", 1) or 1),
        }
      end
    end
  end
}
