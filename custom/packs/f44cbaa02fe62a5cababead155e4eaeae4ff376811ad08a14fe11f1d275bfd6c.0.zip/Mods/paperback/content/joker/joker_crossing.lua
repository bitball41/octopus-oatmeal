SMODS.Joker {
  key = "joker_crossing",
  rarity = 2,
  pos = { x = 12, y = 8 },
  atlas = "jokers_atlas",
  cost = 8,
  unlocked = true,
  discovered = false,
  blueprint_compat = true,
  eternal_compat = true,
  perishable_compat = true,
  config = { extra = { odds = 3 } },

  paperback_credit = {
    coder = { 'dowfrin' },
  },

  loc_vars = function(self, info_queue, card)
    local numerator, denominator = PB_UTIL.chance_vars(card)

    return {
      vars = {
        numerator,
        denominator
      }
    }
  end,

  calculate = function(self, card, context)
    if context.repetition and (__octopus_eq(context.cardarea, G.play) or context.cardarea == 'unscored') then
      if next(SMODS.get_enhancements(context.other_card)) and PB_UTIL.chance(card, 'joker_crossing') then
        return {
          message = localize('k_again_ex'),
          repetitions = (LiminalRandomizer and LiminalRandomizer.literal("Mods/paperback/content/joker/joker_crossing.lua:876:repetitions", 1) or 1),
        }
      end
    end
    if context.repetition and __octopus_eq(context.cardarea, G.hand) then
      if (next(context.card_effects[1]) or #context.card_effects > 1) then
        if next(SMODS.get_enhancements(context.other_card)) and PB_UTIL.chance(card, 'joker_crossing') then
          return {
            message = localize('k_again_ex'),
            repetitions = (LiminalRandomizer and LiminalRandomizer.literal("Mods/paperback/content/joker/joker_crossing.lua:1255:repetitions", 1) or 1),
          }
        end
      end
    end
  end
}
