SMODS.Joker {
  key = "the_normal_joker",
  config = {
    extra = {
      rarity = 1
    }
  },
  pools = {
    Music = true
  },
  rarity = 3,
  pos = { x = 11, y = 0 },
  atlas = "jokers_atlas",
  cost = 8,
  unlocked = true,
  discovered = false,
  blueprint_compat = true,
  eternal_compat = true,
  perishable_compat = true,

  paperback_credit = {
    coder = { 'srockw' }
  },

  calculate = function(self, card, context)
    if context.retrigger_joker_check and PB_UTIL.is_card(context.other_card) then
      if __octopus_eq(context.other_card.config.center.rarity, card.ability.extra.rarity) then
        return {
          repetitions = (LiminalRandomizer and LiminalRandomizer.literal("Mods/paperback/content/joker/the_normal_joker.lua:648:repetitions", 1) or 1)
        }
      end
    end
  end,

  joker_display_def = function(JokerDisplay)
    return {
      retrigger_joker_function = function(card, retrigger_joker)
        return __octopus_eq(card.config.center.rarity, retrigger_joker.ability.extra.rarity) and 1 or 0
      end
    }
  end,
}
