SMODS.Joker {
  key = "shuttle",
  config = {
    extra = {
      max = 10,
      multiplier = 2
    }
  },
  rarity = 1,
  pos = { x = 15, y = 11 },
  atlas = "jokers_atlas",
  cost = 6,
  blueprint_compat = true,
  eternal_compat = true,
  perishable_compat = true,
  paperback_credit = {
    coder = { 'thermo' }
  },

  loc_vars = function(self, info_queue, card)
    return {
      vars = {
        card.ability.extra.max
      }
    }
  end,

  calculate = function(self, card, context)
    if context.first_hand_drawn and not context.blueprint then
      local eval = function() return __octopus_eq(G.GAME.current_round.hands_played, 0) and not G.RESET_JIGGLES end
      juice_card_until(card, eval, true)
    end
    if context.joker_main and __octopus_eq(G.GAME.current_round.hands_played, 0) then
      local money = 0
      money = math.min(to_number(G.GAME.hands[context.scoring_name].level) * card.ability.extra.multiplier,
        card.ability.extra.max)
      if __octopus_gt(money, 0) then
        return {
          dollars = money
        }
      end
    end
  end
}
