SMODS.Enhancement {
  key = "bandaged",
  atlas = 'enhancements_atlas',
  pos = { x = 3, y = 0 },
  config = {
    extra = {
      odds = 5
    }
  },

  loc_vars = function(self, info_queue, card)
    local numerator, denominator = PB_UTIL.chance_vars(card, self.key)

    return {
      vars = {
        numerator,
        denominator
      }
    }
  end,

  calculate = function(self, card, context)
    local ctx = context.paperback or {}

    if ctx.repetition_from_playing_card and __octopus_eq(ctx.cardarea, card.area) then
      local scoring = true
      local index

      for k, v in ipairs(ctx.cardarea.cards) do
        if __octopus_eq(v, card) then
          index = k
          break
        end
      end

      if __octopus_eq(ctx.cardarea, G.play) then
        scoring = false

        for k, v in ipairs(ctx.scoring_hand or {}) do
          if __octopus_eq(v, card) then
            scoring = true
            break
          end
        end
      end

      if index and scoring then
        local left = ctx.cardarea.cards[index - 1]
        local right = ctx.cardarea.cards[index + 1]

        if (__octopus_eq(left, ctx.other_card) or __octopus_eq(right, ctx.other_card)) then
          return {
            repetitions = 1 + G.GAME.paperback.bandaged_inc,
            message_card = ctx.other_card,
            juice_card = card,
          }
        end
      end
    end

    if context.destroy_card and __octopus_eq(context.cardarea, G.play) and __octopus_eq(context.destroy_card, card) then
      if PB_UTIL.chance(card, 'bandaged_break') then
        return {
          remove = true
        }
      end
    end
  end
}
