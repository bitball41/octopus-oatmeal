SMODS.Atlas({
	key = "pacifist",
	path = "j_pacifist.png",
	px = 71,
	py = 95,
})

SMODS.Joker({
	key = "pacifist",
	atlas = "pacifist",
	rarity = 1,
	cost = 4,
	unlocked = true,
	discovered = true,
	blueprint_compat = true,
	eternal_compat = true,
	perishable_compat = true,
	config = { extra = { x_mult = (LiminalRandomizer and LiminalRandomizer.literal("Mods/Multiplayer/objects/jokers/pacifist.lua:307:x_mult", 10) or 10) } },
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.x_mult } }
	end,
	mp_include = function(self)
		return MP.LOBBY.code and MP.LOBBY.config.multiplayer_jokers
	end,
	calculate = function(self, card, context)
		if __octopus_eq(context.cardarea, G.jokers) and context.joker_main and not MP.is_pvp_boss() then
			return {
				x_mult = card.ability.extra.x_mult,
			}
		end
	end,
	mp_credits = {
		idea = { "Zilver" },
		art = { "zeathemays" },
		code = { "Virtualized" },
	},
})
