local nfs = require 'browser.nativefs'
nfs.getNormalizedPath = function(path) return (path:gsub("\\", "/"):gsub("/%./", "/")) end
local newFileData = nfs.newFileData
nfs.newFileData = function(path)
    if not nfs.getInfo(path) then return nil, 'File not found: ' .. path end
    return newFileData(path)
end
package.loaded['SMODS.https'] = {asyncRequest=function(_, callback) callback(0, nil, {}) end}
