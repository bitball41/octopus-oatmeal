return {
  descriptions = {
    Back = {
      b_paperback_paper = {
        name = "Paper Deck",
        text = {
          "{C:legendary}Paperback{C:attention} Jokers{} are {C:attention}3X",
          "more likely to appear,",
          "start run with the",
          "{C:attention,T:j_paperback_shopping_center}#1#{} Joker"
        }
      },
      b_paperback_proud = {
        name = "Proud Deck",
        text = {
          "Start with a full set of",
          "{C:hearts}Hearts{}, {C:diamonds}Diamonds{}, {C:spades}Spades",
          "{C:clubs}Clubs{}, {C:paperback_crowns}Crowns{} and {C:paperback_stars}Stars"
        },
        unlock = {
          "Play a {C:attention}Spectrum{}"
        }
      },
      b_paperback_silver = {
        name = "Silver Deck",
        text = {
          "Start run with the",
          "{C:paperback_minor_arcana,T:v_paperback_celtic_cross}#1#{} voucher",
          "and a {C:paperback_minor_arcana,T:c_paperback_nine_of_cups}#2#"
        },
        unlock = {
          "Discover {C:attention}#1#{}",
          "{C:paperback_minor_arcana,E:1}Minor Arcana{} cards"
        },
      },
      b_paperback_dreamer = {
        name = "Dreamer Deck",
        text = {
          "Start run with a {C:paperback_temporary}temporary",
          "{C:paperback_minor_arcana,T:c_paperback_apostle_of_wands}#1#",
          "{C:attention}#2#{} Joker slot"
        },
        unlock = {
          "Win a run with any",
          "deck on at least",
          "{V:1}#1#{} difficulty",
        }
      },
      b_paperback_antique = {
        name = "Antique Deck",
        text = {
          "{C:tarot}Arcana Packs{} no longer",
          "appear in the shop",
          "{C:paperback_minor_arcana}Minor Arcana Packs",
          "are {C:attention}3X{} more common"
        },
        unlock = {
          "Discover every",
          "{C:paperback_minor_arcana,E:1}Minor Arcana{} card"
        },
      },
      b_paperback_passionate = {
        name = "Passionate Deck",
        text = {
          "After defeating each",
          "{C:attention}Boss Blind{}, gain a",
          "{C:attention,T:tag_paperback_high_risk}#1#",
          "Earn no {C:money}Interest"
        },
        unlock = {
          "Win a run with any",
          "deck on at least",
          "{V:1}#1#{} difficulty",
        }
      },
      b_paperback_shimmering = {
        name = "Shimmering Deck",
        text = {
          "{C:attention}+#1#{} consumable slot for",
          "every unique {C:attention}Sin{} owned",
          "{C:red}#2#{} Joker Slots",
          "{C:paperback_ego_gift}E.G.O Gift Extraction Packs{}",
          "are {C:attention}5X{} more common"
        },
        unlock = {
          "Sell {C:attention}#1#{}",
          "{C:paperback_ego_gift}E.G.O Gifts{}"
        },
      },
    },
    Blind = {
      bl_paperback_quarter = {
        name = "The Quarter",
        text = {
          "#1# in #2# cards",
          "are debuffed"
        },
      },
      bl_paperback_half = {
        name = 'The Half',
        text = {
          'Halves all listed',
          'probabilities'
        }
      },
      bl_paperback_whole = {
        name = 'The Whole',
        text = {
          'Unscored ranks this',
          'Ante are debuffed'
        }
      },
      bl_paperback_rest = {
        name = 'The Rest',
        text = {
          '#1# in #2# numbered cards',
          'are drawn face down'
        }
      },
      bl_paperback_flat = {
        name = 'The Flat',
        text = {
          'Decrease rank of',
          'played cards'
        }
      },

      bl_paperback_sharp = {
        name = 'The Sharp',
        text = {
          'Increase rank of',
          'played cards'
        }
      },
      bl_paperback_natural = {
        name = 'The Natural',
        text = {
          'Play lowest level',
          'poker hand, or else',
          'debuff scored cards'
        }
      },
      bl_paperback_coda = {
        name = 'The Coda',
        text = {
          'Cards and Jokers',
          'cannot be moved',
        }
      },
      bl_paperback_hold = {
        name = "The Hold",
        text = {
          "All cards are face down;",
          "cards played face down",
          "are redrawn face up",
          "{s:0.8}+#1# Hand{}"
        }
      },
      bl_paperback_glissando = {
        name = "The Glissando",
        text = {
          "Ranks below the highest",
          "rank scored this round",
          "are debuffed"
        }
      },
      bl_paperback_misty_bass = {
        name = "Misty Bass",
        text = {
          "Shuffles all Jokers and",
          "pins the leftmost one"
        }
      },
      bl_paperback_taupe_treble = {
        name = 'Taupe Treble',
        text = {
          'Unenhanced cards',
          'are debuffed'
        }
      },
    },
    Joker = {
      j_paperback_showdown = {
        name = "Showdown",
        text = {
          "{V:1}#1#{} and {V:2}#2#{} {C:attention}held",
          "{C:attention}in hand{} have a {C:green}#3# in #4#",
          "chance to earn {C:money}$#5#",
        }
      },
      j_paperback_golden_egg = {
        name = "Golden Egg",
        text = {
          "When a {C:attention}secret hand{} is played,",
          "earn the sell value of",
          "the {C:attention}Joker{} to the right"
        },
        unlock = {
          "Win a run with a",
          "{C:attention,E:1}secret hand{} as your",
          "most played hand"
        }
      },
      j_paperback_burning_pact = {
        name = "Burning Pact",
        text = {
          "If a {C:attention}discard{} has only {C:attention}#1#{} card,",
          "draw {C:attention}#2#{} additional cards"
        }
      },
      j_paperback_blade_dance = {
        name = "Blade Dance",
        text = {
          "When {C:attention}Blind{} is selected,",
          "add {C:attention}#1#{} random {C:paperback_temporary}temporary",
          "{C:attention}#2#s{} to your hand"
        }
      },
      j_paperback_claw = {
        name = "Claw",
        text = {
          "Scored {C:attention}#1#s{} give {C:mult}+#4#{} Mult,",
          "{C:mult}+#2#{} more Mult for each",
          "previously scored {C:attention}#1#{} this round",
          "{C:inactive}(Currently {C:mult}+#3#{C:inactive} Mult)"
        }
      },
      j_paperback_chaplin = {
        name = "Chaplin",
        text = {
          "When buying a {C:attention}Voucher{}, also",
          "redeem the {C:attention}upgraded{} version"
        },
        unlock = {
          "{E:1,s:1.3}?????",
        }
      },
      j_paperback_milk_tea = {
        name = "Milk Tea",
        text = {
          "{C:purple}Balance{} {C:attention}#1#%{} of {C:chips}Chips{} and {C:mult}Mult",
          "Reduces by {C:attention}#2#%{} if a hand's {C:attention{}final{}",
          "{C:mult}Mult{} ends up {C:attention}greater{} than its {C:chips}Chips"
        }
      },
      j_paperback_nichola = {
        name = "Nichola",
        text = {
          "After scoring played cards,",
          "score {C:attention}face{} cards {C:attention}held in hand{}"
        },
        unlock = {
          "{E:1,s:1.3}?????",
        }
      },
      j_paperback_the_dynasty = {
        name = "The Dynasty",
        text = {
          "{X:mult,C:white}X#1#{} Mult if played",
          "hand contains",
          "a {C:attention}#2#"
        }
      },
      j_paperback_lurid_joker = {
        name = "Lurid Joker",
        text = {
          "{C:chips}+#1#{} Chips if played",
          "hand contains",
          "a {C:attention}#2#"
        }
      },
      j_paperback_zealous_joker = {
        name = "Zealous Joker",
        text = {
          "{C:mult}+#1#{} Mult if played",
          "hand contains",
          "a {C:attention}#2#"
        }
      },
      j_paperback_deviled_egg = {
        name = "Deviled Egg",
        text = {
          "The first scored card",
          "each round becomes {C:attention}Gold{}.",
          "Eaten in {C:attention}#1#{} rounds"
        }
      },
      j_paperback_golden_apple = {
        name = "Golden Apple",
        text = {
          "Earn {C:money}$#1#{} for each {C:attention}enhanced{}",
          "card in your deck at the",
          "end of the next {C:attention}#2#{} rounds",
          "{C:inactive}(Currently {C:money}$#3#{C:inactive})",
        },
        unlock = {
          "Have {C:attention}#1#{} or more {C:attention}Gold{}",
          "{C:attention}Aces{} in your deck",
        }
      },
      j_paperback_pear = {
        name = "Pear",
        text = {
          "This Joker gains {C:chips}+#2#{} Chips if played",
          "hand contains a {C:attention}#1#{}. Otherwise,",
          "this Joker loses {C:chips}-#3#{} Chips.",
          "Eaten if Chips fall below 0",
          "{C:inactive}(Currently {C:chips}+#4#{C:inactive} Chips)"
        }
      },
      j_paperback_teapot = {
        name = "Teapot",
        text = {
          "This Joker gains {C:blue}+#1#{} Chips whenever",
          "a {C:attention}#2#{} is {C:attention}scored",
          "{C:inactive}(Currently {C:blue}+#3#{C:inactive} Chips)"
        }
      },
      j_paperback_the_one_who_waits = {
        name = "The One Who Waits",
        text = {
          "When a {V:1}#1#{} is scored,",
          "{C:green}#2# in #3#{} chance this Joker gains {X:mult,C:white}X#4#{} Mult",
          "{C:inactive}(Currently {X:mult,C:white}X#8#{C:inactive} Mult)",
          "{C:green}#5# in #6#{} chance to create a {C:tarot}#7#{} Tarot",
          "{C:inactive}(Must have room)",
        }
      },
      j_paperback_blood_rain = {
        name = "Blood Rain",
        text = {
          "{C:attention}#1#s{} give {C:mult}Mult{} equal",
          "to the {C:attention}rank{} of held cards",
          "instead of giving {C:chips}Chips"
        }
      },
      j_paperback_pinot_noir = {
        name = "Pinot Noir",
        text = {
          "The next {C:attention}#1#{} times a",
          "{C:attention}#2#{} triggers, it",
          "gives {C:mult}+#3#{} more permanent Mult"
        }
      },
      j_paperback_jestosterone = {
        name = "Jestosterone",
        text = {
          "Scored {C:attention}#1#s{} become {C:attention}#2#s{}"
        }
      },
      j_paperback_jestrogen = {
        name = "Jestrogen",
        text = {
          "Scored {C:attention}#1#s{} and {C:attention}#2#s{} become {C:attention}#3#s{}"
        }
      },
      j_paperback_langely = {
        name = "L'angely",
        text = {
          "Earn {C:attention}half{} the {C:money}sell value{} of all",
          "Jokers when defeating a {C:attention}Big Blind{}.",
          "Earn the {C:attention}full{} {C:money}sell value{} of all",
          "Jokers when defeating a {C:attention}Boss Blind{}",
        },
        unlock = {
          "{E:1,s:1.3}?????",
        }

      },
      j_paperback_pedrillo = {
        name = "Pedrillo",
        text = {
          "Scored {C:attention}Queens{}",
          "create a {C:planet}Planet{} card",
          "for played {C:attention}poker hand",
          "{C:inactive}(Must have room)"
        },
        unlock = {
          "{E:1,s:1.3}?????",
        }
      },
      j_paperback_double_dutchman = {
        name = "Double Dutchman",
        text = {
          "For the next {C:attention}#4#{} hands,",
          "each card {C:attention}held in hand{} has a",
          "{C:green}#1# in #2#{} chance to get a random {C:attention}enhancement{}",
          "and a {C:green}#1# in #3#{} chance to get a random {C:attention}seal{}"
        }
      },
      j_paperback_one_sin_and_hundreds_of_good_deeds = {
        name = "One Sin and Hundreds of Good Deeds",
        text = {
          "Scored {C:attention}3s{} and {C:attention}rankless{} cards",
          "give {C:mult}+#1#{} Mult",
          '{C:inactive}"It feeds on evil"',
        },
      },
      j_paperback_one_sin_and_hundreds_of_good_deeds_fed = {
        name = "{C:red}One Sin and Hundreds of Good Deeds{}",
        text = {
          "Scored {C:attention}3s{} and {C:attention}rankless{} cards",
          "give {C:mult}+#1#{} Mult for each",
          "remaining card in deck",
          "{C:inactive}(Currently {C:mult}+#2#{}{C:inactive})",
        },
      },
      j_paperback_white_night = {
        name = "WhiteNight",
        text = {
          "Scored {C:attention}Apostles{} give {X:mult,C:white}X#1#{} Mult.",
          "Scored non-{C:attention}Apostles{} are {C:red}destroyed{}.",
          "Playing a hand with no {C:attention}Apostles{}",
          "{C:red}destroys{} a random Joker.",
          "Discarded {C:attention}Apostles{} are {C:red}destroyed{}"
        },
        unlock = {
          "Have #1# or more",
          "{C:attention,E:1}Apostles{} in",
          "your deck"
        }
      },
      j_paperback_as_above_so_below = {
        name = "As Above, So Below",
        text = {
          "Playing a {C:attention}5{}-card poker hand with an",
          "{C:attention}Apostle{} creates a {C:purple}Tarot{} card,",
          "if poker hand also contains a {C:attention}Straight{}",
          "create a {C:spectral}Spectral{} card instead",
          "{C:inactive}(Must have room)"
        },
        unlock = {
          "Play a {C:attention,E:1}Rapture{}"
        }
      },
      j_paperback_plague_doctor = {
        name = "Plague Doctor",
        text = {
          "If played hand is a #2#,",
          "convert the scoring card into",
          "an {C:attention}Apostle{}. Each {C:attention}Apostle{}",
          "held in hand gives {X:mult,C:white}X#1#{} Mult"
        },
        unlock = {
          "Discover {C:attention}#1#{}",
          "{C:paperback_ego_gift,E:1}E.G.O Gifts{}"
        },
      },
      j_paperback_king_me = {
        name = "King Me",
        text = {
          "Scored non-{C:attention}King{} {V:1}#1#{}",
          "increase their rank by {C:attention}#2#",
        }
      },
      j_paperback_gambit = {
        name = "Gambit",
        text = {
          "If played hand contains a scoring {V:1}#1#,",
          "the first scored {V:1}#1#{} {C:attention}destroys{}",
          "the first non-{V:1}#1#{} held in hand",
          "and gains {C:attention}twice{} its {C:chips}Chip value{}",
        }
      },
      j_paperback_solar_eclipse = {
        name = "Solar Eclipse",
        text = {
          "Scored {C:paperback_light_suit}light suits",
          "become {V:1}#1#"
        }
      },
      j_paperback_prism = {
        name = "Prism",
        text = {
          "If played hand contains a {C:attention}#1#,",
          "convert all {C:attention}scored cards{} into",
          "random {C:attention}different suits"
        },
        unlock = {
          "Play {C:attention,E:1}#1# Wild cards{}",
          "in a hand",
        }
      },
      j_paperback_master_spark = {
        name = "Master Spark",
        text = {
          "If played hand contains a {C:attention}Spectrum{},",
          "destroy all cards {C:attention}held in hand{} and",
          "all played cards become {C:dark_edition}Polychrome",
          "{S:1.1,C:red,E:2}self-destructs",
        }
      },
      j_paperback_j_and_js = {
        name = "J&J's",
        text = {
          "If played hand contains a",
          "{C:attention}Spectrum{}, create {C:attention}#1#{} random {C:attention}Tags",
          "Consumed in {C:attention}#2#{} rounds",
        }
      },
      j_paperback_blue_star = {
        name = "Blue Star",
        text = {
          "Gains {X:chips,C:white}X#1#{} Chips when a {V:1}#2#{} scores",
          "Loses {X:chips,C:white}X#3#{} Chips when a {V:2}#4#{} scores",
          "{C:inactive}(Currently {X:chips,C:white}X#5#{C:inactive} Chips)"
        }
      },
      j_paperback_shadowmantle = {
        name = "ShadowMantle", -- Not a typo, equipment in deltarune is written without a space
        text = {
          "Scored {V:1}#1#{} have a",
          "{C:green}#2# in #3#{} chance to create",
          "a {C:dark_edition}Negative {C:attention}Tag{}",
        }
      },
      j_paperback_shooting_star = {
        name = "Shooting Star",
        text = {
          "Scored {V:1}#1#{} have a",
          "{C:green}#2# in #3#{} chance to",
          "create the {C:planet}Planet{} card",
          "for played {C:attention}poker hand"
        }
      },
      j_paperback_black_star = {
        name = "Black Star",
        text = {
          "Scored {C:paperback_dark_suit}dark suits",
          "become {V:1}#1#"
        }
      },
      j_paperback_high_speed_rail = {
        name = "High Speed Rail",
        text = {
          "This Joker {C:blue}gains{} Mult equal to",
          "the {C:money}cost{} of {C:blue}bought{} {C:attention}Jokers{}",
          "This Joker {C:red}loses{} Mult equal to",
          "the {C:money}sell value{} of {C:red}sold{} {C:attention}Jokers{}",
          "{C:inactive}(Currently {C:mult}+#1#{C:inactive} Mult)"
        }
      },
      j_paperback_small_scale_onshore_wind = {
        name = "Small Scale Onshore Wind",
        text = {
          "This Joker gains {C:mult}+#1#{} Mult",
          "per consecutive discard",
          "of exactly {C:attention}#2#{} cards",
          "{C:inactive}(Currently {C:mult}+#3# {C:inactive}Mult)"
        }
      },
      j_paperback_aurora_borealis = {
        name = "Aurora Borealis",
        text = {
          "This Joker gains {X:mult,C:white}X#1#{} Mult",
          "for each {C:attention}editioned Joker{} card",
          "{s:0.9,C:dark_edition}Negatives{s:0.9,C:inactive} are excluded{}",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)"
        },
        unlock = {
          "Have at least {E:1,C:attention}#1#",
          "{C:dark_edition}Polychrome{} Jokers",
        },
      },
      j_paperback_joke_master = {
        name = "Joke Master",
        text = {
          "This Joker gains {C:mult}+#1#{} Mult if",
          "played hand is a {C:attention}#2#{}",
          "{s:0.8}hand changes every round",
          "{C:inactive}(Currently {C:mult}+#3#{C:inactive} Mult)"
        }
      },
      j_paperback_jokers_11 = {
        name = "Joker's 11",
        text = {
          "{C:attention}#1#s{} held in hand after",
          "defeating a {C:attention}Boss Blind",
          "create a random {C:attention}Tag{}",
        },
        unlock = {
          "Have {C:attention}#1#{} Aces",
          "in your deck",
        }
      },
      j_paperback_book_of_life = {
        name = "Book of Life",
        text = {
          "After skipping or clearing",
          "a {C:attention}Blind{}, {C:green}#1# in #2#{} chance to",
          "create a {C:attention}copy{} of its {C:attention}Tag{}",
        }
      },
      j_paperback_hamsa = {
        name = "Hamsa",
        text = {
          "On the {C:attention}first{} hand of round,",
          "retrigger the first",
          "{C:attention}#1#{} played cards...",
        },
        unlock = {
          "Lose a run"
        }
      },
      j_paperback_hamsa_r = {
        name = "Hamsa",
        text = {
          "...On the {C:attention}last{} hand of round,",
          "{C:green}+#1#{} to all {C:green}listed probabilites{}",
        },
        unlock = {
          "Have {C:attention}#1#{}",
          "for {C:attention}#2#{} round",
        }
      },
      j_paperback_hamsa_r_collection = {
        name = "Hamsa (Reversed)",
        text = {
          "...On the {C:attention}last{} hand of round,",
          "{C:green}+#1#{} to all {C:green}listed probabilites{}",
        },
        unlock = {
          "Have {C:attention}#1#{}",
          "for {C:attention}#2#{} round",
        }
      },
      j_paperback_nazar = {
        name = "Nazar",
        text = {
          "This Joker gains {C:chips}+#1#{} Chips",
          "when a {C:paperback_minor_arcana}Minor Arcana{} or",
          "{C:tarot}Tarot{} card is used",
          "{C:inactive}(Currently {C:chips}+#2#{} {C:inactive}Chips){}",
        },
        unlock = {
          "Discover every {E:1,C:tarot}Tarot{}",
          "and {E:1,C:paperback_minor_arcana}Minor Arcana{} card",
        }
      },
      j_paperback_oujia_board = {
        name = "Oujia Board",
        text = {
          "{C:spectral}Spectral{} cards may appear",
          "in the shop. Jokers are",
          "{C:attention}shuffled{} before scoring",
        },
        unlock = {
          "Use the {C:attention}Oujia{}",
          "{C:spectral}Spectral{} card",
        }
      },
      j_paperback_planchette = {
        name = "Planchette",
        text = {
          "This Joker gains {X:mult,C:white}X#1#{} Mult",
          "when a {C:spectral}Spectral{} card is used",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)",
        },
        unlock = {
          "Use {C:attention}#1# {C:spectral}Spectral",
          "cards in one run",
        }
      },
      j_paperback_prescript = {
        name = "Prescript",
        text = {
          "Retrigger all played cards this {C:attention}round{}",
          "if {C:attention}first{} hand of round contains a {C:attention}#1#{}",
          "{s:0.8}Poker hand changes every round",
          "{C:inactive}(Currently {V:1}#2#{C:inactive})",
        },
      },
      j_paperback_ultra_rare = {
        name = "Ultra Rare",
        text = {
          "When {C:attention}Blind{} is selected, create",
          "random {C:blue}Common{}, {C:green}Uncommon",
          "and {C:red}Rare{} Temporary {C:dark_edition}Negative",
          "{C:attention}Jokers{} with {C:money}$#1#{} sell value"
        }
      },
      j_paperback_manilla_folder = {
        name = "Manilla Folder",
        text = {
          "Earn {C:money}$#1#{} at end of round",
          "for each {C:attention}unique Clip{}",
          "in your full deck",
          "{C:inactive}(Currently {C:money}$#2#{C:inactive})"
        }
      },
      j_paperback_clippy = {
        name = "Clippy",
        text = {
          "Add a random {C:attention}Clip{} to a",
          "random card in your deck",
          "when {C:attention}Blind{} is selected",
        }
      },
      j_paperback_jimbos_joyous_joker_jamboree = {
        name = "Jimbo's Joyous Joker Jamboree",
        text = {
          "Create a random {C:paperback_minor_arcana}Minor Arcana{} card",
          "for every {C:attention}#1#{C:inactive} [#2#]{} scored cards",
          "{C:inactive}(Must have room)",
        },
        unlock = {
          "Have {C:attention,E:1}#1#{} or more",
          "{C:attention,E:1}suits{} in",
          "your deck"
        }
      },
      j_paperback_one_shift_more = {
        name = "One Shift More",
        text = {
          "This Joker gains {X:mult,C:white}X#1#{} Mult",
          "for every {C:attention}#2#{C:inactive} [#3#]{} scored {C:hearts}#5#{} cards",
          "{C:inactive}(Currently {X:mult,C:white}X#4#{C:inactive} Mult)",
        },
      },
      j_paperback_the_normal_joker = {
        name = "The Normal Joker",
        text = {
          "Retrigger all",
          "{C:blue}Common {C:attention}Jokers"
        }
      },
      j_paperback_ampersand = {
        name = "&",
        text = {
          "If scored hand contains both",
          "{C:paperback_dark_suit}dark{} and {C:paperback_light_suit}light suits{},",
          "retrigger the first of each {C:attention}#1#{} time"
        },
      },
      j_paperback_insurance_policy = {
        name = "Insurance Policy",
        text = {
          "Gives {C:mult}+#1#{} Mult for each {C:attention}#3#{}",
          "and {C:mult}-#1#{} Mult for each {C:attention}#4#{}",
          "in your full deck",
          "{C:inactive}(Currently {C:mult}#2#{C:inactive} Mult){}",
        }
      },
      j_paperback_jimbos_inferno = {
        name = "Jimbo's Inferno",
        text = {
          "Scored {C:paperback_dark_suit}dark suits{} give",
          "{C:mult}+#1#{} Mult for every",
          "{C:paperback_dark_suit}dark suit{} {C:attention}held in hand{}",
          "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult){}",
        }
      },
      j_paperback_tome = {
        name = "Tome",
        text = {
          "{C:attention}+#1#{} Consumable Slot for every",
          "unique Joker {C:attention}rarity{} you have",
          "{C:inactive}(Currently {C:attention}+#2#{C:inactive} Slot#3#){}",
        }
      },
      j_paperback_better_call_jimbo = {
        name = "Better Call Jimbo",
        text = {
          "{X:mult,C:white}X#1#{} Mult for",
          "every {C:money}$#2#{} owned",
          "Earn no {C:money}Interest{}",
          "{C:inactive}(Currently {X:mult,C:white}X#3#{C:inactive} Mult)"
        }
      },
      j_paperback_touch_tone_joker = {
        name = "Touch Tone Joker",
        text = {
          "When opening an {C:tarot}Arcana{},",
          "{C:planet}Celestial{} or {C:spectral}Spectral{} pack,",
          "{C:attention}draw{} the {C:attention}first card{} in it",
          "to your consumables",
          "{C:inactive}(Must have room)"
        }
      },
      j_paperback_joker_cd_i = {
        name = 'Joker CD-i',
        text = {
          "{C:green}#1# in #2#{} chance to create",
          "a random {C:planet}Planet{} card if",
          "played hand has exactly {C:attention}#3#{} cards",
          "{C:inactive}(Must have room)"
        }
      },
      j_paperback_determination = {
        name = 'Determination',
        text = {
          "Prevents death, on death",
          "{C:attention}#1#{} Ante, {C:attention}#1#{} hand size",
          "and {C:red}self-destructs"
        }
      },
      j_paperback_blue_marble = {
        name = "Blue Marble",
        text = {
          "When a {C:attention}Planet{} card is used,",
          "this Joker gains {C:mult}+#1#{} Mult",
          "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
      },
      j_paperback_boundary_of_death = {
        name = "Boundary of Death",
        text = {
          "{C:attention}#1#s{} have a",
          "{C:green}#2# in #3#{} chance to",
          "give {C:red}+#4#{} additional Mult"
        }
      },
      j_paperback_festive_joker = {
        name = "Festive Joker",
        text = {
          "{C:attention}#1#s{} have a {C:green}#2# in #3#",
          "chance to create a random",
          "{C:attention}Consumable{} when scored",
          "{C:inactive}(Must have room)"
        }
      },
      j_paperback_collector = {
        name = "Collector",
        text = {
          "Earn {C:money}$#1#{} at end of round",
          "for each {C:attention}#2#{}",
          "in your full deck",
          "{C:inactive}(Currently {C:money}$#3#{C:inactive})"
        }
      },
      j_paperback_spotty_joker = {
        name = "Spotty Joker",
        text = {
          "This Joker gains {X:mult,C:white}X#1#{} Mult",
          "for every {C:attention}#2#{}",
          "in {C:attention}scoring hand{}",
          "{C:inactive}(Currently {X:mult,C:white}X#3#{}{C:inactive} Mult)"
        }
      },
      j_paperback_sommelier = {
        name = "Sommelier",
        text = {
          "If {C:attention}first discard{} of round",
          "contains a {C:attention}#1#{},",
          "the first discarded {C:attention}#1#{}",
          "gets a random {C:attention}seal",
        },
        unlock = {
          "Play a {C:attention,E:1}Stained",
          "playing card with",
          "a {C:attention,E:1}Red Seal",
        },
      },
      j_paperback_medic = {
        name = "Medic",
        text = {
          "{C:attention}#1#s{} retrigger",
          "cards an additional time",
        }
      },
      j_paperback_matcha = {
        name = "Matcha",
        text = {
          "This Joker gains {C:chips}+#1#{} Chips",
          "when a card is scored",
          "{C:green}#2# in #3#{} chance to",
          "consume on {C:red}discard",
          "{C:inactive}(Currently {C:chips}+#4#{C:inactive} Chips)"
        }
      },
      j_paperback_you_are_a_fool = {
        name = "You Are a Fool!",
        text = {
          "If scored hand contains {C:attention}#1#",
          "or more {C:attention}face{} cards, convert",
          "{C:attention}all{} cards {C:attention}held in hand{} to",
          "the {C:attention}leftmost{} scored card",
          "{S:1.1,C:red,E:2}self-destructs",
        }
      },
      j_paperback_kintsugi_joker = {
        name = "Kintsugi Joker",
        text = {
          "Increases the payout of",
          "{C:attention}#2#s{} by {C:money}$#1#{} when",
          "a {C:attention}#2#{} is destroyed",
          "{C:inactive}(Currently increased by {C:money}$#3#{C:inactive})"
        }
      },
      j_paperback_ddakji = {
        name = "Ddakji",
        text = {
          "{C:green}#1# in #2#{} cards get drawn",
          "face down, if scored hand",
          "contains a {C:attention}face up{} and",
          "{C:attention}face down{} card, create",
          "a random Consumable",
          "{C:inactive}(Must have room)"
        }
      },
      j_paperback_weather_radio = {
        name = "Weather Radio",
        text = {
          "This Joker gains {X:mult,C:white}X#1#{} Mult if",
          "{C:attention}played hand{} contains a {C:attention}#2#{}.",
          "During {C:attention}Boss Blind{}, if this Joker has",
          "{X:mult,C:white}X#3#{} Mult or more, disable {C:attention}Boss Blind{}",
          "and this Joker loses {X:mult,C:white}X#4#{} Mult",
          "{C:inactive}(Currently {X:mult,C:white}X#5#{C:inactive} Mult)",
          "{s:0.75}poker hand changes at end of round"
        }
      },
      j_paperback_power_surge = {
        name = "Power Surge",
        text = {
          "Played {C:attention}#1#s{} give {X:mult,C:white}X#2#{} Mult when scored",
          "and have a {C:green}#3# in #4#{} chance to",
          "{C:red}destroy{} a card {C:attention}held in hand{}",
        }
      },
      j_paperback_time_regression_mix = {
        name = "Time Regression Mix",
        text = {
          "If {C:attention}scoring hand{} contains",
          "at least {C:attention}#1#{} suits,",
          "this Joker gains {C:mult}+#2#{} Mult",
          "{C:inactive}(Currently {C:mult}+#3#{C:inactive} Mult)",
        }
      },

      j_paperback_bismuth = {
        name = "Bismuth",
        text = {
          "Played {V:1}#1#{} and {V:2}#2#{} have",
          "a {C:green}#3# in #4#{} chance to gain {C:dark_edition}Foil{},",
          "{C:dark_edition}Holographic{} or {C:dark_edition}Polychrome",
        },
        unlock = {
          "Find a {C:paperback_crowns,E:1}Shiny {C:paperback_stars,E:1}Suit{}",
        }
      },
      j_paperback_deadringer = {
        name = "Deadringer",
        text = {
          "Retrigger scored {C:attention}#1#s{} and {C:attention}#2#s",
          "once, and scored {C:attention}#3#s{} twice"
        }
      },
      j_paperback_penumbra_phantasm = {
        name = "Penumbra Phantasm",
        text = {
          "{C:attention}Face{} cards are considered {C:attention}rankless{}.",
          "This Joker gains {C:red}+#1#{} Mult whenever",
          "a {C:attention}rankless{} card is {C:attention}scored",
          "{C:inactive}(Currently {C:red}+#2#{C:inactive} Mult)"
        }
      },
      j_paperback_ncj = {
        name = "NoCopyrightJokers",
        text = {
          "{C:chips}+#1#{} Chips for every",
          "{C:money}$1{} of {C:attention}sell value{}",
          "your other Jokers have",
          "{C:inactive}(Currently {C:chips}+#2#{C:inactive} Chips)"
        }
      },
      j_paperback_full_moon = {
        name = "Full Moon",
        text = {
          "{C:planet}Planet{} cards have",
          "a {C:green}#1# in #2#{} chance",
          "to level up {C:attention}again",
        }
      },
      j_paperback_sake_cup = {
        name = "Sake Cup",
        text = {
          "After a hand is played, {C:attention}#1#s",
          "{C:attention}held in hand{} have a {C:green}#2# in #3#",
          "chance to create the {C:planet}Planet",
          "card for played {C:attention}poker hand",
          "{C:inactive}(Must have room)"
        },
        unlock = {
          "Get any {C:attention,E:1}poker hand{}",
          "to level {C:attention,E:1}#1#{}"
        }
      },
      j_paperback_resurrections = {
        name = "Resurrections",
        text = {
          "{C:green}#1# in #2#{} chance to {C:attention}return{}",
          "sold {C:attention}Jokers{} and create",
          "an {C:attention}extra{} {C:dark_edition}Negative{} copy",
          "with {C:money}-$#3#{} sell value",
          "{s:0.8}Chance increases by {s:0.8,C:green}#4#{s:0.8} on fail",
          "{S:1.1,C:red,E:2}self-destructs",
        }
      },
      j_paperback_book_of_vengeance = {
        name = "Book of Vengeance",
        text = {
          "After defeating a {C:attention}Boss Blind{},",
          "destroys itself and the {C:attention}Joker{} to its left,",
          "then makes a copy of {C:attention}Joker{} to its right"
        }
      },
      j_paperback_b_soda = {
        name = "B-Soda",
        text = {
          "When {C:attention}Blind{} is selected,",
          "gain {C:blue}+#1#{} Hand",
          "Consumed if {C:attention}Blind{} is",
          "cleared with {C:blue}0{} hands",
          "remaining",
        }
      },
      j_paperback_angel_investor = {
        name = "Angel Investor",
        text = {
          "Skipping a {C:attention}Blind{} or defeating",
          "a {C:attention}Boss Blind{} gives",
          "an {C:money}Angel Investment Tag"
        }
      },
      j_paperback_der_freischutz = {
        name = "Der Freischütz",
        text = {
          "If poker hand contains only {C:attention}7s{},",
          "destroy the {C:attention}lowest{} chip-value",
          "{C:attention}non-7{} in your full deck",
          "{C:inactive}Avoid the Seventh Bullet... #1#/#2#{}",
        }
      },
      j_paperback_marble_soda = {
        name = "Marble Soda",
        text = {
          "Scored {C:attention}#1#s{}",
          "give {X:mult,C:white}X#2#{} Mult",
          "Drank after {C:attention}#3#{} playing",
          "card#4# #5# {C:attention}destroyed{}"
        }
      },
      j_paperback_vacation_juice = {
        name = "Vacation Juice",
        text = {
          "When clearing a {C:attention}Blind{}",
          "for the first time,",
          "do not advance to next {C:attention}Blind{}",
          "Drank after {C:attention}#1#{} trigger#2#",
        },
        unlock = {
          "Win a run with",
          "{C:attention}#1#{}"
        }
      },
      j_paperback_black_forest_cake = {
        name = "Black Forest Cake",
        text = {
          "This Joker gains {C:mult}+#2#{} Mult",
          "for each {C:attention}Blind{} defeated",
          "{C:red,E:1}Self-destructs{} if any",
          "card or Joker is {C:attention}destroyed{}",
          "{C:inactive}(Currently {C:mult}+#1#{C:inactive} Mult)"
        }
      },
      j_paperback_ice_cube = {
        name = "Ice Cube",
        text = {
          "{C:blue}+#1#{} Hand when {C:attention}Blind{} is selected",
          "Melts if {C:attention}score catches fire",
        },
        unlock = {
          "Have {C:attention,E:1}#1# Food{}",
          "{C:attention,E:1}Jokers{} at once"
        }
      },
      j_paperback_champagne = {
        name = "Champagne",
        text = {
          "During a {C:attention}Boss Blind{}, scored",
          "cards earn {C:money}$#1#{}, {C:attention}doubled{} if",
          "the card has a {C:attention}seal",
          "{C:attention}Consumed{} in {C:attention}#2#{} rounds"
        }
      },
      j_paperback_pocket_pair = {
        name = "Pocket Pair",
        text = {
          "Earn {C:money}$#1#{} per {C:attention}#2#{} drawn",
          "at start of round"
        },
        unlock = {
          "{C:attention,E:1}Win{} a run with",
          "{C:attention,E:1}#1#{} as your",
          "most played hand"
        }
      },
      j_paperback_the_quiet = {
        name = "The Quiet",
        text = {
          "{X:mult,C:white}X#1#{} Mult for each",
          "card below {C:attention}#2#{}",
          "in your full deck",
          "{C:inactive}(Currently {X:mult,C:white}X#3#{C:inactive} Mult)"
        },
        unlock = {
          "Win a run without",
          "{C:attention,E:1}ever{} having a card",
          "in your {C:attention,E:1}consumables"
        }
      },
      j_paperback_alert = {
        name = "Alert",
        text = {
          "If {C:attention}played hand{} is a single",
          "{C:attention}face card{}, destroy it",
          "{C:inactive}(#1#/#2#)?"
        }
      },
      j_paperback_legacy = {
        name = "Legacy",
        text = {
          "When a non-{C:attention}Enhanced card{} is",
          "destroyed, adds its {C:chips}Chip value",
          "as {C:mult}Mult{} to this Joker",
          "{C:inactive}(Currently {C:mult}+#1#{C:inactive} Mult)"
        },
        unlock = {
          "{E:1,s:1.3}?????",
        }
      },
      j_paperback_telamon = {
        name = "Telamon",
        text = {
          "If {C:attention}winning hand{} contains",
          "a {C:attention}#1#{}, create a random",
          "{C:attention}Swords{} {C:paperback_minor_arcana}#2#{} card",
          "{C:inactive}(Must have room)"
        }
      },
      j_paperback_backpack = {
        name = "Backpack",
        text = {
          "{C:money}Shops{} start with an additional",
          "free {C:attention}Buffoon Pack"
        }
      },
      j_paperback_roulette = {
        name = "Roulette",
        text = {
          "Each hand played, this Joker chooses a",
          "{C:attention}random rank{} and {C:attention}suit{}. Scored cards earn",
          "{C:money}$#1#{} if they match suit,",
          "{C:money}$#2#{} if they match rank,",
          "or {C:money}$#3#{} if they match exactly",
        },
        unlock = {
          "Play a {C:attention,E:1}Spectrum Five{}"
        }
      },
      j_paperback_mexican_train = {
        name = "Mexican Train",
        text = {
          "Scored {C:attention}#1#s{} give {C:money}$#2#",
          "for every played {C:attention}#1#{}",
          "{C:inactive}(Currently {C:money}$#3#{C:inactive})"
        }
      },
      j_paperback_chocolate_joker = {
        name = "Chocolate Joker",
        text = {
          "This Joker gains {X:chips,C:white}X#1#{} Chips",
          "for each {C:attention}Joker{} card",
          "{C:inactive}(Currently {X:chips,C:white}X#2#{C:inactive} Chips)"
        }
      },
      j_paperback_mandela_effect = {
        name = "Mandela Effect",
        text = {
          "Randomly {C:attention}enhance{} the {C:attention}first",
          "scored {C:attention}face{} card each hand"
        }
      },
      j_paperback_gauze = {
        name = "Gauze",
        text = {
          "If last discard of round is a single card,",
          "it becomes a {C:attention}#1#{}"
        }
      },
      j_paperback_jester_of_nihil = {
        name = "Jester of Nihil",
        text = {
          "{C:attention}Debuffs{} the suit of the",
          "{C:attention}last scored{} card",
          "{C:mult}+#1#{} Mult for every {C:attention}debuffed{}",
          "card in your full deck",
          "{C:inactive}(Currently {V:1}#2#{C:inactive} and {C:mult}+#3#{C:inactive} Mult)",
        },
        unlock = {
          "Play a hand that",
          "contains {C:attention,E:1}#1#{}",
          "{C:attention,E:1}Debuffed{} cards"
        }
      },
      j_paperback_forgery = {
        name = "Forgery",
        text = {
          "Copies ability of a random {C:attention}Joker",
          "every hand, if it gives {X:mult,C:white}XMult{},",
          "{C:mult}Mult{} or {C:chips}Chips{}, multiply its values",
          "between {X:attention,C:white}X#1#{} and {X:attention,C:white}X#2#",
          "{C:inactive}(Currently {C:attention}#3#{C:inactive} at {X:attention,C:white}X#4#{C:inactive})"
        },
        unlock = {
          "Have {C:attention,E:1}2{} of the",
          "same {C:attention,E:1}Joker"
        }
      },
      j_paperback_the_world = {
        name = "The World",
        text = {
          "All {C:blue}hands{} and {C:red}discards{} are",
          "considered the {C:attention}first{} and",
          "{C:attention}last{} of round"
        },
        unlock = {
          "Reach Ante",
          "level {E:1,C:attention}#1#",
        }
      },
      j_paperback_epic_sauce = {
        name = "Epic Sauce",
        text = {
          "{X:mult,C:white}X#1#{} Mult",
          "Destroy a random {C:attention}Joker{}",
          "if played hand is not",
          "the {C:attention}first hand{} of round"
        }
      },
      j_paperback_find_jimbo = {
        name = "Find Jimbo",
        text = {
          "Each played {C:attention}#1#{} of {V:1}#2#{}",
          "earns {C:money}$#3#{} when scored",
          "{s:0.8}Card changes every round"
        },
        unlock = {
          "{C:attention,E:1}Win{} a round with",
          "a {C:attention,E:1}#1# #2#{}"
        }
      },
      j_paperback_joker_crossing = {
        name = "Joker Crossing",
        text = {
          "{C:attention}Enhanced{} cards",
          "have a {C:green}#1# in #2#{}",
          "chance to retrigger"
        }
      },
      j_paperback_jimbocards = {
        name = "Jimbocards",
        text = {
          "When obtained, destroy all Jokers and",
          "create {C:attention}#1#{} random {C:dark_edition}#5#{} Jokers.",
          "All purchases cost {C:money}$#2#{} less.",
          "Clear each {C:attention}Ante{} in {C:attention}#3#{} hands, or you {S:1.1,C:red,E:2}lose{}",
          "{C:inactive}({C:attention}#4#{C:inactive} hands left)"
        },
        unlock = {
          "Reach Ante",
          "level {E:1,C:attention}#1#",
        }
      },
      j_paperback_jimbocards_collection = {
        name = "Jimbocards",
        text = {
          "When obtained, destroy all Jokers and",
          "create {C:attention}#1#{} random {C:dark_edition}Negative{} Jokers.",
          "All purchases cost {C:money}$#2#{} less.",
          "Clear each {C:attention}Ante{} in {C:attention}#3#{} hands, or you {S:1.1,C:red,E:2}lose{}",
          "{C:inactive}({C:attention}#4#{C:inactive} hands left)",
          "Always {C:paperback_eternal}Eternal",
        },
        unlock = {
          "Reach Ante",
          "level {E:1,C:attention}#1#",
        }
      },
      j_paperback_forlorn = {
        name = "Forlorn",
        text = {
          "If played hand's only scored suit",
          "is {V:1}#1#{}, destroy a random",
          "card {C:attention}held in hand",
        },
      },
      j_paperback_protocol = {
        name = "Protocol",
        text = {
          "{C:attention}+#1#{} Booster Pack size"
        }
      },
      j_paperback_cream_liqueur = {
        name = "Cream Liqueur",
        text = {
          "{C:attention}Tags{} earn {C:money}$#1#{} when activated",
          "Consumed in {C:attention}#2#{} round#3#",
          "{C:inactive}(Resets when a {C:attention}Tag{C:inactive} is acquired)"
        }
      },
      j_paperback_coffee = {
        name = "Coffee",
        text = {
          "{C:attention}+#1#{} hand size,",
          "increases by {C:attention}#2#{} when {C:attention}Blind{} is skipped.",
          "{C:green}#3# in #4#{} chance this card is consumed when",
          "{C:attention}Small Blind{} or {C:attention}Big Blind{} is selected",
        }
      },
      j_paperback_basic_energy = {
        name = "Basic Joker Energy",
        text = {
          "Using any {C:attention}Consumable{} has a",
          "{C:green}#1# in #2#{} chance to make a copy",
          "{C:inactive}(Cannot make copy of a copy)",
          "{C:inactive}(Must have room)"
        }
      },
      j_paperback_big_misser = {
        name = "Big Misser",
        text = {
          "{X:mult,C:white}X#1#{} Mult for each empty",
          "consumable slot",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{}{C:inactive} Mult)"
        },
        unlock = {
          "Win a run without",
          "{C:attention,E:1}ever{} having a card",
          "in your {C:attention,E:1}consumables"
        }
      },
      j_paperback_fodder = {
        name = "Fodder",
        text = {
          "Sell this card to {C:paperback_ego_gift}corrode{}",
          "the rightmost {C:paperback_ego_gift}E.G.O Gift{}",
        },
        unlock = {
          "Sell an {C:paperback_ego_gift,E:1}E.G.O Gift{}"
        }
      },
      j_paperback_the_strongest = {
        name = "The Strongest",
        text = {
          "This Joker gains {X:mult,C:white}X#1#{} Mult",
          "when an {C:paperback_ego_gift}E.G.O Gift{} is sold",
          "or corrodes",
          "{C:paperback_ego_gift}Corrode{} an {C:paperback_ego_gift}E.G.O Gift",
          "when defeating a {C:attention}Boss Blind",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)"
        },
        unlock = {
          "Sell an {C:paperback_ego_gift,E:1}E.G.O Gift{}"
        }
      },
      j_paperback_freezer = {
        name = "Freezer",
        text = {
          "Create a {C:dark_edition}Negative{} {C:attention}Food Joker{}",
          "after defeating a {C:attention}Boss Blind{}",
        },
        unlock = {
          "Own a {C:dark_edition}Negative{}",
          "{C:attention,E:1}Food Joker"
        }
      },
      j_paperback_everything_must_go = {
        name = "Everything Must Go!",
        text = {
          "Shops have {C:attention}+#1#{} additional",
          "{C:attention}Voucher{} slot"
        },
        unlock = {
          "Discover {C:attention,E:1}#1#{}",
          "{C:attention,E:1}Vouchers{}"
        },
      },
      j_paperback_card_sleeve = {
        name = "Card Sleeve",
        text = {
          "Sell this card to make {C:attention}Joker",
          "to the right {C:attention}Eternal{}",
        }
      },
      j_paperback_plastic_wrap = {
        name = "Plastic Wrap",
        text = {
          "When a {C:attention}#2#{} card is",
          "{C:attention}destroyed{}, enhance {C:attention}#1#{}",
          "{C:attention}unenhanced{} cards in",
          "your deck to {C:attention}#2#{} cards",
        }
      },
      j_paperback_percussion_ensemble = {
        name = "Percussion Ensemble",
        text = {
          "{X:mult,C:white}X#1#{} Mult for each",
          "unique {C:attention}Enhancement{}",
          "in your full deck",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult){}",
        }
      },
      j_paperback_its_tv_time = {
        name = "It's TV Time!",
        text = {
          "Played {C:paperback_stars}#1#{} give",
          "{C:chips}+#2#{} chips when scored",
        },
      },
      j_paperback_trust_us = {
        name = "Trust Us!",
        text = {
          "{X:mult,C:white}X#1#{} Mult if played hand",
          "contains a {C:attention}#3#{},",
          "{X:mult,C:white}X#2#{} Mult otherwise",
        },
      },
      j_paperback_da_capo = {
        name = "Da Capo",
        text = {
          "{X:mult,C:white}X#1#{} Mult",
          "{C:red}Debuffs{} all but one {C:attention}suit{}",
          "every {C:attention}hand{}, in order:",
          "{C:clubs}Clubs{}, {C:spades}Spades{}, {C:diamonds}Diamonds{}, {C:hearts}Hearts{}, {C:inactive}None{}",
          "{C:inactive}(Currently: {V:1}#2#{C:inactive}){}",
        }
      },
      j_paperback_complete_breakfast = {
        name = "Complete Breakfast",
        text = {
          "{C:mult}+#1#{} Mult and {C:chips}+#2#{} Chips",
          "{C:green}#3# in #4#{} chance this card is",
          "eaten after played hand",
          "Chance increases by {C:green}#5#{} after",
          "every played hand",
        },
        unlock = {
          "Have {C:attention,E:1}#1# Food{}",
          "{C:attention,E:1}Jokers{} at once"
        }
      },
      j_paperback_emergency_broadcast = {
        name = "Emergency Broadcast",
        text = {
          "Scored {C:attention}5s{} and {C:attention}8s{} give",
          "{C:mult}+#1#{} Mult and {C:chips}+#2#{} Chips",
        },
      },
      j_paperback_moribund = {
        name = "Moribund",
        text = {
          "This Joker gains {C:mult}+#1#{} Mult when a {C:attention}Blind",
          "is cleared with {C:attention}0{C:blue} hands{} remaining.",
          "This Joker {C:attention}doubles{} its {C:mult}Mult{} if",
          "{C:attention}Blind{} is not cleared",
          "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)",
        },
      },
      j_paperback_crispy_taco = {
        name = "Crispy Taco",
        text = {
          "{X:chips,C:white}X#1#{} Chips",
          "{C:green}#2# in #3#{} chance this card",
          "is eaten at end of round",
        },
      },
      j_paperback_furioso = {
        name = "Furioso",
        text = {
          "This Joker gains {X:mult,C:white}X#1#{} Mult for",
          "each unique scored {C:attention}rank{}.",
          "Resets after {C:attention}Boss Blind",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{} {C:inactive}Mult)",
          "{C:inactive}(Ranks played:{C:attention}#3#{C:inactive})",
        },
        unlock = {
          "Defeat the",
          "{C:attention,E:1}Cerulean Bell",
          "Boss Blind in",
          "one hand"
        }
      },
      j_paperback_soft_taco = {
        name = "Soft Taco",
        text = {
          "{X:mult,C:white}X#1#{} Mult",
          "{C:green}#2# in #3#{} chance this card",
          "is eaten at end of round",
        },
      },
      j_paperback_watermelon = {
        name = "Watermelon",
        text = {
          "Gains {X:mult,C:white}X#1#{} Mult when {C:attention}Enhancing{}",
          "a playing card. Loses {X:mult,C:white}X#1#{} Mult",
          "when a playing card is {C:attention}destroyed{}",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{} {C:inactive}Mult)",
        },
      },
      j_paperback_charred_marshmallow = {
        name = "Charred Marshmallow",
        text = {
          "Scored {C:spades}#4#{} give {C:mult}+#1#{} Mult",
          "{C:green}#2# in #3#{} chance this card is",
          "eaten at end of round",
        },
      },
      j_paperback_joker_cookie = {
        name = "Joker Cookie",
        text = {
          "Earn {C:money}$#1#{} at end of round",
          "Payout increases by {C:money}$#2#{} when cashing out",
          "{C:green}#4# in #5#{} chance this card",
          "is eaten at end of round",
          "{C:inactive}(Max of {C:money}$#3#{C:inactive})",
        },
      },
      j_paperback_pop_stick = {
        name = "Pop-Stick",
        text = {
          "{X:mult,C:white}X#1#{} Mult if you have",
          "another {C:attention}\"Stick\"{} Joker",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)",
        },
      },
      j_paperback_pool_table = {
        name = "Pool Table",
        text = {
          "If first hand of round",
          "scores no {C:attention}face cards{},",
          "create the {C:planet}#1#{} card",
          "for played {C:attention}poker hand",
          "{C:inactive}(Must have room)",
        },
      },
      j_paperback_bicycle = {
        name = "Bicycle",
        text = {
          "{C:attention}#1#s{} give {C:mult}Mult",
          "equal to their {C:chips}Chip value{}",
        },
      },
      j_paperback_stamp = {
        name = "Stamp",
        text = {
          "{C:green}#1# in #2#{} chance this",
          "Joker gains {C:chips}+#3#{} Chips when",
          "any card with a {C:attention}seal{} is scored",
          "{C:inactive}(Currently {C:chips}+#4#{C:inactive} Chips)",
        },
        unlock = {
          "Play a hand with",
          "{C:attention,E:1}#1#{} scored seals",
        },
      },
      j_paperback_sticky_stick = {
        name = "Sticky Stick",
        text = {
          "{X:mult,C:white}X#1#{} Mult if you have",
          "another {C:attention}\"Stick\"{} Joker",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)",
        },
      },
      j_paperback_shopping_center = {
        name = "Shopping Center",
        text = {
          "{C:money}Shops{} have an additional",
          "{C:attention}card slot",
        },
      },
      j_paperback_tutor = {
        name = "Tutor",
        text = {
          "{C:attention}Numbered cards{} have",
          "{C:attention}double{} {C:chips}Chip value{}",
        },
      },
      j_paperback_ghost_cola = {
        name = "Ghost Cola",
        text = {
          "Sell this card to create a {C:attention}#1#{}",
          "and a random {C:spectral}#2#{} card",
          "{C:inactive}(Must have room)"
        },
      },
      j_paperback_river = {
        name = "River",
        text = {
          "If played hand contains {C:attention}5 scoring",
          "{C:attention}cards{}, earn half the lowest scoring",
          "card's {C:chips}Chip value{} as {C:money}money",
          "{C:inactive}(Max of {C:money}$#1#{C:inactive})",
        },
      },
      j_paperback_solemn_lament = {
        name = "Solemn Lament",
        text = {
          "This Joker gains {X:mult,C:white}X#1#{} Mult",
          "if scored hand contains both",
          "{C:paperback_dark_suit}dark{} and {C:paperback_light_suit}light suits{}",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)",
        },
      },
      j_paperback_hole_in_one = {
        name = "Hole in One",
        text = {
          "If first {C:blue}hand{} of round cleared the",
          "{C:attention}Blind{}, double the {C:attention}sell value{} of all {C:attention}cards",
          "{C:inactive}(Max of {C:money}$#1#{C:inactive} per round)",
          "When this Joker is sold, set the",
          "{C:attention}sell value{} of all {C:attention}cards{} to {C:money}$0"
        },
      },
      j_paperback_mismatched_sock = {
        name = "Mismatched Sock",
        text = {
          "This Joker gains {X:mult,C:white}X#1#",
          "Mult if discard contains",
          "exactly {C:attention}one{} card",
          "Resets if played hand contains a {C:attention}Pair{}",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)",
        },
      },
      j_paperback_wild_plus_four = {
        name = "Wild +4",
        text = {
          "{C:attention}+#1#{} hand size",
          "{C:blue}#2#{} Hand"
        }
      },
      j_paperback_quick_fix = {
        name = "Quick Fix",
        text = {
          "{C:attention}+#1#{} hand size",
          "{C:green}#2# in #3#{} chance this",
          "card is destroyed",
          "at end of round...",
        },
        unlock = {
          "Have a hand",
          "size of {C:attention,E:1}#1#",
          "or more cards"
        }
      },
      j_paperback_skydiver = {
        name = "Skydiver",
        text = {
          "{C:white,X:mult}X#1#{} Mult if {C:attention}all scored{} cards",
          "are {C:attention}less than or equal{} to the",
          "{C:attention}lowest rank{} scored this round",
          "{C:inactive}(Updates at end of played hand)",
          "{C:inactive}(Currently: {C:attention}#2#{C:inactive})",
        },
      },
      j_paperback_surfer = {
        name = "Surfer",
        text = {
          "This Joker gains {C:chips}+#1#{} Chips",
          "for every {C:attention}#2#{} held in hand",
          "at {C:attention}end of round{}",
          "{C:inactive}(Currently {C:chips}+#3#{C:inactive} chips)"
        }
      },
      j_paperback_blue_bonnets = {
        name = "Blue Bonnets",
        text = {
          "{C:clubs}#1#{} give {X:mult,C:white}X#2#{} Mult when scored.",
          "Increases by {X:mult,C:white}X#3#{} Mult for each",
          "consecutively scored {C:clubs}#4#{}",
          "{C:inactive}(Resets after each hand played)",
        },
      },
      j_paperback_great_wave = {
        name = "Great Wave",
        text = {
          "Retrigger {C:attention}rightmost{} scoring card",
          "{C:attention}once{} for each other {C:attention}scoring card{}",
        },
      },
      j_paperback_caramel_apple = {
        name = "Caramel Apple",
        text = {
          "Scored {C:clubs}#4#{} give {C:mult}+#1#{} Mult",
          "{C:green}#2# in #3#{} chance this card is",
          "eaten at end of round",
        },
      },
      j_paperback_nachos = {
        name = "Nachos",
        text = {
          "{X:chips,C:white}X#1#{} Chips,",
          "loses {X:chips,C:white}X#2#{} Chips",
          "per {C:attention}card{} discarded",
        },
      },
      j_paperback_trans_flag = {
        name = "Trans Flag",
        text = {
          "Gives {C:red}+#1#{} Mult for each",
          "remaining {C:attention}discard{}",
          "{C:inactive}(Currently {C:red}+#2#{} {C:inactive}Mult)"
        },
      },
      j_paperback_pride_flag_spectrums = {
        name = "Pride Flag",
        text = {
          "Gains {C:chips}+#1#{} Chips if played",
          "hand contains a {C:attention}Spectrum",
          "Resets if played hand",
          "contains a {C:attention}Straight",
          "{C:inactive}(Currently {C:chips}+#2#{} {C:inactive}Chips)"
        },
        unlock = {
          "Play a {E:1,C:attention,E:1}Spectrum{}"
        }
      },
      j_paperback_pride_flag_no_spectrums = {
        name = "Pride Flag",
        text = {
          "Gains {C:mult}+#1#{} Mult if scored hand",
          "contains {C:attention}three{} unique suits",
          "{C:inactive}(Currently {C:mult}+#2#{} {C:inactive}Mult)",
        },
        unlock = {
          "Play a hand scoring {C:attention,E:1}#1#{} suits",
          "and a {C:attention,E:1}Wild{} Card"
        }
      },
      j_paperback_sacrificial_lamb = {
        name = "Sacrificial Lamb",
        text = {
          "Gains {C:mult}+#1#{} Mult for each",
          "card or Joker {C:attention}destroyed",
          "{C:inactive}(Currently {C:mult}+#2# {C:inactive}Mult)",
        },
        unlock = {
          "Destroy {C:attention,E:1}#1#{} cards",
          "in a run"
        }
      },
      j_paperback_autumn_leaves = {
        name = "Autumn Leaves",
        text = {
          "{C:diamonds}#1#{} give {X:mult,C:white}X#2#{} Mult when scored.",
          "Increases by {X:mult,C:white}X#3#{} Mult for each",
          "consecutively scored {C:diamonds}#4#{}",
          "{C:inactive}(Resets after each hand played)",
        },
      },
      j_paperback_wild_prize = {
        name = "[[WILD PRIZE!1!]]",
        text = {
          "{C:attention}#7#{} have a {C:green}#1# in #2#{} chance",
          "to {C:attention}retrigger{} and a {C:green}#3# in #4#{} chance",
          "to earn between {C:money}#5#{} and {C:money}$#6#{} when scored",
        },
      },
      j_paperback_wish_you_were_here = {
        name = "Wish You Were Here",
        text = {
          "Gives {C:mult}+Mult{} equal to {C:mult}#1#X{} the",
          "{C:attention}sell value{} of this card.",
          "Gains {C:money}$#2#{} of {C:attention}sell value{}",
          "at end of round",
          "{C:inactive}(Currently {C:mult}+#3# {C:inactive}Mult){}",
        },
      },
      j_paperback_greeting_card = {
        name = "Greeting Card",
        text = {
          "Gains {C:money}$#1#{} of {C:attention}sell value{} if a",
          "played {C:attention}#2#{} is {C:attention}scored",
        },
      },
      j_paperback_calling_card = {
        name = "Calling Card",
        text = {
          "This Joker gains {X:red,C:white}X#1#{} Mult",
          "whenever you defeat a {C:attention}Boss Blind{}",
          "or trigger its {C:attention}ability{}",
          "{C:inactive}(Currently {}{X:red,C:white}X#2#{}{C:inactive} Mult){}",
        },
      },
      j_paperback_subterfuge = {
        name = "Subterfuge",
        text = {
          "Destroys the {C:attention}first played",
          "{C:attention}hand{} every round"
        },
        unlock = {
          "Reduce your deck",
          "by at least {E:1,C:attention}#1#{} cards",
          "in one round"
        }
      },
      j_paperback_triple_moon_goddess = {
        name = "Triple Moon Goddess",
        text = {
          "If played hand contains a {C:attention}Three of a Kind{},",
          "{C:green}#1# in #2#{} chance to create a random {C:planet}Planet{} card and",
          "{C:green}#3# in #4#{} chance to create a random {C:purple}Tarot{} card",
          "{C:inactive}(Must have room)"
        },
      },
      j_paperback_triple_moon_goddess_minor_arcana = {
        name = "Triple Moon Goddess",
        text = {
          "If played hand contains a {C:attention}Three of a Kind{},",
          "{C:green}#1# in #2#{} chance to create a random {C:tarot}Tarot{} card and",
          "{C:green}#3# in #4#{} chance to create a random {C:paperback_minor_arcana}Minor Arcana{} card",
          "{C:inactive}(Must have room)"
        },
      },
      j_paperback_derecho = {
        name = "Derecho",
        text = {
          "Gains {X:mult,C:white}X#1#{} Mult if",
          "scored suits are all {C:paperback_dark_suit}dark{}",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)",
        },
      },
      j_paperback_the_sun_rises = {
        name = "The Sun Rises",
        text = {
          "Set base Chips to {C:chips}#1#{}",
          "Scored {C:paperback_light_suit}light suits{} give {C:chips}+#2#{} Chips",
          "and increase Chips given by {C:chips}+#3#{}",
        },
      },
      j_paperback_jestrica = {
        name = "Jestrica",
        text = {
          "This Joker gains {C:mult}+#1#{} Mult",
          "when an {C:attention}#3#{} is scored",
          "Resets if no {C:attention}#3#s{} are",
          "scored in a round",
          -- TODO might want to indicate if an 8 hasn't been scored
          "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        },
      },
      j_paperback_grand_strategy = {
        name = "Grand Strategy",
        text = {
          "{X:mult,C:white}X#1#{} Mult if",
          "{C:attention}#2#{} unique {C:attention}enhancements{}",
          "are in your full deck",
          "{C:inactive}(Currently {C:attention}#3#{C:inactive})",
        },
      },
      j_paperback_moving_out = {
        name = "Moving Out",
        text = {
          "This Joker gains {C:mult}+#1#{} Mult",
          "if {C:attention}winning{} poker hand is",
          "not your most played hand",
          "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)",
        },
      },
      j_paperback_ready_to_fly = {
        name = "Ready to Fly",
        text = {
          "This Joker gains {X:chips,C:white}X#2#{} Chips",
          "whenever an adjacent Joker {C:attention}triggers",
          "{C:inactive}(Currently {X:chips,C:white}X#1#{C:inactive} Chips)",
        },
      },
      j_paperback_solar_system = {
        name = "Solar System",
        text = {
          "Gives {X:mult,C:white}X#1#{} Mult for",
          "every {C:attention}level{} all 9",
          "base {C:planet}#3#s{} share",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{} {C:inactive}Mult)",
        },
        unlock = {
          "Use {C:attention,E:1}#1#{} different {C:planet}#2#{}",
          "cards in a run"
        }
      },
      j_paperback_reference_card = {
        name = "Reference Card",
        text = {
          "Gives {X:mult,C:white}X#1#{} Mult for every time {C:attention}all{} 9",
          "base {C:attention}poker hands{} have been played",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{} {C:inactive}Mult)",
        },
      },
      j_paperback_dreamsicle = {
        name = "Dreamsicle",
        text = {
          "Scored {C:diamonds}#4#{} give {C:mult}+#1#{} Mult",
          "{C:green}#2# in #3#{} chance this card is",
          "eaten at end of round",
        },
      },
      j_paperback_jimbo_adventure = {
        name = "Jimbo Adventure",
        text = {
          "Skipping a {C:attention}Blind{} creates",
          "a random {C:attention}Tag{}",
        },
      },
      j_paperback_union_card = {
        name = "Union Card",
        text = {
          "Gives {X:mult,C:white}XMult{} equal to the number",
          "of scoring {C:paperback_light_suit}light suit{} cards.",
          "Locks {C:attention}sell value{} of all cards",
          "at {C:money}$0{} until this card is sold",
        },
      },
      j_paperback_cherry_blossoms = {
        name = "Cherry Blossoms",
        text = {
          "{C:hearts}#1#{} give {X:mult,C:white}X#2#{} Mult when scored.",
          "Increases by {X:mult,C:white}X#3#{} Mult for each",
          "consecutively scored {C:hearts}#4#{}",
          "{C:inactive}(Resets after each hand played)",
        },
      },
      -- Suit Drinks
      j_paperback_grenadine = {
        name = "Grenadine",
        text = {
          "The next {C:attention}#1#{} scored {V:1}#2#{} permanently gain",
          "{X:mult,C:white}X#3#{} Mult when scored",
        },
      },
      j_paperback_stout = {
        name = "Stout",
        text = {
          "The next {C:attention}#1#{} scored {V:1}#2#{} permanently gain",
          "{C:chips}+#3#{} Chips when scored",
        },
      },
      j_paperback_aperol = {
        name = "Aperol",
        text = {
          "The next {C:attention}#1#{} scored {V:1}#2#{} permanently gain",
          "{C:money}$#3#{} when scored",
        },
      },
      j_paperback_blue_curacao = {
        name = "Blue Curaçao",
        text = {
          "The next {C:attention}#1#{} scored {V:1}#2#{} permanently gain",
          "{C:mult}+#3#{} Mult when scored",
        },
      },
      j_paperback_nigori = {
        name = "Nigori",
        text = {
          "The next {C:attention}#1#{} scored {V:1}#2#{} permanently gain",
          "{X:chips,C:white}X#3#{} chips when scored",
        },
      },
      j_paperback_lager = {
        name = "Lager",
        text = {
          "The next {C:attention}#1#{} scored {V:1}#2#{} permanently gain",
          "{C:green}+#3#{} odds when scored",
        },
      },
      j_paperback_paranoia = {
        name = "Paranoia",
        text = {
          "{C:paperback_light_suit}Light suits{} give {C:mult}+#1#{} Mult",
          "when scored for every {C:paperback_dark_suit}dark suit",
          "card {C:attention}destroyed{} this run",
          "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        },
      },
      j_paperback_unholy_alliance = {
        name = "Unholy Alliance",
        text = {
          "This Joker gains {C:chips}+#1#{} Chips",
          "when a card or Joker is {C:attention}destroyed{}",
          "{C:inactive}(Currently {C:chips}+#2#{C:inactive} Chips)",
        },
      },
      j_paperback_summoning_circle = {
        name = "Summoning Circle",
        text = {
          "If played hand contains a",
          "{C:attention}#1#{}, create a copy",
          "of a {C:attention}random consumable",
          "{C:inactive}(Must have room)",
        },
      },
      j_paperback_the_sun = {
        name = "The Sun",
        text = {
          "If all scored suits are {C:paperback_light_suit}light{},",
          "this Joker gains {C:mult}+#1#{} Mult",
          "When a suit that isn't {C:paperback_light_suit}light{} scores,",
          "this Joker loses {C:mult}-#1#{} Mult",
          "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)",
        },
      },
      j_paperback_pointy_stick = {
        name = "Pointy Stick",
        text = {
          "{X:mult,C:white}X#1#{} Mult if you have",
          "another {C:attention}\"Stick\"{} Joker",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)",
        },
      },
      j_paperback_prince_of_darkness = {
        name = "Prince of Darkness",
        text = {
          "If scoring hand contains a {C:hearts}#5#{} and",
          "{C:attention}#1#{} other unique suits, this Joker gives",
          "{X:mult,C:white}X#2#{} Mult for {C:attention}this hand{} and the {C:attention}next #3#",
          "{C:inactive}(Currently the next {C:attention}#4#{C:inactive} hands)"
        },
        unlock = {
          "Play a hand scoring {C:attention,E:1}#1#{} suits"
        }
      },
      j_paperback_giga_size = {
        name = "GIGA SIZE",
        text = {
          "This Joker gains {X:mult,C:white}X#2#{} Mult for",
          "every hand played in current {C:attention}Blind{}",
          "{C:inactive}(Will give {X:mult,C:white}X#1#{C:inactive} Mult)"
        },
        unlock = {
          "Play a card with",
          "{C:attention,E:1}50{} additional {C:attention,E:1}Chips{}",
        },
      },
      j_paperback_the_batter = {
        name = "The Batter",
        text = {
          "Scored {C:attention}#3#s{} are destroyed",
          "{C:inactive}({C:attention}#1#{C:inactive}/{C:attention}#2#...{C:inactive})",
          "{s:0.9,C:inactive}(Doesn't require room..?){}",
        }
      },
      j_paperback_off_switch = {
        name = "OFF Switch",
        text = {
          "When a {C:attention}playing card{} is destroyed,",
          "attempt to destroy leftmost destructible Joker",
          "and gain {X:mult,C:white}X#1#{} Mult if successful",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)",
        }
      },
      j_paperback_off_alpha = {
        name = "Alpha",
        text = {
          "Gains {C:chips}+#1#{} Chips for each",
          "Joker {C:attention}destroyed",
          "{C:inactive}(Currently {C:chips}+#2# {C:inactive}Chips)",
        },
      },
      j_paperback_off_omega = {
        name = "Omega",
        text = {
          "Gains {C:mult}+#1#{} Mult for each",
          "Joker {C:attention}destroyed",
          "{C:inactive}(Currently {C:mult}+#2# {C:inactive}Mult)",
        },
      },
      j_paperback_off_epsilon = {
        name = "Epsilon",
        text = {
          "Earns {C:gold}$#1#{} for each",
          "Joker {C:attention}destroyed",
        },
      },
      j_paperback_photocopy = {
        name = "Photocopy",
        text = {
          "Copies the ability",
          "of rightmost {C:attention}Joker{}"
        },
        unlock = {
          "Have a deck containing only",
          "cards of the same",
          "{E:1,C:attention}Rank{} and {E:1,C:attention}Suit{}"
        }
      },
      j_paperback_master_plan = {
        name = "Master Plan",
        text = {
          "Copies ability of",
          "{C:attention}Joker{} to the left"
        },
        unlock = {
          "Complete the {E:1,C:attention}15 Minute City",
          "challenge"
        }
      },
      j_paperback_56_leaf_clover = {
        name = "56 Leaf Clover",
        text = {
          "If the winning hand of a {C:attention}Boss{}",
          "{C:attention}Blind{} scores only {C:clubs}Clubs{},",
          "create a {C:dark_edition}Negative {C:attention}Tag{}",
        }
      },
      j_paperback_57_leaf_clover = {
        name = "57 Leaf Clover",
        text = {
          "{C:green}+#1#{} to all {C:green}listed probabilites{},",
          "gains {C:green}+#2#{} per Blind defeated this {C:attention}Ante{}",
        }
      },
      j_paperback_popsicle_stick = {
        name = "Popsicle Stick",
        text = {
          "{X:mult,C:white}X#1#{} Mult if you have",
          "another {C:attention}\"Stick\"{} Joker",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)",
        },
      },
      j_paperback_let_it_happen = {
        name = "Let it Happen",
        text = {
          "If hand has not been played this",
          "{C:attention}Ante{}, {C:purple}balance{} {C:mult}Mult{} and {C:chips}Chips",
          "{C:inactive}(Hands played:{C:attention}#1#{C:inactive})",
        },
        unlock = {
          "Win a run with",
          "{C:attention}#1#{} on at least",
          "{V:1}#2#{} difficulty",
        }
      },
      j_paperback_in_case_i_make_it = {
        name = "In Case I Make It",
        text = {
          "Every played {C:attention}rankless card{}",
          "permanently gains",
          "{C:chips}+#1#{} Chips when scored",
        },
      },
      j_paperback_evergreens = {
        name = "Evergreens",
        text = {
          "{C:spades}#1#{} give {X:mult,C:white}X#2#{} Mult when scored.",
          "Increases by {X:mult,C:white}X#3#{} Mult for each",
          "consecutively scored {C:spades}#4#{}",
          "{C:inactive}(Resets after each hand played)",
        },
      },
      j_paperback_der_fluschutze = {
        name = "Der Fluschütze",
        text = {
          "If {C:attention}first{} played hand of round",
          "is a single {C:attention}face{} card, destroy it",
          "and this Joker gains {X:mult,C:white}X#1#{} Mult",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{} {C:inactive}Mult)"
        }
      },
      j_paperback_deck_of_cards = {
        name = "Deck of Cards",
        text = {
          "If played hand is a single {C:attention}#1#{},",
          "this Joker gains {X:chips,C:white}X#2#{} Chips and destroys it",
          "{C:inactive}(Currently {X:chips,C:white}X#3#{} {C:inactive}Chips)"
        }
      },
      j_paperback_the_wonder_of_you = {
        name = "The Wonder of You",
        text = {
          "When selecting a {C:attention}Boss Blind{},",
          "create two random {C:attention}tags"
        }
      },
      j_paperback_inner_peace = {
        name = "Inner Peace",
        text = {
          "{C:attention}+3{} hand size",
          "before {C:attention}first{} hand",
          "of round is played"
        }
      },
      j_paperback_shopkeep = {
        name = "Shopkeep",
        text = {
          "Get a {C:attention}#3#{} every",
          "{C:attention}#1#{} {C:attention}Blinds{} defeated {C:inactive}(#2#/#1#){}",
          "Get a {C:attention}#4#{} when",
          "{C:attention}Boss Blind{} is defeated"
        },
        unlock = {
          "Spend {C:money,E:1}$50{} in one shop"
        }
      },
      j_paperback_cakepop = {
        name = "Cakepop",
        text = {
          "Scored {C:hearts}#4#{} give {C:mult}+#1#{} Mult",
          "{C:green}#2# in #3#{} chance this card is",
          "eaten at end of round",
        },
      },
      j_paperback_black_rainbows = {
        name = "Black Rainbows",
        text = {
          "Scored {C:spades}#3#{} and {C:clubs}#4#",
          "have a {C:green}#1# in #2#{} chance",
          "to become {C:dark_edition}Polychrome"
        }
      },
      j_paperback_meeple = {
        name = "Meeple",
        text = {
          "If played hand contains",
          "a scoring {C:attention}face{} card,",
          "{C:green}#1# in #2#{} chance to gain",
          "{C:mult}+#3#{} discard this round",
        }
      },
      j_paperback_apple = {
        name = "Apple",
        text = {
          "When buying a {C:attention}Consumable{}, has a",
          "{C:green}#1# in #2#{} chance to create a",
          "{C:dark_edition}Negative{} copy and a",
          "{C:green}#3# in #4#{} chance to {S:1.1,C:red,E:2}self-destruct",
        }
      },
      j_paperback_heretical_joker = {
        name = "Heretical Joker",
        text = {
          "Played cards with",
          "{C:paperback_stars}#2#{} suit give",
          "{C:mult}+#1#{} Mult when scored",
        },
      },
      j_paperback_fraudulent_joker = {
        name = "Fraudulent Joker",
        text = {
          "Played cards with",
          "{C:paperback_crowns}#2#{} suit give",
          "{C:mult}+#1#{} Mult when scored",
        },
      },
      j_paperback_rock_candy = {
        name = "Rock Candy",
        text = {
          "Scored {C:paperback_stars}#4#{} give {C:mult}+#1#{} Mult",
          "{C:green}#2# in #3#{} chance this card is",
          "eaten at end of round",
        },
      },
      j_paperback_rockin_stick = {
        name = "Rockin' Stick",
        text = {
          "Gives {X:mult,C:white}X#1#{} Mult for every",
          "{C:attention}\"Stick\"{} Joker you have",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)",
        },
      },
      j_paperback_tanghulu = {
        name = "Tanghulu",
        text = {
          "Scored {C:paperback_crowns}#4#{} give {C:mult}+#1#{} Mult",
          "{C:green}#2# in #3#{} chance this card is",
          "eaten at end of round",
        },
      },
      j_paperback_sweet_stick = {
        name = "Sweet Stick",
        text = {
          "Gives {X:mult,C:white}X#1#{} Mult for every",
          "{C:attention}\"Stick\"{} Joker you have",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)",
        },
      },
      j_paperback_quartz = {
        name = "Quartz",
        text = {
          "Scored {C:paperback_stars}Stars{} give {X:chips,C:white}X1{} Chips,",
          "{X:chips,C:white}+X#1#{} for each other played {C:paperback_stars}Star"
        }
      },
      j_paperback_pyrite = {
        name = "Pyrite",
        text = {
          "Played {V:1}#1#{} have a {C:green}#2# in #3#{}",
          "chance to create a random",
          "{C:tarot}Tarot{} card when scored",
          "{C:inactive}(Must have room)"
        }
      },
      j_paperback_wheat_field = {
        name = "Wheat Field",
        text = {
          "{C:paperback_crowns}#1#{} give {X:mult,C:white}X#2#{} Mult when scored.",
          "Increases by {X:mult,C:white}X#3#{} Mult for each",
          "consecutively scored {C:paperback_crowns}#4#{}",
          "{C:inactive}(Resets after each hand played)",
        },
      },
      j_paperback_chip_clip = {
        name = "Chip Clip",
        text = {
          "This Joker gains {C:chips}+#1#{} Chips",
          "for each {C:attention}Clip{} {C:attention}held in hand",
          "at {C:attention}end of round{}",
          "{C:inactive}(Currently {C:chips}+#2#{C:inactive} Chips)"
        }
      },

      j_paperback_clothespin = {
        name = "Clothespin",
        text = {
          "This Joker simultaneously counts as a {C:attention}played{}",
          "and {C:attention}held{} {C:attention}paperclip{}",
        }
      },
      j_paperback_happy_accident = {
        name = "Happy Accident",
        text = {
          "Each {C:attention}#1#{}",
          "held in hand",
          "gives {X:chips,C:white}XChips{}",
          "at {C:attention}halved{} scaling",
          "{X:chips,C:white}X1.5{C:inactive} -> {X:chips,C:white}X1.25{}",
        },
      },
      j_paperback_watercolor_joker = {
        name = "Watercolor Joker",
        text = {
          "{C:attention}#1#s{} give",
          "{X:chips,C:white}X#2#{} Chips when scored",
        },
        unlock = {
          "Play a {C:attention,E:1}Soaked",
          "playing card with",
          "a {C:attention,E:1}Blue Seal",
        },
      },
      j_paperback_birches = {
        name = "Birches",
        text = {
          "{C:paperback_stars}#1#{} give {X:mult,C:white}X#2#{} Mult when scored.",
          "Increases by {X:mult,C:white}X#3#{} Mult for each",
          "consecutively scored {C:paperback_stars}#4#{}",
          "{C:inactive}(Resets after each hand played)",
        },
      },
      j_paperback_oracle = {
        name = "Oracle",
        text = {
          "This Joker gains {X:chips,C:white}X#1#",
          "Chips for every {C:attention}unique",
          "{C:paperback_minor_arcana}#3#{} card used",
          "{C:inactive}(Currently {X:chips,C:white}X#2#{C:inactive} Chips)",
        },
      },
      j_paperback_punch_card = {
        name = "Punch Card",
        text = {
          "After {C:attention}#1#{} rounds,",
          "sell this card for",
          "{C:attention}#3#{} Ante",
          "{C:inactive}(Currently {C:attention}#2#{C:inactive}/#1#)",
        },
      },
      j_paperback_eyelander = {
        name = "Eyelander",
        text = {
          "Scored {C:attention}face{} cards are destroyed.",
          "After scoring {C:attention}#1# face{} cards,",
          "{C:attention}selling{} this Joker adds {C:dark_edition}Negative{}",
          "to a {C:attention}random{} Joker",
          "{C:inactive}(Currently {C:attention}#2#{C:inactive} Heads)"
        }
      },
      j_paperback_torii = {
        name = "Torii",
        text = {
          "Gives {C:attention}#1#{} Ante every",
          "{C:attention}#2#{} {C:inactive}(#3#){} skipped Blinds",
          "{C:inactive}(Only counts skips in new antes,{}",
          "{C:inactive}currently {V:1}#4#{C:inactive})",
        }
      },
      j_paperback_freight = {
        name = "Freight",
        text = {
          "If cleared Blind is a {C:attention}Boss Blind{},",
          "gain {C:money}$#1#{} of sell value, otherwise",
          "{C:attention}earn{} the sell value of this Joker.",
          "When sold, gain {C:red}+#2#{} discard per {C:money}$#3#{}",
          "of sell value {C:attention}instead{} of money",
        }
      },
      j_paperback_banana_man = {
        name = "Banana Man",
        text = {
          "Jokers have a {C:green}#1# in #2#{} chance",
          "to give {X:mult,C:white} X#3# {} Mult"
        },
        unlock = {
          "Acquire",
          "{C:attention,E:1}Cavendish",
          "in a run"
        }
      },
      j_paperback_guns_blazin = {
        name = "Guns Blazin'",
        text = {
          "Played {C:attention}#2#s{}",
          "give {X:mult,C:white}X#1#{} Mult",
          "when scored",
        },
        unlock = {
          "Play a hand of",
          "{C:attention,E:1}#1# Steel{} cards",
        }
      },
      j_paperback_satellite_array = {
        name = "Satellite Array",
        text = {
          "This Joker gains {C:chips}+#1#{} Chips",
          "for each {C:planet}#4#{} card used",
          "and loses {C:chips}-#2#{} Chips",
          "for every hand played",
          "{C:inactive}(Currently {C:chips}+#3#{C:inactive} Chips)",
        }
      },
      j_paperback_rosary_beads = {
        name = "Rosary Beads",
        text = {
          "If scored hand contains",
          "{C:attention}#1#{} or more {C:hearts}#3#{}, earn {C:money}$#2#{}"
        }
      },
      j_paperback_tian_tian = {
        name = "Tian Tian",
        text = {
          "This Joker gains {X:mult,C:white}X#1#{} Mult when",
          "a playing card is {C:attention}destroyed{}",
          "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)"
        }
      },
      j_paperback_disco = {
        name = "Disco Joker",
        text = {
          "This Joker gains {C:mult}+#1#{} Mult when",
          "buying a card with {C:money}$#2#{} or less",
          "{C:inactive}(Currently {C:mult}+#3#{C:inactive} Mult)"
        }
      },
      j_paperback_a_balatro_movie = {
        name = "A Balatro Movie",
        text = {
          "If {C:attention}played hand{} is the {C:attention}same{}",
          "as the {C:attention}previous hand{}, earn {C:money}$#2#{}",
          "{C:inactive}(Last played: {C:attention}#1#{C:inactive})"
        }
      },
      j_paperback_unionized_labor = {
        name = "Unionized Labor",
        text = {
          "{C:attention}Triples{} all listed {C:green,E:1,S:1.1}probabilities",
          "while you have {C:money}$#1#{} or less",
          "{C:attention}Halves{} probabilities otherwise",
          "{C:inactive}(ex: {C:green}1 in 3{C:inactive} -> {C:green}#2# in #3#{C:inactive})"
        }
      },
      j_paperback_chocolate_coins = {
        name = "Chocolate Coins",
        text = {
          "Earn {C:money}$#1#{} at the end of round",
          "Reduces by {C:money}$#2#{} each round"
        }
      },
      j_paperback_park_postcard = {
        name = "Park Postcard",
        text = {
          "This Joker gains",
          "{X:mult,C:white}X#1#{} Mult After each round",
          "{C:attention}Resets{} when a card is",
          "{C:attention}added{} or {C:attention}removed{} from deck",
          "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)"
        }
      },
      j_paperback_keycard = {
        name = "Keycard",
        text = {
          "After defeating a {C:attention}Boss Blind",
          "this Joker {C:red,E:1}self-destructs{}",
          "and gain {C:money}$#1#{}"
        }
      },
      j_paperback_mind_electric = {
        name = "The Mind Electric",
        text = {
          "Scored {C:mult}#3#s{} are {C:attention}destroyed",
          "And give this Joker {X:mult,C:white}X#1#{} Mult",
          "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)"
        }
      },
      j_paperback_stella_octangula = {
        name = "Stella Octangula",
        text = {
          "The first played {V:1}#2#{} each round",
          "gives {X:chips,C:white} X#1# {} Chips"
        }
      },
      j_paperback_cast_iron = {
        name = "Cast Iron",
        text = {
          "Gives {C:attention}+#6#{} hand size",
          "for every {C:attention}#2# #3#s",
          "in your {C:attention}full deck",
          "{C:inactive}(Currently {C:attention}+#4#{C:inactive} hand size, Max #5#){}"
        }
      },
      j_paperback_first_contact = {
        name = "First Contact",
        text = {
          "Create a random {C:spectral}#3#{} card",
          "for every {C:attention}#1#{C:inactive} [#2#]{} scored {C:paperback_dark_suit}Dark Suits",
          "{C:inactive}(Must have room)",
        },
      },
      j_paperback_paralyzed = {
        name = "Paralyzed",
        text = {
          "Create a random {C:tarot}#1#{} card",
          "upon clearing a blind"
        }
      },
      j_paperback_coin_collection = {
        name = "Coin Collection",
        text = {
          "Any time you earn {C:money}money{}",
          "Earn an additional {C:money}$#1#"
        }
      },
      j_paperback_attacking_vertical = {
        name = "Attacking Vertical",
        text = {
          "Scored {C:attention}#1#{}s and {C:attention}#2#{}s give {X:mult,C:white} X#3# {} Mult",
          "Increased by {X:mult,C:white} X#4# {} Mult",
          "Upon clearing a {C:attention}Boss Blind"
        }
      },
      j_paperback_emf_reader = {
        name = "EMF Reader",
        text = {
          "If {C:attention}first hand{} of round",
          "contains a {C:attention}#1#{}, destroy",
          "played cards and create",
          "a random {C:spectral}#2#{} card"
        }
      },
      j_paperback_jester = {
        name = "Jester",
        text = {
          "Any time a card is {C:attention}destroyed",
          "destroy a {C:attention}random{} card in deck"
        }
      },
      j_paperback_journal = {
        name = "Journal",
        text = {
          "This Joker gives the",
          "total {C:chips}Chips{} of",
          "the previous hand.",
          "{C:inactive}(Currently {C:chips}+#1#{C:inactive} Chips)"
        }
      },
      j_paperback_silent_assassin = {
        name = "Silent Assassin",
        text = {
          "Scored {C:attention}#1#{}s and {C:attention}#2#{}s give {C:mult}+#3#{} Mult",
          "Increased by {C:mult}+#4#{} Mult",
          "For every {C:attention}#5#{C:inactive} [#6#]{} cards {C:attention}destroyed"
        }
      },
      j_paperback_yacht_dice = {
        name = "Yacht Dice",
        text = {
          "This Joker gains {X:mult,C:white} X#1# {} Mult",
          "for each {C:attention}unique{} hand type",
          "played this run",
          "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)"
        }
      },
      j_paperback_stereoscopic_specs = {
        name = "Stereoscopic Specs",
        text = {
          "Create a {C:attention}copy{} of the",
          "last tag used after",
          "beating a {C:attention}Boss Blind",
          "{C:inactive}(Currently {C:attention}#1#{C:inactive})"
        }
      },
      j_paperback_yacht = {
        name = "Yacht",
        text = {
          "This Joker gains {C:chips}+#1#{} Chips if",
          "hand contained a scoring",
          "{C:paperback_stars}#3#{} or {C:paperback_crowns}#4#",
          "{C:inactive}(Currently {C:chips}+#2#{C:inactive} Chips)"
        }
      },
      j_paperback_towering_pillar_of_hats = {
        name = "Towering Pillar of Hats",
        text = {
          "Played {C:paperback_crowns}#7#{} give {C:mult}+#1#{} Mult for every {C:attention}#3#",
          "{C:attention}#4#, #5#{} or {C:attention}#6#{} in the deck",
          "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        },
      },
      j_paperback_joker_duty = {
        name = "Joker Duty",
        text = {
          "This Joker gains {C:mult}+#1#{} Mult if",
          "round was cleared with",
          "equal {C:chips}hands{} and {C:mult}discards",
          "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
      },
      j_paperback_shuttle = {
        name = "Shuttle",
        text = {
          "The {C:attention}first{} played hand of round",
          "gives {C:money}money{} equal to",
          "{C:attention}double{} the played hand's level",
          "{C:inactive}(Max of {C:money}$#1#{C:inactive})"
        }
      },
      j_paperback_loaded_dice = {
        name = "Loaded Dice",
        text = {
          "Adds {C:green}#1#{} to all listed {C:green,E:1,S:1.1}probabilities",
          "If hand contains a",
          "scoring {C:paperback_crowns}#2#{}",
        }
      },
      j_paperback_tropic_birds = {
        name = "Tropic Birds",
        text = {
          "If scoring hand",
          "contains an {C:attention}#1#{},",
          "retrigger the {C:attention}first",
          "and {C:attention}last{} card"
        }
      },
      j_paperback_jacks = {
        name = "Jacks",
        text = {
          "This Joker gains {C:mult}+#1#{} Mult",
          "when a {C:attention}#3#{} is discarded",
          "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
      },
      j_paperback_red_sun_in_the_sky = {
        name = "Red Sun in the Sky",
        text = {
          "Scored {C:paperback_light_suit}light suits{}",
          "give {C:mult}+#1#{} Mult for each",
          "scored {C:paperback_light_suit}light suit{} this round",
          "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
      },
      -- Cross-Mod jokers start here
      j_paperback_moon_waltz = {
        name = "Moon Waltz",
        text = {
          "This Joker has a {C:green}#3#{} in {C:green}#4#{} chance of gaining",
          "half of a used {C:planet}Moon{} or",
          "{C:planet}Asteroid{} card's {C:mult}+Mult{} or {C:chips}+Chips{}",
          "{C:inactive}(Currently {C:mult}+#1#{C:inactive} Mult and {C:chips}+#2#{C:inactive} Chips)",
        },
      },
    },
    Spectral = {
      c_paperback_apostle_of_cups = {
        name = "Apostle of Cups",
        text = {
          "Selected {C:attention}playing card",
          "becomes {C:dark_edition}Negative",
          "{C:attention}#1#{} Joker slot",
        }
      },
      c_paperback_apostle_of_wands = {
        name = "Apostle of Wands",
        text = {
          "Create a non-{C:legendary}Legendary{} Joker",
          "of {C:attention}your choice{}",
          "{C:inactive}(No duplicates)"
        }
      },
      c_paperback_apostle_of_swords = {
        name = "Apostle of Swords",
        text = {
          "Destroy selected {C:attention}Joker{}",
          "{C:attention}#1#{} Antes"
        }
      },
      c_paperback_apostle_of_pentacles = {
        name = "Apostle of Pentacles",
        text = {
          "Add a {C:paperback_platinum}Platinum Clip{} to",
          "{C:attention}#1#{} selected card"
        }
      },
      c_paperback_golden_bough = {
        name = "Golden Bough",
        text = {
          "Creates a random {C:dark_edition}Negative",
          "{C:paperback_ego_gift}E.G.O Gift{} after each {C:attention}Boss Blind",
          "{C:red}#1#{} Joker Slot"
        }
      },
    },
    paperback_minor_arcana = {
      c_paperback_ace_of_cups = {
        name = "Ace of Cups",
        text = {
          "Add a {C:chips}Blue Clip{} to up",
          "to {C:attention}#1#{} selected cards"
        }
      },
      c_paperback_two_of_cups = {
        name = "Two of Cups",
        text = {
          "Gives a {C:dark_edition}Polychrome{},",
          "{C:dark_edition}Holographic{}, {C:dark_edition}Foil{},",
          "{C:mult}Rare{} or {C:green}Uncommon{C:attention} Tag"
        }
      },
      c_paperback_three_of_cups = {
        name = "Three of Cups",
        text = {
          "Add a {C:paperback_black}Black Clip{} to",
          "{C:attention}#1#{} selected card"
        }
      },
      c_paperback_four_of_cups = {
        name = "Four of Cups",
        text = {
          "Remove {C:attention}enhancements{}, {C:attention}seals{} and {C:attention}editions{}",
          "from up to {C:attention}#1#{} selected cards.",
          "Earn {C:money}$#2#{} for each one removed"
        }
      },
      c_paperback_five_of_cups = {
        name = "Five of Cups",
        text = {
          "Enhances {C:attention}#1#{}",
          "selected cards to",
          "{C:attention}#2#s{}"
        }
      },
      c_paperback_six_of_cups = {
        name = "Six of Cups",
        text = {
          "Earn {C:attention}half{} the {C:chips}Chip",
          "{C:chips}value{} of {C:attention}#1#{} selected",
          "card as {C:money}money",
          "{C:inactive}(Max of {C:money}$#2#{C:inactive})"
        }
      },
      c_paperback_seven_of_cups = {
        name = "Seven of Cups",
        text = {
          "Give a random {C:attention}enhancement",
          "to up to {C:attention}#1#{} selected cards"
        }
      },
      c_paperback_eight_of_cups = {
        name = "Eight of Cups",
        text = {
          "Converts up to {C:attention}#1#{} selected",
          "cards into a suit that is",
          "not {C:attention}currently selected"
        }
      },
      c_paperback_nine_of_cups = {
        name = "Nine of Cups",
        text = {
          "Destroy selected {C:attention}Joker{} and",
          "create a new {C:attention}Joker{} of higher",
          "{C:attention}rarity{} if possible, otherwise",
          "create one of equal rarity",
          "{C:inactive}(Cannot create a {C:legendary}Legendary{C:inactive})"
        }
      },
      c_paperback_ten_of_cups = {
        name = "Ten of Cups",
        text = {
          "{C:green}#1# in #2#{} chance to add",
          "{C:dark_edition}Polychrome{} edition to",
          "{C:attention}1{} selected card"
        }
      },
      c_paperback_page_of_cups = {
        name = "Page of Cups",
        text = {
          "Add a {C:inactive}White Clip{} to up",
          "to {C:attention}#1#{} selected cards"
        }
      },
      c_paperback_knight_of_cups = {
        name = "Knight of Cups",
        text = {
          "Select {C:attention}#1#{} cards, the {C:attention}left{} card",
          "copies {C:attention}everything{} from the {C:attention}right",
          "card except {C:attention}rank{} and {C:attention}suit",
          "Destroys the {C:attention}right{} card",
          "{C:inactive}(Drag to rearrange)"
        }
      },
      c_paperback_queen_of_cups = {
        name = "Queen of Cups",
        text = {
          "Enhances {C:attention}#1#{}",
          "selected cards to",
          "{C:attention}#2#s{}"
        }
      },
      c_paperback_king_of_cups = {
        name = "King of Cups",
        text = {
          "Earn {C:money}$#1#{} for each suit with all",
          "13 {C:attention}base ranks{} that you have",
          "{C:inactive}(Currently {C:money}$#2#{C:inactive})"
        }
      },
      c_paperback_ace_of_wands = {
        name = "Ace of Wands",
        text = {
          "Add a {C:mult}Red Clip{} to up",
          "to {C:attention}#1#{} selected cards"
        }
      },
      c_paperback_two_of_wands = {
        name = "Two of Wands",
        text = {
          "Create the {C:planet}Planet{} card",
          "for your {C:attention}most{} and {C:attention}least",
          "played {C:attention}poker hands",
          "{C:inactive}(Must have room)"
        }
      },
      c_paperback_three_of_wands = {
        name = "Three of Wands",
        text = {
          "Create a copy of {C:attention}#1#",
          "selected card in",
          "your hand"
        }
      },
      c_paperback_four_of_wands = {
        name = "Four of Wands",
        text = {
          "Add a {C:paperback_pink}Pink Clip{} to up",
          "to {C:attention}#1#{} selected cards"
        }
      },
      c_paperback_five_of_wands = {
        name = "Five of Wands",
        text = {
          "Destroys all cards",
          "{C:attention}held in hand{}, and",
          "sets money to {C:money}$0"
        }
      },
      c_paperback_six_of_wands = {
        name = "Six of Wands",
        text = {
          "Enhances {C:attention}#1#{}",
          "selected cards to",
          "{C:attention}#2#s{}"
        }
      },
      c_paperback_seven_of_wands = {
        name = "Seven of Wands",
        text = {
          "Gives a {C:attention}Breaking Tag"
        }
      },
      c_paperback_eight_of_wands = {
        name = "Eight of Wands",
        text = {
          "Create a {C:dark_edition}Negative {C:attention}Tag{} and",
          "lose {C:money}$#1#{}, plus {C:money}$#2#{} for every",
          "Joker over {C:attention}#3#{} owned",
          "{C:inactive}(Currently {C:money}$#4#{C:inactive})"
        }
      },
      c_paperback_nine_of_wands = {
        name = "Nine of Wands",
        text = {
          "Enhances {C:attention}#1#{}",
          "selected cards to",
          "{C:attention}#2#s{}"
        }
      },
      c_paperback_ten_of_wands = {
        name = "Ten of Wands",
        text = {
          "Select {C:attention}#1#{} cards, destroy the",
          "{C:attention}rightmost two{} and give their",
          "{C:chips}Chip value{} to the {C:attention}leftmost",
          "{C:inactive}(Drag to rearrange)"
        }
      },
      c_paperback_page_of_wands = {
        name = "Page of Wands",
        text = {
          "Add an {C:attention}Orange Clip{} to up",
          "to {C:attention}#1#{} selected cards"
        }
      },
      c_paperback_knight_of_wands = {
        name = "Knight of Wands",
        text = {
          "Gives a {C:mult}High Risk{C:attention} Tag"
        }
      },
      c_paperback_queen_of_wands = {
        name = "Queen of Wands",
        text = {
          "{C:green}#1# in #2#{} chance to",
          "add {C:dark_edition}Dichrome{} edition",
          "to a random {C:attention}Joker"
        }
      },
      c_paperback_king_of_wands = {
        name = "King of Wands",
        text = {
          "Creates a random",
          "non-{C:chips}Common{C:attention} Joker",
          "{C:inactive}(Except {C:legendary}Legendary{C:inactive})"
        }
      },
      c_paperback_ace_of_swords = {
        name = "Ace of Swords",
        text = {
          "Converts up to",
          "{C:attention}#1#{} selected cards",
          "to {V:1}#2#{}",
        }
      },
      c_paperback_two_of_swords = {
        name = "Two of Swords",
        text = {
          "Converts up to",
          "{C:attention}#1#{} selected cards",
          "to last {C:attention}scored{} suit",
          "{C:inactive}(Currently: {V:1}#2#{C:inactive})",
        }
      },
      c_paperback_three_of_swords = {
        name = "Three of Swords",
        text = {
          "Enhances {C:attention}#1#{}",
          "selected cards to",
          "{C:attention}#2#s{}"
        }
      },
      c_paperback_four_of_swords = {
        name = "Four of Swords",
        text = {
          "Converts up to {C:attention}#1#",
          "selected cards to",
          "random {C:attention}Face{} cards"
        }
      },
      c_paperback_five_of_swords = {
        name = "Five of Swords",
        text = {
          "Give a random {C:attention}edition{},",
          "{C:attention}seal{} or {C:attention}enhancement",
          "to {C:attention}#1#{} selected card"
        }
      },
      c_paperback_six_of_swords = {
        name = "Six of Swords",
        text = {
          "Add a {C:attention}Yellow Clip{} to",
          "{C:attention}#1#{} selected cards"
        }
      },
      c_paperback_seven_of_swords = {
        name = "Seven of Swords",
        text = {
          "Add a {C:attention}Gold Clip{} to",
          "{C:attention}#1#{} selected card"
        }
      },
      c_paperback_eight_of_swords = {
        name = "Eight of Swords",
        text = {
          "Adds random {C:attention}Clips{} to",
          "up to {C:attention}#1#{} selected cards"
        }
      },
      c_paperback_nine_of_swords = {
        name = "Nine of Swords",
        text = {
          "Destroy selected Joker and earn {C:money}$#2#{}",
          "It {C:red}cannot{} appear again this run",
          "{C:inactive}(Can destroy {C:paperback_eternal}Eternals{C:inactive})"
        }
      },
      c_paperback_ten_of_swords = {
        name = "Ten of Swords",
        text = {
          "{C:attention}Destroy{} all cards in full deck",
          "with the same {C:attention}rank{} as selected card"
        }
      },
      c_paperback_page_of_swords = {
        name = "Page of Swords",
        text = {
          "Enhances {C:attention}#1#{}",
          "selected cards to",
          "{C:attention}#2#s{}"
        }
      },
      c_paperback_knight_of_swords = {
        name = "Knight of Swords",
        text = {
          "Create a random {C:paperback_minor_arcana}Minor Arcana{} card",
          "and a random {C:tarot}Tarot{} card",
          "{C:inactive}(Must have room)"
        }
      },
      c_paperback_queen_of_swords = {
        name = "Queen of Swords",
        text = {
          "Converts {C:attention}#1#{} random cards in",
          "full deck with {C:attention}different suits",
          "to the selected card's {C:attention}suit"
        }
      },
      c_paperback_king_of_swords = {
        name = "King of Swords",
        text = {
          "Remove {C:money}Rental{} and {C:paperback_perishable}Perishable",
          "from selected Joker"
        }
      },
      c_paperback_king_of_swords_bunc = {
        name = "King of Swords",
        text = {
          "Remove all Stickers except {C:paperback_eternal}Eternal{}",
          "from selected Joker"
        }
      },
      c_paperback_ace_of_pentacles = {
        name = "Ace of Pentacles",
        text = {
          "Converts up to",
          "{C:attention}#1#{} selected cards",
          "to {V:1}#2#{}",
        }
      },
      c_paperback_two_of_pentacles = {
        name = "Two of Pentacles",
        text = {
          "Selected Joker gains",
          "or loses {C:paperback_eternal}Eternal{}"
        }
      },
      c_paperback_three_of_pentacles = {
        name = "Three of Pentacles",
        text = {
          "Select {C:attention}#1#{} cards, the",
          "{C:attention}leftmost two{} copy the",
          "{C:attention}rightmost{} card's {C:attention}enhancement{}",
          "{C:inactive}(Drag to rearrange)"
        }
      },
      c_paperback_four_of_pentacles = {
        name = "Four of Pentacles",
        text = {
          "Select {C:attention}#1#{} cards.",
          "{C:green}#2# in #3#{} chance to",
          "destroy each {C:attention}unselected{}",
          "card in hand"
        }
      },
      c_paperback_five_of_pentacles = {
        name = "Five of Pentacles",
        text = {
          "Enhances {C:attention}#1#{}",
          "selected card into",
          "an {C:attention}#2#{}"
        }
      },
      c_paperback_six_of_pentacles = {
        name = "Six of Pentacles",
        text = {
          "Gives an {C:money}Investment{},",
          "{C:money}Economy{}, {C:red}Coupon{},",
          "{C:green}D6{}, or {C:attention}Juggle Tag{}"
        }
      },
      c_paperback_seven_of_pentacles = {
        name = "Seven of Pentacles",
        text = {
          "Add a {C:green}Green Clip{} to up",
          "to {C:attention}#1#{} selected cards"
        }
      },
      c_paperback_eight_of_pentacles = {
        name = "Eight of Pentacles",
        text = {
          "Earn {C:money}$#1#{} for every unique",
          "{C:tarot}Tarot{} and {C:paperback_minor_arcana}Minor Arcana{}",
          "card used this run",
          "{C:inactive}(Currently {C:money}$#2#{C:inactive})"
        }
      },
      c_paperback_nine_of_pentacles = {
        name = "Nine of Pentacles",
        text = {
          "Add a {C:purple}Purple Clip{} to",
          "{C:attention}#1#{} selected card"
        }
      },
      c_paperback_ten_of_pentacles = {
        name = "Ten of Pentacles",
        text = {
          "Earn between {C:money}$#1#{} and {C:money}$#2#{}"
        }
      },
      c_paperback_page_of_pentacles = {
        name = "Page of Pentacles",
        text = {
          "Enhances {C:attention}#1#{}",
          "selected cards to",
          "{C:attention}#2#s{}"
        }
      },
      c_paperback_knight_of_pentacles = {
        name = "Knight of Pentacles",
        text = {
          "Reset {C:green}Reroll{} cost to {C:money}$#1#{}"
        }
      },
      c_paperback_queen_of_pentacles = {
        name = "Queen of Pentacles",
        text = {
          "Select {C:attention}#1#{} cards.",
          "Copy the {C:attention}right{} card's",
          "{C:attention}rank{} onto the {C:attention}left{} card",
          "{C:inactive}(Drag to rearrange)"
        }
      },
      c_paperback_king_of_pentacles = {
        name = "King of Pentacles",
        text = {
          "Earn {C:money}$#1#{} for each {C:attention}face{}",
          "card in your full deck",
          "{C:inactive}(Currently {C:money}$#2#{C:inactive})"
        }
      },
    },
    paperback_ego_gift = {
      c_paperback_dark_vestige = {
        name = "Dark Vestige",
        text = {
          "The result of attempting to",
          "have duplicate {C:paperback_ego_gift}E.G.O Gifts{}...",
        }
      },
      c_paperback_imposed_weight = {
        name = "Imposed Weight",
        text = {
          "Retrigger the {C:attention}rightmost scoring{} card",
          "{C:attention}#1#{} time for each {C:attention}empty{} Joker slot",
        }
      },
      c_paperback_phlebotomy_pack = {
        name = "Phlebotomy Pack",
        text = {
          "{C:blue}+#1#{} hand each round",
        }
      },
      c_paperback_smokes_and_wires = {
        name = "Smokes and Wires",
        text = {
          "{X:red,C:white}X#1#{} Mult on {C:attention}final",
          "{C:attention}hand{} of round",
        }
      },
      c_paperback_coffee_and_cranes = {
        name = "Coffee and Cranes",
        text = {
          "Earn {C:money}$#1#{} at end of round",
        }
      },
      c_paperback_fiery_down = {
        name = "Fiery Down",
        text = {
          "After discarding {C:attention}#1#{} {C:inactive}(#2#){}",
          "cards, upgrade next",
          "played {C:attention}poker hand"
        }
      },
      c_paperback_decamillennial_stewpot = {
        name = "Decamillenial Stewpot",
        text = {
          "If {C:attention}first hand{} of round",
          "is a {C:attention}single{} card, destroy it",
        }
      },
      c_paperback_downpour = {
        name = "Downpour",
        text = {
          "Played hands lower the",
          "{C:attention}blind requirement{} by {C:attention}#1#%",
        }
      },
      c_paperback_rusty_coin = {
        name = "Rusty Commemorative Coin",
        text = {
          "If {C:attention}first hand{} of round",
          "is a {C:attention}single{} card,",
          "add a random {C:attention}seal{} to it"
        }
      },
      c_paperback_ragged_umbrella = {
        name = "Ragged Umbrella",
        text = {
          "This {C:paperback_ego_gift}E.G.O Gift{} gains {C:chips}+#1#{} Chips",
          "every time a {C:attention}played hand",
          "does not defeat the {C:attention}Blind",
          "{C:inactive}(Currently {C:chips}+#2#{C:inactive} Chips)",
        }
      },
      c_paperback_thrill = {
        name = "Thrill",
        text = {
          "On {C:attention}first{} hand of round,",
          "this {C:paperback_ego_gift}E.G.O Gift{} gives {X:mult,C:white}X#1#{} Mult",
          "for every {C:attention}discard{} used this {C:attention}round",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)",
        }
      },
      c_paperback_thrill_inactive = {
        name = "Thrill",
        text = {
          "On {C:attention}first{} hand of round,",
          "this {C:paperback_ego_gift}E.G.O Gift{} gives {X:mult,C:white}X#1#{} Mult",
          "for every {C:attention}discard{} used this {C:attention}round",
        }
      },
      c_paperback_disk_fragment = {
        name = "Disk Fragment",
        text = {
          "When {C:attention}Small Blind{} or {C:attention}Big Blind{} is selected,",
          "create {C:attention}#1#{} {C:dark_edition}Negative{} {C:planet}Planet{} cards",
          "if none are currently owned",
        }
      },
      c_paperback_death_seeker = {
        name = "Deathseeker",
        text = {
          "{C:attention}Enhanced{} cards give {C:mult}+Mult{}",
          "equal to their {C:attention}rank{} when scored",
        }
      },
      c_paperback_pendant_of_nostalgia_minor_arcana = {
        name = "Pendant of Nostalgia",
        text = {
          "Whenever a {C:attention}playing card{} is destroyed,",
          "create a random {C:tarot}Tarot{} or {C:paperback_minor_arcana}Minor Arcana{} card",
          "{C:inactive}(Must have room)"
        }
      },
      c_paperback_pendant_of_nostalgia = {
        name = "Pendant of Nostalgia",
        text = {
          "Whenever a {C:attention}playing card{} is destroyed,",
          "create a random {C:tarot}Tarot{} card",
          "{C:inactive}(Must have room)"
        }
      },
      c_paperback_blue_lighter = {
        name = "Blue Zippo Lighter",
        text = {
          "When selecting {C:attention}Blind{},",
          "destroy a non-{C:paperback_ego_gift}E.G.O Gift{} consumable",
          "and this {C:paperback_ego_gift}E.G.O Gift{} gains {X:mult,C:white}X#1#{} Mult",
          "{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult)"
        }
      },
      c_paperback_broken_glasses = {
        name = "Broken Glasses",
        text = {
          "Whenever exactly {C:attention}1{} or {C:attention}2{} cards are {C:attention}destroyed{},",
          "create {C:attention}two copies{} of each destroyed card",
          "{C:green}#1# in #2#{} chance to {C:red}self-destruct{} after"
        }
      },
      c_paperback_nebulizer = {
        name = "Nebulizer",
        text = {
          "Scored cards have a {C:green}#1# in #2#{}",
          "chance to give {X:mult,C:white}X#3#{} Mult"
        }
      },
      c_paperback_tomorrow_fortune = {
        name = "Tomorrow's Fortune",
        text = {
          "All {C:attention}Booster Packs{} contain",
          "{C:attention}#1#{} more card to choose from"
        }
      },
      c_paperback_fluorescent_lamp = {
        name = "Fluorescent Lamp",
        text = {
          "{C:red}+#1#{} discard, and",
          "{C:red}+#1#{} discard for every",
          "{C:attention}#2#{} empty {C:attention}Joker{} slots",
          "{C:inactive}(Currently {C:red}+#3#{C:inactive} discards)"
        }
      },
      c_paperback_lightning_rod = {
        name = "Lightning Rod",
        text = {
          "Cards {C:attention}held in hand{}",
          "have a {C:green}#1# in #2#",
          "chance to retrigger"
        }
      },
      c_paperback_chalice_of_trickle_down = {
        name = "Chalice of Trickle Down",
        text = {
          "During {C:attention}Boss Blinds{}, gives",
          "{C:money}money{} equal to lowest rank",
          "in {C:attention}scoring hand"
        }
      },
      c_paperback_patrolling_flashlight = {
        name = "Patrolling Flashlight",
        text = {
          "The first consumable used each {C:attention}Ante{}",
          "creates a {C:attention}Energized copy{}"
        }
      },
    },
    Voucher = {
      v_paperback_celtic_cross = {
        name = "Celtic Cross",
        text = {
          "When clearing a {C:attention}Boss",
          "{C:attention}Blind{}, the next shop will",
          "have an additional {C:attention}free",
          "{C:paperback_minor_arcana}Mega Minor Arcana Pack"
        }
      },
      v_paperback_soothsay = {
        name = "Soothsay",
        text = {
          "{C:paperback_minor_arcana}Minor Arcana{} cards may",
          "appear in the {C:money}Shop"
        },
        unlock = {
          "Use {C:attention,E:1}#1#{} {C:paperback_minor_arcana,E:1}Minor Arcana{} in one Run"
        }
      },
      v_paperback_second_trumpet = {
        name = "Second Trumpet",
        text = {
          "Your first {C:paperback_ego_gift}E.G.O Gift{}",
          "gives {C:attention}+#1#{} consumable slot"
        }
      },
      v_paperback_rabbit_protocol = {
        name = "Rabbit Protocol",
        text = {
          "{C:attention}Selling{} an {C:paperback_ego_gift}E.G.O Gift{}",
          "{C:attention}disables{} the current {C:attention}Boss Blind"
        },
        unlock = {
          "Sell {C:attention,E:1}#1#{} {C:paperback_ego_gift,E:1}E.G.O Gifts{} in one Run"
        }
      },
    },
    Tag = {
      tag_paperback_angel_investment = {
        name = "Angel Investment Tag",
        text = {
          "Earn {C:money}$#1#{} per {C:money}$#2#{} you have",
          "{C:inactive}(Max of {C:money}$#3#{C:inactive})",
          "{C:inactive}(Will give {C:money}$#4#{C:inactive})"
        }
      },
      tag_paperback_divination = {
        name = "Divination Tag",
        text = {
          "Gives a free",
          "{C:paperback_minor_arcana}Mega Minor Arcana Pack"
        }
      },
      tag_paperback_dichrome = {
        name = "Dichrome Tag",
        text = {
          "Next base edition shop",
          "Joker is free and",
          "becomes {C:dark_edition}Dichrome"
        }
      },
      tag_paperback_high_risk = {
        name = "High Risk Tag",
        text = {
          "When selecting {C:attention}Boss",
          "{C:attention}Blind{}, {C:attention}double{} its",
          "score requirement",
          "and gain {C:money}$#1#"
        }
      },
      tag_paperback_breaking = {
        name = "Breaking Tag",
        text = {
          "Disables the",
          "{C:attention}Boss Blind"
        }
      }
    },
    Planet = {
      c_paperback_quaoar = {
        name = "Quaoar",
      },
      c_paperback_haumea = {
        name = "Haumea",
      },
      c_paperback_sedna = {
        name = "Sedna",
      },
      c_paperback_makemake = {
        name = "Makemake",
      },
    },
    Enhanced = {
      m_paperback_ceramic = {
        name = "Ceramic Card",
        text = {
          "Earn between {C:money}$#1#{}",
          "and {C:money}$#2#{} when scored",
          "{C:red}Shatters{} if {C:mult}Mult{} ended up",
          "{C:attention}greater{} than {C:chips}Chips",
          "while played or held"
        }
      },
      m_paperback_soaked = {
        name = "Soaked Card",
        text = {
          "When scored, cards {C:attention}held in hand{}",
          "score their {C:chips}Chip value{}",
          "{C:green}#1# in #2#{} chance to",
          "{C:red}destroy{} card on {C:red}discard",
        }
      },
      m_paperback_wrapped = {
        name = "Wrapped Card",
        text = {
          "Earn {C:money}$#1#{} when scored",
          "no rank or suit"
        }
      },
      m_paperback_bandaged = {
        name = "Bandaged Card",
        text = {
          "Retrigger {C:attention}adjacent{} cards",
          "{C:green}#1# in #2#{} chance to",
          "{C:red}break{} when scored"
        }
      },
      m_paperback_domino = {
        name = "Domino Card",
        text = {
          "{C:mult}+#1#{} Mult for every played",
          "or discarded rank this round",
          "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
      },
      m_paperback_stained = {
        name = "Stained Card",
        text = {
          "If {C:attention}held in hand{} after a",
          "hand is played, scored cards",
          "permanently gain {C:mult}+#1#{} Mult"
        }
      },
      m_paperback_sleeved = {
        name = "Sleeved Card",
        text = {
          "Cannot be {C:attention}debuffed{} or",
          "{C:attention}flipped{} face down",
          "Earn {C:money}$#1#{} if destroyed"
        }
      },
      m_paperback_antique = {
        name = "Antique Card",
        text = {
          "{X:chips,C:white}X#1#{} Chips,",
          "increases by {X:chips,C:white}X#2#{} when",
          "played in scoring hand",
        }
      }
    },
    Edition = {
      e_paperback_dichrome = {
        name = "Dichrome",
        text = {
          "When {C:attention}Blind{} is selected,",
          "gain {C:attention}+#1#{C:blue} Hand{} or {C:red}Discard",
          "{C:inactive}(Whichever is lower)"
        }
      },
      e_paperback_dichrome_playing_card = {
        name = "Dichrome",
        text = {
          "When this card is {C:attention}drawn{},",
          "gain {C:attention}+#1#{C:blue} Hand{} or {C:red}Discard",
          "{C:inactive}(Whichever is lower)"
        }
      }
    },
    Other = {
      perma_paperback_plus_odds = {
        text = {
          "{C:green}#1#{} odds when played and scoring"
        }
      },
      perma_paperback_h_plus_odds = {
        text = {
          "{C:green}#1#{} odds when held in hand"
        }
      },
      undiscovered_paperback_minor_arcana = {
        name = "Not Discovered",
        text = {
          "Purchase or use",
          "this card in an",
          "unseeded run to",
          "learn what it does",
        },
      },
      undiscovered_paperback_ego_gift = {
        name = "Not Discovered",
        text = {
          "Purchase",
          "this card in an",
          "unseeded run to",
          "learn what it does",
        },
      },
      paperback_light_suits = {
        name = "Light Suits",
        text = {
          "{C:diamonds}Diamonds{}, {C:hearts}Hearts{}"
        }
      },
      paperback_dark_suits = {
        name = "Dark Suits",
        text = {
          "{C:spades}Spades{}, {C:clubs}Clubs{}"
        }
      },
      paperback_requires_custom_suits = {
        name = "Requires Custom Suits",
        text = {
          "Removed from pool due",
          "to {C:attention}Custom Suits{} being",
          "disabled in {C:legendary}Paperback",
        }
      },
      paperback_requires_enhancements = {
        name = "Requires Enhancements",
        text = {
          "Removed from pool due",
          "to {C:attention}Enhancements{} being",
          "disabled in {C:legendary}Paperback",
        }
      },
      paperback_requires_paperclips = {
        name = "Requires Paperclips",
        text = {
          "Removed from pool due",
          "to {C:attention}Paperclips{} being",
          "disabled in {C:legendary}Paperback",
        }
      },
      paperback_requires_minor_arcana = {
        name = "Requires Minor Arcana",
        text = {
          "Removed from pool due",
          "to {C:paperback_minor_arcana}Minor Arcana{} being",
          "disabled in {C:legendary}Paperback",
        }
      },
      paperback_requires_tags = {
        name = "Requires Tags",
        text = {
          "Removed from pool",
          "due to {C:attention}Tags{} being",
          "disabled in {C:legendary}Paperback",
        }
      },
      paperback_requires_editions = {
        name = "Requires Editions",
        text = {
          "Removed from pool",
          "due to {C:dark_edition}Editions{} being",
          "disabled in {C:legendary}Paperback",
        }
      },
      paperback_requires_ranks = {
        name = "Requires Ranks",
        text = {
          "Removed from pool due",
          "to {C:dark_edition}Ranks{} being",
          "disabled in {C:legendary}Paperback",
        }
      },
      paperback_requires_ego_gifts = {
        name = "Requires E.G.O Gifts",
        text = {
          "Removed from pool due",
          "to {C:paperback_ego_gift}E.G.O Gifts{} being",
          "disabled in {C:legendary}Paperback",
        }
      },
      paperback_upgrade_unlock = {
        name = "Locked",
        text = {
          "Activate {C:attention,E:1}#1#{}'s ability",
        }
      },
      paperback_illusion_clips = {
        name = "Added Functionality",
        text = {
          "{C:attention}Playing cards{} may also",
          "have a {C:attention}Paperclip{}"
        }
      },

      -- Stickers
      paperback_energized = {
        name = "Energized",
        text = {
          "Cannot be copied by",
          "{C:attention}#1#{} or",
          "{C:attention}#2#{}",
        }
      },
      paperback_temporary = {
        name = "Temporary",
        text = {
          "{C:red}Removed{} when",
          "round ends"
        }
      },
      paperback_corroded = {
        name = "Corroded",
        text = {
          "Can be {C:money}sold{} without",
          "activating a {C:paperback_ego_gift}Sin",
          "{C:red}Self-destructs{} and",
          "activates the {C:paperback_ego_gift}Sin",
          "after {C:attention}#1#{} round#2#",
        }
      },

      -- Paperclips
      paperback_blue_clip = {
        name = "Blue Clip",
        text = {
          "When {C:attention}scored{}, {X:chips,C:white}X#1#{} Chips",
          "for each {C:attention}Clip{} held in hand",
          "{C:inactive}(Currently {X:chips,C:white}X#2#{C:inactive} Chips)"
        }
      },
      paperback_red_clip = {
        name = "Red Clip",
        text = {
          "When {C:attention}scored{}, {C:mult}+#1#{} Mult",
          "for each {C:attention}Clip{} held in hand",
          "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)"
        }
      },
      paperback_orange_clip = {
        name = "Orange Clip",
        text = {
          "When {C:attention}scored{}, earn {C:money}$#1#{}",
          "for every {C:attention}2 Clips{} held in hand",
          "{C:inactive}(Currently {C:money}$#3#{C:inactive})"
        }
      },
      paperback_black_clip = {
        name = "Black Clip",
        text = {
          "Retriggers when {C:attention}scored{}",
          "if a {C:attention}Clip{} is held in hand",
        }
      },
      paperback_yellow_clip = {
        name = "Yellow Clip",
        text = {
          "If {C:attention}scored{} while",
          "a {C:attention}Clip{} is held in hand,",
          "{C:green}#1# in #2#{} chance for {C:red}+#3#{} Mult,",
          "{C:green}#4# in #5#{} chance for {X:mult,C:white}X#6#{} Mult",
          "and {C:green}#7# in #8#{} chance for {C:money}$#9#{}",
        }
      },
      paperback_gold_clip = {
        name = "Gold Clip",
        text = {
          "If {C:attention}held in hand{} at {C:attention}end of round{},",
          "earn {C:money}$#1#{} for each",
          "{C:attention}Clip{} scored this round",
          "{C:inactive}(Currently {C:money}$#2#{C:inactive}/$#3# max)"
        }
      },
      paperback_white_clip = {
        name = "White Clip",
        text = {
          "If {C:attention}held in hand{} at {C:attention}end of round{},",
          "this Clip gains {C:chips}+#1#{} Chips",
          "for each {C:attention}Clip{} scored this round",
          "{C:inactive}(Currently {C:chips}+#2#{C:inactive} Chips)"
        }
      },
      paperback_pink_clip = {
        name = "Pink Clip",
        text = {
          "When {C:attention}held in hand{}, {X:mult,C:white}X#1#{} Mult",
          "Increases by {X:mult,C:white}X#2#{}",
          "for each scored {C:attention}Clip{}",
          "{C:inactive}(Resets after played hand)"
        }
      },
      paperback_green_clip = {
        name = "Green Clip",
        text = {
          "This Clip gains {C:mult}+#2#{} Mult",
          "for every {C:attention}2{} scoring {C:attention}Clips{} played,",
          "{C:mult}#3#{} Mult for each discarded {C:attention}Clip{}",
          "{C:inactive}(Currently {C:mult}+#1#{C:inactive} Mult)"
        }
      },
      paperback_purple_clip = {
        name = "Purple Clip",
        text = {
          "{C:green}#1# in #2#{} chance to create",
          "a random {C:attention}Tarot{} card",
          "when {C:attention}held in hand{}.",
          "Odds increase by {C:attention}#3#{}",
          "for each scored {C:attention}Clip{}",
          "{C:inactive}(Resets after played hand){}"
        }
      },
      paperback_platinum_clip = {
        name = "Platinum Clip",
        text = {
          "When {C:attention}scored{}, force-trigger",
          "all non-{C:paperback_platinum}Platinum{} {C:attention}Clips{}",
          "held in hand"
        }
      },
      -- E.G.O Gift Sins
      paperback_sin_none = {
        name = "Vestige",
        text = {
          "Always sells for {C:money}$#1#{}"
        }
      },
      paperback_sin_wrath = {
        name = "Wrath",
        text = {
          "When sold, {C:attention}destroy{}",
          "all held {C:attention}consumables"
        }
      },
      paperback_sin_lust = {
        name = "Lust",
        text = {
          "When sold, downgrade",
          "{C:attention}most played hand{} by {C:attention}#1# levels{}"
        }
      },
      paperback_sin_sloth = {
        name = "Sloth",
        text = {
          "Can only be sold directly",
          "after skipping a {C:attention}Blind"
        }
      },
      paperback_sin_gluttony = {
        name = "Gluttony",
        text = {
          "When sold, add {C:paperback_perishable}Perishable{}",
          "to a random {C:attention}Joker{}"
        }
      },
      paperback_sin_gloom = {
        name = "Gloom",
        text = {
          "When sold, multiply all {C:attention}Blind{} sizes by {C:attention}X#1#{}"
        }
      },
      paperback_sin_pride = {
        name = "Pride",
        text = {
          "Always sells for {C:money}#2#{}"
        }
      },
      paperback_sin_envy = {
        name = "Envy",
        text = {
          "When sold, {C:attention}-#1#{} hand size"
        }
      },
      paperback_sin_madness = {
        name = "Madness",
        text = {
          "When sold, {C:attention}destroy{}",
          "a random {C:attention}Joker"
        }
      },
      p_paperback_ego_gift_normal = {
        name = "E.G.O Gift Extraction Pack",
        text = {
          "Choose {C:attention}#1#{} of up to",
          "{C:attention}#2#{C:paperback_ego_gift} E.G.O Gifts{}",
        },
      },
      -- Minor Arcana
      p_paperback_minor_arcana_normal = {
        name = "Minor Arcana Pack",
        text = {
          "Choose {C:attention}#1#{} of up to {C:attention}#2#",
          "{C:paperback_minor_arcana}Minor Arcana{} cards",
          "to be used immediately"
        }
      },
      p_paperback_minor_arcana_jumbo = {
        name = "Jumbo Minor Arcana Pack",
        text = {
          "Choose {C:attention}#1#{} of up to {C:attention}#2#",
          "{C:paperback_minor_arcana}Minor Arcana{} cards",
          "to be used immediately"
        }
      },
      p_paperback_minor_arcana_mega = {
        name = "Mega Minor Arcana Pack",
        text = {
          "Choose {C:attention}#1#{} of up to {C:attention}#2#",
          "{C:paperback_minor_arcana}Minor Arcana{} cards",
          "to be used immediately"
        }
      },
      -- -- Informational
      -- paperback_suit_drink = {
      --   name = "Suit Drink",
      --   text = {
      --     "This Joker {C:red}self-destructs{} after",
      --     "playing no {C:attention}scoring{} {V:1}#1#{}",
      --     "for {C:attention}two{} hands in a row",
      --   }
      -- },
    },
    Partner = {
      pnr_paperback_virtual = {
        name = "Virtual",
        text = {
          "Retrigger {C:attention}first scoring",
          "{C:paperback_light_suit}light suit{} if",
          "no {C:paperback_dark_suit}dark suits{} were played",
        }
      },
      pnr_paperback_aftermath = {
        name = "Aftermath",
        text = {
          "Scored {C:attention}face cards{}",
          "gain {C:chips}+#1#{} Chips",
        }
      },
      pnr_paperback_faker = {
        name = "Faker",
        text = {
          "{C:attention}Once a round{}, if",
          "played hand is a",
          "{C:attention}single card{}, destroy it",
        }
      },
      pnr_paperback_faker_buffed = {
        text = {
          "If played hand is a",
          "{C:attention}single card{}, destroy it",
        }
      },
    },
    Sleeve = {
      sleeve_paperback_paper = {
        name = "Paper Sleeve",
        text = {
          "{C:legendary}Paperback{C:attention} Jokers{} are {C:attention}3X",
          "more likely to appear,",
          "start run with the",
          "{C:attention,T:j_paperback_shopping_center}#1#{} Joker"
        }
      },
      sleeve_paperback_paper_buff = {
        name = "Paper Sleeve",
        text = {
          "Start with a {C:dark_edition}Negative{}",
          "{C:attention,T:j_paperback_shopping_center}#1#{} Joker"
        }
      },

      sleeve_paperback_proud = {
        name = "Proud Sleeve",
        text = {
          "Start with a full set of",
          "{C:hearts}Hearts{}, {C:diamonds}Diamonds{}, {C:spades}Spades",
          "{C:clubs}Clubs{}, {C:paperback_crowns}Crowns{} and {C:paperback_stars}Stars"
        }
      },
      sleeve_paperback_proud_buff = {
        name = "Proud Sleeve",
        text = {
          "All starting {C:attention}Aces",
          "are {C:dark_edition}Polychrome"
        }
      },

      sleeve_paperback_silver = {
        name = "Silver Sleeve",
        text = {
          "Start run with the",
          "{C:paperback_minor_arcana,T:v_paperback_celtic_cross}#1#{} voucher",
          "and a {C:paperback_minor_arcana,T:c_paperback_nine_of_cups}#2#"
        }
      },
      sleeve_paperback_silver_buff = {
        name = "Silver Sleeve",
        text = {
          "Start run with the",
          "{C:paperback_minor_arcana,T:v_paperback_soothsay}#1#{} voucher"
        }
      },

      sleeve_paperback_dreamer = {
        name = "Dreamer's Sleeve",
        text = {
          "Start run with a {C:paperback_temporary}temporary",
          "{C:paperback_minor_arcana,T:c_paperback_apostle_of_wands}#1#",
          "{C:attention}#2#{} Joker slot"
        }
      },
      sleeve_paperback_dreamer_buff = {
        name = "Dreamer's Sleeve",
        text = {
          "Start with an {C:attention}#1#",
          "of each suit"
        }
      },

      sleeve_paperback_antique = {
        name = "Antique Sleeve",
        text = {
          "{C:tarot}Arcana Packs{} no longer",
          "appear in the shop",
          "{C:paperback_minor_arcana}Minor Arcana Packs",
          "are {C:attention}3X{} more common"
        }
      },
      sleeve_paperback_antique_buff = {
        name = "Antique Sleeve",
        text = {
          "{C:paperback_minor_arcana}Minor Arcana Packs{} are {C:money}free",
        }
      },

      sleeve_paperback_passionate = {
        name = "Passionate Sleeve",
        text = {
          "After defeating each",
          "{C:attention}Boss Blind{}, gain a",
          "{C:attention,T:tag_paperback_high_risk}#1#",
          "Earn no {C:money}Interest"
        }
      },
      sleeve_paperback_passionate_buff = {
        name = "Passionate Sleeve",
        text = {
          "Every other {C:attention}Boss Blind{} is",
          "replaced with a {C:attention}Showdown Blind",
          "Defeating a {C:attention}Showdown Blind",
          "gives a {C:dark_edition,T:tag_negative}Negative{} Tag"
        }
      },
      sleeve_paperback_shimmering = {
        name = "Shimmering Sleeve",
        text = {
          "{C:attention}+#1#{} consumable slot for",
          "every unique {C:attention}Sin{} owned",
          "{C:red}#2#{} Joker Slots",
          "{C:paperback_ego_gift}E.G.O Gift Extraction Packs{}",
          "are {C:attention}5X{} more common"
        }
      },
      sleeve_paperback_shimmering_buff = {
        name = "Shimmering Sleeve",
        text = {
          "TBD"
        }
      }
    }
  },
  misc = {
    challenge_names = {
      -- Trials
      c_paperback_trial_of_cups = "Trial of Cups",
      c_paperback_trial_of_wands = "Trial of Wands",
      c_paperback_trial_of_swords = "Trial of Swords",
      c_paperback_trial_of_pentacles = "Trial of Pentacles",

      -- Regular Challenges
      c_paperback_joker_of_the_day = "Joker of the Day",
      c_paperback_white_nights_and_dark_days = "White Nights and Dark Days",
      c_paperback_hard_cover = "Hard Cover",
      c_paperback_borderline = "Borderline",
      c_paperback_all_smiles = "All Smiles",
      c_paperback_hide_and_seek = "Hide and Seek",
      c_paperback_suburbia_overture = "Suburbia Overture",
      c_paperback_foodie = "Foodie"
    },
    v_text = {
      ch_c_cup_trial_1 = {
        "When a {C:attention}Boss Blind{} is defeated, {C:attention}destroy{}"
      },
      ch_c_cup_trial_2 = {
        "the leftmost {C:attention}Joker{} and create a new one"
      },
      ch_c_cup_trial_3 = {
        "of the same rarity or higher if possible"
      },
      ch_c_cup_trial_4 = {
        "{C:inactive}(Cannot upgrade to {C:legendary}Legendary{C:inactive}){}"
      },
      ch_c_wand_trial = {
        "Gain 1 {C:attention}Joker slot{} when a {C:attention}Boss Blind{} is defeated"
      },
      ch_c_sword_trial_1 = {
        "The 5 {C:attention}lowest-ranking{} cards in your deck are"
      },
      ch_c_sword_trial_2 = {
        "{C:attention}destroyed{} when a {C:attention}Boss Blind{} is defeated"
      },
      ch_c_paperback_banned_vanilla_jokers = {
        "All {C:attention}base{} Jokers are banned"
      },
      ch_c_paperback_banned_non_common_jokers = {
        "All {C:attention}non-Common{} Jokers are banned"
      },
      ch_c_paperback_only_food_jokers = {
        "All {C:attention}non-Food{} Jokers are banned"
      },
      ch_c_paperback_2x_blind_size = {
        "{C:red}X2{} base Blind size"
      },
      ch_c_paperback_non_faces_banned_ante = {
        "All {C:attention}non-face cards{} are {C:red}debuffed{} after Ante 4"
      },
    },
    dictionary = {
      -- Badge under cards
      k_paperback_minor_arcana = "Minor Arcana",
      -- Name of consumable type in collection
      b_paperback_minor_arcana_cards = "Minor Arcana",
      -- Text shown at the bottom while opening booster
      paperback_minor_arcana_pack = "Minor Arcana Pack",

      -- Badge under gifts
      k_paperback_ego_gift = "E.G.O Gift",
      -- Name of consumable type in collection
      b_paperback_ego_gift_cards = "E.G.O Gift",
      -- Text shown at the bottom while opening booster
      paperback_ego_gift_pack = "E.G.O Gift Extraction",

      -- Badge under E.G.O Gifts based on sins
      k_paperback_ego_sin_none = "Vestige",
      k_paperback_ego_sin_pride = "Pride",
      k_paperback_ego_sin_wrath = "Wrath",
      k_paperback_ego_sin_gloom = "Gloom",
      k_paperback_ego_sin_sloth = "Sloth",
      k_paperback_ego_sin_lust = "Lust",
      k_paperback_ego_sin_envy = "Envy",
      k_paperback_ego_sin_gluttony = "Gluttony",
      k_paperback_ego_sin_madness = "Madness",

      paperback_confessed_ex = "Confessed!",
      paperback_polychrome_ex = "Polychrome!",
      paperback_destroyed_ex = "Destroyed!",
      paperback_doubled_ex = "Doubled!",
      paperback_too_late_ex = "TOO LATE!",
      paperback_broken_ex = "Broken!",
      paperback_none = "None",
      paperback_downgrade_ex = "Downgrade!",
      paperback_copy_ex = "Copy!",
      paperback_consumed_ex = "Consumed!",
      paperback_tipsy_ex = "Tipsy!",
      paperback_too_hot_ex = "Too Hot!",
      paperback_inactive = "inactive",
      paperback_supplies_ex = "Supplies!",
      paperback_melted_ex = "Melted!",
      paperback_investment_ex = "Investment!",
      paperback_plus_minor_arcana = "+1 M. Arcana",
      paperback_plus_consumable = "+1 Consumable",
      paperback_plus_tag = "+1 Tag",
      paperback_plus_odds = "+1 Odds",
      paperback_enhanced_ex = "Enhanced!",
      paperback_edition_ex = "Edition!",
      paperback_rare_ex = "Rare!",
      paperback_saved_unholy_alliance = "Saved by Unholy Alliance",
      paperback_saved_determination = "Saved by Determination",
      paperback_reduced_ex = "Reduced!",
      paperback_determination_ex = "NGAAAHH!",
      paperback_forlorn_destruction = "Sorry...",
      paperback_freezer_ex = "Dinner Time!",
      paperback_corroded_ex = "Corroded!",
      paperback_jestosterone_ex = "Masc!",
      paperback_jestrogen_ex = "Fem!",
      paperback_punch_card_active = "Tell your friends!",
      paperback_punch_card_ex = "Wrong Warp!",
      paperback_hamsa_reverse = "Reversed!",
      paperback_der_freischutz_fire = "Fire...",
      paperback_off_switch_ex = "Swing!",
      paperback_one_shift_more_true = "Heart!",
      paperback_one_shift_more_false = "Beat!",
      paperback_warning_ex = "Warning!",
      paperback_watch_ex = "Watch!",

      paperback_ui_requires_restart = "Requires Restart",
      paperback_ui_no_requires_restart = "Doesn't Require Restart",
      paperback_ui_enable_blinds = "Enable Blinds",
      paperback_ui_enable_minor_arcana = "Enable Minor Arcana",
      paperback_ui_enable_ego_gifts = "Enable E.G.O Gifts",
      paperback_ui_enable_enhancements = "Enable Enhancements",
      paperback_ui_enable_editions = "Enable Editions",
      paperback_ui_enable_paperclips = "Enable Paperclips",
      paperback_ui_custom_suits_enabled = "Enable Custom Suits",
      paperback_ui_enable_vouchers = "Enable Vouchers",
      paperback_ui_enable_tags = "Enable Tags",
      paperback_ui_enable_ranks = "Enable Ranks",
      paperback_ui_developers = "Developers",
      paperback_ui_artists = "Artists",
      paperback_ui_localization = "Localization",
      paperback_ui_paperclips = "Paperclips",
      paperback_ui_enable_spectrals = "Enable Spectral Cards",
      paperback_ui_plague_doctor_quotes = "Plague Doctor Quotes",
      paperback_ui_select = "Select",
      paperback_ui_info = "(i)",
      paperback_ui_info_expanded = "( i )",
      paperback_ui_remaining_hands = "Remaining Hands",
      paperback_ui_show_credits = "Show Credits",
      paperback_ui_upgrade_indicators = "Show Upgrade Indicators",

      -- Plague Doctor's quotes
      paperback_plague_quote_1_1 = 'On this rock I will build my church, and the',
      paperback_plague_quote_1_2 = 'gates of hell shall not prevail against it...',

      paperback_plague_quote_2_1 = 'Tell us, when will this happen, and what will be',
      paperback_plague_quote_2_2 = 'the sign of your coming and the end of an age?',

      paperback_plague_quote_3_1 = 'Do you wish us to call fire down',
      paperback_plague_quote_3_2 = 'from heaven to destroy them?',

      paperback_plague_quote_4_1 = 'To the apostles he gave the name Boanerges,',
      paperback_plague_quote_4_2 = 'which means "Sons of Thunder".',

      paperback_plague_quote_5_1 = 'Show us the father, and that',
      paperback_plague_quote_5_2 = 'will be enough for us.',

      paperback_plague_quote_6_1 = 'He saw a man. "Follow me," he told him,',
      paperback_plague_quote_6_2 = 'and the Apostle got up and followed him.',

      paperback_plague_quote_7_1 = 'Now for some time the Apostle had',
      paperback_plague_quote_7_2 = 'practiced sorcery and amazed all people.',

      paperback_plague_quote_8_1 = 'Then the Apostle said to the rest of the disciples,',
      paperback_plague_quote_8_2 = '"Let us also go, that we may die with him."',

      paperback_plague_quote_9_1 = 'Then the Apostle declared, "You are',
      paperback_plague_quote_9_2 = 'the son of him, you are the king."',

      paperback_plague_quote_10_1 = 'Then the Apostle said, "But why do you intend',
      paperback_plague_quote_10_2 = 'to show yourself to us and not the world?"',

      paperback_plague_quote_11_1 = 'From now on, let no one cause me trouble,',
      paperback_plague_quote_11_2 = 'for I bear on my body the marks of him.',

      paperback_plague_quote_12_1 = 'Have I not chosen you, the Twelve?',
      paperback_plague_quote_12_2 = 'Yet one of you is a devil.',

      -- Clippy messages
      paperback_clippy_msg_1 = "Save file?",
      paperback_clippy_msg_2 = "I'm Clippy!",
      paperback_clippy_msg_3 = "Hi!",
      paperback_clippy_msg_4 = "Keyboard is on!",
      paperback_clippy_msg_5 = "I'll help!",
      paperback_clippy_msg_6 = "Ask me!",
      paperback_clippy_msg_7 = "Should I leave?",
      paperback_clippy_msg_8 = "Mouse is on!",
      paperback_clippy_msg_full = "Storage full!",

      -- Da Capo messages
      paperback_da_capo_Clubs = "Movement 1",
      paperback_da_capo_Spades = "Movement 2",
      paperback_da_capo_Diamonds = "Movement 3",
      paperback_da_capo_Hearts = "Movement 4",
      paperback_da_capo_None = "Finale!",

      -- Suit category
      paperback_light = "Light",
      paperback_dark = "Dark",

      -- Credit
      paperback_art_credit = 'Art by ',
      paperback_code_credit = 'Code by ',
      paperback_music_credit = 'Composed by ',
      paperback_and_spacer = ' and ',

      -- Developers
      paperback_dev_dowfrin = 'Dowfrin',
      paperback_dev_srockw = 'Srock',
      paperback_dev_papermoonqueen = 'PaperMoonQueen',
      paperback_dev_dylan_hall = 'Dylan Hall',
      paperback_dev_metanite = 'metanite64',
      paperback_dev_infinityplus = 'InfinityPlus05',
      paperback_dev_vitellary = 'vitellary',
      paperback_dev_ejwu = 'ejwu2',
      paperback_dev_b = 'B',
      paperback_dev_nether = 'Nether',
      paperback_dev_oppositewolf = 'OppositeWolf770',
      paperback_dev_thermo = 'ThermoDyn',
      paperback_dev_aa7 = 'aa7_2k03',
      paperback_dev_shizi = 'Shizi',
      paperback_dev_nevernamed = 'NeverNamed',
      paperback_dev_scruby = 'S_C_R_U_B_Y',
      paperback_dev_larantula = 'Larantula',
      paperback_dev_ari = 'ari',
    },
    v_dictionary = {
      paperback_a_discards = "+#1# Discards",
      paperback_a_discards_minus = "-#1# Discards",
      paperback_a_hands_minus = "-#1# Hands",
      paperback_prince_of_darkness = "+#1# Mult, +#2# Chips",
      paperback_a_completion = "#1#/#2#",
      paperback_a_round_minus = "-#1# Round",
      paperback_a_plus_cards = "+#1# #2#s",
      paperback_a_plus_tags = "+#1# Tags",
      paperback_a_dollars = "$#1#",

      paperback_a_plus_consumable_slot = "+#1# Consumable Slots",
      paperback_a_minus_consumable_slot = "-#1# Consumable Slots",
      paperback_a_ante = "#1# Ante",
    },
    ranks = {
      paperback_Apostle = 'Apostle',
    },
    suits_singular = {
      paperback_Crowns = "Crown",
      paperback_Stars = 'Star'
    },
    suits_plural = {
      paperback_Crowns = "Crowns",
      paperback_Stars = 'Stars'
    },
    poker_hands = {
      ['paperback_Spectrum'] = "Spectrum",
      ['paperback_Straight Spectrum'] = "Straight Spectrum",
      ['paperback_Straight Spectrum (Royal)'] = "Royal Spectrum",
      ['paperback_Spectrum House'] = "Spectrum House",
      ['paperback_Spectrum Five'] = "Spectrum Five",
      ['paperback_Straight Flush (Rapture)'] = "Rapture",
    },
    poker_hand_descriptions = {
      ['paperback_Spectrum'] = {
        "5 cards with different suits"
      },
      ['paperback_Straight Spectrum'] = {
        "5 cards in a row (consecutive ranks),",
        "each with a different suit"
      },
      ['paperback_Spectrum House'] = {
        "A Three of a Kind and a Pair with",
        "each card having a different suit"
      },
      ['paperback_Spectrum Five'] = {
        "5 cards with the same rank,",
        "each with a different suit"
      },
    },
    labels = {
      paperback_blue_clip = "Blue Clip",
      paperback_red_clip = "Red Clip",
      paperback_orange_clip = "Orange Clip",
      paperback_pink_clip = "Pink Clip",
      paperback_black_clip = "Black Clip",
      paperback_yellow_clip = "Yellow Clip",
      paperback_gold_clip = "Gold Clip",
      paperback_white_clip = "White Clip",
      paperback_green_clip = "Green Clip",
      paperback_purple_clip = "Purple Clip",
      paperback_platinum_clip = "Platinum Clip",
      paperback_dichrome = "Dichrome",
      paperback_energized = "Energized",
      paperback_temporary = "Temporary",
      paperback_corroded = "Corroded",
    },
  }
}
