SMODS.Joker {
  key = "big_misser",
  config = {
    extra = {
      Xmult_mod = 0.75,
      Xmult = 0
    }
  },
  rarity = 2,
  pos = { x = 9, y = 5 },
  atlas = 'jokers_atlas',
  cost = 6,
  unlocked = false,
  discovered = false,
  blueprint_compat = true,
  eternal_compat = true,
  paperback_credit = {
    coder = { 'srockw' }
  },

  check_for_unlock = function(self, args)
    return args.type == 'win' and G.GAME.paperback.max_consumeables <= 0
  end,

  loc_vars = function(self, info_queue, card)
    return {
      vars = {
        card.ability.extra.Xmult_mod,
        card.ability.extra.Xmult
      }
    }
  end,

  update = function(self, card, dt)
    if G.consumeables then
      local empty_consumables = G.consumeables.config.card_limit - #G.consumeables.cards
      card.ability.extra.Xmult = math.max(0, empty_consumables * card.ability.extra.Xmult_mod)
    end
  end,

  calculate = function(self, card, context)
    if context.joker_main then
      -- Show a message if mult is 0
      if card.ability.extra.Xmult == 0 then
        return {
          x_mult_mod = 0,
          message = localize {
            type = 'variable',
            key = 'a_xmult',
            vars = { 0 }
          },
          sound = 'multhit1',
          colour = G.C.MULT
        }
      end

      return {
        x_mult = card.ability.extra.Xmult,
      }
    end
  end,

  joker_display_def = function(JokerDisplay)
    return {
      text = {
        {
          border_nodes = {
            { text = 'X' },
            { ref_table = 'card.ability.extra', ref_value = 'Xmult' }
          }
        }
      },
    }
  end
}
