SMODS.Joker {
  key = 'prince_of_darkness',
  config = {
    extra = {
      unique_suits = 2,
      x_mult = 2,
      hands = 3,
      hands_remaining = 0,
      suit = "Hearts"
    }
  },
  rarity = 2,
  pos = { x = 6, y = 2 },
  atlas = 'jokers_atlas',
  cost = 7,
  unlocked = false,
  discovered = false,
  blueprint_compat = true,
  eternal_compat = true,
  perishable_compat = false,
  soul_pos = nil,

  paperback_credit = {
    coder = { 'oppositewolf' }
  },

  loc_vars = function(self, info_queue, card)
    return {
      vars = {
        card.ability.extra.unique_suits,
        card.ability.extra.x_mult,
        math.max(0, card.ability.extra.hands - 1),
        card.ability.extra.hands_remaining,
        localize(card.ability.extra.suit, 'suits_singular')
      }
    }
  end,

  locked_loc_vars = function(self, info_queue, card)
    return { vars = { 4 } }
  end,

  check_for_unlock = function(self, args)
    if args.type == 'hand' then
      return PB_UTIL.get_unique_suits(args.scoring_hand, nil, true) >= 4
    end
  end,

  calculate = function(self, card, context)
    -- Check if the card is not debuffed
    if not card.debuff then
      -- Check if the card is being calculated before the scoring hand is scored and not blueprinted
      if context.before and not context.blueprint then
        local unique_suits = PB_UTIL.get_unique_suits(context.scoring_hand, true)

        local heart_found = false
        for i = 1, #context.scoring_hand do
          if context.scoring_hand[i]:is_suit(card.ability.extra.suit, false, true) then
            heart_found = true
            break
          end
        end

        -- Check if the scoring hand contains a Heart and two additional unique suits (three unique suits with Heart included)
        if heart_found and unique_suits >= 3 then
          card.ability.extra.hands_remaining = card.ability.extra.hands

          return {
            message = localize("k_active_ex"),
            colour = G.C.GREEN,
            card = card,
          }
        end
      end

      -- Give the mult and chips during play
      if context.joker_main then
        if card.ability.extra.hands_remaining > 0 then
          return {
            x_mult = card.ability.extra.x_mult
          }
        end
      end

      -- Reduce the hands remaining after the hand is scored
      if context.after and not context.blueprint then
        if card.ability.extra.hands_remaining > 0 then
          card.ability.extra.hands_remaining = card.ability.extra.hands_remaining - 1

          if card.ability.extra.hands_remaining == 0 then
            return {
              message = localize("paperback_inactive"),
              colour = G.C.RED,
              card = card
            }
          else
            return {
              message = localize { type = 'variable', key = 'paperback_a_hands_minus', vars = { 1 } },
              colour = G.C.RED,
              card = card
            }
          end
        end
      end
    end
  end
}
