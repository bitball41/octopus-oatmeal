PB_UTIL.MinorArcana {
  key = 'five_of_cups',
  config = {
    max_highlighted = 2,
    mod_conv = 'm_paperback_soaked'
  },
  atlas = 'minor_arcana_atlas',
  pos = { x = 4, y = 0 },
  unlocked = true,
  discovered = false,
  paperback_credit = {
    coder = { 'oppositewolf' }
  },

  paperback = {
    requires_enhancements = true
  }
}
