local decs = {
	descriptions = {
		Enhanced = {
			m_entr_flesh = {
				name = "Flesh Card",
				text = {
					"{C:green}#1# in #2#{} chance to",
					"destroy this card",
					"when {C:attention}discarded{}"
				}
			},
			m_entr_disavowed = {
				name = "Disavowed",
				text = {
					"Cannot change Enhancements"
				}
			},
			m_entr_disavowed_gfb = {
				name = "Avowed",
				text = {
					"Can change Enhancements"
				}
			},
			m_entr_prismatic = {
				name = "Prismatic Card",
				text = {
					"{X:slib_emult,C:white}^#1#{} Mult",
					"This card gains {X:slib_emult,C:white}^#2#{}",
					"mult when scored."
				}
			},
			m_entr_dark = {
				name = "Dark Card",
				text = {
					"{X:blue,C:white}X#2#{} Chips when held in hand",
					"This card gains {X:blue,C:white}X#1#{} Chips",
					"for each {C:attention}unique{} suit in played hand"
				}
			},
			m_entr_ceramic = {
				name = "Ceramic Card",
				text = {
					"This card has its own {C:attention}rank{}",
					"and counts as every {C:attention}suit{}.",
					"When scored, {C:red}destroy{} this card",
					"When destroyed, create a {C:attention}random{} consumable"
				}
			},
			m_entr_radiant = {
				name = "Radiant Card",
				text = {
					"{C:gold}+#1#{} Ascension Power"
				}
			},

			m_entr_ethereal = {
				name = "Ethereal Card",
				text = {
					"Creates a {C:spectral}Spectral{}",
					"card when modified",
					"{C:inactive}(Must have room){}"
				}
			},

			m_entr_samsara = {
				name = "Samsara Card",
				text = {
					"{C:red}Self destructs{} when modified",
					"Create a {C:attention}copy{} of this card",
					"with {X:blue,C:white}+X#2#{} Chips when destroyed",
					"{C:inactive}(Currently {X:blue,C:white}X#1#{C:inactive})"
				}
			},

			--BLINDSIDE
			m_entr_scarlet_sun = {
				name = "Scarlet Sun",
				text = {
					"{X:red,C:white}Red{}",
					"While held in hand,",
					"gives {C:gold}+#1#{} Ascension Power",
					"for each {C:attention}played{} Blind"
				}
			},
			m_entr_burgundy_baracuda = {
				name = "Burgundy Barracuda",
				text = {
					{
						"{X:red,C:white}Red{}",
						"{X:mult,C:white}X#1#{} Mult",
					},
					{
						"Retriggers {C:attention}#2#{} times",
						"Resets when played"
					},
					{
						"While held in hand",
						"{C:attention}Burn{} all Blinds in",
						"scoring hand and gain {C:attention}#3#{}",
						"Retriggers for each",
						"played Blind"
					}
				}
			},
			m_entr_diamond_dawn = {
				name = "Diamond Dawn",
				text = {
					{
						"{X:chips,C:white}Blue{}",
						"Retriggers adjacent ",
						"scoring Blinds {C:attention}#1#{} times"
					},
					{
						"Copies the {C:attention}Hue{} of",
						"adjacent Blinds"
					},
				}
			},
			m_entr_olive_orchard = {
				name = "Olive Orchard",
				text = {
					"{X:green,C:white}Green{}",
					"When this Blind is {C:attention}discarded{}",
					"all Blinds held in hand gain",
					"{X:mult,C:white}X#1#{} Mult"
				}
			},
			m_entr_citrine_comet = {
				name = "Citrine Comet",
				text = {
					"{X:gold,C:white}Yellow{}",
					"Gains {C:gold}#2#{} Ascension Power",
					"when another Blind {C:attention}Burns{}",
					"{C:inactive}(Currently {C:gold}#1#{C:inactive} Ascension Power){}"
				}
			},
			m_entr_alabaster_anchor = {
				name = "Alabaster Anchor",
				text = {
					"{X:dark_edition,C:white}Faded{}",
					"{C:dark_edition}Forcibly{} Upgrades",
					"rightmost Blind if part of",
					"scored hand",
					"{C:inactive}(If possible)"
				}
			},
			m_entr_alabaster_anchor_two = {
				name = "Alabaster Anchor",
				text = {
					"{X:dark_edition,C:white}Faded{}",
					"{C:dark_edition}Forcibly{} Upgrades",
					"rightmost Blind twice if part",
					"of scored hand",
					"{C:inactive}(If possible)"
				}
			},
		},
		["Content Set"] = {
			set_entr_inversions = {
				name = "Inversions",
				text = {
					"{C:attention}Consumable{} inversions",
					"added by Entropy"
				}
			},
			set_entr_tags = {
				name = "Tags",
				text = {
					"{C:attention}Tags{} added",
					"by Entropy"
				}
			},
			set_entr_blinds = {
				name = "Blinds",
				text = {
					"{C:attention}Boss Blinds{} added",
					"by Entropy"
				}
			},
			set_entr_decks = {
				name = "Decks",
				text = {
					"{C:attention}Decks{} added",
					"by Entropy"
				}
			},
			set_entr_misc = {
				name = "Misc",
				text = {
					"Things that don't",
					"fit in any other",
					"{C:cry_ascendant}Thematic Set",
				},
			},
			set_entr_entropics = {
				name = "Entropic Jokers",
				text = {
					"Powerful Jokers with",
					"{C:entr_entropic}Entropic{} rarity",
				},
			},
			set_entr_vouchers = {
				name = "Vouchers",
				text = {
					"{C:attention}Vouchers{} added",
					"by Entropy"
				}
			},
			set_entr_spectrals = {
				name = "Spectral Cards",
				text = {
					"{C:attention}Spectral{} cards",
					"added by Entropy"
				}
			},
			set_entr_misc_jokers = {
				name = "Misc. Jokers",
				text = {
					"{C:attention}Jokers{} that don't",
					"fit in any other",
					"{C:cry_ascendant}Thematic Set",
				},
			},
			set_entr_altpath = {
				name = "Alternate Path",
				text = {
					"{C:attention}Content{} related to",
					"an {C:entr_entropic}alternative path{} of",
					"progression during runs",
				},
			},
			set_entr_dice_jokers = {
				name = "Dice Jokers",
				text = {
					"{C:attention}Jokers{} that modify",
					"probabilities based on dice",
					"added by Entropy"
				},
			},
			set_entr_runes = {
				name = "Runes",
				text = {
					"A new {C:attention}Consumable Type{}",
					"added by Entropy",
				},
			},
			set_entr_actives = {
				name = "Activated Jokers",
				text = {
					"{C:attention}Jokers{} that are",
					"{C:attention}manually{} activated",
					"added by Entropy"
				},
			},
			set_entr_void_jokers = {
				name = "Void Jokers",
				text = {
					"{C:entr_void}Inverted{} {C:attention}Jokers{}",
					"added by Entropy"
				},
			},
		},
		Joker = {
			--Crossmod Jokers
			j_entr_compositor = {
				name = "Compositor",
				text = {
					"When {C:attention}Blind{} is selected","print a random {C:attention}Inverted card{}"
				}
			},

			j_cry_redeo = {
				name = "Redeo",
				text = {
					"{C:attention}#1#{} Ante when",
					"{C:money}$#2#{} {C:inactive}($#3#){} spent",
					"{s:0.8}Requirements increase",
					"{C:attention,s:0.8}exponentially{s:0.8} per use",
					"{C:money,s:0.8}Next increase: {s:1,c:money}$#4#",
				},
			},
			j_entr_stillicidium = {
				name = "Stillicidium",
				text = {
					"Transform {C:attention}Jokers{} to the right",
					"and all {C:attention}consumables{} into the",
					"card that precedes them in the",
					"Collection at the end of the shop",
					"Reduce the rank of {C:attention}scored cards{} by 1",
					"Reduce Blind sizes by {C:attention}30%{}"
				}
			},
			j_entr_surreal_joker = {
				name = "Surreal Joker",
				text = {
 					"Mult {X:entr_eqmult,C:white}=#1#{}"
				}
			},
			j_entr_tesseract = {
				name = "Tesseract",
				text = {
 					"Rotates Mult by {X:dark_edition,C:white}#1#{}",
					"degrees counterclockwise",
					"and Chips by {X:dark_edition,C:white}#1#{}",
					"degrees clockwise"
				}
			},
			j_entr_tesseract_gfb = {
				name = "Tesseract",
				text = {
					{
						"Rotates Mult by {X:dark_edition,C:white}#1#{}",
						"degrees counterclockwise",
						"and Chips by {X:dark_edition,C:white}#1#{}",
						"degrees clockwise"
					},
					{
						"This Joker gains {X:dark_edition,C:white}+#2#{}",
						"degrees if played hand has",
						"exactly {C:attention}4{} cards"
					}
				}
			},
			j_entr_epitachyno = {
				name = "Epitachyno",
				text = {
					{
						"This Joker transforms into a",
						"random {C:legendary,E:1}hidden{} consumable when",
						"a {C:attention}Blind{} is selected"
					},
					{
                    	"Use this Joker to use",
						"the {C:attention}current{} consumable",
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Boss Blind",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
					}
				}
			},
			j_entr_helios= {
				name = "Helios",
				text = {
					{
						"When a card is scored {C:attention}all{}",
						"cards held in hand with the",
						"same {C:attention}rank{} become {C:attention}Marked{}"
					},
					{
						"All played cards provide",
						"{C:gold}+#1#{} Ascension Power",
					}
				}
			},
			j_entr_xekanos = {
				name = "Xekanos",
				text = {
 					"{X:dark_edition,C:white}#1#X{} {C:attention}Ante gain{}",
					"increases by {X:dark_edition,C:white}#2#{}",
					"when the Ante changes",
					"{X:dark_edition,C:white}Halve{} this value when",
					"a {C:attention}Rare{} or higher rarity {C:attention}Joker{}",
					"is sold"
				}
			},
			j_entr_ieros = {
				name = "Ieros",
				text = {
 					"Jokers in the shop",
					"have {C:entr_entropic}upgraded {C:attention}rarities",
				}
			},
			j_entr_dekatria = {
				name = "Dekatria",
				text = {
					"When another {C:attention}Joker{} triggers,",
					"use the {C:planet}Planet{} or {C:purple}Star{}",
					"card for the played {C:purple}poker hand{}"
				}
			},
			j_entr_oekrep = {
				name = "Oekrep",
				text = {
					"Consumables can be {C:attention}selected{}",
					"from all Booster Packs",
					"{C:green}#1# in #2#{} chance for Booster",
					"Packs to spawn {C:dark_edition}Negative{}"
				}
			},
			j_entr_kciroy = {
				name = "Kciroy",
				text = {
					"{C:dark_edition}+#1#{} hand size, {C:dark_edition}+#2#{} card selection limit",
					"This Joker gains {X:dark_edition,C:white}^#3#{} Chips every",
					"{C:attention}#4#{} {C:inactive}[#5#]{} cards discarded",
					"{C:inactive}(Currently{} {X:dark_edition,C:white}^#6#{} {C:inactive}Chips){}"
				}
			},
			j_entr_tocihc = {
				name = "Tocihc",
				text = {
					"Fixed {C:green}50%{} chance to not",
					"progress when beating a Blind",
					"then obtain the Blind's {C:attention}skip Tag{}",
				}
			},
			j_entr_teluobirt = {
				name = "Teluobirt",
				text = {
					"Scored {C:attention}Jacks{} give {X:chips,C:white}XChips{}",
					"equal to the {C:attention}number{} of played Jacks.",
					"Retrigger {C:attention}scored{} Jacks based on their",
					"order in the played hand"
				}
			},
			j_entr_oinac = {
				name = "Oinac",
				text = {
					"This Joker gains {X:slib_echips,C:white}^#1#{} Chips",
					"when a {C:attention}face{} card is destroyed by this Joker",
					"{C:attention}Played{} cards are destroyed",
					"and a card with +1 rank is drawn to the {C:attention}hand{}",
					"{C:inactive}(Currently {X:slib_echips,C:white}^#2#{} {C:inactive}Chips){}"
				}
			},
			j_entr_entropy_card = {
				name = "Drac Pihsrebmem",
				text = {
					"{X:gold,C:white}X#1#{} Ascension Power for",
					"each {C:attention}sun_with_face{} emoji in",
					"Entropy's #ascended-hands-worship channel",
					"{C:inactive}(Currently {X:gold,C:white}X#2#{}{C:inactive}){}",
					"{C:blue,s:0.7}https://discord.gg/beqqy4Bb7m{}",
				}
			},
			j_entr_solarflare = {
				name = "Solar Flare",
				text = {
					"Other {C:dark_edition}Solar{} cards",
					"each give {X:gold,C:white}X#1#{} Ascension Power",
				},
			},
			j_entr_burnt_m= {
				name = "Burnt M",
				text = {
					"If played hand {C:attention}contains{} a Pair",
					"apply {C:dark_edition}Solar{} to the first card",
					"Apply {C:dark_edition}Solar{} to 1 more card for",
					"each {C:dark_edition}Jolly{} Joker"
				},
			},
			j_entr_anaptyxi= {
				name = "Anaptyxi",
				text = {
					"Scaling Jokers scale all other Jokers by",
					"{X:dark_edition,C:white}X#1#{} the same amount, then increase",
					"this by {X:dark_edition,C:white}X#2#{} at the end of round",
					"{C:inactive}(Anaptyxi excluded){}",
				},
			},
			j_entr_chaos= {
				name = "Chaos",
				text = {
					"When a card is {C:attention}created{}",
					"instead create a card of",
					"a {C:attention}random type{}"
				},
			},
			j_entr_parakmi = {
				name = "Parakmi",
				text = {
					"{C:attention}Anything{} can appear",
					"in the place of any card",
					"{C:dark_edition}+#1#{} shop slots"
				}
			},
			j_entr_exousia = {
				name = "Exousia",
				text = {
					"{C:entr_entropic}Ascends{} all Tags",
					"Gain {C:attention}#1#{} skip Tags when",
					"any Blind is selected"
				}
			},
			j_entr_akyros = {
				name = "Akyros",
				text = {
					"Joker slots can be {C:attention}bought{}",
					"for {C:gold}$#1#{} and {C:attention}sold{} for {C:gold}$#2#{}",
					"Gain money at end of round based on how",
					"many empty Joker slots you have",
					"{C:inactive}(Currently{} {C:money}#3#{}{C:inactive}){}"
				}
			},
			j_entr_dni = {
				name = "DNI",
				text = {
					"Chooses one suit per hand",
					"Destroy all {C:attention}scored{} cards with that suit",
					"{C:inactive}(Currently{} {V:1}#1#{}{C:inactive}){}"
				}
			},
			j_entr_strawberry_pie = {
				name = "Strawberry Pie",
				text = {
					"{C:attention}Flush{}, {C:attention}Straight{} and {C:attention}Full House",
					"level-ups are redirected to",
					"{C:attention}High Card{}",
				}
			},
			j_entr_recursive_joker = {
				name = "Recursive Joker",
				text = {
					"When this Joker is {C:attention}sold{},",
					"create a copy of this Joker",
					"{C:red}Works once per round{}",
					"{C:inactive}(Currently #1#){}"
				}
			},
			j_entr_recursive_joker_gfb = {
				name = "Recursive Joker",
				text = {
					"{CANVAS:DESC_CANVAS} {}"
				}
			},
			j_entr_trapezium_cluster = {
				name = "Trapezium Cluster",
				text = {
					"Other {C:dark_edition}Fractured{} cards",
					"each force-trigger {C:dark_edition}#1#{}",
					"random cards"
				},
			},
			j_entr_katarraktis = {
				name = "Katarraktis",
				text = {
					"Retrigger the {C:attention}Joker{} to",
					"the right {C:attention}#1#{} time#<s>1# then",
					"retrigger each subsequent",
					"{C:attention}Joker{} {X:dark_edition,C:white,f:entr_phi}Xo{} as many",
					"times as the previous"
				}
			},
			j_entr_dr_sunshine = {
				name = "Dr. Sunshine",
				text = {
					"This {C:attention}Joker{} gains",
					"{C:gold}+#1#{} Ascension Power",
					"when a playing card is {C:attention}destroyed{}",
					"{C:inactive}(Currently {}{C:gold}+#2#{}{C:inactive}){}"
				}
			},
			j_entr_sunny_joker = {
				name = "Sunny Joker",
				text = {
					"{C:gold}+#1#{} Ascension Power"
				}
			},
			j_entr_metanoia = {
				name = "Metanoia",
				text = {
					"Discarded cards become",
					"{C:attention}Flesh{} Cards"
				}
			},
			j_entr_antidagger = {
				name = "Anti-Dagger",
				text = {
					"Unbanish a random banished Joker",
					"when a {C:attention}Blind{} is selected",
					"{C:green}#1# in #2#{} chance to {C:attention}banish{}",
					"this Joker instead"
				}
			},
			j_entr_solar_dagger = {
				name = "Solar Dagger",
				text = {
					"When {C:attention}Blind{} is selected",
					"destroy Joker to the right",
					"and permanently add {C:attention}one quarter{}",
					"of its sell value to this Joker's",
					"{C:gold}Ascension Power{}",
					"{C:inactive}(Currently {C:gold}#1#{} {C:inactive}Ascension Power){}"
				}
			},
			j_entr_insatiable_dagger = {
				name = "Insatiable Dagger",
				text = {
					"When {C:attention}Blind{} is selected",
					"banish rightmost Joker",
					"Joker to the left gains {C:attention}#1#%{}",
					"of its sell value as {C:purple}xValues{}",
					"then decrease this value by {C:attention}#2#{}"
				}
			},
			j_entr_insatiable_dagger_gfb = {
				name = "Insatiable Dagger",
				text = {
					"Increases values of {C:attention}Joker",
					"to the right by {X:attention,C:white}X#1#{}",
					"at the end of the shop"
				}
			},
			j_entr_rusty_shredder = {
				name = "Rusty Shredder",
				text = {
					"{C:green}#1# in #2#{} chance to create",
					"a {C:attention}temporary{} {C:dark_edition}Negative{}",
					"copy of discarded cards"
				}
			},
			j_entr_chocolate_egg = {
				name = "Chocolate Egg",
				text = {
					"Create a random {C:dark_edition}Sunny{} {C:red}Rare{} Joker",
					"when this Joker is destroyed",
					"Create a random {C:dark_edition}Sunny{} {C:cry_epic}Epic{} Joker instead",
					"when this Joker is {C:red}banished{}"
				}
			},
			j_entr_chocolate_egg_cryptidless = {
				name = "Chocolate Egg",
				text = {
					"Create a random {C:dark_edition}Sunny{} {C:red}Rare{} Joker",
					"when this Joker is destroyed",
				}
			},
			j_entr_antireal = {
				name = "Antireal Joker",
				text = {
					"{X:gold,C:white}+X#1#{} Ascension Power per",
					"empty Joker slot",
					"{s:0.8}Antireal Joker included{}",
					"{C:inactive}(Currently{} {X:gold,C:white}X#2#{}{C:inactive}){}"
				}
			},
			j_entr_jokerinyellow = {
				name = "The Joker in Yellow",
				text = {
					"{C:green}#1# in #2#{} chance for drawn cards",
					"to be given a {C:diamonds}Yellow Sign{} sticker",
					"Played {C:diamonds}Diamonds{} {C:red}banish{} a random Joker",
					"Selected {C:diamonds}Diamonds{} give {C:dark_edition}Temporary{}",
					"to a random card of any type",
					"Self destructs if {C:attention}7 Diamonds{} are held when hand played"
				}
			},
			j_entr_lotteryticket = {
				name = "Lottery Ticket",
				text = {
					"Lose {C:gold}$#5#{} at the end of round",
					"{C:green}#1# in #2#{} chance to earn {C:gold}$#6#{}",
					"{C:green}#3# in #4#{} chance to earn {C:gold}$#7#{} instead"
				}
			},
			j_entr_ruby = {
				name = "Ruby, Lord of Hope",
				text = {
					"Gain a random {C:attention}Tag{}",
					"every {C:attention}#1#{} {C:inactive}[#2#]{} Jokers bought",					
					"Tags may randomly become",
					"{C:entr_entropic}Ascended{}"
				}
			},
			j_entr_slipstream = {
				name = "Slipstream, Heir of Time",
				text = {
					"Create an {C:red}Omen{} card",
					"when Blind is selected",
					"Held {C:red}Omens{} give {X:mult,C:white}X#1#{} Mult"
				}
			},
			j_entr_cass = {
				name = "Cassknows, Muse of Void",
				text = {
					"Add {C:attention}#7#{} to a random",
					"stat when a {C:planet}Planet{} or {C:purple}Star{} card is used",
					"{C:inactive}({C:blue}+#1#{C:inactive} hand size, {C:attention}+#2#{C:inactive} card selection limit)",
					"{C:inactive}({C:blue}+#3#{C:inactive} hands and {C:red}+#4#{C:inactive} discards)",
					"{C:inactive}({C:dark_edition}+#5#{C:inactive} consumable slots, {C:attention}+#6#{C:inactive} shop slots)"
				}
			},
			j_entr_devilled_suns = {
				name = "Devilled Suns",
				text = {
					"Gold Cards Give",
					"{C:gold}+#1#{} Ascension Power",
					"and {C:gold}+#2#{} more for every",
					"{C:dark_edition}Sunny{} Joker owned"
				}
			},
			j_entr_eden = {
				name = "The Garden of Eden",
				text = {
					"Other {C:dark_edition}Sunny{} cards",
					"each give {C:gold}+#1#{} Ascension Power",
				},
			},
			j_entr_exelixi = {
				name = "Exelixi",
				text = {
					"Upgrade the {C:attention}Enhancement{}",
					"of playing cards when scored",
					"{C:attention}Enhancements{} are given to adjacent cards",
					"when {C:attention}discarding{} cards"
				}
			},
			j_entr_seventyseven = {
				name = "77+33",
				text = {
					"{X:entr_eqchips,C:white}=#1#{} Chips"
				}
			},
			j_entr_jokezmann_brain = {
				name = "Jokezmann Brain",
				text = {
					"When exiting the shop there is a",
					"{C:green}#1# in #2#{} chance for all",
					"empty Joker slots to be filled with",
					"random {C:dark_edition}Perishable, Oversaturated{} Jokers"
				}
			},
			j_entr_libra = {
				name = "Libra",
				text = {
					"Scored {C:dark_edition}Wild{} and {C:attention}face{} cards",
					"balance their values with {C:attention}this{} Joker",
					"{C:inactive}(Currently {X:slib_echips,C:white}^#1#{} {C:inactive}Chips){}"
				}
			},
			j_entr_scorpio = {
				name = "Scorpio",
				text = {
					"Scored {C:attention}8s{} temporarily boost probabilities",
					"Grant {X:slib_echips,C:white}^Chips{} based on {C:attention}8 d8s{}",
					"Rolling {C:attention}eight{} 8s instead grants {X:slib_echips,C:white}^#1#{} Chips"
				}
			},
			j_entr_ridiculus_absens = {
				name = "Ridiculus Absens",
				text = {
					"{C:green}#1# in #2#{} scored non-{C:dark_edition}Glitched{} cards",
					"become {C:dark_edition}Glitched{} and gain an extra effect",
					"{C:attention}Randomize{} this probability when hand is {c:attention}played{}"
				}
			},

			j_entr_endlessentropy = {
				name = "Endless Entropy",
				text = {
					"Cycles through the {C:attention}following{} effects",
					"when {C:blue}hand{} is played and when {C:red}discarding{} respectively",
					"#1#",
					"#2#"
				}
			},

			j_entr_scarlet_sun = {
				name = "Scarlet Sun",
				text = {
					{
						"Scored cards give",
						"{C:attention}+#1#{} Ascension Power",
					},
					{
						"Apply {C:dark_edition}Sunny{} to",
						"scored {C:hearts}Hearts{}"
					}
				}
			},
			j_entr_burgundy_baracuda = {
				name = "Burgundy Barracuda",
				text = {
					"At the end of the shop",
					"{C:red}destroy{} a random consumable",
					"and gain {X:mult,C:white}X#2#{} Mult",
					"{C:inactive}(Currently {X:mult,C:white}X#1#{C:inactive} Mult)"
				}
			},
			j_entr_olive_orchard = {
				name = "Olive Orchard",
				text = {
					{
						"{C:green}#1# in #2#{} chance to create",
						"a {C:dark_edition}Negative{} {C:attention}Perishable",
						"copy of a random Joker when",
						"Blind is selected",
						"{C:inactive}(Excludes self)"
					},
					{
						"This Joker gains {X:mult,C:white}X#4#{} Mult",
						"when a card Perishes",
						"{C:inactive}(Currently {X:mult,C:white}X#3#{C:inactive} Mult)"
					}
				}
			},
			j_entr_citrine_comet = {
				name = "Citrine Comet",
				text = {
					{
						"Fixed {C:green}50%{} chance to",
						"create a {C:red}Temporary{} {C:dark_edition}Negative{}",
						"copy of all drawn cards"
					},
					{
						"{C:dark_edition}Negative{} cards give",
						"{C:attention}+1{} card selection limit",
						"when selected"
					}
				}
			},

			j_entr_diamond_dawn = {
				name = "Diamond Dawn",
				text = {
					{
						"Strip the rank and suit",
						"from the {C:attention}rightmost{}",
						"scored card every hand and",
						"add it to this Joker's {C:money}money{}",
					},
					{
						"Earn {C:gold}$#1#{} at end of round"
					}
				}
			},

			j_entr_alabaster_anchor = {
				name = "Alabaster Anchor",
				text = {
					"When a card is {C:red}discarded{}",
					"a random Joker gains {X:attention,C:white}X#1#{} values",
					"and another random Joker gains",
					"{X:attention,C:white}X#2#{} values",
					"{C:inactive}(Excludes self)"
				}
			},

			j_entr_skullcry = {
				name = ":skullcry:",
				text = {
					"Prevents Death if Chips scored are",
					"greater than {C:attention}log_#1#(Blind Requirement){}",
					"{C:red}Self destructs{} if Chips are not",
					"within {C:attention}#2#%{} of {C:attention}log_#1#(Blind requirement){}"
				}
			},
			j_entr_dating_simbo = {
				name = "Dating Sim-Bo",
				text = {
					"Scored {C:hearts}Hearts{} are destroyed",
					"and their {C:blue}Chips{} are {C:attention}added{} to this Joker",
					"{C:inactive}(Currently {}{C:blue}+#1#{} {C:inactive}Chips){}"
				}
			},
			j_entr_bossfight = {
				name = "Bossfight",
				text = {
					"If exactly {C:attention}#1#{} cards are played",
					"all cards held in {C:attention}hand{}",
					"gain {C:blue}+#2#{} Chip#<s>2#"
				}
			},
			j_entr_sweet_tooth = {
				name = "Sweet Tooth",
				text = {
					"{C:blue}+#1#{} Chip#<s>1#",
					"at the end of the {C:attention}shop{}",
					"destroy all {C:attention}Food{} or {C:attention}Candy{} Jokers",
					"then increase this Joker's Chips by {X:blue,C:white}X#2#{}",
					"if any {c:attention}Food{} or {C:attention}Candy{} Jokers were destroyed"
				}
			},
			j_entr_phantom_shopper = {
				name = "Phantom Shopper",
				text = {
					"Sell this Joker to create a",
					"{C:attention}#1#{} Rarity Joker",
					"Increases every {C:attention}#2#{} {C:inactive}[#3#]{}",
					"shops visited"
				}
			},
			j_entr_sunny_side_up = {
				name = "Sunny Side Up",
				text = {
					"{C:gold}+#1#{} Ascension Power",
					"{C:gold}-#2#{} Ascension Power per",
					"hand played"
				}
			},
			j_entr_atomikos = {
				name = "Atomikos",
				text = {
					"{C:attention}High Card's{} {C:dark_edition}operator{} is set to {C:attention}^{}",
					"{C:attention}Played{} poker hands are {C:red}deleted{}",
					"and their stats are {C:attention}added{} to {C:attention}High Card{}",
				}
			},
			j_entr_code_m = {
				name = "M()",
				text = {
					"When a {C:green}Code{} card is used",
					"apply {C:dark_edition}Jolly{} to a",
					"{C:attention}random{} Joker"
				}
			},

			j_entr_sunflower_seeds = {
				name = "Sunflower Seeds",
				text = {
					"After playing {C:attention}#1#{} {C:inactive}[#2#]{}",
					"{C:gold}Ascended{} hands, apply {C:dark_edition}Sunny{}",
					"to a {C:attention}random{} Joker and {C:red}self destruct{}"
				}
			},
			j_entr_tenner = {
				name = "Tenner",
				text = {
					"$ = {X:gold,C:white}#1#{}"
				}
			},
			j_entr_sticker_sheet = {
				name = "Sticker Sheet",
				text = {
					"Gives {C:mult}+#1#{} Mult",
					"for each applied {C:attention}sticker{}",
					"Apply a {C:attention}random{} sticker to",
					"a {C:attention}random{} scored card",
					"{C:inactive}(Currently{} {C:mult}+#2#{} {C:inactive}Mult){}"
				}
			},

			j_entr_metamorphosis = {
				name = "Metamorphosis",
				text = {
					"Main Joker {C:attention}scoring{} effects",
					"instead trigger when {C:attention}#1#{}s are scored",
					"Rank changes every hand"
				}
			},

			j_entr_fourbit = {
				name = "4Bit Joker",
				text = {
					"Every {C:attention}#1#{}th {C:inactive}[#2#]{} scoring card",
					"has a {C:attention}random{} card applied",
					"as an {C:attention}Enhancement{}"
				}
			},
			j_entr_scenic_route = {
				name = "Scenic Route",
				text = {
					"Create a {C:red}(~)$ new(){}",
					"when a {C:attention}Boss Blind{}",
					"is defeated",
					"{C:inactive}(Must have room){}"
				}
			},
			j_entr_crimson_flask = {
				name = "Crimson Flask",
				text = {
					"This Joker gains {X:mult,C:white}X#1#{} Mult when a Joker",
					"is {C:attention}debuffed{} and {X:mult,C:white}X#2#{} when a {C:attention}debuffed{}",
					"playing card is drawn to hand",
					"Debuff a {C:attention}random{} Joker each round",
					"{C:inactive}(Currently{} {X:mult,C:white}X#3#{} {C:inactive}Mult){}",
				},
			},
			j_entr_grotesque_joker = {
				name = "Grotesque Joker",
				text = {
					"This Joker gains {X:mult,C:white}X#1#{} Mult when a Flesh Card is",
					"added and {X:chips,C:white}X#2#{} Chips when a Flesh Card is destroyed",
					"{C:inactive}(Currently{} {X:mult,C:white}X#3#{}, {X:chips,C:white}X#4#{}{C:inactive}){}",
				},
			},
			j_entr_nyctophobia = {
				name = "Nyctophobia",
				text = {
					"When Blind is selected, destroy",
					"a random {C:attention}consumable{} and draw two",
					"random {C:dark_edition}Dark{} Cards to hand for every time",
					"that consumable was {C:attention}used{} previously"
				},
			},
			j_entr_dog_chocolate = {
				name = "Dog Chocolate",
				text = {
					"When {C:attention}Dog Tags{} are merged",
					"instead create a {C:attention}Food{} Joker",
					"and {C:red}destroy{} both of the {C:attention}Dog Tags{}",
					"{C:attention}Dog Tags{} appear more frequently"
				},
			},
			j_entr_nucleotide = {
				name = "Nucleotide",
				text = {
					"Draw a copy of the first discarded",
					"card per round with an {C:attention}inverted{} rank",
					"and suit and an upgraded {C:dark_edition}Edition{} to {C:attention}hand{}"
				},
			},
			j_entr_caviar = {
				name = "Caviar",
				text = {
					"{C:entr_entropic}Ascend{} the next {C:attention}#1#{}",
					"obtained Tags"
				},
			},
			j_entr_afterimage = {
				name = "Afterimage",
				text = {
					"Scored cards have a {C:green}#1# in #2#{}",
					"chance to draw a {C:attention}Banana{}",
					"{C:attention}Perishable{} copy to hand"
				},
			},

			j_entr_apeirostemma = {
				name = "Apeirostemma",
				text = {
					{
                    	"Use this Joker to {C:attention}retrigger{}",
						"all selected cards for {C:attention}one{} round",
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Blind",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
					}
				}
			},

			j_entr_qu= {
				name = "Qu",
				text = {
					"One {C:attention}random{} card in hand",
					"gains a random {C:red}Inverted{} card",
					"as an Enhancement when {C:attention}Blind{}",
					"is selected"
				}
			},
			j_entr_memento_mori= {
				name = {
					"A Knee Slapping Joke Joker Title",
					"Referring to how Entropy Joker",
					"Effects are always kinda like that",
					"(Memento Mori Entropic Edit)"
				},
				text = {
					"The {C:attention}first{} played card",
					"each round is {C:attention}destroyed{}"
				}
			},
			j_entr_broadcast = {
				name = "Broadcast",
				text = {
					"Copies the {C:attention}#1#{}#2# Joker's ability",
					"Increases by {C:attention}1{} at end of round",
					"Resets after reaching your {C:attention}last{} Joker"
				}
			},
			j_entr_d0 = {
				name = "D0",
				text = {
					"Multiplies all {C:attention}listed{}",
					"{C:green,E:1}probabilities{} by {C:attention}0",
					"{C:inactive}(ex. {C:green}1 in 3{C:inactive} -> {C:green}0 in 3{C:inactive})"
				}
			},
			j_entr_d1 = {
				name = "D1",
				text = {
					"The {C:attention}first{} probability roll",
					"each round is {C:green}guaranteed{}"
				}
			},
			j_entr_d4 = {
				name = "D4",
				text = {
					"Probability rolls are rolled {C:attention}twice{}",
					"with only {C:attention}one{} success needed"
				}
			},

			j_entr_d6 = {
				name = "D6",
				text = {
					"This Joker gains {C:green}+#2#{} numerator",
					"when a probability {C:red}fails{}",
					"and resets when a probability {C:green}succeeds{}",
					"{C:inactive}(Currently {C:green}+#1#{C:inactive})"
				}
			},

			j_entr_eternal_d6 = {
				name = "Eternal D6",
				text = {
					"When rerolling, {C:green}#1# in #2#{} chance",
					"to {C:red}destroy{} a random shop card, else gain",
					"{C:green}+#4#{} numerator, resets at the end of the Ante",
					"{C:inactive}(Currently {C:green}+#3#{C:inactive})"
				}
			},

			j_entr_d7 = {
				name = "D7",
				text = {
					"{C:green}#1# in #2#{} chance to",
					"retrigger each {C:green}probability{}",
					"based {C:attention}Joker{} and {C:attention}Enhancement{}"
				}
			},
			j_entr_d8 = {
				name = "D8",
				text = {
					"Probabilities are rolled with",
					"a {C:green}denominator{} lowered by {C:attention}#1#{}",
				}
			},
			j_entr_d10 = {
				name = "D10",
				text = {
					"Probabilities are rolled with",
					"{C:attention}randomly{} offset {C:green}numerators{} and {C:green}denominators{}",
				}
			},
			j_entr_d12 = {
				name = "D12",
				text = {
					"{C:green}+#1#{} numerator",
					"for every {C:attention}held{} consumable"
				}
			},
			j_entr_d100 = {
				name = "D100",
				text = {
					"Permanently {C:attention}randomize{} probabilities",
					"when they are triggered"
				}
			},
			j_entr_d100_gfb = {
				name = "D100",
				text = {
					"Randomize {C:red}ALL{} other Jokers",
					"when selecting a Blind"
				}
			},
			j_entr_capsule_machine = {
				name = "Capsule Machine",
				text = {
					"When Blind is selected",
					"create a {C:attention}Perishable{} {C:green}Dice{} {C:attention}Joker{}",
					"{C:inactive}(Must have room){}"
				}
			},

			j_entr_milk_chocolate = {
                name = "Milk Chocolate",
                text = {
                    "Sell this card to",
                    "create a free",
                    "{C:attention}#1#",
                },
            },

			j_entr_insurance_fraud = {
                name = "Insurance Fraud",
                text = {
                    "Create a random {C:red}Fraud{} card",
					"when a {C:purple}Tarot{} card is sold"
                },
            },

			j_entr_free_samples = {
                name = "Free Samples",
                text = {
                    "{C:green}#1# in #2#{} chance for",
					"opened {C:attention}Booster Packs{}",
					"to be {C:attention}copied{} to your consumables",
					"{C:inactive}(Must have room){}"
                },
            },
			j_entr_fused_lens = {
                name = "Fused Lens",
                text = {
                    "{C:green}#1# in #2#{} chance to create",
					"the {C:purple}Star{} card for your played hand",
					"{C:inactive}(Must have room){}"
                },
            },
			j_entr_opal = {
                name = "Opal",
                text = {
                    "Suitless cards may be used",
					"to form poker hands",
					"{C:attention}Retrigger{} suitless cards"
                },
            },
			j_entr_inkbleed = {
                name = "Inkbleed",
                text = {
                    "Cards that {C:attention}share{} a",
					"{C:attention}rank{} or {C:attention}modification{}",
					"count as each other's suit"
                },
            },
			j_entr_roulette = {
                name = "Roulette",
                text = {
                    "{C:green}#1# in #2#{} chance for",
					"each scored card to gain {C:red}+#3#{} bonus Mult",
					"Destroy every {C:attention}#4#{}th scoring card"
                },
            },
			j_entr_debit_card = {
                name = "Debit Card",
                text = {
                    "Earn {C:money}$#1#{} for every",
					"{C:money}$#2#{} {C:inactive}[$#3#]{} spent",
					"at the end of round",
					"{C:inactive}(Currently {C:money}$#4#{C:inactive}){}"
                },
            },
			j_entr_birthday_card = {
                name = "Birthday Card",
                text = {
                    "{X:mult,C:white}X#1#{} Mult if you have",
					"at least {C:attention}#2#{} held consumables"
                },
            },
			j_entr_sandpaper = {
                name = "Sandpaper",
                text = {
                    "If played hand contains a {C:attention}Stone Card{}",
					"{C:red}destroy{} all played {C:attention}Stone Cards{}",
					"and create a {C:attention}random{} {C:purple}Rune card{}"
                },
            },
			j_entr_purple_joker = {
                name = "Purple Joker",
                text = {
                    "This Joker gains {X:mult,C:white}X#1#{} Mult",
					"whenever a {C:purple}Rune{} triggers",
					"{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult){}"
                },
            },
			j_entr_chalice_of_blood = {
                name = "Chalice of Blood",
                text = {
                    "{X:mult,C:white}X#1#{} Mult per {C:red}Pact{}",
					"card used this run",
					"{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult){}"
                },
            },
			j_entr_chalice_of_blood_gfb = {
                name = "Chalice of {C:red}Blood{}",
                text = {
                    "'Only for those who are {C:entr_zenith}worthy{}'"
                },
            },
			j_entr_torn_photograph = {
                name = "Torn Photograph",
                text = {
                    "This Joker gains {X:mult,C:white}X#1#{} Mult",
					"whenever a {C:red}Inverted{} card is sold",
					"{C:inactive}(Currently {X:mult,C:white}X#2#{C:inactive} Mult){}"
                },
            },
			j_entr_chuckle_cola = {
                name = "Chuckle Cola",
                text = {
                    "Multiply the {C:blue}Chips{} of {C:attention}scored{}",
					"cards by {X:blue,C:white}X#1#{}, {C:red}self destructs{}",
					"after {C:attention}#2#{} card#<s>2# scored"
                },
            },
			j_entr_antiderivative = {
                name = "Antiderivative",
                text = {
                    "{C:attention}Ranks{} and {C:attention}suits{} are swapped",
					"for {C:attention}Jokers{} and {C:attention}poker hand{} detection",
					"{C:inactive,s:0.8}Spades, Hearts, Clubs, and Diamonds{}",
					"{C:inactive,s:0.8}count as Ace, King, Queen, Jack respectively{}"
                },
            },
			j_entr_alles = {
                name = "Oops, All e's!",
                text = {
                    "Earn {C:money}$#1#{} at end of round if",
					"you take {C:attention}more{} than {C:blue}1{} hand",
					"to beat the {C:attention}Blind{}"
                },
            },
			j_entr_verbophobia = {
                name = "Verbophobia",
                text = {
                    "The first {C:attention}5{} letter or lower",
					"Word each round is {C:red}always{} counted",
					"as a {C:attention}valid{} Word"
                },
            },
			j_entr_feynman_point = {
                name = "Feynman Point",
                text = {
                    "Round Joker {C:attention}decimals{} to",
					"the next {X:dark_edition,C:white}#1#{} increasing",
					"by {X:dark_edition,C:white}#2#{} whenever a",
					"probability {C:green}succeeds{}"
                },
            },
			j_entr_neuroplasticity = {
                name = "Neuroplasticity",
                text = {
                    "Poker hands calculate",
					"as a {C:attention}random{} hand",
					"Changes {C:attention}every round{}"
                },
            },
			j_entr_dragonfruit = {
                name = "Dragonfruit",
                text = {
                    "{C:attention}+#1#{} card selection limit",
					"{C:attention}-#2#{} card selection limit",
					"after every played hand"
                },
            },
			j_entr_prismatikos = {
                name = "Prismatikos",
                text = {
                    "Chooses an effect randomly when triggered",
					"{X:chips,C:white}???{} Chips, {X:mult,C:white}???{} Mult, {X:money,C:white}???{} Ascension Power",
					"{X:money,C:white}???{} money, {X:blue,C:white}???{} hands",
					"Create {C:attention}2{} Inverted cards, played hand gains random {C:dark_edition}Editions{}",
					"{X:attention,C:white}X0.9{} Blind size, ...",
                },
            },
			j_entr_jestradiol = {
                name = "Jestradiol",
                text = {
					{
                    	"Use this Joker to turn up to {C:attention}#1#{}",
						"selected cards into {C:entr_trans}Queens{}",
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Boss Blind"
					}
                },
            },
			j_entr_penny = {
                name = "Lost Penny",
                text = {
                    "{C:blue}+#1#{} Chips",
					"{C:dark_edition}Doubles{} when Boss Blind",
					"is defeated"
                },
            },
			j_entr_slothful_joker = {
                name = "Slothful Joker",
                text = {
                    "Played {C:purple}suitless{} cards give",
                    "{C:mult}+#1#{} Mult when scored",
                },
            },
			j_entr_radar = {
                name = "Radar",
                text = {
                    "Earn the last played",
					"{C:attention}poker hand's{} level",
					"as money at end of round",
					"{C:inactive}(Currently {C:money}$#1#{C:inactive})"
                },
            },
			j_entr_abacus = {
                name = "Abacus",
                text = {
                    "Scored numbered cards give",
					"one half of their",
					"{C:blue}Chips{} as {C:red}Mult{}"
                },
            },
			j_entr_matryoshka_dolls = {
                name = "Matryoshka Dolls",
                text = {
                    "{C:red}+#1#{} Mult",
					"When Blind is selected",
					"create a {C:attention}copy{} of this Joker",
					"with {C:red}1{} fewer Mult",
					"{C:inactive}(Must have room)"
                },
            },
			j_entr_matryoshka_dolls_gfb = {
                name = "Matryoshka Dolls",
                text = {
                    "{X:blue,C:white}X#1#{} Chips",
					"When Blind is selected",
					"create a {C:attention}copy{} of this Joker",
					"with {X:blue,C:white}0.5{} fewer XChips",
					"{C:inactive}(Must have room)"
                },
            },
			j_entr_menger_sponge = {
                name = "Menger Sponge",
                text = {
                    "{C:blue}+#1#{} Chips",
					"Multiplies by {X:attention,C:white}X#2#{} at end of round",
					"{C:red}Resets{} when the Boss Blind is defeated"
                },
            },
			j_entr_menger_sponge_gfb = {
                name = "Menger Sponge",
                text = {
                    "{C:blue}+#1#{} Chips",
					"Multiplies by {X:attention,C:white}(sin(#1#)+1)X#2#{} at end of round",
                },
            },
			j_entr_arbitration = {
                name = "Arbitration",
                text = {
                    "Create a {C:attention}Judgement{}",
					"when a {C:attention}Glass Card{}",
					"is destroyed",
					"{C:inactive}(Must have room)"
                },
            },
			j_entr_masterful_gambit = {
                name = "Masterful Gambit",
                text = {
                    "Earn {C:money}$#1#{}",
					"if played hand contains",
					"{C:attention}only{} a single card"
                },
            },
			j_entr_fourty_benadryls = {
                name = "Fourty Benadryls",
                text = {
                    "{C:blue}+#1#{} Chip#<s>1#",
					"for each Ante",
					"{C:inactive}(Currently {C:blue}#2#{C:inactive} Chip#<s>2#)"
                },
            },
			j_entr_fourty_benadryls_gfb = {
                name = "Fourty Benadryls",
                text = {
                    "Go directly to",
					"Ante {C:red}32{}"
                },
            },
			j_entr_red_fourty = {
                name = "Red-40",
                text = {
                    "{C:red}+#1#{} Mult",
					"{C:red}-#2#{} Mult when",
					"spending money in the shop"
                },
            },
			j_entr_promotion = {
                name = "Promotion",
                text = {
                    "Create a {C:attention}random{} Booster Pack",
					"in the consumables tray when",
					"the Boss Blind is defeated",
					"{C:inactive}(Must have room)"
                },
            },
			j_entr_offbrand = {
                name = "Offbrand",
                text = {
                    "{C:red}-#1#{} Mult",
					"Earn {C:money}$#2#{} at",
					"end of round"
                },
            },
			j_entr_girldinner = {
                name = "Girldinner",
                text = {
                    "The first scored {C:attention}Queen{}",
					"each round gives {C:mult}+#1#{} Mult",
					"and {C:blue}+#2#{} Chips"
                },
            },
			j_entr_recycling_bin = {
                name = "Recycling Bin",
                text = {
                    "This Joker gains {C:red}+#1#{} Mult",
					"per each {C:attention}discarded{} card and",
					"{C:red}resets{} at the end of round",
					"{C:inactive}(Currently {C:red}#2#{C:inactive} Mult)"
                },
            },
			j_entr_gold_bar = {
                name = "Gold Bar",
                text = {
                    "Earn {C:money}$#1#{} at end of round",
					"decreases by {C:red}$#2#{} when triggered"
                },
            },
			j_entr_scribbled_joker = {
                name = "Scribbled Joker",
                text = {
                    "{C:blue}+#1#{} Chips",
					"if scored hand contains",
					"an {C:attention}Enhanced{} card"
                },
            },
			j_entr_jokers_against_humanity = {
                name = "Jokers Against Humanity",
                text = {
                    "First scored card each",
					"hand becomes {C:attention}Eternal{}",
					"Scored {C:attention}Eternal{} cards give",
					"{C:blue}+#1#{} Chips and",
					"{C:red}+#2#{} Mult"
                },
            },
			j_entr_blind_collectible_pack = {
                name = "Blind Collectible Pack",
                text = {
                    "Sell this card to",
					"create a free",
					"{C:attention}Blind Token{}",
					"{C:inactive}(Must have room)"
                },
            },
			j_entr_blind_collectible_pack_gfb = {
                name = "Plant Collectible Pack",
                text = {
                    "Sell this card to",
					"create a free",
					"{C:attention}Plant Blind Token{}",
					"{C:inactive}(Must have room)"
                },
            },
			j_entr_prayer_card = {
                name = "Prayer Card",
                text = {
                    "{C:attention}-#1#{} Blind requirement",
					"for each Ante",
					"{C:inactive}(Currently {C:attention}#2#{C:inactive})"
                },
            },
			j_entr_desert = {
                name = "Desert",
                text = {
                    "This Joker gains {C:gold}+#1#{}",
					"Ascension Power if played hand",
					"contains exactly {C:attention}1{} card",
					"{C:inactive}(Currently {C:gold}#2#{C:inactive} Ascension Power)"
                },
            },
			j_entr_rugpull = {
                name = "Rugpull",
                text = {
                    "Earn no Payout",
					"{X:attention,C:white}X#1#{} The Payout amount",
					"is added to this Joker's",
					"{C:attention}sell value{} instead"
                },
            },
			j_entr_grape_juice = {
                name = "Grape Juice",
                text = {
					{
						"Use this Joker to",
						"turn a random card held in hand",
						"into a {C:attention}Bonus{}, {C:attention}Mult{}, or {C:attention}Wild{} Card",
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Boss Blind",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
					}
                },
            },
			j_entr_petrichor = {
                name = "Petrichor",
                text = {
                    "Non-scored cards",
					"give {C:blue}+#1#{} Chips"
                },
            },
			j_entr_otherworldly_joker = {
                name = "Otherworldly Joker",
                text = {
                    "Create a {C:red}Inverted{} card",
					"when any {C:attention}Booster Pack{}",
					"is skipped",
					"{C:inactive}(Must have room){}"
                },
            },
			j_entr_error = {
                name = "ERROR",
                text = {
                    "Calculated effects are",
					"slightly {C:attention}offset{}",
					"{C:inactive,S:0.8}(Eg. {C:blue}+30{C:inactive} Chips or {X:red,C:white}X2{C:inactive} Mult)"
                },
            },
			j_entr_thirteen_of_stars = {
                name = "Thirteen of Stars",
                text = {
                    "Gives one {C:attention}quarter{} of the",
					"played poker hand's {C:purple}level{}",
					"as {C:gold}Ascension Power{}"
                },
            },
			j_entr_diode_red = {
                name = "LED (Red)",
                text = {
                    "{C:red}+#1#{} Mult",
					"{C:inactive,S:0.8}Switches after hand played"
                },
            },
			j_entr_diode_blue = {
                name = "LED (Blue)",
                text = {
                    "{C:blue}+#1#{} Chips",
					"{C:inactive,S:0.8}Switches after hand played"
                },
            },
			j_entr_prismatic_shard = {
                name = "Prismatic Shard",
                text = {
                    "Scored cards give",
					"{C:mult}+#1#{} Mult,",
					"{C:blue}+#2#{} Chips, or",
					"{C:gold}+#3#{} Ascension Power"
                },
            },
			j_entr_chameleon = {
                name = "Chameleon",
                text = {
                    "Scores as a",
					"random {C:attention}Enhancement{}"
                },
            },
			j_entr_thanatophobia = {
                name = "Thanatophobia",
                text = {
                    "Gives half the {C:attention}sell value{} of all",
					"sold or destroyed {C:attention}Jokers{} as Mult",
					"{C:inactive}(Currently {C:mult}+#1#{C:inactive})"
                },
            },
			j_entr_redkey= {
                name = "Red Key",
                text = {
					{
						"Use this Joker to add an {C:attention}extra{} ",
						"{C:red}Red Room{} Blind",
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Boss Blind",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
					}
                },
            },
			j_entr_polaroid = {
                name = "Polaroid",
                text = {
					{
					"Use this Joker to copy another {C:attention}Joker's{}",
					"abilities until next used",
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Blind",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
					}
                },
            },

			j_entr_polaroid_gfb = {
				name = "The Polaroid",
				text = {
					{
						"Use this Joker to create",
						"a {C:attention}Photograph",
						"{C:inactive}(Must have room)"
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Blind",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
					}
                },
			},
			j_entr_polaroid_gfbn = {
				name = "The Negative",
				text = {
					{
						"Use this Joker to create",
						"a {C:attention}Photograph",
						"{C:inactive}(Must have room)"
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Blind",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
					}
                },
			},
			j_entr_car_battery = {
                name = "Car Battery",
                text = {
					"Useable {C:attention}Jokers{} and {C:attention}consumables{}",
					"gain {C:attention}#1#{} extra use",
					"when defeating a Boss Blind",
                },
            },
			j_entr_chair = {
                name = "Chair",
                text = {
					"If played hand is {C:attention}Three of a Kind",
					"apply {C:attention}Freaky{} to the {C:attention}third{}",
					"scoring card"
                },
            },
			j_entr_captcha = {
                name = "Captcha",
                text = {
					{
						"Use this Joker to apply a random",
						"{C:attention}Joker{}, {C:attention}consumable{}",
						"{C:attention}Booster Pack{} or {C:attention}Voucher{}",
						"as an Enhancement to a",
						"{C:attention}random{} card held in hand"
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Blind",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
					}
                },
            },
			j_entr_deck_enlargement_pills = {
                name = "Deck Enlargement Pills",
                text = {
					"After {C:attention}#1#{} {C:inactive}[#2#]{} rounds",
					"sell this card to",
					"{C:attention}apply{} a random {C:attention}Deck's{} effects"
                },
            },
			j_entr_deck_enlargement_pills_gfb = {
                name = "Deck Enlargement Pills",
                text = {
					"{C:green}Duplicate your entire Deck.",
					"{C:red}Add {C:attention}Bad Luck{}"
                },
            },
			j_entr_photocopy = {
                name = "Photocopy",
                text = {
					"The first card in {C:attention}Standard Packs{}",
					"always has your most common",
					"{C:attention}suit{} and {C:attention}rank{}"
                },
            },

			j_entr_hexa = {
                name = "HexaCryonic, Witch of Light",
                text = {
					"Extra played cards provide",
					"{C:gold}+3{} Ascension Power",
					"{C:attention}+3{} card selection limit"
                },
            },
			j_entr_hexa_cryptid = {
                name = "HexaCryonic, Knight of Mind",
                text = {
					"Extra played cards provide {X:gold,C:white}X3{}",
					"as much Ascension Power",
					"{C:attention}+#1#{} card selection limit"
                },
            },
			j_entr_grahkon = {
                name = "First Guardian, Grahkon",
                text = {
					{
						"{C:attention}-#1#{} Blind size",
						"Increases by {X:attention,C:white}X#2#{} when a ",
						"playing card is destroyed, use this Joker to",
						"destroy {C:attention}#3#{} random card#<s>3# in hand",
					},
					{
						"This Joker gains {C:attention}#4#{} use#<s>4#",
						"when defeating a Blind",
						"{C:inactive}(Currently {C:attention}#5#{C:inactive} use#<s>5#)"
					}
                },
            },
			j_entr_ybur = {
                name = "Ybur",
                text = {
					"Prevents Death once per Ante",
					"if no Blinds were skipped",
					"This Joker gains {X:slib_echips,C:white}^#2#{} Chips",
					"when death is prevented",
					"{C:inactive}(Currently {X:slib_echips,C:white}^#1#{C:inactive} Chips, #3#)"
                },
            },
			j_entr_ybur_gfb = {
				name = "Ruby Prime",
				text = {
					"I CAN {C:red}TANK{} {C:entr_zenith}ANY{} ATTACK"
				}
			},
			j_entr_zelavi = {
                name = "Zelevai",
                text = {
					"This Joker gains {X:blue,C:white}X#2#{} Chips",
					"whenever a {C:spectral}Spectral Pack{} is opened",
					"Each shop always contains a {C:spectral}Mega Spectral Pack{}",
					"{C:inactive}(Currently {X:blue,C:white}X#1#{C:inactive} Chips)"
                },
            },
			j_entr_ssac = {
                name = "Swonkssac",
                text = {
					"{C:attention}Force-trigger{} the rightmost",
					"{C:attention}Joker{}, {C:attention}playing card{}, and {C:attention}consumable{}",
					"once for every two base ranks missing in full deck",
					"{C:inactive}(Currently {C:attention}#1#{C:inactive})"
                },
            },
			j_entr_axeh = {
                name = "CinoyrcAxeh",
                text = {
					"Creates a {C:attention}Sunny Joker{}",
					"when obtained",
					"{X:gold,C:white}X#1#{} to all sources",
					"of Ascension Power"
                },
            },
			j_entr_nokharg = {
                name = "Nokharg",
                text = {
					"Copies played hand if no {C:red}discards{}",
					"have been used in the {C:attention}current round{}",
					"{X:attention,C:white}+X#2#{} Blind size for every copied card",
					"{C:inactive}(Currently {X:attention,C:white}X#1#{C:inactive} Blind size)"
                },
            },

			j_entr_enlightenment = {
                name = "Enlightenment",
                text = {
					"Allows {C:attention}The Fool{} to copy",
					"any {C:red}non-Inverted{} or {C:red}hidden{} consumable",
					"or Booster Pack, allows {C:red}The Master{} to copy",
					"{C:red}Twisted Packs{}"
                },
            },
			j_entr_black_rose_green_sun = {
                name = "Black Rose, Green Sun",
                text = {
					"{C:spades}Spades{} and {C:clubs}Clubs{}",
					"held in hand give",
					"{C:gold}+#1#{} Ascension Power"
                },
            },

			j_entr_heimartai = {
                name = "Heimartai",
                text = {
                    "Probabilities are {C:attention}retriggered{}",
					"until they {C:green}succeed{}",
					"Gain {X:slib_echips,C:white}^Chips{} equal to the {C:attention}number of rolls{}",
					"divided by the {C:green}probability's denominator{}",
					"{C:inactive}(Currently {X:slib_echips,C:white}^#1#{C:inactive} Chips)"
                },
            },
			j_entr_jack_off = {
                name = "Jack-Off",
                text = {
                    "Scored {C:attention}Jacks{} discard",
					"a {C:attention}random{} card held",
					"in hand"
                },
            },
			j_entr_fast_food = {
                name = "Fast Food",
                text = {
					"When {C:attention}Blind{} is selected",
                    "create a {C:attention}Perishable Food{} Joker",
					"{C:inactive}(Must have room)"
                },
            },
			j_entr_antipattern= {
                name = "Antipattern",
                text = {
					"This Joker gains {X:blue,C:white}X#1#{} Chips",
					"for each {C:attention}Unique{} pair of {C:attention}poker hands{} played",
					"{C:inactive}(Currently {X:blue,C:white}X#2#{C:inactive} Chips)"
                },
            },
			j_entr_spiral_of_ants = {
                name = "Spiral of Ants",
                text = {
					"This Joker gains {C:blue}+#1#{} Chips",
					"for each {C:attention}consecutive{} hand with {C:attention}fewer{}",
					"cards than the previous hand",
					"{C:inactive}(Currently {C:blue}+#2#{C:inactive} Chips)"
                },
            },
			j_entr_fork_bomb = {
                name = "Fork Bomb",
                text = {
					"When {C:attention}Blind{} is selected",
					"create a {C:attention}copy{} of this Joker",
					"{C:inactive}(May overflow, max of 16)"
                },
            },
			j_entr_fork_bomb_gfb = {
				name = "Fork Bomb",
				text = {
					"When {C:attention}Blind{} is selected",
					"create a {C:attention}copy{} of this Joker",
				}
			},
			j_entr_solar_panel = {
                name = "Solar Panel",
                text = {
					"Discarded {C:attention}Sunny{} and {C:attention}Radiant{}",
					"Cards give {C:money}$#1#{}"
                },
            },
			j_entr_kintsugi = {
                name = "Kintsugi",
                text = {
					"{C:attention}Ceramic{} Cards are turned",
					"to {C:attention}Gold{} Cards instead",
					"of {C:red}self destructing{}"
                },
            },
			j_entr_blooming_crimson = {
                name = "Blooming Crimson",
                text = {
                    "Scored cards give",
					"{X:mult,C:white}X#1#{} Mult,",
					"{X:blue,C:white}X#2#{} Chips, or",
					"{X:gold,C:white}X#3#{} Ascension Power"
                },
            },
			j_entr_overpump = {
                name = "Overpump",
                text = {
                    "{X:mult,C:white}X#1#{} Mult on {C:attention}final{}",
					"{C:attention}hand{} of round",
					"Increases by {X:mult,C:white}X#2#{} for each",
					"{C:attention}unique{} poker hand played this round"
                },
            },
			j_entr_shadow_crystal = {
                name = "Shadow Crystal",
                text = {
                    "Consumables have a {C:green}#1# in #2#{}",
					"chance to also trigger their",
					"{C:red}Inverted{} counterparts",
					"{C:inactive}(If possible)",
					"{C:inactive}(Hidden consumables excluded)"
                },
            },
			j_entr_miracle_berry = {
                name = "Miracle Berry",
                text = {
                    "The next {C:attention}#1#{} consumables to",
					"appear will be {C:spectral}Spectrals{}",
                },
            },
			j_entr_meridian = {
                name = "Meridian",
                text = {
                    "Gives Mult based on",
					"{C:attention}position{} in the Jokers tray",
					"{C:inactive}(Currently {C:mult}+#1#{C:inactive} Mult)"
                },
            },
			j_entr_mango = {
                name = "Mango",
                text = {
                    "Copy the {C:attention}first played{} card",
					"of the next {C:attention}#1#{} hands",
					"then draw it to {C:attention}hand{}"
                },
            },
			j_entr_kitchenjokers = {
                name = "Kitchen Joker",
                text = {
                    "Food Jokers are {C:attention}more likely{}",
					"to appear, are {C:attention}X#1#{} as expensive",
					"and are {C:dark_edition}Low-Res{}"
                },
            },
			j_entr_hash_miner = {
                name = "Hash Miner",
                text = {
                    "{C:green}#1# in #2#{} chance to corrupt",
					"played hands, corrupted hands have a",
					"{C:green}#3# in #4#{} chance to recover",
					"Gain {C:money}$#5#{} of sell value",
					"per corrupted hand at the end of round",
                },
            },
			j_entr_dice_shard = {
                name = "Dice Shard",
                text = {
					{
						"Use this Joker to transform a selected",
						"{C:attention}Joker{} into the previous Joker",
						"according to the Collection order",
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Blind",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#, #3#)"
					}
                },
            },
			j_entr_bell_curve = {
                name = "Bell Curve",
                text = {
					"Retrigger all played",
					"cards other than the",
					"{C:attention}first{} and {C:attention}last"
                },
            },
			j_entr_pineapple = {
                name = "Pineapple",
                text = {
					"Add a {C:attention}permanent{} retrigger",
					"to {C:attention}1{} random card from",
					"{C:attention}full deck{} at the end of",
					"the next {C:attention}#1#{} rounds"
                },
            },
			j_entr_rubber_ball = {
                name = "Rubber Ball",
                text = {
					"{C:green}#1# in #2#{} chance to",
					"retrigger each scored card",
					"then {C:red}reverse{} scoring {C:attention}order{}",
					"when triggered"
                },
            },
			j_entr_stand_arrow = {
                name = "Stand Arrow",
                text = {
					{
						"Use this Joker to {C:red}destroy{} a selected",
						"Joker with a {C:green}#3# in #4#{} chance,",
						"otherwise apply {C:dark_edition}Polychrome, Negative{}",
						"{C:dark_edition}Sunny, Solar, Fractured{} or {C:dark_edition}Freaky{}",
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Blind",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
					}
                },
            },
			j_entr_dancer = {
                name = "Dancer",
                text = {
					"{C:attention}+#1#{} card selection limit",
					"{C:red}#2#{} discards"
                },
            },
			j_entr_kings_scepter = {
                name = "King's Scepter",
                text = {
					"Destroy {C:attention}all{} played",
					"{C:red}debuffed{} cards"
                },
            },
			j_entr_monkeys_paw = {
                name = "Monkey's Paw",
                text = {
					"Use this Joker to create",
					"a random {C:attention}Eternal{} {C:red}Pact{}",
					"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
                },
            },
			j_entr_magic_skin = {
                name = "Magic Skin",
                text = {
					{
						"Use this Joker to create {C:attention}#3#{}",
						"{C:dark_edition}Negative{} cards based on",
						"the {C:attention}currently{} opened Booster Pack",
						"{C:inactive,s:0.8}Has a higher chance to show up after each use",
					},
					{
						"This Joker gains {C:attention}#4#{} use#<s>4#",
						"when defeating a Blind",
						"{C:inactive}(Currently {C:attention}#2#{}, {C:attention}#1#{C:inactive} use#<s>1#)"
					}
                },
            },
			j_entr_lambda_calculus = {
                name = "Lambda Calculus",
                text = {
					"Whenever another Joker {C:attention}triggers{}",
					"add its {C:attention}values{} to this Jokers {C:blue}Chips{}",
					"{C:red}Resets{} when this Joker triggers",
					"{C:inactive}(Currently {C:blue}+#1#{C:inactive} Chips)"
                },
            },
			j_entr_elderberries = {
                name = "Elderberries",
                text = {
					"Forcibly use {C:attention}#1#{}",
					"{C:spectral}Spectral{} cards",
					"when sold"
                },
            },
			j_entr_elderberries_gfb = {
				name = "Elderberries",
				text = {
					"Forcibly use {C:spectral}Ankh{} when sold",
					"{C:green}0.3%{} chance to use {C:spectral}The Soul{} instead"
				}
			},
			j_entr_nostalgic_d6 = {
                name = "Nostalgic D6",
                text = {
					"Use this Joker for {C:money}$#1#{}",
					"to {C:attention}reroll{} a Booster Pack's",
					"contents"
                },
            },
			j_entr_blood_orange = {
                name = "Blood Orange",
                text = {
					"Create an {C:red}Inverted{} consumable",
					"for the next {C:attention}#1#{}",
					"playing cards destroyed",
					"{C:inactive}(Must have room)"
                },
            },
			j_entr_false_vacuum_collapse = {
                name = "False Vacuum Collapse",
                text = {
					"This Joker is played as the {C:attention}first{}",
					"card of hand and {C:red}destroys{} the",
					" {C:attention}second{} played card when scored",
					"then returns"
                },
            },
			j_entr_mark_of_the_beast = {
                name = "Mark of The Beast",
                text = {
					"Each shop contains a",
					"{C:red}Mega Twisted Pack{} at the cost",
					"of {C:attention}1{} random card from",
					"{C:attention}full deck{}"
                },
            },

			j_entr_echo_chamber = {
                name = "Echo Chamber",
                text = {
					{
						"Use this Joker to destroy a selected",
						"{C:attention}consumable{}, the last three",
						"consumables destroyed by this",
						"Joker are {C:attention}triggered{} again",
						"when another consumable is destroyed",
						"{C:inactive}({V:1}#5#{}, {V:2}#6#{}, {V:3}#7#{C:inactive})",
						"{C:inactive}(Hidden consumables excluded)"
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"after spending {C:money}$#3#{} in the shop",
						"{C:inactive}(Currently {C:money}$#4#{}, {C:attention}#1#{C:inactive} use#<s>1#)"
					}
                },
            },

			j_entr_milk = {
                name = "Milk Carton",
                text = {
					"This Joker gains {C:blue}+#2#{}",
					"Chips when a round is won",
					"in more than {C:attention}one{} hand",
					"Turns into {C:attention}Yogurt{} after",
					"reaching {C:blue}#3#{} Chips",
					"{C:inactive}(Currently {C:blue}+#1# {C:inactive}Chips)"
                },
            },
			j_entr_yogurt = {
                name = "Yogurt",
                text = {
					"This Joker loses {C:blue}#2#{}",
					"Chips when any Chip effect",
					"is triggered",
					"{C:inactive}(Currently {C:blue}+#1# {C:inactive}Chips)"
                },
            },

			j_entr_milk_gfb = {
                name = "Strawberry Milk",
                text = {
					"This Joker gains {C:red}+#2#{}",
					"Mult when a round is won",
					"in more than {C:attention}one{} hand",
					"Turns into {C:attention}Strawberry Yogurt{} after",
					"reaching {C:red}#3#{} Mult",
					"{C:inactive}(Currently {C:red}+#1# {C:inactive}Mult)"
                },
            },
			j_entr_yogurt_gfb = {
                name = "Strawberry Yogurt",
                text = {
					"This Joker loses {C:red}#2#{}",
					"Mult when any Mult effect",
					"is triggered",
					"{C:inactive}(Currently {C:red}+#1# {C:inactive}Mult)"
                },
            },
			j_entr_box_of_chocolates = {
                name = "Box of Chocolates",
                text = {
					"{C:attention}Force-trigger{} a random card",
					"from the next {C:attention}#1#{}",
					"opened {C:attention}Booster Packs{}"
                },
            },
			j_entr_carrot_cake = {
                name = "Carrot Cake",
                text = {
					"The next {C:attention}#1#{}",
					"created consumables will",
					"appear {C:dark_edition}Gilded{}"
                },
            },
			j_entr_twisted_pair = {
                name = "Twisted Pair",
                text = {
					"Retrigger all cards played",
					"All retriggered cards score",
					"with {X:attention,C:white}X#1#{} card values",
					"temporarily"
                },
            },
			j_entr_texas_hold_em = {
                name = "Texas Hold 'Em",
                text = {
					"{C:red}-#1#{} card selection limit",
					"apply {C:attention}Marked{} to the",
					"first {C:attention}#2#{} cards drawn",
					"each Blind"
                },
            },
			j_entr_fasciation = {
                name = "Fasciation",
                text = {
					"Retrigger each scored card",
					"once for every {C:attention}previous{} scored",
					"card with the same {C:attention}suit{}"
                },
            },
			j_entr_fasciation_gfb = {
				name = "Why the long Face?"
			},
			j_entr_amaryllis = {name = "Amaryllis", text = {""}},
			j_entr_amaryllis_white = {
                name = "White Amaryllis",
                text = {
					{
						"Create a {C:purple}Rune{} card",
						"when {C:attention}Blind{} is selected",
						"{C:inactive}(Must have room)"
					},
					{
						"Switches colour at",
						"end of round"
					}
                },
            },
			j_entr_amaryllis_red = {
                name = "Red Amaryllis",
                text = {
					{
						"Played cards are",
						"converted to {C:hearts}Hearts"
					},
					{
						"Switches colour at",
						"end of round"
					}
                },
            },
			j_entr_amaryllis_pink = {
                name = "Pink Amaryllis",
                text = {
					{
						"A random card in the",
						"first {C:attention}drawn{} hand",
						"becomes {C:entr_freaky}Freaky{}"
					},
					{
						"Switches colour at",
						"end of round"
					}
                },
            },
			j_entr_amaryllis_orange = {
                name = "Orange Amaryllis",
                text = {
					{
						"When {C:attention}Blind{} is selected",
						"gain {C:blue}+#1#{} hands"
					},
					{
						"Switches colour at",
						"end of round"
					}
                },
            },
			j_entr_amaryllis_purple = {
                name = "Purple Amaryllis",
                text = {
					{
						"Each {C:attention}face card{}",
						"held in hand balances",
						"{C:blue}Chips{} and {C:red}Mult{}"
					},
					{
						"Switches colour at",
						"end of round"
					}
                },
            },
			j_entr_amaryllis_yellow = {
                name = "Yellow Amaryllis",
                text = {
					{
						"Earn {C:gold}$#2#{} at",
						"end of round",
					},
					{
						"Switches colour at",
						"end of round"
					}
                },
            },
			j_entr_cooking_pot = {
                name = "Cooking Pot",
                text = {
					"Obtained {C:attention}Food{} Jokers are",
					"instead added to this Joker",
					"without being able to degrade",
					"{C:red}self destructs{} after {C:attention}3{}",
					"{C:attention}Food{} Jokers obtained",
					"{C:inactive}(Currently {C:attention}#1#{C:inactive}, {C:attention}#2#{C:inactive}, {C:attention}#3#{C:inactive})"
                },
            },
			j_entr_brownies = {
				name = "Brownies",
				text = {
					"Earn {C:gold}$#1#{} when",
					"the next {C:attention}#2#{} consumables",
					"are used"
				}
			},
			j_entr_redacted = {
				name = "{X:white,C:entr_transparent}______{} Joker",
				text = {
					"Flip a random Joker",
					"and apply {C:attention}Rental{} when",
					"Blind is selected",
					"{C:attention}rental{} Jokers give",
					"{C:mult}+#1#{} Mult"
				}
			},
			j_entr_void_cradle = {
				name = "Void Cradle",
				text = {
					{
						"Use this Joker to {C:red}Invert{}",
						"a selected consumable",
						"All {C:attention}future{} instances of",
						"this consumable are",
						"also {C:red}Inverted{}"
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Boss Blind",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
					}
				}
			},
			j_entr_arachnophobia = {
				name = "Arachnophobia",
				text = {
					"Create an {C:entr_omen}Omen{}",
					"card if {C:attention}#1#{} or more",
					"{C:attention}8{}'s are scored in",
					"one hand",
					"{C:inactive}(Must have room)"
				}
			},
			j_entr_pound_of_flesh = {
				name = "A Pound of Flesh",
				text = {
					"All {C:attention}Booster Packs{} instead cost",
					"{C:attention}1{} random card from {C:attention}full deck{}",
					"All {C:attention}Vouchers{} instead cost {C:attention}3{}",
					"random cards from {C:attention}full deck{}"
				}
			},
			j_entr_fthof = {
				name = "Force the Hand of Fate",
				text = {
					"{C:attention}Vouchers{} in the shop are",
					"replaced by {C:dark_edition}Gilded{} {C:red}Rare{} Jokers",
					"{C:green}#1# in #2#{} chance to {C:red}self destruct{} ",
					"when buying any other card from",
					"the {C:attention}shop{}"
				}
			},
			j_entr_searing_joke = {
				name = "Searing Joke",
				text = {
					"This Joker may be {C:red}Inverted{}",
					"and gains {X:mult,C:white}X#2#{} Mult",
					"when being {C:red}Inverted{}",
					"{C:inactive}(Currently {X:mult,C:white}X#1#{C:inactive} Mult)"
				}
			},
			j_entr_ancestral_recall = {
				name = "Ancestral Recall",
				text = {
					{
                    	"Use this Joker to draw {C:attention}three{}",
						"extra cards then apply",
						"{C:attention}Marked{} to them",
						"and lose {C:red}#3#{} Hands for",
						"the rest of the current round"
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Blind",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
					}
				}
			},

			j_entr_planetarium = {
				name = "Planetarium",
				text = {
					"Changes {C:entr_ascended}Effect{} based on",
					"the last used hand specific",
					"{C:planet}Planet{} or {C:purple}Star{} card"
				}
			},

			["j_entr_planetarium_High Card"] = {
				name = "Planetarium: Pluto",
				text = {
					{
						"All hands score as {C:attention}High Card{}"
					},
					{
						"Apply {C:attention}Marked{} to",
						"all unscored cards"
					},
					{
						"Changes {C:entr_ascended}Effect{} based on",
						"the last used hand specific",
						"{C:planet}Planet{} or {C:purple}Star{} card"
					}
				}
			},
			["j_entr_planetarium_Pair"] = {
				name = "Planetarium: Mercury",
				text = {
					{
						"Before hand is played convert",
						"the {C:attention}leftmost{} selected card",
						"into the {C:attention}rightmost{} selected card"
					},
					{
						"Changes {C:entr_ascended}Effect{} based on",
						"the last used hand specific",
						"{C:planet}Planet{} or {C:purple}Star{} card"
					}
				}
			},
			["j_entr_planetarium_Two Pair"] = {
				name = "Planetarium: Uranus",
				text = {
					{
						"Poker Hands calculate",
						"with an extra copy of the",
						"{C:attention}first{} and {C:attention}second{} played cards"
					},
					{
						"Changes {C:entr_ascended}Effect{} based on",
						"the last used hand specific",
						"{C:planet}Planet{} or {C:purple}Star{} card"
					}
				}
			},
			["j_entr_planetarium_Three of a Kind"] = {
				name = "Planetarium: Venus",
				text = {
					{
						"If played {C:attention}Ranks{} add",
						"to a multiple of {C:attention}3{}",
						"scored cards give {X:mult,C:white}X#1#{} Mult"
					},
					{
						"Changes {C:entr_ascended}Effect{} based on",
						"the last used hand specific",
						"{C:planet}Planet{} or {C:purple}Star{} card"
					}
				}
			},
			["j_entr_planetarium_Flush"] = {
				name = "Planetarium: Jupiter",
				text = {
					{
						"Before hand is played convert",
						"the {C:attention}suit{} of two other random",
						"selected cards into the {C:attention}suit{}",
						"of the leftmost selected card"
					},
					{
						"Changes {C:entr_ascended}Effect{} based on",
						"the last used hand specific",
						"{C:planet}Planet{} or {C:purple}Star{} card"
					}
				}
			},
			["j_entr_planetarium_Straight"] = {
				name = "Planetarium: Saturn",
				text = {
					{
						"Earn {C:money}$#1#{} for each",
						"{C:attention}unique{} rank in played hand"
					},
					{
						"Changes {C:entr_ascended}Effect{} based on",
						"the last used hand specific",
						"{C:planet}Planet{} or {C:purple}Star{} card"
					}
				}
			},
			["j_entr_planetarium_Full House"] = {
				name = "Planetarium: Terra",
				text = {
					{
						"Lowest {C:attention}rank{} in played hand",
						"earns {C:money}$#1#{} when scored",
						"Highest {C:attention}rank{} in played hand",
						"gives {X:mult,C:white}X#2#{} Mult"
					},
					{
						"Changes {C:entr_ascended}Effect{} based on",
						"the last used hand specific",
						"{C:planet}Planet{} or {C:purple}Star{} card"
					}
				}
			},
			["j_entr_planetarium_Straight Flush"] = {
				name = "Planetarium: Neptune",
				text = {
					{
						"{C:red}-1{} Level to",
						"poker hands played",
						"during the Boss Blind"
					},
					{
						"Hands require{C:attention}1{}",
						"less card to form for every",
						"{C:attention}3{} levels they have"
					},
					{
						"Changes {C:entr_ascended}Effect{} based on",
						"the last used hand specific",
						"{C:planet}Planet{} or {C:purple}Star{} card"
					}
				}
			},
			["j_entr_planetarium_Four of a Kind"] = {
				name = "Planetarium: Mars",
				text = {
					{
						"Gain {C:red}+#1#{} Discard#<s>1#",
						"when a hand is played"
					},
					{
						"Changes {C:entr_ascended}Effect{} based on",
						"the last used hand specific",
						"{C:planet}Planet{} or {C:purple}Star{} card"
					}
				}
			},
			["j_entr_planetarium_Five of a Kind"] = {
				name = "Planetarium: Planet X",
				text = {
					{
						"If exactly {C:attention}5{} cards",
						"are played all {C:attention}scored{} cards",
						"gain a random {C:attention}Modification{} and",
						"ranomize suits"
					},
					{
						"Changes {C:entr_ascended}Effect{} based on",
						"the last used hand specific",
						"{C:planet}Planet{} or {C:purple}Star{} card"
					}
				}
			},
			["j_entr_planetarium_Flush House"] = {
				name = "Planetarium: Ceres",
				text = {
					{
						"This Joker gains {X:mult,C:white}X#1#{}",
						"Mult for every {C:attention}Pair{} in",
						"the winning hand and loses {X:mult,C:white}X#2#{}",
						"Mult for every {C:attention}Suit{} in",
						"the winning hand",
						"{C:inactive}(Currently {X:mult,C:white}X#3#{C:inactive} Mult)"
					},
					{
						"Changes {C:entr_ascended}Effect{} based on",
						"the last used hand specific",
						"{C:planet}Planet{} or {C:purple}Star{} card"
					}
				}
			},
			["j_entr_planetarium_Flush Five"] = {
				name = "Planetarium: Eris",
				text = {
					{
						"Copy the {C:attention}first{} scored card",
						"each round then add it to",
						"your {C:attention}played hand{}"
					},
					{
						"Changes {C:entr_ascended}Effect{} based on",
						"the last used hand specific",
						"{C:planet}Planet{} or {C:purple}Star{} card"
					}
				}
			},
			["j_entr_planetarium_entr_derivative"] = {
				name = "Planetarium: Interloper",
				text = {
					{
						"Strip the {C:attention}rank{} and {C:attention}suit{}",
						"of {C:attention}leftmost{} card held in hand",
						"at the end of round"
					},
					{
						"Retrigger all {C:attention}suitless{}",
						"cards held in hand or",
						"played"
					},
					{
						"Changes {C:entr_ascended}Effect{} based on",
						"the last used hand specific",
						"{C:planet}Planet{} or {C:purple}Star{} card"
					}
				}
			},
			j_entr_double_down = {
				name = "Double Down",
				text = {
					"Apply {C:attention}Marked{} to",
					"scored {C:attention}Lucky{} cards"
				}
			},
			j_entr_wormwood = {
				name = "Wormwood",
				text = {
					{
						"Playing cards permanently lose",
						"{C:red}#1#{} Mult when scored",
					},
					{
						"Scored cards give {C:gold}+#2#{}",
						"Acension Power for each",
						"{C:blue}chip{} they have"
					}
				}
			},

			--void jokers
			j_entr_apoptosis = {
				name = "Apoptosis",
				text = {
					{
						"Held in hand cards {C:attion}score{}",
						"as if they were {C:entr_void}played{}"
					},
					{
						"Unenhanced cards held in hand",
						"give {C:gold}+#1#{} Ascension Power"
					},
					{
						"{s:0} "
					},
				}
			},
			j_entr_egocentrism = {
				name = "Egocentrism",
				text = {
					{
						"{C:entr_void}Forcetrigger{} the rightmost",
						"Joker. Debuff the {C:attention}first{}",
						"and {C:attention}last{} played cards"
					},
					{
						"{s:0} "
					},
				}
			},
			j_entr_generator_meltdown = {
				name = "Generator Meltdown",
				text = {
					{
						"When a Poker Hand is leveled Up",
						"Swap {C:entr_void}25%{} of its {C:blue}Chips",
						"with {C:entr_void}25%{} of its {C:red}Mult"
					},
					{
						"{s:0} "
					},
				}
			},
			j_entr_voidheart = {
				name = "Voidheart",
				text = {
					{
						"Replace all blinds",
						"in ante with a singular",
						"{C:entr_void}Abyss{} blind"
					},
					{
						"{s:0} "
					},
				}
			},
			j_entr_unstable_rift = {
				name = "Unstable Rift",
				text = {
					{
						" "
					},
					{
						"When {C:red}Mult{} or {C:blue}Chips{}",
						"are changed add {C:entr_void}20%{} of",
						"the change to this Jokers",
						"{C:red}Mult{} and {C:blue}Chips{}"
					},
					{
						"On last hand of round",
						"score using this Joker's",
						"{C:mult}Mult{} and {C:blue}Chips{} instead",
						"then {C:red}reset{}"
					},
					{
						"{s:0} "
					},
				}
			},
			j_entr_pluripotent_larvae = {
				name = "Pluripotent Larvae",
				text = {
					{
						"Sell this Joker to {C:entr_void}Invert{}",
						"all {C:entr_void}Invertable{} Jokers and",
						"then fill empty Joker slots",
						"with {C:entr_void}Inverted{} Jokers"
					},
					{
						"{s:0} "
					},
				}
			},
			j_entr_desiderium = {
				name = "Desiderium",
				text = {
					{
						"Gain {C:entr_void}+#1#{} Joker Slot",
						"if all {C:blue}Hands{} and {C:red}Discards{}",
						"are used in an ante",
						"{C:inactive}(Currently #2#)"
					},
					{
						"{s:0} "
					}
				}
			},
			j_entr_nadir = {
				name = "Nadir",
				text = {
					{
						"Use this Joker to {C:entr_void}store{}",
						"and destroy all other Jokers"
					},
					{
						"When another Joker triggers",
						"{C:entr_void}forcetrigger{} a random stored Joker"
					},
					{
						"{s:0} "
					}
				}
			},
			j_entr_yaldabaoth = {
				name = "Yaldabaoth",
				text = {
					{
						"Apply {C:entr_void}Marked for Death{}",
						"to one {C:attetntion}random{} card per Booster Pack",
					},
					{
						"When a card {C:entr_void}Marked for Death{}",
						"is destroyed gain {C:gold}+#1#{} Ascension Power",
						"{C:inactive}(Currently {C:gold}+#2# {C:inactive}Ascension Power)"
					},
					{
						"{s:0} "
					},
				}
			},
			j_entr_mutagenesis = {
				name = "Mutagenesis",
				text = {
					{
						"Effects from {C:attention}Playing Cards{}",
						"are added to this Joker",
					},
					{
						"{s:0} "
					},
				}
			},
			j_entr_crooked_penny = {
				name = "Crooked Penny",
				text = {
					{
						"Multiplies payout by {X:money,C:white}X#1#{}",
						"for every {C:blue}Hand{} played this round",
						"{C:inactive}(Extra copies stack additively)"
					},
					{
						"Set money to {C:entr_void}$0{}",
						"when leaving the shop"
					},
					{
						"{s:0} "
					},
				}
			},
			j_entr_phoenix_a = {
				name = "Phoenix A*",
				text = {
					{
						"This Joker is played as the {C:entr_void}last{}",
						"card of hand and destroys every",
						"{C:entr_void}consecutive{} card with the same rank",
						"starting from the end before scoring"
					},
					{
						"This Joker gains {X:mult,C:white}X#1#{} Mult",
						"and {X:blue,C:white}X#2#{} Chips whenever",
						"a card is destroyed by it",
						"{C:inactive}(Currently {X:mult,C:white}X#3#{C:inactive} {X:blue,C:white}X#4#{C:inactive})"
					},
					{
						"{s:0} "
					},
				}
			},
			j_entr_antimatter_sheath = {
				name = "Antimatter Sheath",
				text = {
					{
						"When round begins add {C:attention}#1#{}",
						"temporary copie#<s>1# of",
						"{C:attention}The Dagger{} to your hand"
					},
					{
						"When {C:attention}The Dagger{} is",
						"scored destroy a {C:attention}random{}",
						"card in full deck and gain",
						"{X:mult,C:white}X#2#{} Mult and {X:chips,C:white}X#3#{} Chips",
						"{C:inactive}(Currently {X:mult,C:white}X#4#{C:inactive}, {X:chips,C:white}X#5#{C:inactive})"
					},
					{
						"{s:0} "
					},
				}
			},
			j_entr_caledscratch = {
				name = "Caledscratch",
				text = {
					{
						"Playing card retriggers are",
						"blocked and stored. Retrigger",
						"leftmost {C:attention}Joker{} once for",
						"every {C:entr_void}stored{} retrigger",
						"then reset"
					},
					{
						"{s:0} "
					},
				}
			},
			j_entr_nyx = {
				name = "Nyx, Lord of Void",
				text = {
					{
						"When {C:attention}Blind{} is selected",
						"create {C:attention}1{} {C:dark_edition}Negative{} {C:attention}Temporary{} ",
						"{C:entr_void}Inverted{} Joker for every",
						"other non-Inverted Joker"
					},
					{
						"Use this Joker for {X:money,C:white}X#1#{} this",
						"Jokers cost and the highlighted",
						"cards cost to remove {C:entr_void}Temporary{}",
						"from all selected cards",
						"{C:inactive}(Currently {C:money}$#2#{C:inactive})"
					},
					{
						"{s:0} "
					}
				}
			},

			j_lusty_joker_gfb = {
				name = "Freaky Joker",
				text= {
					"Player Cards with",
					"{C:hearts}#2#{} suit give",
					"{X:entr_freaky,C:white}Xlog_#1#(Chips){} Chips when scored"
				}
			},
			j_space_joker_gfb = {
				name = "Space Joker",
				text = {
					"{C:green}#1# in #2#{} chance to add",
					"{C:dark_edition}Foil{}, {C:dark_edition}Holographic{}, or",
					"{C:dark_edition}Polychrome{} edition",
					"to a random Joker"
				}
			},
			j_hanging_chad_gfb = {
				name = "Hanging Chad",
				text = {
					{
						"Retrigger first scored",
						"or held in hand cards",
						"{C:attention}#1#{} additional times"
					},
					{
						"{C:red,E:1}hows that for a rework,",
						"{C:red,E:1}losers."
					}
				}
			},
			j_smiley_gfb = {
				name = "Sunny Face",
				text = {
					"Played {C:attention}face{} cards",
					"give {C:gold}+#1#{} Ascension Power",
					"when scored"
				}
			},
			j_blueprint_gfb = {
				name = "Crimsonprint",
				text = {
					{
						"Copies ability of",
						"{C:attention}Joker{} to the left"
					},
					{
						"{C:red,E:1}well never liked that{}",
						"{C:red,E:1}blue guy anyway{}",
					}
				}
			},
			j_brainstorm_gfb = {
				name = "Green Needle",
				text = {
					{
						"Copies the ability",
						"of rightmost {C:attention}Joker"
					},
					{
						"{C:red,E:1}Dont get too close..."
					}
				}
			},
			j_stone_gfb = {
				name = "Stone Joker",
				text = {
					"Replace all playing cards with",
					"{C:attention}Stone Cards{} at",
					"the end of the shop"
				}
			},
			j_golden_gfb = {
				name = "Midas Touch",
				text = {
					"All shop and booster pack",
					"items are {C:attention}Gold Cards{}"
				}
			},
			j_joker_gfb = {
				name = "Jorker",
				text = {
					"{C:mult}+#1#{} Mult, {C:mult}-#1#{} Mult",
					"{C:mult}+#1#{} Mult, {C:mult}-#1#{} Mult",
					"{C:mult}+#1#{} Mult, {C:mult}-#1#{} Mult",
					"{C:mult}+#1#{} Mult, {C:mult}-#1#{} Mult",
					"{C:mult}+#1#{} Mult, {C:mult}-#1#{} Mult",
					"{C:mult}+#1#{} Mult, {C:mult}-#1#{} Mult",
					"{C:mult}+#1#{} Mult, {C:mult}-#1#{} Mult",
					"{C:mult}+#1#{} Mult, {C:mult}-#1#{} Mult",
					"{C:mult}+#1#{} Mult, {C:mult}-#1#{} Mult",
					"{C:mult}+#1#{} Mult, {C:mult}-#1#{} Mult",
					"{C:mult}+#1#{} Mult",
				}
			},
			j_entr_searing_joke_gfb = {
				name = "Negative Pulse",
				text = {
					{
						"Use this Joker to reduce",
						"the rank of all cards",
						"held in hand by {C:attention}2{}",
						"{C:inactive}(2's and 3's get destroyed)"
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2#",
						"when defeating a Boss Blind",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
					}
				}
			},
			j_entr_gros_michel_2 = {
				name = "Gros Michel {s:1.5,C:red}2",
				text = {
					"{X:slib_emult,C:white}^#1#{} Mult",
                    "{C:green}#2# in #3#{} chance this",
                    "card is destroyed",
                    "at end of round",
				}
			},
			j_photograph_gfb = { name = "#2#" },
			j_banner_gfb = {
				name = "Banner",
				text = {
					{
						"{C:chips}+#1#{} Chips for",
						"each remaining",
						"{C:attention}discard",
					}, 
					{
						"When a card is sold",
						"banish it too"
					}
				}
			},
            j_chaos_gfb = {
                name = "Chaos the Clown",
                text = {
					"This Joker gains {C:chips}+#2#{} Chips",
					"per {C:attention}reroll{} in the shop",
					"{C:green}All rerolls are free{}",
					"{C:inactive}(Currently {C:chips}+#1#{C:inactive} chips)",
                },
            },
			j_seance_gfb = {
				name = "Séance",
				text={
                    "If {C:attention}poker hand{} is a",
                    "{C:attention}Zero Pair{}, create a",
                    "random {C:purple}Tarot{} card",
                    "{C:inactive}(Must have twice as much room)",
                },
			},
			j_diet_cola_gfb = {
				name = "Diet Cola",
				text = {
					"When a Joker is sold",
					"create the corresponding",
					"{C:entr_zenith}Rarity{} {C:attention}Tag{}"
				}
			},
			j_credit_card_gfb = {
				name = "Credit Card",
				text = {
					{
						"Go up to",
						"{C:red}-$#1#{} in debt",
					},
					{
						"If in {C:red}debt{}",
						"multiply money by {X:money,C:white}X1.25{}",
						"at the end of the shop"
					}
				}
			},
			j_certificate_gfb = {
				name = "Certificate",
				text = {
					{
						"When round begins,",
						"add a random {C:attention}Certificate{}",
						"with a random",
						"{C:attention}seal{} to your hand"
					},
				}
			},
			j_baron_gfb = {
				name = "Baron",
				text = {
					"Each {C:attention}King{}",
					"held in hand",
					"gives {X:blue,C:white}X#1#{} Chips"
				}
			},
			j_merry_andy_gfb = {
				name = "Mercury Andy",
				text = {
					"{C:blue}+#1#{} {C:attention}Mercuries{}",
					"each round,",
					"{C:red}#2#{} Hand Size"
				}
			},

			j_entr_midnight = {
				name = "Midnight",
				text = {
					"Scored {C:spades}Spades{} and",
					"{C:diamonds}Diamonds{} give",
					"{C:gold}+#1#{} Ascension Power"
				}
			},
			j_entr_quadrants = {
				name = "Quadrants",
				text = {
					"If scored hand has atleast {C:attention}2{} suits",
					"Scored {C:hearts}Hearts{} give {C:red}+#1#{} Mult",
					"Scored {C:diamonds}Diamonds{} give {C:gold}+$#2#{}",
					"Scored {C:spades}Spades{} give {C:blue}+#3#{} Chips",
					"Scored {C:clubs}Clubs{} give {C:gold}+#4#{} Ascension Power",
				}
			},
			j_entr_complexion = {
				name = "Complexion",
				text = {
					"Pairs, Three of a Kind and",
					"Four of a Kind may become",
					"flush for {C:purple}2X{}, {C:purple}3X{} or {C:purple}4X{}",
					"base stats respectively."
				}
			},
			j_entr_hidden_gem = {
				name = "Hidden Gem",
				text = {
					"When Blind is selected",
					"add {C:attention}#1#{} temporary",
					"retrigger#<s>1# to a random Joker",
				}
			},
			j_entr_bloodletting = {
				name = "Bloodletting",
				text = {
					{
						"This Joker loses {C:red}#2#{} Mult",
						"when a blind is selected",
						"{C:inactive}(Currently {C:red}#1#{C:inactive} Mult)"
					},
					{
						"After reaching {C:red}#3#{} Mult",
						"transform into a random {C:red}Rare{} Joker",
						"with the same amount of",
						"negative mult"
					}
				}
			},
			j_entr_paranoia = {
				name = "Paranoia",
				text = {
					"When blind is selected",
					"create {C:attention}#1#{} {C:entr_void}Temporary{}",
					"Jokers",
					"{C:inactive}(May Overflow)"
				}
			},
			j_entr_antiasceticism = {
				name = "Anti-Asceticism",
				text = {
					"The first time you go",
					"below {C:money}$#2#{} each ante",
					"earn {C:money}$#1#{}"
				}
			},
			j_entr_record_disc = {
				name = "Record Disc",
				text = {
					"Prevents changes in Ante",
					"Breaks after spending or",
					"gaining money {C:attention}5{} {C:inactive}(#1#){} Times"
				}
			},
			j_entr_broken_record_disc = {
				name = "Record Disc?",
				text = {
					"When sold lose {C:red}$#1#{}"
				}
			},

			j_entr_exhume = {
				name = "Exhume",
				text = {
					{
						"Discard your entire hand",
						"after a hand is played"
					},
					{
						"{C:green}#1# in #2#{} chance for",
						"played cards to return to hand",
						"after a hand is played"
					}
				}
			},
			j_entr_projesterone = {
				name = "Projesterone",
				text = {
					{
						"Add {C:gold}#2#{} Ascension Power",
						"to the next scored card then",
						"reset this value"
					},
					{
						"Scored {C:attention}Queens{} instead",
						"increase this value by {C:gold}+#1#{}"
					}
				}
			},
			j_entr_catastrophe = {
				name = "Catastrophe",
				text = {
					"When {C:attention}Blind{} is selected",
					"destroy a random Joker and create",
					"a {C:dark_edition}Negative{} {C:purple}Star{} or {C:planet}Planet{} card"
				}
			},
			j_entr_lycanthropy = {
				name = "Lycanthropy",
				text = {
					"Scored {C:attention}Mult{} cards",
					"give {X:mult,C:white}X#1#{} Mult"
				}
			},

			j_entr_hellfire = {
				name = "HELLFIRE",
				text = {
					"One {C:red}half{} of all cards",
					"held in hand and scored",
					"are {C:red}Debuffed{}."
				}
			},
			j_entr_rot = {
				name = "ROT",
				text = {
					"Your rightmost Joker",
					"is {C:red}Debuffed{}."
				}
			},
			j_entr_famine = {
				name = "FAMINE",
				text = {
					"{C:blue}Hands{} are set to 1",
					"{C:red}Discards{} are set to 0"
				}
			},
			j_entr_hypnotism = {
				name = "Hypnotism",
				text = {
					"All non-useable Jokers",
					"can be used to {C:purple}Forcetrigger{}",
					"and then {C:red}self-destruct{}"
				}
			},
			j_entr_hypnotism_gfb = {
				name = "Hypnotism",
				text = {
					"{B:entr_freaky,C:white,s:0.8}[Content removed due to Mod Moderation]"
				}
			},
			j_entr_demon_form = {
				name = "Demon Form",
				text = {
					"The first played {C:attention}Enhanced{}",
					"card each round gains",
					"{C:gold}+#1#{} Ascension Power",
					"while held"
				}
			},
			j_entr_broken_god = {
				name = "Mekhane, The Broken God",
				text = {
					{
						"When blind is selected",
						"add a {C:attention}copy{} of this",
						"Joker to your {C:attention}Hand{}"
					},
					{
						"Gives {X:mult,C:white}X#1#{} Mult",
						"if scored as part",
						"of a hand"
					},
					{
						"This card always scores"
					}
				}
			},
			j_entr_rivulet = {
				name = "Rivulet",
				text = {
					{
						"{element:1}",
						"Increase {C:attention}Karma{} by 1 when",
						"hitting the {C:attention}Interest Cap{}",
						"Decrease {C:attention}Karma{} by 1 after",
						"rerolling {C:attention}3{} times in a shop",
						"{C:inactive}(Currently #2#/#3# {C:attention}Karma{C:inactive})"
					},
					{
						"Cards held in hand give",
						"{X:blue,C:white}X#4#{} Chips for each level",
						"of {C:attention}Karma{} above {C:attention}1",
						"{C:inactive}(Currently, {X:blue,C:white}X#1#{C:inactive} Chips)"
					}
				}
			},
			j_entr_fragment = {
				name = "Fragmentation",
				text = {
					"When a non-editioned card is",
					"{C:red}destroyed{} create a {C:dark_edition}Foil",
					"and a {C:dark_edition}Holographic{} copy"
				}
			},
			j_entr_bountiful_harvest = {
				name = "The harvest is bountiful this year",
				text = {
					"All other Jokers gain",
					'"{C:green}#1# in #2#{} Chance to',
					'create a random tag',
					'when a {C:attention}Joker{} is sold"'
				}
			},
			j_entr_plushy = {
				name = "Plushy",
				text = {
					"Earn {C:gold}$#1#{} when",
					"a playing card is modified"
				}
			},
			j_entr_survivorship_bias = {
				name = "Survivorship Bias",
				text = {
					{
						"When a Joker is {C:attention}sold{} this",
						"Joker gains {C:chips}+#2#{} Chips",
						"{C:inactive}(Currently {C:chips}+#1#{C:inactive} Chips)"
					},
					{
						"When a Joker is destroyed",
						"it is {C:red}Banished{}"
					}
				}
			},
			j_entr_rotisserie_chicken = {
				name = "Rotisserie Chicken",
				text = {
					"Joker to the right has {X:attention,C:white}X#1#{} values",
					"{s:0.8}recalculates when this Joker is moved"
				}
			},
			j_entr_immanentize = {
				name = "Immanentize",
				text = {
					"The next {C:attention}#1#{} opened",
					"{C:attention}Boosters{} will contain",
					"cards of random types"
				}
			},
			j_entr_big_walk = {
				name = "Big Walk",
				text = {
					"Retrigger the {C:attention}first{}",
					"and {C:attention}last{} scored cards"
				}
			},
			j_entr_infinite_loop = {
				name = "Infinite Loop",
				text = {
					"{C:red}+#1#{} Mult",
					"when another card is",
					"retriggered, retrigger",
					"this card."
				}
			},
			j_entr_prototype = {
				name = "Prototype",
				text = {
					"Copy the ability of",
					"the {C:attention}first{} triggered",
					"Joker each round",
					"until a Blind is selected"
				}
			},
			j_entr_slime_joker = {
				name = "Slime Joker",
				text = {
					"Cards held in hand gain",
					"{C:blue}+#1#{} held in hand chips",
					"Cards discarded lose {C:blue}#1#{}",
					"held in hand chips"
				}
			},
			j_entr_bag_of_chips = {
				name = "Bag of Chips",
				text = {
					"Refund the next {C:attention}#1#",
					"purchased card#<s>1#"
				}
			},
			j_entr_cider = {
				name = "Cider",
				text = {
					"{X:mult,C:white}X#1#{} Mult",
					"decreases by {X:mult,C:white}X#2#{} after a hand",
					"is played, increases by {X:mult,C:white}X#3#{} for",
					"every played enhanced card",
					"{C:inactive}(Maximum of {X:mult,C:white}X4{C:inactive})"
				}
			},
			j_entr_photonegative = {
				name = "Photonegative",
				text = {
					{
                    	"Use this Joker to use",
						"enter/exit the {C:purple}Flipside{}",
						"and {C:attention}reroll{} all Blinds"
					},
					{
						"This Joker gains {C:attention}#2#{} use#<s>2# for",
						"every {C:attention}#3#{} {C:inactive}[#4#]{} card#<s>3# discarded",
						"{C:inactive}(Currently {C:attention}#1#{C:inactive} use#<s>1#)"
					}
				}
			},
			j_entr_snakebite = {
				name = "Snakebite",
				text = {
					"If exactly {C:attention}1{} card is",
					"discarded, decrease Blind",
					"Size by {C:attention}#1#%{}"
				}
			}
		},
		Blind = {
			bl_entr_red = {
				name = "Red Room",
				text = {
					"???"
				}
			},
			bl_entr_abyss = {
				name = "The Abyss",
				text = {
					"Gains effects and increases",
					"requirement when beaten",
					"Ante increases upon loss when",
					"losing twice in a row lose the run",
				}
			},
			bl_entr_void = {
				name = "???",
				text = {
					"???"
				}
			},
			bl_entr_scarlet_sun = {
				name = "Scarlet Sun",
				text = {
					"-0.25 Ascension Power after",
					"scoring per Joker triggered",
					"this blind"
				}
			},
			bl_entr_burgundy_baracuda = {
				name = "Burgundy Barracuda",
				text = {
					"1 in 2 played",
					"cards are destroyed"
				}
			},
			bl_entr_diamond_dawn = {
				name = "Diamond Dawn",
				text = {
					"Remove the rank and suit",
					"of all discarded cards"
				}
			},
			bl_entr_olive_orchard = {
				name = "Olive Orchard",
				text = {
					"Cards in hand become Disavowed",
					"when playing or discarding"
				}
			},
			bl_entr_citrine_comet = {
				name = "Citrine Comet",
				text = {
					"Selected cards destroy",
					"adjacent cards with a",
					"1 in 2 chance"
				}
			},
			bl_entr_entropic_cultist = {
				name = "Entropic Cultist",
				text = {
					"Copies 3 random Showdowns",
					"Go directly to ante 32",
					"when defeated"
				}
			},
			bl_entr_brimstone = {
				name = "Burning Brimstone",
				text = {
					"???",
				}
			},
			bl_entr_ekklisia = {
				name = "Ekklisia",
				text = {
					"Copies Verdant Leaf,",
					"Callous Chorus, and",
					"Alabaster Anchor"
				}
			},
			bl_entr_puppet = {
				name = "Piercing Puppet",
				text = {
					"Must play #1#, #2#",
					"and #3# before score",
					"can change",
				}
			},
			bl_entr_erebus = {
				name = "Erevos",
				text = {
					"Copies Amber Acorn,",
					"Sorrowful Styx, and",
					"Diamond Dawn"
				}
			},
			bl_entr_decay = {
				name = "Deceitful Decay",
				text = {
					"Temporarily remove all",
					"Jokers and hand levels"
				}
			},
			bl_entr_extinction = {
				name = "Exaleipsi",
				text = {
					"Copies Cerulean Bell,",
					"Limitless Labyrinth, and",
					"Citrine Comet"
				}
			},
			bl_entr_nadir = {
				name = "Nameless Nadir",
				text = {
					"You must lose this blind."
				}
			},
			bl_entr_euphoria = {
				name = "Efforia",
				text = {
					"Copies Violet Vessel,",
					"Pristine Pandora and",
					"Olive Orchard"
				}
			},
			bl_entr_fracture = {
				name = "Fervent Fracture",
				text = {
					"Choose 1 of 3 Debuffs",
					"to apply for the rest",
					"of the Ante."
				}
			},
			bl_entr_feast = {
				name = "Eorti",
				text= {
					"Copies Crimson Heart,",
					"Condemned Cassandra and",
					"Burgundy Baracuda"
				}
			},
			bl_entr_cleave = {
				name = "Calamitous Cleaver",
				text= {
					"Destroy all Played and",
					"discarded Cards"
				}
			},
			bl_entr_endless = {
				name = "Endless Entropy",
				text= {
					"???"
				}
			},

			bl_entr_alabaster_anchor = {
				name = "Alabaster Anchor",
				text = {
					"Playing hands, discarding, and",
					"selecting/unselecting playing cards",
					"temporarily decreases Joker",
					"values by 5%"
				}
			},
			--alt blinds
			bl_entr_alpha = {
				name = "Alpha",
				text = {
					"First scored card each",
					"hand is destroyed"
				}
			},
			bl_entr_beta = {
				name = "Beta",
				text = {
					"-1 hand size",
					"-1 more hand size",
					"per hand played"
				}
			},
			bl_entr_gamma = {
				name = "Gamma",
				text = {
					"Divide base Mult",
					"based on the number",
					"of unplayed suits"
				}
			},
			bl_entr_delta = {
				name = "Delta",
				text = {
					"Divide final Mult based",
					"on the number of played",
					"hands in this Blind"
				}
			},
			bl_entr_epsilon = {
				name = "Epsilon",
				text = {
					"Divide final Mult",
					"based on the number",
					"of played cards"
				}
			},
			bl_entr_zeta = {
				name = "Zeta",
				text = {
					"Hand must not contain",
					"3 or 5 cards"
				}
			},
			bl_entr_eta = {
				name = "Eta",
				text = {
					"#1# cards are debuffed",
					"Changes when hand played"
				}
			},
			bl_entr_theta = {
				name = "Theta",
				text = {
					"Mult operations now",
					"affect Chips instead"
				}
			},
			bl_entr_iota = {
				name = "Iota",
				text = {
					"Applies the effects",
					"of #1#",
					"Changes every hand played"
				}
			},
			bl_entr_kappa = {
				name = "Kappa",
				text = {
					"Scoring cards dont score",
					"Unscored cards score instead"
				}
			},
			bl_entr_lambda = {
				name = "Lambda",
				text = {
					"Scored cards become",
					"debuffed for 5 rounds"
				}
			},
			bl_entr_mu = {
				name = "Mu",
				text = {
					"Sum of selected ranks",
					"must not exceed 30"
				}
			},
			bl_entr_nu = {
				name = "Nu",
				text = {
					"0.8x Interest per",
					"card trigger"
				}
			},
			bl_entr_xi = {
				name = "Xi",
				text = {
					"First discarded hand",
					"becomes Eternal"
				}
			},
			bl_entr_omicron = {
				name = "Omicron",
				text = {
					"First played hand",
					"gives no Score"
				}
			},
			bl_entr_pi = {
				name = "Pi",
				text = {
					"Discarded cards",
					"return to deck"
				}
			},
			bl_entr_rho = {
				name = "Rho",
				text = {
					"Divide final Mult",
					"based on the",
					"number of played ranks"
				}
			},
			bl_entr_sigma = {
				name = "Sigma",
				text = {
					"Hands and discards",
					"are now a shared",
					"resource"
				}
			},
			bl_entr_tau = {
				name = "Tau",
				text = {
					"+1 selection limit",
					"-1 selection limit",
					"when discarding"
				}
			},
			bl_entr_upsilon = {
				name = "Upsilon",
				text = {
					"Scored cards give",
					"-0.25 Ascension Power"
				}
			},
			bl_entr_phi = {
				name = "Phi",
				text = {
					"Ranks that arent",
					"Ace, 3, 6, 8, or 9",
					"are debuffed"
				}
			},
			bl_entr_chi = {
				name = "Chi",
				text = {
					"The first scored",
					"card of each",
					"rank is debuffed"
				}
			},
			bl_entr_psi = {
				name = "Psi",
				text = {
					"#1# in 2 chance for",
					"scored cards to become",
					"Disavowed"
				}
			},
			bl_entr_omega = {
				name = "Omega",
				text = {
					"Playing a #1#",
					"multiplies score",
					"requirements by 2x"
				}
			},

			bl_entr_styx = {
				name = "Sorrowful Styx",
				text = {
					"Jokers and playing cards",
					"cannot be rearranged",
					"Move 1 Joker and playing card",
					"before hand is scored"
				}
			},
			bl_entr_choir = {
				name = "Callous Chorus",
				text = {
					"Triggered Jokers are",
					"debuffed for this round"
				}
			},
			bl_entr_pandora = {
				name = "Pristine Pandora",
				text = {
					"#1# in 3 chance to",
					"instead draw a random",
					"Temporary card",
					"when a card is drawn",
				}
			},
			bl_entr_cassandra = {
				name = "Condemned Cassandra",
				text = {
					"Discarded cards return",
					"to the deck, #1# in 5",
					"Jokers are debuffed",
					"before scoring"
				}
			},
			bl_entr_labyrinth = {
				name = "Limitless Labyrinth",
				text = {
					"+3 hand size, +1 selection limit",
					"Cards cannot be deselected",
					"Select a random card when a",
					"card is selected"
				}
			},

			bl_entr_small = {
				name = "Small Blind",
				text = {
					
				}
			},
			bl_entr_big = {
				name = "Big Blind",
				text = {
					
				}
			},

			bl_entr_paw = {
				name = "The Paw",
				text = {
					"All non Freaky Edition",
					"cards are debuffed"
				}
			}
		},
		Edition = {
			e_entr_solar = {
				name = "Solar",
				text = {
					"{X:gold,C:white}X#1#{} Ascension Power",
				},
			},
			e_entr_fractured = {
				name = "Fractured",
				text = {
					"{C:dark_edition}Force-trigger{} #1# random cards",
					"when scored"
				},
			},
			e_entr_sunny = {
				name = "Sunny",
				text = {
					"{C:gold}+#1#{} Ascension Power",
					"Ever heard of {X:gold,C:white}ascendant{}",
					"humor buddy?"
				}
			},
			e_entr_freaky = {
				name = "Freaky",
				text = {
					"{X:entr_freaky,C:white}Xlog_#1#(Chips){} Chips"
				},
			},
			e_entr_neon = {
				name = "Neon",
				text = {
					"Passively provides",
					"{C:attention}X#1#{} shop costs"
				},
			},
			e_entr_neon_gfb = {
				name = "Neon",
				text = {
					"Passively provides",
					"{C:attention}+1{} shop slot"
				},
			},
			e_entr_lowres = {
				name = "Low-Res",
				text = {
					"{C:attention}Retrigger{} this card {C:attention}#1#{} times",
					"{C:attention}X#2#{} card values {C:inactive}(If possible){}"
				},
			},
			e_entr_kaleidoscopic = {
				name = "Kaleidoscopic",
				text = {
					"Retrigger {C:attention}#1#{} random",
					"cards in this cards area"
				},
			},
			e_entr_gilded  = {
				name = "Gilded",
				text = {
					"{C:attention}Retrigger{} this card"
				},
			},
			e_entr_gilded_consumable = {
				name = "Gilded",
				text = {
					"Triggered {C:attention}twice{}",
					"when used"
				},
			},
		},
		Back = {
			b_entr_twisted = {
				name = "Twisted Deck",
				text =  {
								"All {C:red}Invertable{} consumables",
								"are automatically {C:red}Inverted{}",
							}
			},
			b_entr_ccd2 = {
				name = "Redefined Deck",
				text =  {
								"Every card is also a random",
								"{C:attention}Joker{}, {C:attention}Booster Pack{},",
								"{C:attention}Voucher{}, or {C:attention}consumable{}"
							}
			},
			b_entr_doc = {
				name = "Deck of Containment",
				text = {
					"Gain {X:dark_edition,C:white}Entropy{} when playing",
					"Editioned/Enhanced cards, secret hands or",
					"using consumables, {C:entr_entropic}Beyond{}, {C:cry_exotic}Gateway{}",
					"and {C:spectral}Spectral Packs{} show up more often",
					"Chips are lowered based on {X:dark_edition,C:white}Entropy{}"
				}
			},
			b_entr_doc_cryptidless = {
				name = "Deck of Containment",
				text = {
					"Gain {X:dark_edition,C:white}Entropy{} when playing",
					"Editioned/Enhanced cards, secret hands or",
					"using consumables, {C:entr_entropic}Fervour?{}, {C:cry_exotic}Soul{}",
					"and {C:spectral}Spectral Packs{} show up more often",
					"Chips are lowered based on {X:dark_edition,C:white}Entropy{}"
				}
			},
			b_entr_crafting = {
				name = "Deck of Destiny",
				text =  {
					"Jokers may no longer appear naturally",
					"Start with an {C:dark_edition}Aleph, Negative{} {T:c_entr_destiny}Destiny{}",
					"Cards have a higher chance to be Enhanced",
					"Start with {C:attention,T:v_magic_trick}Magic Trick{} amd {C:attention,T:v_illusion}Illusion{}"
				}
			},
			b_entr_butterfly = {
				name = "Butterfly Deck",
				text =  {
					"{C:attention}-2{} Joker slots",
					"Sold Jokers have a {C:green}1 in 2{}",
					"chance to still trigger"
				}
			},
			b_entr_ambisinister = {
				name = "Ambisinister Deck",
				text =  {
					"{C:attention}Joker slots{} and",
					"{C:dark_edition}card selection limit{}",
					"are now a shared resource",
					"{C:attention}+3{} Joker slots"
				}
			},
			b_entr_gemstone = {
				name = "Gemstone Deck",
				text =  {
					"Non-Rune consumables have a {C:green}#1# in #2#{}",
					"chance to {C:red}fail{}, create a",
					"random {C:purple}Rune card{} every",
					"{C:attention}2{} non-Rune consumables used"
				}
			},
			b_entr_corrupted = {
				name = "Corrupted Deck",
				text =  {
					"{C:attention}Jokers{} and {C:attention}consumables{}",
					"cycle between {C:attention}3{} options",
					"{C:red}-1{} shop slot"
				}
			},
			b_entr_discordant = {
				name = "Malformed Deck",
				text =  {
					"Created {C:attention}cards{}, {C:attention}Vouchers{}",
					"and {C:attention}Booster Packs{} are replaced",
					"by a random card type",
					"Rerolls scale {C:red}twice{} as fast"
				}
			},
		},
		Sleeve = {
			sleeve_entr_twisted = {
				name = "Twisted Sleeve",
				text = {
					"All {C:red}Invertable{} consumables",
					"are automatically {C:red}Inverted{}",
				},
			},
			sleeve_entr_ccd2 = {
				name = "Redefined Sleeve",
				text = {
					"Every card is also a random",
					"{C:attention}Joker{}, {C:attention}Booster Pack{},",
					"{C:attention}Voucher{}, or {C:attention}consumable{}"
				},
			},
			sleeve_entr_doc = {
				name = "Anomalous Sleeve",
				text = {
					"Gain {X:dark_edition,C:white}Entropy{} when playing",
					"Editioned/Enhanced cards, secret hands or",
					"using consumables, {C:entr_entropic}Beyond{}, {C:cry_exotic}Gateway{}",
					"and {C:spectral}Spectral Packs{} show up more often",
					"Chips are lowered based on {X:dark_edition,C:white}Entropy{}"
				}
			},
			sleeve_entr_doc_cryptidless = {
				name = "Anomalous Sleeve",
				text = {
					"Gain {X:dark_edition,C:white}Entropy{} when playing",
					"Editioned/Enhanced cards, secret hands or",
					"using consumables, {C:entr_entropic}Fervour?{}, {C:cry_exotic}Soul{}",
					"and {C:spectral}Spectral Packs{} show up more often",
					"Chips are lowered based on {X:dark_edition,C:white}Entropy{}"
				}
			},
			sleeve_entr_ambisinister = {
				name = "Ambisinister Sleeve",
				text = {
					"{C:attention}Joker slots{} and",
					"{C:dark_edition}card selection limit{}",
					"are now a shared resource",
					"{C:attention}+3{} Joker slots"
				},
			},
			sleeve_entr_crafting = {
				name = "Sleeve of Fate",
				text =  {
					"Jokers may no longer appear naturally",
					"Start with an {C:dark_edition}Aleph, Negative{} {T:c_entr_destiny}Destiny{}",
					"Cards have a higher chance to be Enhanced",
					"Start with {C:attention,T:v_magic_trick}Magic Trick{} amd {C:attention,T:v_illusion}Illusion{}"
				}
			},
			sleeve_entr_butterfly = {
				name = "Butterfly Sleeve",
				text =  {
					"{C:attention}-2{} Joker slots",
					"Sold Jokers have a {C:green}1 in 2{}",
					"chance to still trigger"
				}
			},
			sleeve_entr_gemstone  = {
				name = "Gemstone Sleeve",
				text = {
					"Non-Rune consumables have a {C:green}#1# in #2#{}",
					"chance to {C:red}fail{}, create a",
					"random {C:purple}Rune card{} every",
					"{C:attention}2{} non-Rune consumables used"
				},
			},
			sleeve_entr_corrupted = {
				name = "Corrupted Sleeve",
				text =  {
					"{C:attention}Jokers{} and {C:attention}consumables{}",
					"cycle between {C:attention}2{} options",
					"{C:red}-1{} shop slot"
				}
			},
		},
		Fraud = {
			c_entr_master = {
				name = "The Master",
				text = {
					"Creates the last",
					"{C:red}Inverted{} card",
					"used during this run",
					"{s:0.8,C:red}The Master{} {s:0.8}excluded{}"
				}
			},
			c_entr_statue = {
				name = "The Statue",
				text = {
					"Convert {C:attention}#1#{} random card#<s>1#",
					"in full deck to {C:attention}#2#{}",
					"selected card#<s>2# then transform the",
					"selected card#<s>2# into a blank {C:attention}Stone Card{}"
				}
			},
			c_entr_whetstone = {
				name = "Whetstone",
				text = {
					"{C:green}#1# in #2#{} chance to",
					"randomly {C:attention}upgrade{} the Enhancement",
					"of up to #3# selected card#<s>3#"
				}
			},
			c_entr_feast = {
				name = "The Feast",
				text = {
					"{C:attention}Sell{} and {C:attention}destroy{}",
					"#<up to >1##1# selected Card#<s>1#",
					"Voucher#<s>1#, or Booster Pack#<s>1#",
					"from the {C:attention}shop{}",
					"for {X:attention,C:white}X#2#{} their buy cost"
				}
			},
			c_entr_servant = {
				name = "The Servant",
				text = {
					"Create {C:attention}#1#{} random Consumable#<s>1# of the",
					"{C:red}Inverted{} type of #<up to >2#{C:attention}#2#{} selected consumables#<s>2#",
					"{C:inactive}(Must have room){}"
				}
			},
			c_entr_endurance = {
				name = "Endurance",
				text = {
					"Multiply #1# selected card#<s>1#",
					"values by {X:attention,C:white}X#2#{} then",
					"debuff it for {C:attention}#3#{} rounds"
				}
			},
			c_entr_scar = {
				name = "The Scar",
				text = {
					"Apply a {C:dark_edition}Scarred{} sticker",
					"to up to {C:attention}#1#{} selected card#<s>1#"
				}
			},
			c_entr_dagger = {
				name = "The Dagger",
				text = {
					"Destroy {C:attention}#1#{} selected playing card#<s>1#",
					"and add {X:dark_edition,C:white}X#2#{}",
					"the selected card#<s>1# Chips",
					"to your {C:attention}most played{} hand's Chips"
				}
			},
			c_entr_penumbra = {
				name = "Penumbra",
				text = {
					"Banish the Enhancement of {C:attention}#1#{}",
					"selected card#<s>1#, then",
					"{C:attention}destroy{} the selected card#<s>1#"
				}
			},
			c_entr_integrity = {
				name = "Integrity",
				text = {
					"Remove the {C:attention}Enhancement#<s>1#{} of",
					"{C:attention}#1#{} selected card#<s>1# then",
					"add a random {C:dark_edition}Seal and Edition{}"
				}
			},
			c_entr_forgiveness = {
				name = "Forgiveness",
				text = {
					"Create a random {C:attention}previously sold{} Joker",
					"{C:inactive}(May overflow){}"
				}
			},
			c_entr_feud = {
				name = "The Feud",
				text = {
					"Select {C:attentiom}#1#{} card#<s>1#,",
					"add {X:chips,C:white}X#3#{} the {C:attention}right{} card's {C:blue}Chips{}",
					"to the {C:attention}left{} card then",
					"{C:attention}destroy{} the right card#<s>2#"
				}
			},
			c_entr_advisor = {
				name = "The Advisor",
				text = {
					"Create an {C:attention}Enhanced{} copy",
					"of your most played hand's {C:attention}example{}",
					"and {C:attention}draw{} it to hand"
				}
			},
			c_entr_heretic = {
				name = "The Heretic",
				text = {
					"Randomize one {C:attention}aspect{} or {C:attention}modification{}",
					"of up to {C:attention}#1#{} selected card#<s>1#"
				}
			},
			c_entr_earl = {
				name = "The Earl",
				text = {
					"For the next round",
					"spare {C:blue}hands{} give {C:money}$#1#{}",
					"and spare {C:red}discards{} give {C:money}$#2#{}"
				}
			},
			c_entr_mason = {
				name = "The Mason",
				text = {
					"Create {C:attention}#1# Stone{} Card#<s>1#",
					"with a random {C:attention}Edition{}"
				}
			},
			c_entr_princess = {
				name = "The Princess",
				text = {
					"For the {C:attention}remainder{} of",
					"the {C:attention}current{} Ante,",
					"{C:planet}Planet{} cards are replaced",
					"with {C:purple}Star{} cards"
				}
			},
			c_entr_imp = {
				name = "The Imp",
				text = {
					"Enhance {C:attention}#1#{} selected card#<s>1#",
					"into {C:attention}Dark{} Cards"
				}
			},
			c_entr_oracle = {
				name = "The Oracle",
				text = {
					"Enhance {C:attention}#1#{} random card#<s>1#",
					"held in hand into an",
					"{C:attention}Editioned{} {C:purple}Star{} card"
				}
			},
			c_entr_ocean = {
				name = "The Ocean",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}Diamonds",
					"{C:blue}+#4#{} Chips"
				}
			},
			c_entr_forest = {
				name = "The Forest",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}Clubs",
					"{C:blue}+#4#{} Chips"
				}
			},
			c_entr_mountain = {
				name = "The Mountain",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}Hearts",
					"{C:blue}+#4#{} Chips"
				}
			},
			c_entr_tent = {
				name = "The Tent",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}Spades",
					"{C:blue}+#4#{} Chips"
				}
			},
			c_entr_companion = {
				name = "The Companion",
				text = {
					"Raise the {C:attention}interest{} cap by {C:gold}#1##2#{}",
					"then gain {C:gold}money{} based on the interest cap"
				}
			},
			c_entr_prophecy = {
				name = "The Prophecy",
				text = {
					"The next {C:attention}#1#{} {C:red}Inverted{} card#<s>1#",
					"become the last used {C:red}Fraud{} card"
				}
			},
			c_entr_mallet = {
				name = "The Mallet",
				text = {
					"Destroy {C:attention}#1#{} random card#<s>1# in hand",
					"and create {C:attention}#1#{} random {C:red}Command{} card#<s>1#",
					"{C:inactive}(Must have room){}"
				}
			},
			c_entr_village = {
				name = "The Village",
				text = {
					"Give cards {C:attention}held{} in hand",
					"{C:blue}+#1#{} bonus Chips"
				}
			},
			c_entr_frail = {
				name = "Frail",
				text = {
					"Destroy {C:attention}#1#{} selected card#<s>1#",
					"and {C:attention}distribute{} their modifications",
					"between {C:attention}other{} cards held in hand"
				}
			},
			c_entr_disturbance = {
				name = "The Disturbance",
				text = {
					"Banish {C:attention}#1#{} selected card#<s>1#",
					"without {C:attention}destroying{} them"
				}
			},
			c_entr_avarice = {
				name = "Avarice",
				text = {
					"Immediately open {C:attention}#1#{} Standard Packs"
				}
			},
			c_entr_muse = {
				name = "The Muse",
				text = {
					"{C:attention}Link together{} any",
					"#1# selected cards"
				}
			},
			--Description feels awkwardly worded.
			c_entr_garden = {
				name = "The Garden",
				text = {
					"{C:attention}Converts{} the rank and suit of {C:attention}#1#{} cards",
					"to a single random rank and suit"
				}
			},
			c_entr_desert = {
				name = "The Desert",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}Fleurons",
					"{C:blue}+#4#{} Chips"
				}
			},
			c_entr_wastes = {
				name = "The Wastes",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}Halberds",
					"{C:blue}+#4#{} Chips"
				}
			},
			c_entr_inferno = {
				name = "Inferno",
				text = {
					"Destroy {C:attention}all{} selected cards",
					"Lose {C:money}$#1#{} for every card",
					"past {C:attention}2{}"
				}
			},
			c_entr_disturbance = {
				name = "The Disturbance",
				text = {
					"Banish {C:attention}#1#{} selected card#<s>1#",
					"without {C:attention}destroying{} them"
				}
			},
			c_entr_avarice = {
				name = "Avarice",
				text = {
					"Immediately open {C:attention}#1#{} Standard Packs"
				}
			},
			c_entr_muse = {
				name = "The Muse",
				text = {
					"{C:attention}Link together{} any",
					"#1# selected cards"
				}
			},
			--Description feels awkwardly worded.
			c_entr_garden = {
				name = "The Garden",
				text = {
					"{C:attention}Converts{} the rank and suit of {C:attention}#1#{} cards",
					"to a single random rank and suit"
				}
			},
			c_entr_desert = {
				name = "The Desert",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}Fleurons",
					"{C:blue}+#4#{} Chips"
				}
			},
			c_entr_wastes = {
				name = "The Wastes",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}Halberds",
					"{C:blue}+#4#{} Chips"
				}
			}
		},
		Planet = {
			c_entr_wormhole = {
				name = "Interloper",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#2#{S:0.8}){} Level up",
					"{C:attention}#1#",
					"{C:mult}+#3#{} Mult and",
					"{C:chips}+#4#{} Chip#<s>4#",
				},
			},
			c_entr_tyche = {
				name = "Tyche",
				text = {
					"Level up the {C:blue}Chips{} and {C:red}Mult{}",
					"per level of a {C:attention}random{} poker hand",
					"{C:mult}+#2#{} Mult per level and",
					"{C:chips}+#1#{} Chips per level"
				},
			},
			c_entr_theia = {
				name = "Theia",
				text = {
					"Level up the {C:blue}Chips{} and {C:red}Mult{}",
					"per level of your {C:attention}highest{}",
					"level poker hand",
					"{C:mult}+#2#{} Mult per level and",
					"{C:chips}+#1#{} Chips per level"
				},
			},
			c_entr_chiron = {
				name = "Chiron",
				text = {
					"Level up the {C:blue}Chips{} per level",
					"of a {C:attention}random{} poker hand",
					"{C:chips}X#1#{} Chips per level"
				},
			},
			c_entr_neith = {
				name = "Neith",
				text = {
					"Level up the {C:red}Mult{} per level",
					"of a {C:attention}random{} poker hand",
					"{C:mult}X#1#{} Mult per level"
				},
			},
			c_entr_sputnik = {
				name = "Sputnik I",
				text = {
					"Level up {C:attention}#1#{}",
					"random poker hands",
					"{C:mult}+???{} Mult and",
					"{C:chips}+???{} Chips",
				},
			},
		},
		Voucher = {
			v_entr_marked = {
				name = "Marked Cards",
				text = {
					"{C:red}Inverted{} consumables have a",
					"fixed {C:red}10%{} chance to replace",
					"their regular counterparts"
				},
			},
			v_entr_trump_card = {
				name = "Trump Card",
				text = {
					"{C:red}Flipside{} can appear in",
					"{C:attention}Celestial{} and {C:attention}Arcana{} Packs",
				},
			},
			v_entr_supersede = {
				name = "Supersede",
				text = {
					"{C:red}Twisted{} Booster Packs have a",
					"fixed {C:red}20%{} chance to replace",
					"any other Booster Pack in the shop"
				},
			},

			v_entr_diviner = {
				name = "Diviner",
				text = {
					"The chance for {C:purple}Runes{} to",
					"show up in Booster Packs is increased"
				},
			},
			v_entr_providence = {
				name = "{E:entr_shader}Providence{}",
				text = {
					"Runes have {C:purple,E:1}enhanced{} effects",
				},
			},
			v_entr_ascension = {
				name = "Ascension",
				text = {
					"Copy the {C:attention}first",
					"used {C:purple}Rune{} each round"
				},
			},
			v_entr_starter_kit = {
				name = "Starter Kit",
				text = {
					"{C:attention}Booster Packs{} may",
					"replace cards in",
					"the shop"
				},
			},
			v_entr_expansion_pack = {
				name = "Expansion Pack",
				text = {
					"Create a {C:attention}deck{}",
					"in the Voucher slots",
					"every {C:attention}2{} antes"
				},
			},
		},
		Command = {
			c_entr_memory_leak = {
				name = "(~)$ memoryleak",
				text = {
					"{C:red}int *m = new int{}",
				}
			},
			c_entr_root_kit = {
				name = "(~)$ rootkit",
				text = {
					"For the next defeated Blind,",
					"spare hands give {C:red}$#1#{}",
				}
			},
			c_entr_break = {
				name = "(~)$ break;",
				text = {
					"Return to the {C:red}Blind selection{} screen,",
					"the {C:red}current Blind{} is still upcoming",
				}
			},
			c_entr_interference = {
				name = "(~)$ interference",
				text = {
					"{C:red}Randomizes{} {C:attention}played hands{}, {C:attention}Blind size{}",
					"and {C:attention}Payout{} for the remainder of",
					"the {C:red}current round{}"
				}
			},
			c_entr_fork = {
				name = "(~)$ fork",
				text = {
					"Create a {C:red}Glitched{} copy of",
					"a selected {C:attention}playing card{} with",
					"a new {C:red}random Enhancement{}"
				}
			},
			c_entr_push = {
				name = "(~)$ push -f",
				text = {
					"{C:red}Destroy{} all held {C:attention}Jokers{}, {C:red}create{} a",
					"new {C:attention}Joker{} based on their {C:red}rarities{}",
					
				}
			},
			c_entr_increment = {
				name = "(~)$ increment",
				text = {
					"{C:red}+1{} {C:attention}shop slots{}",
					"for the remainder of {C:attention}this Ante{}",
				}
			},
			c_entr_decrement = {
				name = "(~)$ decrement",
				text = {
					"Transform {C:red}#1#{} selected {C:attention}Joker#<s>1#{}",
					"to the {C:red}Joker{} that appears",
					"previously in the {C:red}collection{}",
					"{C:inactive}(Currently #2#){}"
				}
			},
			c_entr_cookies = {
				name = "(~)$ cookies",
				text = {
					"Create a {C:dark_edition}Negative{} {C:red}Candy Joker{}",
				}
			},
			c_entr_overflow = {
				name = "(~)$ overflow",
				text = {
					"{C:red}Infinite{} {C:attention}card selection limit{}",
					"until the end of the {C:red}current Blind{}",
				}
			},
			c_entr_refactor = {
				name = "(~)$ refactor",
				text = {
					"Apply the {C:attention}Edition of a selected",
					"{C:red}Joker{} to a random {C:red}Joker{}",
				}
			},
			c_entr_ctrl_x = {
				name = "(~)$ ctrl+x",
				text = {
					"{C:red}#1#{} #2# {C:attention}card{},",
					"{C:attention}Booster Pack{}, or {C:attention}Voucher{}",
					"{C:inactive}(Currently #3#){}"
				}
			},
			c_entr_segfault = {
				name = "(~)$ segfault",
				text = {
					"Create a random {C:attention}playing card{}",
					"with a {C:red}random{} {C:attention}consumable{}, {C:attention}Joker{},",
					"{C:attention}Booster Pack{}, or {C:attention}Voucher{} applied",
					"as an {C:red}Enhancement{}",
					"then put it in the {C:attention}deck{}"
				}
			},
			c_entr_sudo = {
				name = "(~)$ sudo",
				text = {
					"{C:red}Permanently{} modify {C:attention}one{} selected",
					"{C:red}poker hand{} to always score as",
					"{C:attention}another{} {C:red}poker hand{}"
				}
			},
			c_entr_constant = {
				name = "(~)$ constant",
				text = {
					"Convert all {C:red}cards{} with the same",
					"rank as {C:attention}1{} selected card into",
					"the {C:red}selected card{}"
				}
			},
			c_entr_new = {
				name = "(~)$ new()",
				text = {
					"Adds an {C:attention}extra{} {C:red}Red Room{} Blind",
					"before the next {C:attention}upcoming{} Blind",
				}
			},
			c_entr_multithread = {
				name = "(~)$ multithread",
				text = {
					"Create Temporary {C:dark_edition}Negative{} copies",
					"of all {C:red}selected{} cards in {C:red}hand{}",
				}
			},
			c_entr_invariant = {
				name = "(~)$ invariant",
				text = {
					"Apply an {C:red}Invariant{} sticker to",
					"1 selected card in the {C:red}shop{}",
				}
			},
			c_entr_inherit = {
				name = "(~)$ inherit",
				text = {
					"Convert {C:red}all{} cards with the same",
					"{C:red}Enhancement{} as 1 selected card",
					"into a {C:red}chosen Enhancement",
				}
			},
			c_entr_autostart = {
				name = "(~)$ autostart",
				text = {
					"Gain {C:red}#1#{} random skip Tags",
					"obtained {C:red}previously{} in the run",
				}
			},
			c_entr_quickload = {
				name = "(~)$ quickload",
				text = {
					"{C:red}Retrigger{} the Payout screen",
					"with {C:red}no{} Blind money",
				}
			},
			c_entr_hotfix = {
				name = "(~)$ hotfix",
				text = {
					"Apply a {C:red}Hotfix{} sticker to",
					"1 selected card",
				}
			},
			c_entr_pseudorandom = {
				name = "(~)$ pseudorandom",
				text = {
					"Apply a {C:red}Pseudorandom{} sticker to",
					"{C:red}all{} cards on screen",
				}
			},
			c_entr_bootstrap = {
				name = "(~)$ bootstrap",
				text = {
					"The final {C:blue}Chips{} and {C:red}Mult{} of",
					"{C:red}this{} hand are applied to the",
					"base {C:blue}Chips{} and {C:red}Mult{} of the next hand"
				}
			},
			c_entr_local = {
				name = "(~)$ local",
				text = {
					"Apply {C:red}Temporary{} to",
					"#1# selected playing cards"
				}
			},
			c_entr_transpile = {
				name = "(~)$ transpile",
				text = {
					"{C:dark_edition}#1#{} Joker slots",
					"{C:dark_edition}+#2#{} consumable slots",
					"{C:dark_edition}+#3#{} hand size"
				}
			},
			c_entr_detour = {
				name = "(~)$ detour",
				text = {
					"Create a {C:attention}card, booster pack, or voucher{}",
					"with a type {C:attention}corresponding{} to the",
					"{C:attention}last obtained{} card, booster pack or voucher",
					"{C:inactive}(Currently #1#){}"
				}
			},
			c_entr_mbr = {
				name = "(~)$ mbr",
				text = {
					"Add a {C:dark_edition}Banana Voucher Pack{}",
					"to the Booster Packs of the current shop"
				}
			},
			c_entr_desync = {
				name = "(~)$ desync",
				text = {
					"Apply a {C:red}Desync{} sticker to",
					"1 selected Joker or consumable",
				}
			},
			c_entr_badarg = {
				name = "(~)$ bad arg*",
				text = {
					"{C:red}Stop{} a {C:attention}selected{} poker hand from {C:red}scoring{}",
					"or using up hands for the",
					"{C:attention}remainder{} of the run"
				}
			},
			c_entr_interpolate = {
				name = "(~)$ interpolate",
				text = {
					"Select and {C:red}destroy{} #1# selected {C:attention}Joker#<s>1#{}",
					"or {C:attention}consumable#<s>1#{}, this card may",
					"appear in future {C:red}Twisted{} or {C:cry_code}Program{} packs"
				}
			},
			c_entr_overload = {
				name = "(~)$ overload",
				text = {
					"The {C:attention}next{} played hand",
					"counts as containing {C:red}all{}",
					"other hands"
				}
			},
			c_entr_echo = {
				name = "(~)$ echo",
				text = {
					"Select {C:attention}two{} consumables",
					"to {C:dark_edition}trigger{} each other's effects",
					"when they are used",
					"{C:inactive}(including from the shop){}"
				}
			},
		},
		Star = {
			c_entr_regulus = {
				name = "Proxima Centauri",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_hydrae = {
				name = "Alpha Centauri",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_vega = {
				name = "Polaris",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_polaris = {
				name = "Dabih",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_cassiopeiae = {
				name = "Capella",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_pegasi = {
				name = "Trappist-1",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_persei = {
				name = "Kepler-90",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_ophiuchi = {
				name = "55 Cancri",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_carinae = {
				name = "Betelgeuse",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_procyon = {
				name = "Procyon B",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_tauri = {
				name = "W33A",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_sirius = {
				name = "Sirius",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_starspectrum = {
				name = "Vega",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_starstraightspectrum = {
				name = "Rigel",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_starhousespectrum = {
				name = "Eltanin",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			--least sure about the name of this one, feel free to change it to a different star
			c_entr_starfivespectrum = {
				name = "HD 33579",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_multiverse = {
				name = Cryptid_config.family_mode and "Multiverse" or "The Multiverse In Its Fucking Entirety",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_binarystars = {
				name = "Mizar",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_deadcore = {
				name = "Dead Core",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_dark_matter = {
				name = "Dark Matter",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_dyson_swarm = {
				name = "Dyson Swarm",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_starlua = {
				name = "Star.lua",
				text = {
					"{C:green}#1# in #2#{} chance to",
					"upgrade every",
					"{C:legendary,E:1}poker hand{}",
					"{C:gold}+#3#{} Ascension Power",
				}
			},
			c_entr_strange_star = {
				name = "Strange Star",
				text = {
					"Upgrade a random",
					"{C:legendary,E:1}poker hand{}",
					"{C:attention}+#2#{} {C:gold}Ascension Power{} for each",
					"{C:attention}Strange Star{} used",
					"in this run",
					"{C:inactive}(Currently{C:attention} #1#{C:inactive}){}",
				}
			},
			c_entr_nemesis = {
				name = "Nemesis",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{S:0.8}){}",
					"Increase exponent of",
					"{C:attention}Ascended{} hands by {X:gold,C:white}+X#2#{}",
					"{C:inactive}(Currently {X:gold,C:white}#3#{C:inactive})",
				}
			},
			c_entr_paras = {
				name = "Paras",
				text = {
					"({V:1}lvl.#4#{}{C:gold}#8#{})({V:2}lvl.#5#{}{C:gold}#9#{})({V:3}lvl.#6#{}{C:gold}#10#{})",
					"Level up",
					"{C:attention}#1#{},",
					"{C:attention}#2#{},",
					"and {C:attention}#3#{}",
					"{C:gold}+#7#{} Ascension Power"
				},
			},
			c_entr_jatka = {
				name = "Jatka",
				text = {
					"({V:1}lvl.#4#{}{C:gold}#8#{})({V:2}lvl.#5#{}{C:gold}#9#{})({V:3}lvl.#6#{}{C:gold}#10#{})",
					"Level up",
					"{C:attention}#1#{},",
					"{C:attention}#2#{},",
					"and {C:attention}#3#{}",
					"{C:gold}+#7#{} Ascension Power"
				},
			},
			c_entr_rouva = {
				name = "Rouva",
				text = {
					"({V:1}lvl.#4#{}{C:gold}#8#{})({V:2}lvl.#5#{}{C:gold}#9#{})({V:3}lvl.#6#{}{C:gold}#10#{})",
					"Level up",
					"{C:attention}#1#{},",
					"{C:attention}#2#{},",
					"and {C:attention}#3#{}",
					"{C:gold}+#7#{} Ascension Power"
				},
			},
			c_entr_assa = {
				name = "Assa",
				text = {
					"({V:1}lvl.#4#{}{C:gold}#8#{})({V:2}lvl.#5#{}{C:gold}#9#{})({V:3}lvl.#6#{}{C:gold}#10#{})",
					"Level up",
					"{C:attention}#1#{},",
					"{C:attention}#2#{},",
					"and {C:attention}#3#{}",
					"{C:gold}+#7#{} Ascension Power"
				},
			},
			c_entr_kivi = {
				name = "Kivi",
				text = {
					"({V:1}lvl.#4#{}{C:gold}#8#{})({V:2}lvl.#5#{}{C:gold}#9#{})({V:3}lvl.#6#{}{C:gold}#10#{})",
					"Level up",
					"{C:attention}#1#{},",
					"{C:attention}#2#{},",
					"and {C:attention}#3#{}",
					"{C:gold}+#7#{} Ascension Power"
				},
			},
			c_entr_chunk = {
				name = "Chunk",
				text = {
					"({V:1}lvl.#4#{}{C:gold}#8#{})({V:2}lvl.#5#{}{C:gold}#9#{})({V:3}lvl.#6#{}{C:gold}#10#{})",
					"Level up",
					"{C:attention}#1#{},",
					"{C:attention}#2#{},",
					"and {C:attention}#3#{}",
					"{C:gold}+#7#{} Ascension Power"
				},
			},
			c_entr_supernova = {
				name = "Collapse",
				text = {
					"Remove #1# {C:gold}Ascension Power{} from",
					"your {X:purple,C:white}Nemesis'{}",
					"highest {C:gold}Ascension Power{}",
					"{C:legendary,E:1}poker hand{}",
				},
			},
			c_entr_pocket_dimension = {
				name = "Pocket Dimension",
				text = {
					"{S:0.8}({S:0.8,V:1}lvl.#1#{}{S:0.8,C:gold}#2#{}{S:0.8}){} Level up",
					"{C:attention}#3#",
					"{C:gold}+#4#{} Ascension Power"
				}
			},
			c_entr_black_dwarf = {
				name = "Black Dwarf",
				text = {
					"Level up {C:gold}Ascension Power{}",
					"per level of all poker hands",
					"{C:gold}+#1#{} Ascension Power"
				}
			},
			c_entr_frozen_star = {
				name = "Frozen Star",
				text = {
					"Level up your {C:attention}highest{} level",
					"poker hand",
					"{C:gold}+#1#{} Ascension Power"
				}
			},
			c_entr_coatlicue = {
				name = "Coatlicue",
				text = {
					"Level up a {C:attention}random{} poker hand's",
					"{C:gold}Ascension Power{} by {C:attention}1/20{}th",
					"of its {C:chips}Chips{} per level"
				}
			},
			c_entr_threefour = {
				name = "34 Tauri",
				text = {
					"Level up a {C:attention}random{} poker hand's",
					"{C:gold}Ascension Power{} by {C:attention}1/3{}rd",
					"of its {C:mult}Mult{} per level"
				}
			},
			c_entr_fuzzball = {
				name = "Fuzzball",
				text = {
					"Level up {C:attention}#1#{}",
					"random poker hands",
					"{C:gold}+#2#{} Ascension Power",
				}
			},
		},
		Omen = {
			c_entr_rift = {
				name = "Rift",
				text = {
					"Apply a {C:attention}random{} {C:dark_edition}Edition{}",
					"to {C:attention}#1#{} selected card#<s>1#"
				}
			},
			c_entr_define = {
				name = "#1#define",
				text = {
					"Replace all future instances of",
					"a {C:entr_omen}selected card{} with",
					"a card of {C:entr_omen}your choice{}",
					"then {C:attention}destroy{} the selected card",
					"{C:inactive}(Hidden consumables and{}",
					"{C:inactive}>=Exotic Jokers excluded){}"
				}
			},
			c_entr_beyond = {
				name = "Beyond",
				text = {
					"Create a random",
					"{C:entr_entropic,E:1}Entropic{} Joker",
					"Destroy all other held Jokers"
				}
			},
			c_entr_highway = {
				name = "Highway",
				text = {
					"Destroy {C:red}all{} Jokers except {C:attention}one{}",
					"then create an {C:entr_entropic,E:1}Entropic{} Joker"
				}
			},
			c_entr_fervour={
                name="Fervour",
                text={
                    "Create a",
                    "{C:entr_reverse_legendary,E:1}Legendary? {}Joker",
                    "{C:inactive}(Must have room)",
                },
            },
			c_entr_pulsar = {
				name = "Pulsar",
				text = {
					"Upgrade your most played",
					"{C:legendary,E:1}poker hand{}'s Ascension Power",
					"by {X:gold,C:white}X3{} its current level",
					"{C:inactive}({C:gold}+#1#{C:inactive} Ascension Power)",

				}
			},
			c_entr_quasar = {
				name = "Quasar",
				text = {
					"Upgrade every {C:legendary,E:1}poker hand{}'s",
					"Ascension Power by one half",
					"of its {C:attention}current{} level"
				}
			},

			c_entr_dispel = {
				name = "Dispel",
				text = {
					"Banish {C:attention}#1#{} selected Joker#<s>1#",
					"{C:inactive}(Bypasses Eternal){}"
				}
			},
			c_entr_weld = {
				name = "Weld",
				text = {
					"Apply {C:dark_edition}Negative{} and {C:purple,E:1}Aleph{}",
					"to #1# selected Joker#<s>1#"
				}
			},
			c_entr_cleanse = {
				name = "Cleanse",
				text = {
					"{C:attention}Remove{} the suit and rank",
					"from {C:attention}all{} cards in hand",
					"{C:gold}$#1#{} for each Chip taken"
				}
			},

			c_entr_insignia = {
				name = "Insignia",
				text = {
					"Add a {V:1}Silver Seal{}",
					"to #1# selected card",
				}
			},
			c_entr_rendezvous = {
				name = "Rendezvous",
				text = {
					"Add a {V:1}Crimson Seal{}",
					"to #1# selected card",
				}
			},
			c_entr_eclipse = {
				name = "Veil",
				text = {
					"Add a {V:1}Sapphire Seal{}",
					"to #1# selected card",
				}
			},
			c_entr_calamity = {
				name = "Calamity",
				text = {
					"Add a {V:1}Pink Seal{}",
					"to #1# selected card",
				}
			},
			c_entr_downpour = {
				name = "Downpour",
				text = {
					"Add a {V:1}Cerulean Seal{}",
					"to #1# selected card",
				}
			},
			c_entr_script = {
				name = "Script",
				text = {
					"Add a {V:1}Verdant Seal{}",
					"to #1# selected card",
				}
			},
			c_entr_inscribe = {
				name = "Inscribe",
				text = {
					"Multiply the Chips of all numbered",
					"cards in hand by {X:chips,C:white}X#1#{}",
					"Then {C:attention}debuff{} all numbered cards",
					"in hand for 1 round"
				}
			},
			c_entr_siphon = {
				name = "Siphon",
				text = {
					"Destroy 1 selected {C:attention}Editioned{}",
					"Joker then apply the {C:attention}previous{} Edition",
					"to {C:attention}#2#{} random cards in hand",
					"{C:inactive}(Currently {C:dark_edition}#1#{C:inactive}, excludes {C:dark_edition}Negative{C:inactive})"
				}
			},
			c_entr_changeling = {
				name = "Changeling",
				text = {
					"Convert {C:attention}#1#{} random cards",
					"held in hand into {C:dark_edition}Editioned{} face cards"
				}
			},
			c_entr_ward = {
				name = "Ward",
				text = {
					"Debuff {C:attention}1{} random Joker",
					"for {C:attention}#2#{} rounds then earn",
					"{X:gold,C:white}X#1#{} its sell value",
				}
			},
			c_entr_ichor = {
				name = "Ichor",
				text = {
					"A {C:attention}random{} held Joker",
					"takes up {C:dark_edition}+1{} Joker slot",
					"{C:dark_edition}+#1#{} Joker slots"
				}
			},
			c_entr_pact = {
				name = "Bind",
				text = {
					"{C:attention}Link{} up to {C:attention}#1#{}",
					"cards together. All modifications",
					"affect all of the linked cards"
				}
			},
			c_entr_rend = {
				name = "Rend",
				text = {
					"Convert up to {C:attention}#1#{}",
					"selected cards to",
					"{C:attention}Flesh{} Cards"
				}
			},
			c_entr_rejuvenate = {
				name = "Rejuvenate",
				text = {
					"Add a random {C:attention}Seal{},",
					"{C:attention}Enhancement{}, and {C:attention}Edition{}",
					"to 1 selected card held in hand, then",
					"convert {C:attention}#1#{} other cards",
					"held in hand into this card, {C:gold}#2#{}",
				}
			},
			c_entr_crypt = {
				name = "Crypt",
				text = {
					"Select {C:attention}#1#{} Jokers and",
					"debuff a {C:attention}random{} selected",
					"Joker, then turn it into the",
					"{C:attention}other{} Joker"
				}
			},
			c_entr_charm = {
				name = "Charm",
				text = {
					"Apply a {C:attention}random{} {C:dark_edition}Edition{} and",
					"{C:attention}Eternal{} to a selected Joker",
				}
			},
			c_entr_entropy = {
				name = "Entropy",
				text = {
					"Completely {C:attention}randomize{}",
					"up to #1# selected cards",
				}
			},
			c_entr_fusion = {
				name = "Fusion",
				text = {
					"{C:attention}#1#{} random cards in hand",
					"become random cards of 1",
					"selected card's type"
				}
			},
			c_entr_substitute = {
				name = "Substitute",
				text = {
					"{C:attention}Unredeem{} a random Voucher",
					"and all lower tiers, then redeem the next",
					"tier of Voucher"
				}
			},
			c_entr_evocation = {
				name = "Evocation",
				text = {
					"{C:attention}Upgrade{} #1# selected Joker's",
					"rarity then destroy all other Jokers",
					"{C:blue}#2#{} hands"
				}
			},
			c_entr_mimic = {
				name = "Mimic",
				text = {
					"Create a {C:attention}Banana Perishable{} copy",
					"of #1# selected cards",
				}
			},
			c_entr_superego = {
				name = "Project",
				text = {
					"Apply a {C:attention}Projected{}",
					"sticker to 1 selected Joker, then",
					"debuff it"
				}
			},
			c_entr_engulf = {
				name = "Engulf",
				text = {
					"Apply {C:dark_edition}Solar{} effect",
					"to {C:attention}1{} selected card",
					"in hand"
				}
			},
			c_entr_offering = {
				name = "Offering",
				text = {
					"All Jokers become {C:attention}Rental{}",
					"{X:gold,C:white}X#1#{} shop costs",
				}
			},
			c_entr_entomb = {
				name = "Entomb",
				text = {
					"Create a {C:attention}Mega Booster Pack{}",
					"corresponding to the type of #1# selected",
					"consumable"
				}
			},
			c_entr_conduct = {
				name = "Conduct",
				text = {
					"Apply the {C:attention}previous{} Edition",
					"to adjacent cards of 1 selected card",
					"or consumable",
					"{C:inactive}(Currently #1#){}"
				}
			},
			c_entr_disavow = {
				name = "Disavow",
				text = {
					"{C:red}Disavow{} {C:attention}1{} selected card",
					"held in hand, all {C:attention}other{} cards held",
					"in hand gain its Enhancement"
				}
			},
			c_entr_regenerate = {
				name = "Regenerate",
				text = {
					"Completely reset up to",
					"{C:attention}#1#{} selected cards",
					"or Jokers",
					"{C:inactive}(Doesn't remove Aleph){}"
				}
			},
			c_entr_purity = {
				name = "Purity",
				text = {
					"Apply a {C:dark_edition}Pure{} sticker to",
					"{C:attention}#1#{} selected Joker#<s>1#"
				}
			},
			c_entr_transcend = {
				name = "Transcend",
				text = {
					"Convert {C:attention}#1#{} selected card#<s>1#",
					"to a {C:attention}random{} {C:red}object{}"
				}
			},
			c_entr_malediction = {
				name = "Malediction",
				text = {
					"Add an {V:1}Amber Seal{}",
					"to #1# selected card",
				}
			},
			c_entr_serpents = {
				name = "Pact of Serpents",
				text = {
					"Create a random {C:legendary,E:1}hidden{} consumable",
					"{C:inactive}(May overflow){}"
				}
			},

			c_entr_splinter = {
				name = "Splinter",
				text = {
					"One {C:attention}random{} card in full deck",
					"becomes a random {C:attention}Shattered{} Joker"
				}
			},
			c_entr_dream = {
				name = "Dream",
				text = {
					"Draw {C:attention}#1#{} random",
					"{C:attention}Enhanced{} {C:purple}Eye#<s>1#{}",
					"to hand"
				}
			},
			c_entr_void = {
				name = "Void",
				text = {
					"Add a {V:1}Mini Seal{}",
					"to #1# selected card",
				}
			},
			c_entr_sharpen = {
				name = "Sharpen",
				text = {
					"Add a {V:1}Sharp Seal{}",
					"to #1# selected card",
				}
			},
			c_entr_singularity = {
				name = "Singularity",
				text = {
					"Add an {V:1}Vantablack Seal{}",
					"to #1# selected card",
				}
			},

			c_entr_idyll = {
				name = "Idyll",
				text = {
					"Create a {C:attention}copy{}",
					"and an {C:entr_entropic}Ascended{}",
					"variant of the last obtained {C:attention}Tag{}"
				}
			},
			c_entr_flipside_omen = {
				name = "Flipside",
				text = {
					"Convert {C:attention}#1#{} selected card#<s>1#",
					"into an {C:red}Inverted{} variant",
				}
			},
			c_entr_ruin = {
				name = "Ruin",
				text = {
					"Destroy {C:attention}#2#{} selected Joker#<s>2#",
					"Create {C:attention}#1#{} randomly {C:attention}Enhanced{}",
					"and {C:attention}Editioned{} copies of a card",
					"from your full deck"
				}
			}
		},
		Aesthetic = {
			c_entr_vintage = {
				name = "Vintage",
				text = {
					"Enhance up to {C:attention}#1#{} selected",
                	"Joker with {C:attention}#2#{}",
				}
			},
			c_entr_retro = {
				name = "Retro",
				text = {
					"Enhance up to {C:attention}#1#{} selected",
                	"Joker with {C:attention}#2#{}",
				}
			},
			c_entr_ytp = {
				name = "YTP",
				text = {
					"Enhance up to {C:attention}#1#{} selected",
                	"Joker with {C:attention}#2#{}",
				}
			},
			c_entr_solarpunk = {
				name = "Solarpunk",
				text = {
					"Enhance up to {C:attention}#1#{} selected",
                	"Joker with {C:attention}#2#{}",
				}
			},
			c_entr_breakcore = {
				name = "Breakcore",
				text = {
					"Enhance up to {C:attention}#1#{} selected",
                	"Joker with {C:attention}#2#{}",
				}
			},
			c_entr_lewd = {
				name = "Lewd",
				text = {
					"Enhance up to {C:attention}#1#{} selected",
                	"Joker with {C:attention}#2#{}",
				}
			},
			c_entr_disco = {
				name = "Disco",
				text = {
					"Enhance up to {C:attention}#1#{} selected",
                	"Joker with {C:attention}#2#{}",
				}
			},
		},
		Transient = {
			c_entr_cage = {
				name = "Cage",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} selected card#<s>1#,",
					"then change their suit into the",
					"{C:attention}leftmost{} selected card's suit"
				}
			},
			c_entr_implode = {
				name = "Implode",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} selected card#<s>1#,",
					"then turn them into {C:attention}Ace of Nils{}"
				}
			},
			c_entr_meteor = {
				name = "Meteor",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} random card#<s>1# in hand,",
					"then give them {C:purple}Sapphire{} Seals"
				}
			},
			c_entr_concentrate = {
				name = "Concentrate",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}all{} selected cards,",
					"then copy them to hand"
				}
			},
			c_entr_pyrite = {
				name = "Pyrite",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} selected card#<s>1#,",
					"then turn them into {C:attention}Gold Cards{}"
				}
			},
			c_entr_set = {
				name = "Set",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} selected card#<s>1#,",
					"then change their rank into the",
					"{C:attention}leftmost{} selected card's rank"
				}
			},
			c_entr_trickster = {
				name = "Trickster",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} selected card#<s>1#,",
					"then turn them into a",
					"random {C:red}Rare{} {C:attention}Joker{}"
				}
			},
			c_entr_sundial = {
				name = "Sundial",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} selected card#<s>1#,",
					"then turn them into {C:attention}Glass Cards{}"
				}
			},
			c_entr_candle = {
				name = "Candle",
				text = {
					"{C:attention}+#1#{} hand size",
					"for this Blind"
				}
			},
			c_entr_faith = {
				name = "Faith",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} selected card#<s>1#,",
					"then turn them into {C:attention}Lucky Cards{}"
				}
			},
			c_entr_oasis = {
				name = "Oasis",
				text = {
					"Apply {C:attention}Temporary{} to",
					"a selected card, then",
					"copy it {C:attention}#1#{} times"
				}
			},
			c_entr_ragtag = {
				name = "Ragtag",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} selected card#<s>1#,",
					"then turn them into a",
					"random {C:blue}Common{} {C:attention}Joker{}"
				}
			},
			c_entr_burn = {
				name = "Burn",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} random card#<s>1# in hand,",
					"then give them {C:purple}Pink{} Seals"
				}
			},
			c_entr_escape = {
				name = "Escape",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} random card#<s>1# in hand,",
					"then randomize them"
				}
			},
			c_entr_gbdecay = {
				name = "Decay",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} selected card#<s>1#,",
					"then turn them into {C:attention}Steel Cards{}"
				}
			},
			c_entr_visage = {
				name = "Visage",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} selected card#<s>1#,",
					"then turn them into {C:attention}Stone Cards{}"
				}
			},
			c_entr_nebula = {
				name = "Nebula",
				text = {
					"Create {C:attention}#1#{} random",
					"{C:attention}Temporary{} Blind Tokens"
				}
			},
			c_entr_essence = {
				name = "Essence",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} selected card#<s>1#,",
					"then turn them into {C:attention}random{}",
					"suited Kings"
				}
			},
			c_entr_manifest = {
				name = "Manifest",
				text = {
					"{C:attention}+#1#{} selection limit",
					"for this Blind"
				}
			},
			c_entr_hope = {
				name = "Hope",
				text = {
					"Apply {C:attention}Temporary{} to",
					"{C:attention}#1#{} random card#<s>1# in hand,",
					"then give them {V:1}Silver{} Seals"
				}
			},
		},
		Tarot = {
			c_entr_kiln = {
				name = "Kiln",
				text = {
					"Enhances {C:attention}#1#{} selected",
					"card#<s>1# into a",
					"{C:attention}Ceramic Card{}"
				}
			},
			c_entr_comet = {
				name = "The Comet",
				text = {
					"Enhances {C:attention}#1#{} selected",
					"card#<s>1# into a",
					"{C:attention}Radiant Card{}"
				}
			},
			c_lovers_gfb = {
				name = "The Lovers",
				text = {
					"Applies {C:entr_freaky}Freaky{}",
					"to {C:attention}#1#{} selected card"
				}
			},
			c_star_gfb = {
				name = "The Star",
				text = {
					"Enhances {C:attention}#1#{} selected",
					"cards into a",
					"{C:attention}Supernova Card{}"
				}
			},
			c_sun_gfb = {
				name = "The Sun",
				text = {
					"Enhances {C:attention}#1#{} selected",
					"cards into a",
					"{C:attention}Sunny Joker Card{}"
				}
			},
			c_world_gfb = {
				name = "The World",
				text = {
					"Enhances {C:attention}#1#{} selected",
					"cards into an",
					"{C:attention}Earth Card{}"
				}
			},
			c_moon_gfb = {
				name = "The Moon",
				text = {
					"Enhances {C:attention}#1#{} selected",
					"cards into a",
					"{C:attention}To the Moon Card{}"
				}
			},
			c_death_gfb = {
				name = "Death",
				text = {
					"Select {C:attention}#1#{} cards,",
					"convert the {C:attention}right{} card",
					"into the {C:attention}left{} card",
					"{C:inactive}(Drag to rearrange)"
				}
			}
		},
		Spectral = {
			c_entr_flipside = {
				name = "Flipside",
				text = {
					"Convert {C:attention}#1#{} selected card#<s>1#",
					"into an {C:red}Inverted{} variant",
				}
			},
			c_entr_destiny = {
				name = "Destiny",
				text = {
					"Sacrifice {C:attention}5{} playing cards to craft",
					"one Joker based on their Enhancements",
					"{C:inactive}(Currently #1#){}"
				}
			},
			c_entr_shatter = {
				name = "Shatter",
				text = {
					"Apply {C:dark_edition}Fractured{} to",
					"{C:attention}#1#{} selected cards in hand",
					"{C:red}-#2#{} card selection limit"
				}
			},
			c_entr_lust = {
				name = "Lust",
				text = {
					"Apply {C:dark_edition}Freaky{} to",
					"{C:attention}#1#{} random card#<s>1# in hand",
				}
			},
			c_entr_null = {
				name = "Null",
				text = {
					"Destroy {C:attention}1{} random card ",
					"in your hand, add {C:attention}#1#{}",
					"random {C:attention}Enhanced Nil of Nil{}",
					"card#<s>1# to your hand",
				}
			},
			c_entr_antithesis = {
				name = "Antithesis",
				text = {
					"Drawn cards gain {C:attention}Editions{}",
					"based on the {C:attention}Collection{} order",
					"until the next round",
					"{C:inactive}(Excludes {C:dark_edition}Negative{C:inactive})"
				}
			},
			c_entr_oss = {
				name = "Rune of Oss",
				text = {
					"The next opened {C:attention}Booster Pack{}",
					"will contain a {C:legendary,E:1}hidden{} consumable",
					"{C:inactive}(If possible)"
				}
			},
			c_entr_oss_providence = {
				name = "Rune of Oss{C:purple}+{}",
				text = {
					"The next opened {C:attention}Booster Pack{}",
					"will contain a {C:legendary,E:1}hidden{} consumable",
					"and a {C:purple}Rune{} is {C:purple,E:1}generated{} when this occurs",
					"{C:inactive}(If possible)"
				}
			},
			c_entr_enchant = {
				name = "Enchant",
				text = {
					"Add an {C:purple}Ornate Seal{}",
					"to {C:attention}#1#{} selected",
					"card in your hand"
				}
			},
			c_entr_manifest = {
				name = "Manifest",
				text = {
					"Create {C:entr_entropic}Ascended{}",
					"variants of this Ante's",
					"skip Tags"
				}
			},

			c_talisman_gfb = {
				name = "Download Amulet Free Working 2026",
				text = {
					"Add a {C:attention}Gold Seal{}",
					"to {C:attention}1{} selected",
					"card in your hand",
					"{C:red}WARNING: UNSTABLE"
				}
			}
		},
		Stake = {
			stake_entr_copper = {
				name = "Copper Stake",
				text = {
					"{C:attention}Copied{} playing cards may become {C:red}Disavowed{}",
					"{s:0.8}Applies all previous Stakes",
				},
			},
			stake_entr_platinum = {
				name = "Platinum Stake",
				text = {
					"Jokers cost {C:red}20%{} more",
					"{s:0.8}Applies all previous Stakes",
				},
			},
			stake_entr_meteorite = {
				name = "Meteorite Stake",
				text = {
					"Hand leveling may {C:red}fail{}",
					"{s:0.8}Applies all previous Stakes",
				},
			},
			stake_entr_obsidian = {
				name = "Obsidian Stake",
				text = {
					"Always obtain a {C:red}Curse{} when",
					"defeating the Boss Blind",
					"{s:0.8}Applies all previous Stakes",
				},
			},
			stake_entr_iridium = {
				name = "Iridium Stake",
				text = {
					"Win Ante is {C:red}10{}",
					"{s:0.8}Applies all previous Stakes",
					"{C:entr_trans,s:0.7}Trans Rights",
				},
			},
			stake_entr_zenith = {
				name = "Zenith Stake",
				text = {
					"what if {E:1,C:entr_zenith}Endless Entropy{}",
					"had {C:green}WhatsApp{}",
					"Ruby Crimsonfang          15:23",
					"{C:inactive}I NEED SUPERBOSSES!           ",
					"Jade Crimsonfang  	    15:28",
					"{C:inactive}I NEED SUPERBOSSES!           ",
					"Baron          		  14:23",
					"{C:inactive}I HATE YOU I HATE YOU!        ",
				},
			},
			stake_entr_gfb = {
				name =  "Ruby 'Crimsonfang' Presents: The Joker is you, an opera",
				text = {
					"Enjoy.",
					"Unlocks cannot be earned on",
					"this stake"
				}
			}
		},
		Tag= {
			tag_entr_dog = {
				name = "Dog Tag",
				text = { "Woof.", "{C:inactive}Level {C:dark_edition}#1#" },
			},
			tag_entr_sunny = {
				name = "Sunny Tag",
				text = { 
					"Next base Edition shop",
					"Joker is free and",
					"becomes {C:dark_edition}Sunny{}"	
				},
			},
			tag_entr_solar = {
				name = "Solar Tag",
				text = { 
					"Next base Edition shop",
					"Joker is free and",
					"becomes {C:dark_edition}Solar{}"	
				},
			},
			tag_entr_fractured = {
				name = "Fractured Tag",
				text = { 
					"Next base Edition shop",
					"Joker is free and",
					"becomes {C:dark_edition}Fractured{}"	
				},
			},
			tag_entr_freaky = {
				name = "Freaky Tag",
				text = { 
					"Next base Edition shop",
					"Joker is free and",
					"becomes {C:dark_edition}Freaky{}"	
				},
			},

			tag_entr_neon = {
				name = "Neon Tag",
				text = { 
					"Next base Edition shop",
					"Joker is free and",
					"becomes {C:dark_edition}Neon{}"	
				},
			},

			tag_entr_lowres = {
				name = "Low-Res Tag",
				text = { 
					"Next base Edition shop",
					"Joker is free and",
					"becomes {C:dark_edition}Low-Res{}"	
				},
			},
			tag_entr_kaleidoscopic = {
				name = "Kaleidoscopic Tag",
				text = { 
					"Next base Edition shop",
					"Joker is free and",
					"becomes {C:dark_edition}Kaleidoscopic{}"	
				},
			},
			tag_entr_gilded = {
				name = "Gilded Tag",
				text = { 
					"Next base Edition shop",
					"Joker is free and",
					"becomes {C:dark_edition}Gilded{}"	
				},
			},

			tag_entr_ascendant_rare = {
				name = "{C:gold}Rare Tag{}",
				text = { "Shop has a free", "{C:rare}Rare Joker{}" },
			},
			tag_entr_ascendant_epic = {
				name = "{C:gold}Epic Tag{}",
				text = { "Shop has a free", "{C:cry_epic}Epic Joker{}" },
			},
			tag_entr_ascendant_legendary = {
				name = "{C:gold}Legendary Tag{}",
				text = { "Shop has a free", "{C:legendary}Legendary Joker{}" },
			},
			tag_entr_ascendant_exotic = {
				name = "{C:gold}Exotic Tag{}",
				text = { "Shop has a free", "{C:cry_exotic}Exotic Joker{}" },
			},
			tag_entr_ascendant_entropic = {
				name = "{C:gold}Entropic Tag{}",
				text = { "Shop has a free", "{C:entr_entropic}Entropic Joker{}" },
			},
			tag_entr_ascendant_copying = {
				name = "{C:gold}Duplicate Tag{}",
				text = { "Gives {C:attention}#1#{} copies of the", "next selected Tag", "{C:inactive}(Copying tags excluded){}" },
			},
			tag_entr_ascendant_voucher = {
				name = "{C:gold}Voucher Tag{}",
				text = { "Adds one tier {C:attention}3{} Voucher", "to the next shop" },
			},
			tag_entr_ascendant_voucher_cryptidless = {
				name = "{C:gold}Voucher Tag{}",
				text = { "Adds {C:attention}two{} Vouchers", "to the next shop" },
			},
			tag_entr_ascendant_better_voucher = {
				name = "{C:gold}Pristine Voucher Tag{}",
				text = { "Adds 2 tier {C:attention}3{} Vouchers", "to the next shop" },
			},
			tag_entr_ascendant_saint = {
				name = "{C:gold}Saint Tag{}",
				text = { "Shop has a free", "{C:attention}Editioned Candy Joker{}" },
			},
			tag_entr_ascendant_negative = {
				name = "{C:gold}Negative Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Negative{}" },
			},
			tag_entr_ascendant_foil = {
				name = "{C:gold}Foil Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Foil{}" },
			},
			tag_entr_ascendant_holo = {
				name = "{C:gold}Holographic Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Holographic{}" },
			},
			tag_entr_ascendant_poly = {
				name = "{C:gold}Polychrome Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Polychrome{}" },
			},
			tag_entr_ascendant_glass = {
				name = "{C:gold}Fragile Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Fragile{}" },
			},
			tag_entr_ascendant_glitched = {
				name = "{C:gold}Glitched Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Glitched{}" },
			},
			tag_entr_ascendant_gold = {
				name = "{C:gold}Golden Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Golden{}" },
			},
			tag_entr_ascendant_blurry = {
				name = "{C:gold}Blurred Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Blurred{}" },
			},
			tag_entr_ascendant_m = {
				name = "{C:gold}M Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Jolly{}", "{C:inactive}M{}" },
			},
			tag_entr_ascendant_mosaic = {
				name = "{C:gold}Mosaic Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Mosaic{}" },
			},
			tag_entr_ascendant_astral = {
				name = "{C:gold}Astral Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Astral{}" },
			},
			tag_entr_ascendant_oversat = {
				name = "{C:gold}Oversaturated Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Oversaturated{}" },
			},
			tag_entr_ascendant_sunny = {
				name = "{C:gold}Sunny Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Sunny{}" },
			},
			tag_entr_ascendant_solar = {
				name = "{C:gold}Solar Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Solar{}" },
			},
			tag_entr_ascendant_fractured = {
				name = "{C:gold}Fractured Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Fractured{}" },
			},
			tag_entr_ascendant_freaky = {
				name = "{C:gold}Freaky Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Freaky{}" },
			},

			tag_entr_ascendant_neon = {
				name = "{C:gold}Neon Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Neon{}" },
			},
			tag_entr_ascendant_lowres = {
				name = "{C:gold}Low-Res Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Low-Res{}" },
			},
			tag_entr_ascendant_kaleidoscopic = {
				name = "{C:gold}Kaleidoscopic Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Kaleidoscopic{}" },
			},
			tag_entr_ascendant_gilded = {
				name = "{C:gold}Gilded Tag{}",
				text = { "{C:attention}All{} shop items are {C:dark_edition}Gilded{}" },
			},

			tag_entr_ascendant_infdiscard = {
				name = "{C:gold}Discard Tag{}",
				text = { "{C:attention}+3{} discards", "next round" },
			},
			tag_entr_ascendant_cat = {
				name = "{C:gold}Cat Tag{}",
				text = { "{C:gold}Meow.{}", "{C:inactive}Level {C:dark_edition}#1#" },
			},
			tag_entr_ascendant_dog = {
				name = "{C:gold}Dog Tag{}",
				text = { "{C:red}Woof.{}", "{C:inactive}Level {C:dark_edition}#1#" },
			},
			tag_entr_ascendant_canvas = {
				name = "{C:gold}Canvas Tag{}",
				text = { "Shop has a", "{C:attention}Canvas{}" },
			},
			tag_entr_ascendant_unbounded = {
				name = "{C:gold}Unbounded Tag{}",
				text = {"Gives a free {C:spectral}Spectral Pack",
				"with {C:green,E:1}Pointer{} and {C:entr_entropic,E:1}Beyond{}", },
			},
			tag_entr_ascendant_ejoker = {
				name = "{C:gold}Buffoon Tag{}",
				text = { "Gives a free Editioned", "{C:attention}Mega Buffoon Pack{}" },
			},
			tag_entr_ascendant_universal = {
				name = "{C:gold}Universal Tag{}",
				text = { "Level up {C:attention}#1#{}", "{C:gold}+3{} Ascension Power" },
			},
			tag_entr_ascendant_ebundle = {
				name = "{C:gold}Bundle Tag{}",
				text = {"Creates a {C:attention}Console Tag{}, {C:attention}Ethereal Tag{},",
				"{C:attention}Twisted Tag{}, and {C:attention}Bundle Tag{}", },
			},
			tag_entr_ascendant_twisted = {
				name = "{C:gold}Twisted Tag{}",
				text = {"Gives a free","{C:red}Twisted Pack{}", },
			},
			tag_entr_ascendant_stock = {
				name = "{C:gold}Stock Tag{}",
				text = {"Multiplies your money by 2X", },
			},
			tag_entr_ascendant_blind = {
				name = "{C:gold}Blind Tag{}",
				text = {"Gives a free","{C:attention}Blind Pack{}", },
			},
			tag_entr_ascendant_reference = {
				name = "{C:gold}Reference Tag{}",
				text = {"Gives a free","{C:green}Reference Pack{}", },
			},
			tag_entr_ascendant_cavendish = {
				name = "{C:gold}Cavendish Tag{}",
				text = {"Gives a free","{C:attention}Cavendish{}", },
			},
			tag_entr_ascendant_credit = {
				name = "{C:gold}Credit Tag{}",
				text = {"Initial cards and", "Booster Packs in the next", "shop are free", "Rerolls start at {C:gold}-$5{}" },
			},

			tag_entr_ascendant_topup = {
				name = "{C:gold}Top-Up Tag{}",
				text = {
					"Creates up to {C:attention}3{}",
					"{C:green}Uncommon{} Jokers",
					"{C:inactive}(Must have room){}",
				},
			},
			tag_entr_ascendant_better_topup = {
				name = "{C:gold}Better Top-Up Tag{}",
				text = {
					"Creates up to {C:attention}3{}",
					"{C:red}Rare{} Jokers",
					"{C:inactive}(Must have room){}",
				},
			},
			tag_entr_ascendant_booster = {
				name = "{C:gold}Booster Tag{}",
				text = {
					"Next {C:cry_code}Booster Pack{} has",
					"{C:attention}triple{} cards and",
					"{C:attention}triple{} choices",
				},
			},
			tag_entr_ascendant_effarcire = {
				name = "{C:gold}Infinite Tag{}",
				text = {
					"Draw {C:green}full deck{} to hand", "next round"
				},
			},
			tag_entr_arcane = {
				name = "Arcane Tag",
				text = {
					"Obtain a random {C:purple}Rune{}"
				},
			},
			tag_entr_ascendant_arcane = {
				name = "{C:gold}Arcane Tag{}",
				text = {
					"Obtain {C:attention}two{} random {C:purple}Runes{}"
				},
			},

			tag_entr_ascendant_negative_eternal = {
				name = "{C:gold}Negative Eternal Tag{}",
				text = { "{C:attention}All{} shop items are","{C:dark_edition}Negative{} and {C:attention}Eternal{}" },
			},
			tag_entr_ascendant_kitty = {
				name = "{C:gold}Kitty Tag{}",
				text = { "Every {C:attention}Kitty Tag{} owned", "gives {X:chips,C:white}X#1#{} Chips" },
			},

			tag_entr_asc_additive = {
				name = "{C:gold}Additive Tag{}",
				text = { "{C:green}#1# in #2# chance to enhance", "played Blinds" },
			},
			tag_entr_asc_max = {
				name = "{C:gold}Max Tag{}",
				text = { "{C:red}X2{} Mult and","{C:blue}X2{} Chips", "after hand is scored" },
			},
			tag_entr_asc_symmetry = {
				name = "{C:gold}Symmetry Tag{}",
				text = { "Retrigger each scoring Blind","{C:green}#1# in #2# chance to retrigger", "each scoring Blind twice" },
			},
			tag_entr_asc_recursive = {
				name = "{C:gold}Recursive Tag{}",
				text = { "{X:blue,C:white}X0.1{} Chips for", "each held tag", "{C:inactive}({X:blue,C:white}X#2#{C:inactive} Chips)" },
			},
			tag_entr_asc_wave = {
				name = "{C:gold}Wave Tag{}",
				text = { "Every {C:attention}played Blind{}", "counts in scoring" },
			},
			tag_entr_asc_prison_break = {
				name = "{C:gold}Prisonbreak Tag{}",
				text = { "Disable all {C:attention}Jokers", "this Ante" },
			},
			tag_entr_asc_collector = {
				name = "{C:gold}Collector Tag{}",
				text = { "Next opened {C:attention}Symbol Pack{}", "will have Editioned upgraded Blinds" },
			},
			tag_entr_asc_memory = {
				name = "{C:gold}Memory Tag{}",
				text = { "Create a random {C:bld_keepsake,E:1}Editioned Keepsake{}", "{C:inactive}(Must have room)" },
			},
			tag_entr_asc_magic = {
				name = "{C:gold}Magic Tag{}",
				text = { "Create a random {C:attention,E:1}Editioned Trinket{}", "{C:inactive}(Must have room)" },
			},
			tag_entr_asc_debuff = {
				name = "{C:gold}Debuff Tag{}",
				text = { "Halve {C:blue}Chips{} and {C:red}Mult{} after scoring", "if played hand is a {C:attention}#1#{}" },
			},
			tag_entr_asc_joker = {
				name = "{C:gold}Joker Tag{}",
				text = { "{C:red}+0.5{} Mult to Joker", "after each played hand" },
			},
			tag_entr_asc_mantle = {
				name = "{C:gold}Mantle Tag{}",
				text = { "Each hand, {C:red}destroys{}", "{C:attention}1{} played Blind" },
			},
			tag_entr_asc_awe = {
				name = "{C:gold}Awe Tag{}",
				text = { "Before each hand,", "{C:red}Debuff{} either your", "{C:attention}leftmost{} or {C:attention}rightmost{}", "Trinket" },
			},
			tag_entr_asc_downpour = {
				name = "{C:gold}Downpour Tag{}",
				text = { "After each hand,", "{C:green}#1# in #2#{} chance for each", "played Blind to lose", "all {C:attention}Modifiers{}" },
			},
			tag_entr_asc_voodoo = {
				name = "{C:gold}Voodoo Tag{}",
				text = { "Gives an unskippable", "{C:attention}Voodoo Pack{}" },
			},
			tag_entr_asc_burden = {
				name = "{C:gold}Burden Tag{}",
				text = { "After each hand,", "lose a {C:attention}third{} of held", "{C:money}money{} rounded down" },
			},

			tag_curse_entr_blind = {
				name = "Curse of The Blind",
				text = {
					"Cards in the shop",
					"may be {C:red}flipped{}"
				}
			},
			tag_curse_entr_darkness = {
				name = "Curse of Darkness",
				text = {
					"Booster packs have",
					"{C:red}fewer{} choices"
				}
			},
			tag_curse_entr_lost = {
				name = "Curse of The Lost",
				text = {
					"No {C:red}Small Blind{}"
				}
			},
			tag_curse_entr_maze = {
				name = "Curse of The Maze",
				text = {
					"Blind order is {C:red}Randomized{}"
				}
			},
		},
		["Rune Tag"] = {
			rune_entr_fehu = {
				name = "Fehu",
				text = {
					"The next {C:attention}sold{} card",
					"adds {C:attention}half{} its sell",
					"value to your Jokers"
				}
			},
			rune_entr_fehu_providence = {
				name = "Fehu{C:purple}+{}",
				text = {
					"The next {C:attention}sold{} card",
					"adds its {C:purple,E:1}full{} sell",
					"value to your Jokers"
				}
			},
			rune_entr_uruz = {
				name = "Uruz",
				text = {
					"Increases the next",
					"{C:attention}Payout{} by {X:gold,C:white}50%{}",
					"{C:inactive}(Stacks additively){}"
				}
			},
			rune_entr_uruz_providence = {
				name = "Uruz{C:purple}+{}",
				text = {
					"Increases the next",
					"{C:attention}Payout{} by {X:purple,C:white,E:1}100%{}",
					"{C:inactive}(Stacks additively){}"
				}
			},
			rune_entr_thurisaz = {
				name = "Thurisaz",
				text = {
					"Copies the next",
					"{C:attention}discarded{} card"
				}
			},
			rune_entr_thurisaz_providence = {
				name = "Thurisaz{C:purple}+{}",
				text = {
					"Copies the next",
					"{C:attention}discarded{} card {C:purple,E:1}twice{}"
				}
			},
			rune_entr_ansuz = {
				name = "Ansuz",
				text = {
					"Copies the next",
					"{C:attention}obtained{} Tag or Rune"
				}
			},
			rune_entr_ansuz_providence = {
				name = "Ansuz{C:purple}+{}",
				text = {
					"Copies the next",
					"{C:attention}obtained{} Tag or Rune {C:purple,E:1}twice{}"
				}
			},
			rune_entr_raido = {
				name = "Raido",
				text = {
					"{C:green}#1# in #2#{} chance",
					"to prevent the next",
					"change of Ante",
				}
			},
			rune_entr_raido_providence = {
				name = "Raido{C:purple}+{}",
				text = {
					"{C:purple,E:1}Prevents{} the next",
					"change of Ante",
				}
			},
			rune_entr_kaunan = {
				name = "Kaunan",
				text = {
					"Levels up the",
					"next {C:attention}played{} hand"
				}
			},
			rune_entr_kaunan_providence = {
				name = "Kaunan{C:purple}+{}",
				text = {
					"Levels up the",
					"next {C:attention}played{} hand",
					"{C:purple,E:1}twice{}"
				}
			},
			rune_entr_gebo = {
				name = "Gebo",
				text = {
					"Creates a card of",
					"the same type as the",
					"next {C:attention}sold{} card",
					"{C:inactive}(Must have room){}"
				}
			},
			rune_entr_gebo_providence = {
				name = "Gebo{C:purple}+{}",
				text = {
					"Creates a card of",
					"the same type as the",
					"next {C:attention}sold{} card",
					"{C:purple,E:1}(May overflow){}"
				}
			},

			rune_entr_wunjo = {
				name = "Wunjo",
				text = {
					"Creates a {C:attention}random{} {C:purple}Rune{}",
					"when the next consumable",
					"is used"
				}
			},
			rune_entr_wunjo_providence = {
				name = "Wunjo{C:purple}+{}",
				text = {
					"Creates {C:purple}2{} {C:attention}random{} {C:purple}Runes{}",
					"when the next consumable",
					"is used"
				}
			},

			rune_entr_haglaz = {
				name = "Haglaz",
				text = {
					"{C:red}Destroys{} the next",
					"played hand"
				}
			},
			rune_entr_haglaz_providence = {
				name = "Haglaz{C:purple}+{}",
				text = {
					"{C:red}Destroys{} the next",
					"played or {C:purple,E:1}discarded{} hand"
				}
			},

			rune_entr_naudiz = {
				name = "Naudiz",
				text = {
					"Next item can",
					"be bought {C:attention}regardless{}",
					"of your current money"
				}
			},
			rune_entr_naudiz_providence = {
				name = "Naudiz{C:purple}+{}",
				text = {
					"Next item can",
					"be bought {C:attention}regardless{}",
					"of your current money",
					"{C:purple,E:1}Obtain no debt from this{}"
				}
			},

			rune_entr_isaz = {
				name = "Isaz",
				text = {
					"Adds an additional",
					"{C:attention}Voucher{} to the",
					"next shop"
				}
			},
			rune_entr_isaz_providence = {
				name = "Isaz{C:purple}+{}",
				text = {
					"Adds an additional",
					"{C:purple,E:1}half price{} {C:attention}Voucher{} to",
					"the next shop"
				}
			},

			rune_entr_jera = {
				name = "Jera",
				text = {
					"Copies the next",
					"{C:attention}used{} consumable"
				}
			},
			rune_entr_jera_providence = {
				name = "Jera{C:purple}+{}",
				text = {
					"Copies the next",
					"{C:attention}used{} consumable",
					"{C:purple,E:1}twice{}"
				}
			},

			rune_entr_ihwaz = {
				name = "Ihwaz",
				text = {
					"Randomizes one aspect of",
					"the next {C:attention}played{} card"
				}
			},
			rune_entr_ihwaz_providence = {
				name = "Ihwaz{C:purple}+{}",
				text = {
					"{C:purple,E:1}Fully{} randomizes",
					"the next {C:attention}played{} card"
				}
			},

			rune_entr_perthro = {
				name = "Perthro",
				text = {
					"Restocks {C:attention}Booster Packs{}",
					"on the next {C:attention}reroll{}"
				}
			},
			rune_entr_perthro_providence = {
				name = "Perthro{C:purple}+{}",
				text = {
					"Restocks {C:attention}Booster Packs{}",
					"and grants {C:purple,E:1}+1{} temporary",
					"shop slot on the next {C:attention}reroll{}"
				}
			},

			rune_entr_algiz = {
				name = "Algiz",
				text = {
					"Costs {C:money}$10{} to",
					"prevent the next {C:red}Death{}",

				}
			},
			rune_entr_algiz_providence = {
				name = "Algiz{C:purple}+{}",
				text = {
					"Costs {C:purple,E:1}$5{} to",
					"prevent the next {C:red}Death{}",
				}
			},

			rune_entr_sowilo = {
				name = "Sowilo",
				text = {
					"Gives the next {C:attention}discarded{} hand",
					"{C:gold}+2{} Ascension Power"

				}
			},
			rune_entr_sowilo_providence = {
				name = "Sowilo{C:purple}+{}",
				text = {
					"Gives the next {C:attention}discarded{} hand",
					"{C:purple,E:1}+4{} Ascension Power"
				}
			},

			rune_entr_tiwaz = {
				name = "Tiwaz",
				text = {
					"Randomly {C:attention}modifies{}",
					"the next {C:attention}drawn card{}"

				}
			},
			rune_entr_tiwaz_providence = {
				name = "Tiwaz{C:purple}+{}",
				text = {
					"Randomly {C:attention}modifies{}",
					"the next {C:attention}drawn card{}",
					"{C:purple,E:1}twice{}"
				}
			},

			rune_entr_berkano = {
				name = "Berkano",
				text = {
					"Creates {C:attention}two{} copies",
					"of the next {C:red}destroyed{} card"

				}
			},
			rune_entr_berkano_providence = {
				name = "Berkano{C:purple}+{}",
				text = {
					"Creates {C:purple,E:1}three{} copies",
					"of the next {C:red}destroyed{} card"
				}
			},

			rune_entr_ehwaz = {
				name = "Ehwaz",
				text = {
					"Gives access to a {C:attention}Payout{} and a {C:attention}shop{}",
					"on the next {C:attention}skipped{} Blind"

				}
			},
			rune_entr_ehwaz_providence = {
				name = "Ehwaz{C:purple}+{}",
				text = {
					"Gives access to a {C:attention}Payout{} and a {C:attention}shop{}",
					"with {C:purple,E:1}+1{} shop slot",
					"on the next {C:attention}skipped{} Blind"
				}
			},

			rune_entr_mannaz = {
				name = "Mannaz",
				text = {
					"Adds a {C:spectral}Spectral{} card to",
					"the next {C:attention}opened{} Booster Pack"

				}
			},
			rune_entr_mannaz_providence = {
				name = "Mannaz{C:purple}+{}",
				text = {
					"Adds {C:purple,E:1}two{} {C:spectral}Spectral{} cards to",
					"the next {C:attention}opened{} Booster Pack"
				}
			},

			rune_entr_laguz = {
				name = "Laguz",
				text = {
					"Refunds the next {C:attention}discard{}"
				}
			},
			rune_entr_laguz_providence = {
				name = "Laguz{C:purple}+{}",
				text = {
					"Refunds the next {C:attention}discard{}",
					"and temporarily gives {C:purple,E:1}+1{} hand"
				}
			},

			rune_entr_ingwaz = {
				name = "Ingwaz",
				text = {
					"The next {C:attention}probability{} roll",
					"will {C:green}succeed{}"
				}
			},
			rune_entr_ingwaz_providence = {
				name = "Ingwaz{C:purple}+{}",
				text = {
					"The next {C:attention}probability{} roll",
					"will {C:green}succeed{} with a",
					"{C:purple,E:1}33%{} chance to not consume",
					"this Rune when triggered"
				}
			},

			rune_entr_dagaz = {
				name = "Dagaz",
				text = {
					"Inverts the next",
					"{C:attention}obtained{} consumable"
				}
			},
			rune_entr_dagaz_providence = {
				name = "Dagaz{C:purple}+{}",
				text = {
					"Inverts the next",
					"{C:attention}obtained{} consumable",
					"{C:purple,E:1}Create{} a random Inverted",
					"consumable when this occurs",
					"{C:inactive}(Must have room){}"
				}
			},

			rune_entr_othila = {
				name = "Othila",
				text = {
					"The next {C:attention}sold{} card gives",
					"{X:gold,C:white}X3{} as much money"
				}
			},
			rune_entr_othila_providence = {
				name = "Ohtila{C:purple}+{}",
				text = {
					"The next {C:attention}sold{} card gives",
					"{X:purple,C:white,E:1}X5{} as much money"
				}
			},

			rune_entr_oss = {
				name = "Oss",
				text = {
					"The next opened {C:attention}Booster Pack{}",
					"will contain a {C:legendary,E:1}hidden{} consumable",
					"{C:inactive}(If possible)"
				}
			},
			rune_entr_oss_providence = {
				name = "Oss{C:purple}+{}",
				text = {
					"The next opened {C:attention}Booster Pack{}",
					"will contain a {C:legendary,E:1}hidden{} consumable",
					"and a {C:purple}Rune{} is {C:purple,E:1}generated{} when this occurs",
					"{C:inactive}(If possible)"
				}
			},
			--pacts
			rune_entr_avarice = {
				name = "Mark of Avarice",
				text = {
					{
						"Marked by {C:red}Avarice{}"
					},
					{
						"All sell values are",
						"multiplied by {X:red,C:white}X#1#{}"
					}
				}
			},
			rune_entr_rage = {
				name = "Mark of Rage",
				text = {
					"Marked by {C:red}Rage{}"
				}
			},
			rune_entr_thorns = {
				name = "Mark of Thorns",
				text = {
					"Marked by {C:red}Thorns{}"
				}
			},
			rune_entr_denial = {
				name = "Mark of Denial",
				text = {
					"Marked by {C:red}Denial{}"
				}
			},
			rune_entr_chains = {
				name = "Mark of Chains",
				text = {
					{
						"Marked by {C:red}Chains{}"
					},
					{
						"Retrigger all {C:attention}Eternal{} playing cards",
						"The first {C:attention}drawn{} card each round becomes {C:attention}Eternal{}"
					}
				}
			},
			rune_entr_decay = {
				name = "Mark of Decay",
				text = {
					"Marked by {C:red}Decay{}"
				}
			},
			rune_entr_envy = {
				name = "Mark of Envy",
				text = {
					{
						"Marked by {C:red}Envy{}"
					},
					{
						"Retrigger a {C:attention}random{} Joker,",
						"target {C:attention}changes{} every round"
					}
				}
			},
			rune_entr_youth = {
				name = "Mark of Youth",
				text = {
					"Marked by {C:red}Youth{}"
				}
			},
			rune_entr_shards = {
				name = "Mark of Shards",
				text = {
					{
						"Marked by {C:red}Shards{}"
					},
					{
						"Playing card {C:red}destruction{}",
						"may {C:red}fail{}"
					}
				}
			},
			rune_entr_desire = {
				name = "Mark of Desire",
				text = {
					{
						"Marked by {C:red}Desire{}"
					},
					{
						"{C:attention}Booster Packs{} are",
						"more {C:red}expensive{}"
					}
				}
			},
			rune_entr_ice = {
				name = "Mark of Ice",
				text = {
					{
						"Marked by {C:red}Ice{}"
					},
					{
						"Your most {C:attention}levelled{} hand",
						"{C:red}cannot{} change levels"
					}
				}
			},
			rune_entr_gluttony = {
				name = "Mark of Gluttony",
				text = {
					{
						"Marked by {C:red}Gluttony{}"
					},
					{
						"{C:red}All{} consumables are {C:attention}Eternal"
					}
				}
			},
			rune_entr_rebirth = {
				name = "Mark of Rebirth",
				text = {
					{
						"Marked by {C:red}Rebirth{}"
					},
					{
						"Playing cards are {C:attention}duplicated{}",
						"instead of being {C:red}destroyed{}"
					}
				}
			},
			rune_entr_despair = {
				name = "Mark of Despair",
				text = {
					"Marked by {C:red}Despair{}"
				}
			},
			rune_entr_strength = {
				name = "Mark of Strength",
				text = {
					"Marked by {C:red}Strength{}"
				}
			},			
			rune_entr_darkness = {
				name = "Mark of Darkness",
				text = {
					{
						"Marked by {C:red}Darkness{}"
					},
					{
						"Playing cards may be",
						"drawn face {C:red}down{}"
					}
				}
			},
			rune_entr_freedom = {
				name = "Mark of Freedom",
				text = {
					"Marked by {C:red}Freedom{}"
				}
			},
			rune_entr_eternity = {
				name = "Mark of Eternity",
				text = {
					"Marked by {C:red}Eternity{}"
				}
			},
			rune_entr_loyalty = {
				name = "Mark of Loyalty",
				text = {
					{
						"Marked by {C:red}Loyalty{}"
					},
					{
						"Interest Rate is now every {C:money}$#1#{}",
						"{X:mult,C:white}X#2#{} Mult every other hand"
					}
				}
			},
			rune_entr_brimstone = {
				name = "Mark of Brimstone",
				text = {
					{
						"Marked by {C:red}Brimstone{}"
					},
					{
						"{X:mult,C:white}X#1#{} Mult after hand played",
						"on the {C:attention}final hand{} of round"
					}
				}
			},
			rune_entr_dreams = {
				name = "Mark of Dreams",
				text = {
					{
						"Marked by {C:red}Dreams{}"
					},
					{
						"Small Blinds give no {C:attention}Reward{}"
					}
				}
			},
			rune_entr_energy = {
				name = "Mark of Energy",
				text = {
					"Marked by {C:red}Energy{}"
				}
			},
			rune_entr_blood = {
				name = "Mark of Blood",
				text = {
					"Marked by {C:red}Blood{}"
				}
			},
			rune_entr_awakening = {
				name = "Mark of Awakening",
				text = {
					"Marked by {C:red}Awakening{}"
				}
			},
			rune_entr_serpents = {
				name = "Mark of Serpents",
				text = {
					"Marked by {C:red}Serpents{}",
					"{C:red,E:1,s:0.8}Your Fate is sealed{}"
				}
			},
		},
		Rune = {
			c_entr_fehu = {
				name = "Rune of Fehu",
				text = {
					"The next {C:attention}sold{} card",
					"adds {C:attention}half{} its sell",
					"value to your Jokers"
				}
			},
			c_entr_fehu_providence = {
				name = "Rune of Fehu{C:purple}+{}",
				text = {
					"The next {C:attention}sold{} card",
					"adds its {C:purple,E:1}full{} sell",
					"value to your Jokers"
				}
			},
			c_entr_uruz = {
				name = "Rune of Uruz",
				text = {
					"The next {C:attention}Payout{} is",
					"increased by {X:gold,C:white}50%{}",
					"{C:inactive}(Stacks additively){}"
				}
			},
			c_entr_uruz_providence = {
				name = "Rune of Uruz{C:purple}+{}",
				text = {
					"The next {C:attention}Payout{} is",
					"increased by {X:purple,C:white,E:1}100%{}",
					"{C:inactive}(Stacks additively){}"
				}
			},
			c_entr_thurisaz = {
				name = "Rune of Thurisaz",
				text = {
					"Create a {C:attention}copy{} of",
					"the next {C:attention}discarded{} card",
					"and draw it to {C:attention}hand{}"
				}
			},
			c_entr_thurisaz_providence = {
				name = "Rune of Thurisaz{C:purple}+{}",
				text = {
					"Create {C:purple,E:1}two{} {C:attention}copies{} of",
					"the next {C:attention}discarded{} card",
					"and draw it to {C:attention}hand{}"
				}
			},
			c_entr_ansuz = {
				name = "Rune of Ansuz",
				text = {
					"Create a {C:attention}copy{} of",
					"the next {C:attention}obtained{} Tag or Rune",
				}
			},
			c_entr_ansuz_providence = {
				name = "Rune of Ansuz{C:purple}+{}",
				text = {
					"Create {C:purple,E:1}two{} {C:attention}copies{} of",
					"the next {C:attention}obtained{} Tag or Rune",
				}
			},
			c_entr_raido = {
				name = "Rune of Raido",
				text = {
					"{C:green}#1# in #2#{} chance that",
					"the next {C:attention}change{} in",
					"Ante is prevented"
				}
			},
			c_entr_raido_providence = {
				name = "Rune of Raido{C:purple}+{}",
				text = {
					"The next {C:attention}change{} in",
					"Ante is {C:purple,E:1}prevented{}"
				}
			},
			c_entr_kaunan = {
				name = "Rune of Kaunan",
				text = {
					"Level up the",
					"next {C:attention}played{} hand"
				}
			},
			c_entr_kaunan_providence = {
				name = "Rune of Kaunan{C:purple}+{}",
				text = {
					"Level up the",
					"next {C:attention}played{} hand",
					"{C:purple,E:1}twice{}"
				}
			},

			c_entr_gebo = {
				name = "Rune of Gebo",
				text = {
					"Creates a card of",
					"the same type as the",
					"next {C:attention}sold{} card",
					"{C:inactive}(Must have room){}"
				}
			},
			c_entr_gebo_providence = {
				name = "Rune of Gebo{C:purple}+{}",
				text = {
					"Creates a card of",
					"the same type as the",
					"next {C:attention}sold{} card",
					"{C:purple,E:1}(May overflow){}"
				}
			},

			c_entr_wunjo = {
				name = "Rune of Wunjo",
				text = {
					"Create a {C:attention}random{} {C:purple}Rune{}",
					"when the next consumable",
					"is used"
				}
			},
			c_entr_wunjo_providence = {
				name = "Rune of Wunjo{C:purple}+{}",
				text = {
					"Create {C:purple}2{} {C:attention}random{} {C:purple}Runes{}",
					"when the next consumable",
					"is used"
				}
			},

			c_entr_haglaz = {
				name = "Rune of Haglaz",
				text = {
					"{C:red}Destroy{} the next",
					"played hand"
				}
			},
			c_entr_haglaz_providence = {
				name = "Rune of Haglaz{C:purple}+{}",
				text = {
					"{C:red}Destroy{} the next",
					"played or {C:purple,E:1}discarded{} hand"
				}
			},

			c_entr_naudiz = {
				name = "Rune of Naudiz",
				text = {
					"The next {C:attention}bought{} shop card",
					"can be bought {C:attention}regardless{} of",
					"your current money, sending",
					"you into {C:attention}debt{} if needed"
				}
			},
			c_entr_naudiz_providence = {
				name = "Rune of Naudiz{C:purple}+{}",
				text = {
					"The next {C:attention}bought{} shop card",
					"can be bought {C:attention}regardless{} of",
					"your current money",
					"{C:purple,E:1}without gaining any debt{}"
				}
			},

			c_entr_isaz = {
				name = "Rune of Isaz",
				text = {
					"The next {C:attention}shop{}",
					"contains an additional {C:attention}Voucher{}"
				}
			},
			c_entr_isaz_providence = {
				name = "Rune of Isaz{C:purple}+{}",
				text = {
					"The next {C:attention}shop{}",
					"contains an additional {C:attention}Voucher{}",
					"at {C:purple,E:1}half price{}"
				}
			},

			c_entr_jera = {
				name = "Rune of Jera",
				text = {
					"Create a {C:attention}copy{} of",
					"the next {C:attention}used{}",
					"consumable",
					"{C:inactive}(Hidden consumables excluded)"
				}
			},
			c_entr_jera_providence = {
				name = "Rune of Jera{C:purple}+{}",
				text = {
					"Create {C:purple,E:1}two{} {C:attention}copies{} of",
					"the next {C:attention}used{}",
					"consumable"
				}
			},
			c_entr_ihwaz = {
				name = "Rune of Ihwaz",
				text = {
					"Randomize one aspect of",
					"the next {C:attention}played{} card"
				}
			},
			c_entr_ihwaz_providence = {
				name = "Rune of Ihwaz{C:purple}+{}",
				text = {
					"{C:purple,E:1}Fully{} randomize the",
					"next {C:attention}played{} card"
				}
			},

			c_entr_perthro = {
				name = "Rune of Perthro",
				text = {
					"Restock {C:attention}Booster Packs{}",
					"on the next {C:attention}reroll{}"
				}
			},
			c_entr_perthro_providence = {
				name = "Rune of Perthro{C:purple}+{}",
				text = {
					"Restock {C:attention}Booster Packs{}",
					"and {C:attention}temporarily{} grant",
					"{C:purple,E:1}+1{} shop slots",
					"on the next {C:attention}reroll{}"
				}
			},

			c_entr_algiz = {
				name = "Rune of Algiz",
				text = {
					"Costs {C:money}$10{} to",
					"prevent the next {C:red}Death{}",
				}
			},
			c_entr_algiz_providence = {
				name = "Rune of Algiz{C:purple}+{}",
				text = {
					"Costs {C:purple,E:1}$5{} to",
					"prevent the next {C:red}Death{}",
				}
			},

			c_entr_sowilo = {
				name = "Rune of Sowilo",
				text = {
					"The next {C:attention}discarded{} hand",
					"gains {C:gold}+2{} Ascension Power"
				}
			},
			c_entr_sowilo_providence = {
				name = "Rune of Sowilo{C:purple}+{}",
				text = {
					"The next {C:attention}discarded{} hand",
					"gains {C:purple,E:1}+4{} Ascension Power"
				}
			},

			c_entr_tiwaz = {
				name = "Rune of Tiwaz",
				text = {
					"The next {C:attention}drawn{} card",
					"gains a {C:attention}random{} modification"
				}
			},
			c_entr_tiwaz_providence = {
				name = "Rune of Tiwaz{C:purple}+{}",
				text = {
					"The next {C:attention}drawn{} card",
					"gains {C:purple,E:1}two{} {C:attention}random{} modifications"
				}
			},

			c_entr_berkano = {
				name = "Rune of Berkano",
				text = {
					"Create {C:attention}two{} copies of",
					"the next {C:red}destroyed{} card"
				}
			},
			c_entr_berkano_providence = {
				name = "Rune of Berkano{C:purple}+{}",
				text = {
					"Create {C:purple,E:1}three{} copies of",
					"the next {C:red}destroyed{} card"
				}
			},

			c_entr_ehwaz = {
				name = "Rune of Ehwaz",
				text = {
					"Gives access to a {C:attention}Payout{} and a {C:attention}shop{}",
					"on the next {C:attention}skipped{} Blind"
				}
			},
			c_entr_ehwaz_providence = {
				name = "Rune of Ehwaz{C:purple}+{}",
				text = {
					"Gives access to a {C:attention}Payout{} and a {C:attention}shop{}",
					"with {C:purple,E:1}+1 shop slots{}",
					"on the next {C:attention}skipped{} Blind"
				}
			},

			c_entr_mannaz = {
				name = "Rune of Mannaz",
				text = {
					"The next {C:attention}opened{} Booster Pack",
					"will contain a {C:spectral}Spectral{} card"
				}
			},
			c_entr_mannaz_providence = {
				name = "Rune of Mannaz{C:purple}+{}",
				text = {
					"The next {C:attention}opened{} Booster Pack",
					"will contain {C:purple,E:1}two{} {C:spectral}Spectral{} cards"
				}
			},

			c_entr_laguz = {
				name = "Rune of Laguz",
				text = {
					"The next {C:attention}discard{}",
					"is refunded"
				}
			},
			c_entr_laguz_providence = {
				name = "Rune of Laguz{C:purple}+{}",
				text = {
					"The next {C:attention}discard{}",
					"is refunded and temporarily",
					"gives {C:purple,E:1}+1{} hands"
				}
			},

			c_entr_ingwaz = {
				name = "Rune of Ingwaz",
				text = {
					"The next {C:attention}probability{} roll",
					"will {C:green}succeed{}"
				}
			},
			c_entr_ingwaz_providence = {
				name = "Rune of Ingwaz{C:purple}+{}",
				text = {
					"The next {C:attention}probability{} roll",
					"will {C:green}succeed{} with a",
					"{C:purple,E:1}33%{} chance to not consume",
					"this Rune when triggered"
				}
			},

			c_entr_dagaz = {
				name = "Rune of Dagaz",
				text = {
					"Invert the next",
					"{C:attention}obtained{} consumable"
				}
			},
			c_entr_dagaz_providence = {
				name = "Rune of Dagaz{C:purple}+{}",
				text = {
					"Invert the next",
					"{C:attention}obtained{} consumable and",
					"{C:purple,E:1}create{} a random Inverted",
					"consumable when this occurs",
					"{C:inactive}(Must have room){}"
				}
			},
			c_entr_othila = {
				name = "Rune of Othila",
				text = {
					"The next {C:attention}sold{} card gives",
					"{X:gold,C:white}X3{} as much money"
				}
			},
			c_entr_othila_providence = {
				name = "Rune of Othila{C:purple}+{}",
				text = {
					"The next {C:attention}sold{} card gives",
					"{X:purple,C:white,E:1}X5{} as much money"
				}
			},
		},
		Pact = {
			c_entr_avarice = {
				name = "Pact of Avarice",
				text = {
					"Duplicate your highest {C:attention}sell value{}",
					"Joker then multply all {C:attention}current{} and {C:attention}future{}",
					"sell values by {X:red,C:white}X0.25{}",
					"{C:inactive}(Must have room, Strips negative)"
				}
			},
			c_entr_rage = {
				name = "Pact of Rage",
				text = {
					"Randomly {C:red}destroy{} {C:attention}20%{}",
					"of your {C:attention}full{} deck",
					"{C:inactive}(Minimum of 5, Currently #1#)"
				}
			},
			c_entr_thorns = {
				name = "Pact of Thorns",
				text = {
					"Apply {C:attention}Rental{} to {C:attention}#1#{} random Jokers",
					"then give them {C:attention}random{} Editions"
				}
			},
			c_entr_denial = {
				name = "Pact of Denial",
				text = {
					"Create a {C:attention}copy{} of the last {C:attention}sold{} card",
					"then {C:red}banish{} that card",
					"{C:inactive}(Currently {C:attention}#1#{C:inactive}, must have room){}"
				}
			},
			c_entr_chains = {
				name = "Pact of Chains",
				text = {
					"Retrigger all {C:attention}Eternal{}",
					"playing cards, the first {C:attention}drawn{} card",
					"each round becomes {C:attention}Eternal{}"
				}
			},
			c_entr_decay = {
				name = "Pact of Decay",
				text = {
					"{C:red}Remove{} {C:attention}#1#{} level from {C:attention}#2#{} random hands",
					"Your most played hand gains {C:attention}#3#{} levels"
				}
			},
			c_entr_envy = {
				name = "Pact of Envy",
				text = {
					"{C:red}Destroy{} a {C:attention}random{} Joker",
					"Retrigger a {C:attention}random{} Joker,",
					"target changes each round"
				}
			},
			c_entr_youth = {
				name = "Pact of Youth",
				text = {
					"{C:attention}Destroy{} a random Joker",
					"{C:attention}-#1#{} Ante",
				}
			},
			c_entr_shards = {
				name = "Pact of Shards",
				text = {
					"Apply {C:dark_edition}Fractured{} to a",
					"random Joker, {C:attention}future{} playing card",
					"destruction may {C:red}fail{}"
				}
			},
			c_entr_desire = {
				name = "Pact of Desire",
				text = {
					"Create {C:attention}#1#{} random",
					"{C:spectral}Spectral{} or {C:red}Omen{} cards",
					"{C:attention}Booster Packs{} cost {C:money}50%{} more",
					"{C:inactive}(Must have room){}"
				}
			},
			c_entr_ice = {
				name = "Pact of Ice",
				text = {
					"Redeem {C:attention}#1#{} random {C:attention}Vouchers{}",
					"Your most {C:attention}levelled{} hand",
					"{C:red}cannot{} change levels"
				}
			},
			c_entr_gluttony = {
				name = "Pact of Gluttony",
				text = {
					"{C:attention}+#1#{} consumable slots",
					"{C:red}All{} consumables are {C:attention}Eternal{}"
				}
			},
			c_entr_rebirth = {
				name = "Pact of Rebirth",
				text = {
					"Playing cards are {C:attention}duplicated{}",
					"instead of being {C:red}destroyed{}",
					"{C:blue}-#1#{} hand size"
				}
			},
			c_entr_despair = {
				name = "Pact of Despair",
				text = {
					"Enhance {C:attention}#1#{} random card#<s>1#",
					"in your {C:attention}full deck{}, debuff {C:attention}#2#%{} of",
					"cards in your {C:attention}full deck{} for {C:attention}#3#{} rounds"
				}
			},	
			c_entr_strength = {
				name = "Pact of Strength",
				text = {
					"Copy your {C:attention}most played{} card {C:attention}#1#{} times",
					"apply {C:attention}Rental{} to a random Joker"
				}
			},	
			c_entr_darkness = {
				name = "Pact of Darkness",
				text = {
					"Apply {C:dark_edition}Negative{} to a random Joker",
					"Playing cards may be drawn face {C:red}down{}"
				}
			},	
			c_entr_freedom = {
				name = "Pact of Freedom",
				text = {
					"{C:attention}+#1#{} card selection limit",
					"{C:attention}-#2#{} hand size"
				}
			},	
			c_entr_eternity = {
				name = "Pact of Eternity",
				text = {
					"{C:gold}+#1#{} Ascension Power to your",
					"most {C:attention}played{} hand, a random",
					"Joker becomes {C:attention}Eternal{}"
				}
			},	
			c_entr_loyalty = {
				name = "Pact of Loyalty",
				text = {
					"Interest Rate is now every {C:money}$4{}",
					"{X:mult,C:white}X0.5{} Mult every other hand"
				}
			},
			c_entr_brimstone = {
				name = "Pact of Brimstone",
				text = {
					"{X:mult,C:white}X3.6{} Mult after hand played",
					"on the {C:attention}final hand{} of round",
					"{C:blue}-#1#{} hands"
				}
			},
			c_entr_dreams = {
				name = "Pact of Dreams",
				text = {
					"Gain {C:attention}#1#{} random Tags",
					"Small Blinds give no {C:attention}Reward{}"
				}
			},
			c_entr_energy = {
				name = "Pact of Energy",
				text = {
					"Apply random {C:dark_edition}Editions{}",
					"to the last discarded hand",
					"{C:red}-#1#{} discard#<s>1#"
				}
			},	
			c_entr_blood = {
				name = "Pact of Blood",
				text = {
					"Link {C:attention}#1#{} random",
					"playing cards from your",
					"{C:attention}full deck{} together"
				}
			},		
			c_entr_awakening = {
				name = "Pact of Awakening",
				text = {
					"Create a random {C:dark_edition}Negative{} Voucher",
					"{C:attention}-#1#{} Booster Pack slot#<s>1#"
				}
			},
		},
		mtx = {
			c_entr_extrajoker = {
				name = "Extra Jokers",
				text = {
					"{C:attention}+#1# Joker slot{}",
					"{C:purple}-c.#2#{}"
				}
			},
			c_entr_unstick = {
				name = "Unstick",
				text = {
					"Remove ALL {C:attention}stickers{}",
					"from your {C:attention}Jokers{}",
					"{C:purple}-c.#1#{}"
				}
			},
			c_entr_extrahands = {
				name = "Extra Hands",
				text = {
					"{C:blue}+#1# hand{}",
					"{C:purple}-c.#2#{}"
				}
			},
			c_entr_moneybundle = {
				name = "Bundle of Dollars",
				text = {
					"{C:money}+$#1#{}",
					"{C:purple}-c.#2#{}"
				}
			},
			c_entr_biggerpockets = {
				name = "Bigger Pockets",
				text = {
					"{C:attention}+#1# consumable slot{}",
					"{C:purple}-c.#2#{}"
				}
			},
			c_entr_deckfix = {
				name = "Deckfix",
				text = {
					"Destroy up to {C:attention}#1#{}",
					"selected cards",
					"{C:purple}-c.#2#{}"
				}
			},
			c_entr_generousdonation = {
				name = "Generous Donation",
				text = {
					"{C:purple}-c.#1#{}"
				}
			},
		},
		Other = {
			entr_bountiful_harvest = {
				'{C:green}#1# in #2#{} Chance to',
				'create a random tag',
				'when a {C:attention}Joker{} is sold'
			},
			asc_power_tutorial = {
				name = "Ascension Power Explanation",
				text = {
					"Ascension Power multiplies",
					"{C:blue}Chips{} and {C:mult}Mult",
					"by {X:gold,C:white}X(1.25 ^ Power)",
					"{C:inactive,s:0.8}Eg. +0.5 Asc Power -> X1.11 Chips/Mult",
					"{C:inactive,s:0.6}This popup can be disabled in the config"
				}
			},
			antipattern_pair = {
				name = "Antipattern",
				text = {
					"Hands played after #1#: ",
					"#2# #3# #4# #5# #6# #7#",
					"#8# #9# #10# #11# #12#",
				}
			},
			cry_multiuse = {
				name = "m",
				text = {
					"{C:inactive}Multiuse: ({V:1}#1#{C:inactive} remaining)",
				},
			},
			cry_banana_booster = {
				name = "Banana",
				text = {
					"All cards in pack",
					"are {C:attention}Banana{}",
				},
			},
			cry_banana_voucher = {
				name = "Banana",
				text = {
					"{C:green}#1# in #2#{} chance of being",
					"unredeemed each round",
				},
			},
			cry_banana_consumeable = {
				name = "Banana",
				text = {
					"{C:green}#1# in #2#{} chance to do",
					"nothing on use",
				},
			},
			banana = {
				name = "Banana",
				text = {
					"{C:green}#1# in #2#{} chance of being",
					"destroyed each round",
				},
			},
			echo_tooltip = {
				name = "(~)$ echo",
				text = {
					"When this card is used,",
					"also trigger {C:attention}#1#{}"
				}
			},
			temporary_debuff_tooltip = {
				name = "Temporary Debuff",
				text = {
					"Debuffed for the",
					"next {C:attention}#1#{} rounds"
				}
			},
			temporary_retriggers_tooltip = {
				name = "Temporary Retriggers",
				text = {
					"Temporary Retriggers are",
					"removed when this card is",
					"retriggered",
					"{C:inactive}(Currently {C:attention}#1#{C:inactive})"
				}
			},
			temporary_retriggers_tooltip_gem = {
				name = "Temporary Retriggers",
				text = {
					"Temporary Retriggers are",
					"removed when this card is",
					"retriggered",
				}
			},
			inversion_allowed = {
				name = "Inversion",
				text = {
					"Can be {C:red}Inverted{}",
					"into {C:red}#1#{}"
				}
			},
			no_downside = {
				name = "Downside Negated",
				text = {
					"Downside is removed",
				}
			},
			no_downside_cond = {
				name = "Downside Negated",
				text = {
					"Downside is removed",
					"when {X:dark_edition,C:white}Entropy{}",
					"is higher than {C:attention}100{}"
				}
			},
			p_entr_twisted_pack_normal = { 
				name = "Twisted Pack",
				group_name = "Inverted Card",
				text={
					"Choose {C:attention}#1#{} of up to",
					"{C:attention}#2#{C:red} Inverted{} cards to",
					"be used immediately or taken",
				}
			},
			p_entr_twisted_pack_jumbo = { 
				name = "Jumbo Twisted Pack",
				group_name = "Inverted Card",
				text={
					"Choose {C:attention}#1#{} of up to",
					"{C:attention}#2#{C:red} Inverted{} cards to",
					"be used immediately or taken",
				},
			},
			p_entr_twisted_pack_mega = { 
				name = "Mega Twisted Pack",
				group_name = "Inverted Card",
				text={
					"Choose {C:attention}#1#{} of up to",
					"{C:attention}#2#{C:red} Inverted{} cards to",
					"be used immediately or taken",
				},
			},
			p_entr_twisted_pack_normal_2 = { 
				name = "Twisted Pack",
				group_name = "Inverted Card",
				text={
					"Choose {C:attention}#1#{} of up to",
					"{C:attention}#2#{C:red} Inverted{} cards to",
					"be used immediately or taken",
				}
			},
			p_entr_twisted_pack_jumbo_2 = { 
				name = "Jumbo Twisted Pack",
				group_name = "Inverted Card",
				text={
					"Choose {C:attention}#1#{} of up to",
					"{C:attention}#2#{C:red} Inverted{} cards to",
					"be used immediately or taken",
				},
			},
			p_entr_twisted_pack_mega_2 = { 
				name = "Mega Twisted Pack",
				group_name = "Inverted Card",
				text={
					"Choose {C:attention}#1#{} of up to",
					"{C:attention}#2#{C:red} Inverted{} cards to",
					"be used immediately or taken",
				},
			},
			p_entr_blind = { 
				name = "Blind Pack",
				group_name = "Blinds",
				text={
					"Choose {C:attention}#1#{} of up to",
					"{C:attention}#2#{} {C:attention}Blind Tokens{} to",
					"be used immediately or taken",
				}
			},
			p_entr_unbounded = {
				name = "Unbounded Pack",
				text = {
					"Choose {C:attention}#1#{} of up to",
					"{C:attention}#2#{C:spectral} Spectral{} card#<s>2#",
					"{s:0.8,C:inactive}(Generated by Unbounded Tag)",
				},
			},
			p_entr_reference_pack = { 
				name = "Reference Pack",
				group_name = "Inverted Card",
				text={
					"Choose {C:attention}#1#{} of up to",
					"{C:attention}#2#{} {C:attention}Reference Jokers{}",
				}
			},
			p_entr_voucher_pack = {
				name = "Voucher Pack",
				group_name = "Voucher",
				text={
					"Choose {C:attention}#1#{} of up to",
					"{C:attention}#2#{} {C:attention}Vouchers{}",
				}
			},
			undiscovered_rune = {
				name = "Not Discovered",
				text = {
					"Purchase or use",
					"this card in an",
					"unseeded run to",
					"learn what it does",
				},
			},
			undiscovered_pact = {
				name = "Not Discovered",
				text = {
					"Purchase or use",
					"this card in an",
					"unseeded run to",
					"learn what it does",
				},
			},
			undiscovered_fraud = {
				name = "Not Discovered",
				text = {
					"Purchase or use",
					"this card in an",
					"unseeded run to",
					"learn what it does",
				},
			},
			undiscovered_omen = {
				name = "Not Discovered",
				text = {
					"Purchase or use",
					"this card in an",
					"unseeded run to",
					"learn what it does",
				},
			},
			undiscovered_star = {
				name = "Not Discovered",
				text = {
					"Purchase or use",
					"this card in an",
					"unseeded run to",
					"learn what it does",
				},
			},
			undiscovered_command = {
				name = "Not Discovered",
				text = {
					"Purchase or use",
					"this card in an",
					"unseeded run to",
					"learn what it does",
				},
			},
			undiscovered_cblind = {
				name = "Not Discovered",
				text = {
					"Purchase or use",
					"this card in an",
					"unseeded run to",
					"learn what it does",
				},
			},
			undiscovered_transient = {
				name = "Not Discovered",
				text = {
					"Purchase or use",
					"this card in an",
					"unseeded run to",
					"learn what it does",
				},
			},
			entr_pinned = {
				name = "Invariant",
				text = {
					"{C:attention}Cannot{} be rerolled",
					"{C:attention}Returns{} in the next",
					"round's shop"
				}
			},
			entr_hotfix = {
				name = "Hotfix",
				text = {
					"{C:attention}Cannot{} be debuffed",
				}
			},
			entr_pseudorandom = {
				name = "Pseudorandom",
				text = {
					"All {C:red}probabilities{} are",
					"{C:red}guaranteed{} until the",
					"next round"
				}
			},
			temporary = {
				name = "Temporary",
				text = {
					"{C:red}Destroyed{} at the end",
					"of the round"
				}
			},
			superego = {
				name = "Projected",
				text = {
					"Create {C:attention}#1#{} copies",
					"of this card when sold",
					"Increase every 2 rounds"
				}
			},
			desync = {
				name = "Desync",
				text = {
					"{C:dark_edition}Force-trigger{}",
					"during {C:attention}#1#{}",
					"Randomizes when hand played"
				}
			},
			entr_aleph = {
				name = "Aleph",
				text = {
					"Cannot be {C:attention}removed{} {C:red}ever{}"
				}
			},
			entr_copper_sticker = {
                name = 'Copper Sticker',
                text = {
                    'Used this Joker',
                    'to win on {C:attention}Copper',
                    '{C:attention}Stake{} difficulty'
                }
            },
			entr_platinum_sticker = {
                name = 'Platinum Sticker',
                text = {
                    'Used this Joker',
                    'to win on {C:attention}Platinum',
                    '{C:attention}Stake{} difficulty'
                }
            },
			entr_meteorite_sticker = {
                name = 'Meteorite Sticker',
                text = {
                    'Used this Joker',
                    'to win on {C:attention}Meteorite',
                    '{C:attention}Stake{} difficulty'
                }
            },
			entr_obsidian_sticker = {
                name = 'Obsidian Sticker',
                text = {
                    'Used this Joker',
                    'to win on {C:attention}Obsidian',
                    '{C:attention}Stake{} difficulty'
                }
            },
			entr_iridium_sticker = {
                name = 'Iridium Sticker',
                text = {
                    'Used this Joker',
                    'to win on {C:attention}Iridium',
                    '{C:attention}Stake{} difficulty'
                }
            },
			entr_zenith_sticker = {
                name = 'Zenith Sticker',
                text = {
                    'Used this Joker',
                    'to win on {C:entr_zenith}Zenith',
                    '{C:attention}Stake{} difficulty'
                }
            },
			entr_marked = {
				name = "Marked",
				text = {
					"Always added to",
					"each played hand",
					"this round"
				}
			},
			entr_death_mark = {
				name = "Marked for Death",
				text = {
					"{C:red}Destroyed{} when",
					"Triggered"
				}
			},
			void_temporary = {
				name = "Temporary",
				text  = {
					"{C:red}Destroyed{} at the",
					"end of round"
				}
			},
			entr_death_mark_consumeable = {
				name = "Marked for Death",
				text = {
					"{C:red}Destroyed{} instead",
					"of being used"
				}
			},
			entr_crimson_seal = {
				name = "Crimson Seal",
				text = {
					"Retrigger {C:attention}adjacent{} cards"
				}
			},
			entr_sapphire_seal = {
				name = "Sapphire Seal",
				text = {
					"Give {C:attention}+0.25{} Ascension ",
					"Power to the played hand",
					"if {C:attention}held{} in hand",
					"at end of round"
        		}
			},
			entr_silver_seal = {
				name = "Silver Seal",
				text = {
					"Gives {C:gold}$1{} for each",
					"card held in {C:attention}hand{} when scored",
        		}
			},
			entr_pink_seal = {
				name = "Pink Seal",
				text = {
					"Creates an {C:red}Inverted{}",
					"card when discarded",
					"and is then {C:attention}destroyed{}",
					"{C:inactive}(Must have room){}"
				}
			},
			entr_verdant_seal = {
				name = "Verdant Seal",
				text = {
					"Creates a {C:red}Command{}",
					"card when played {C:attention}if{}",
					"this is the {C:attention}only{}",
					"scored card"
				}
			},
			entr_cerulean_seal = {
				name = "Cerulean Seal",
				text = {
					"Create 3 {C:dark_edition}Negative{} {C:purple}Star{} cards",
					"for played hand if this",
					"card is {C:attention}part{}",
					"of the poker hand,",
					"then {C:attention}destroy{}",
					"the played hand"
				}
			},
			entr_ornate_seal = {
				name = "Ornate Seal",
				text = {
					"Creates a {C:purple}Rune{} card",
					"when {C:red}destroyed{}",
					"{C:inactive}(Must have room){}"
				}
			},
			entr_amber_seal = {
				name = "Amber Seal",
				text = {
					"Creates a {C:red}Pact{} card",
					"and {C:red}destroys{} itself",
					"when {C:attention}copied{} or {C:attention}duplicated{}",
					"{C:inactive}(Must have room){}"
				}
			},
			entr_mini_seal = {
				name = "Mini Seal",
				text = {
					"{C:green}#1# in #2#{} chance to",
					"{C:red}destroy{} {C:attention}adjacent{} cards",
					"after scoring"
				}
			},
			entr_sharp_seal = {
				name = "Sharp Seal",
				text = {
					"{C:green}#1# in #2#{} chance to",
					"upgrade this card's {C:attention}Enhancement{}",
					"before scoring"
				}
			},
			entr_vantablack_seal = {
				name = "Vantablack Seal",
				text = {
					"{C:attention}+1{} card selection limit",
					"when selected"
				}
			},
			link = {
				name = "Linked",
				text = {
					"Shares modifications",
					"with other cards that",
					"share the same link",
					"{C:inactive}(#1#){}"
				}
			},
			xmult_bonus = {
				name = "Bonus Mult",
				text = {
					"{X:red,C:white}X#1#{} extra",
					"Mult"
				}
			},
			entr_yellow_sign = {
				name = "Yellow Sign",
				text = {
					"{C:attention}Temporarily{} counts",
					"as {C:diamonds}Diamonds{}"
				}
			},
			scarred = {
				name = "Scarred",
				text = {
					"{C:attention}Not{} removed from",
					"hand when discarding,",
					"extra cards are {C:attention}still{} drawn"
				}
			},
			tmtrainer_dummy = {
				name = "Glitched Effect",
				text = {
					"#1#",
					"#2#"
				}
			},
			entr_pure = {
				name = "Pure",
				text = {
					"This Joker's values",
					"cannot change"
				}
			},
			entr_card_suit_level = {
				text = {
					"--------------",
					"{S:0.8,V:1}#1#{} {S:0.8}({S:0.8,V:2}lvl.#3#{})",
					"{C:blue}+#2#{} Chips"
				}
			}
		},
		Partner = {
			pnr_entr_parakmi = {
				name = "Tyhaois",
				text = {
					"Booster Packs may",
					"may be randomized",
					"to another random",
					"Booster Pack"
				}
			}
		},
		TheFamily_Tab = {
            entr_rune_tags = {
                name = "Rune Tags",
                text = {
                    "Hide or Display Rune Tags"
                }
            }
        },
		TheFamily_Group = {
            entr_misc_group = {
                name = "Miscelaneous Items (Entropy)",
                text = {
                    "Toggles for various UI elements added by Entropy"
                }
            }
        },
		Mod = {
            entr = {
				name = "Entropy",
				text = {
					"{s:1.2}A Very {C:red,s:1.2}Chaotic{s:1.2} Balatro mod inspired",
					"{s:1.2}by {C:red,s:1.2}TBOI: Repentance{s:1.2} among other things",
					"{s:1.2}focused on {C:red,s:1.2}Inverted{s:1.2} Consumables and",
					"{s:1.2}expanding on Vanilla mechanics in various other ways",
					"{s:1.2}Generally Vanilla adjacent but not exactly Vanilla{C:purple,s:1.2}+{}"
				}
			}
		}
	},
	misc = {
		tutorial = {
			entr_tut_intro_1 = {
				"Hello there! My name is {C:red}Ruby{}, I'm here",
				"to help you learn the ropes of {C:entr_entropic}Entropy{}"
			},
			entr_tut_intro_2 = {
				"The mechanics of this mod are",
				"not too different from Vanilla."
			},
			entr_tut_intro_3 = {
				"But there are a few new things",
				"I need to introduce you to."
			},
			entr_tut_intro_4 = {
				"For now I'll see you in the shop.",
			},

			entr_ap_1 = {
				"Nicely done, now you can see what",
				"the {C:entr_entropic}Entropy{} shop has to offer."
			},
			entr_ap_2 = {
				"Try buying this {C:gold}Sunny{} Devil"
			},
			entr_ap_3 = {
				"This is one of the {C:attention}#1#{} Jokers added by this mod"
			},
			entr_ap_4 = {
				"This one adds {C:gold}+2{} Ascension Power,",
				"You may be wondering what that does"
			},
			entr_ap_5 = {
				"Well. every {C:gold}+1{} Ascension Power",
				"multiplies both {C:blue}Chips{} and {C:red}Mult{} by {X:purple,C:white}X1.25{}"
			},
			entr_ap_6 = {
				"so {C:gold}+2{} would be Two triggers of",
				"{X:purple,C:white}X1.25{} to both or roughly {X:purple,C:white}X1.56{}"
			},
			entr_ap_7 = {
				"If you want to know the exact",
				"formula its {X:gold,C:white}X(1.25 ^ Power)"
			},
			entr_ap_8 = {
				"Lets try this {C:attention}Joker{} in the next round."
			},

			entr_alt_1 = {
				"Welcome to the post. Boss Blind shop",
				"This will be mostly the same however",
				"there is one difference."
			},
			entr_alt_2 = {
				"You may have noticed this new",
				"{C:purple}purple{} shop button"
			},
			entr_alt_3 = {
				"In {C:entr_entropic}Entropy{} there are",
				"two differences for your run which can impact",
				"the {C:red}Difficulty{} and {C:entr_void}Rewards{}"
			},
			entr_alt_4 = {
				"The Main path has the regular Blinds",
				"including those from {C:attention}Vanilla{} and some",
				"new Blinds from {C:entr_entropic}Entropy{}"
			},
			entr_alt_5 = {
				"The Alternate path also known as {C:purple}The Flipside{}",
				"has new Blinds that only show up here",
				"but are generally more difficult"
			},
			entr_alt_6 = {
				"It also has a higher chance of {C:red}Twisted Packs{} and",
				"you might see some new {C:entr_void}Jokers{}. So keep an eye out"
			},
			entr_alt_7 = {
				"You may switch Paths once",
				"in every Post-Boss Blind shop"
			},
			entr_alt_8 = {
				"For now lets switch {C:purple}Path{} and",
				"ill see you in the next shop"
			},

			entr_packs_1 = {
				"Now lets take a look at",
				"Booster Packs in the shop"
			},
			entr_packs_2 = {
				"Try buying this {C:red}Twisted{}",
				"Pack which has been added",
				"by {C:entr_entropic}Entropy{}"
			},
			entr_packs_3 = {
				"Twisted Packs are booster packs",
				"that only contain Inverted Consumables",
			},
			entr_packs_4 = {
				"{C:red}Inverted{} Consumables are cards",
				"based off of existing {C:spectral}Consumables{}",
				"but warped in some way"
			},
			entr_packs_5 = {
				"For Example, This card is {C:entr_omen}Charm{}",
				"and it is the counterpart to {C:spectral}Hex{}",
				"from Vanilla Balatro"
			},
			entr_packs_6 = {
				"These consumables can also be",
				"obtained in other ways such as",
				"from {C:spectral}Flipside{} or {C:purple}Dagaz{}"
			},
			entr_packs_7 = {
				"Inverted consumables may",
				"always be selected from a pack"
			},
			entr_packs_8 = {
				"Lets try using {C:entr_omen}Charm{}"
			},
			entr_packs_9 = {
				"Now onto changes to existing",
				"Booster Packs. Try buying",
				"this {C:attention}Celestial Pack{}"
			},
			entr_packs_10 = {
				"You may have noticed a new",
				"{C:purple{}Consumable Type{} in this pack"
			},
			entr_packs_11 = {
				"These are runes, They have a small chance",
				"to replace {C:purple}Tarots{} in Arcana Packs",
				"and {C:blue}Planets{} in Celestial Packs"
			},
			entr_packs_12 = {
				"Runes do not have their own",
				"Booster pack so this chance",
				"is the main way to obtain them"
			},
			entr_packs_13 = {
				"Lets try using this Rune",
				"to take advantage of its effect"
			},
			entr_packs_14 = {
				"Well, Ill leave you to it now."
			}

		},
		achievement_names = {
			ach_entr_event_horizon = "Event Horizon",
			ach_entr_here_comes_the_sun = "Here comes The Sun",
			ach_entr_megalyteri = "Megalyteri",
			ach_entr_acheros = "Acheros",
			ach_entr_rift = "Rift",
			ach_entr_katevaino = "Katevaino",
			ach_entr_joy_to_the_world = "Joy To The World",
			ach_entr_suburban_jungle = "Suburban Jungle",
			ach_entr_f_x = "f(x)",
			ach_entr_c_sharp = "Completionist#"
		},
		achievement_descriptions = {
			ach_entr_event_horizon = "Use #define to turn Obelisk into Sob",
			ach_entr_here_comes_the_sun = "Obtain a Sunny Joker",
			ach_entr_acheros = "Beat Ante 32's Boss Blind, Endless Entropy",
			ach_entr_rift = "Beat Ante 8 on The Alternate Path",
			ach_entr_katevaino = "Use Transcend on Parakmi",
			ach_entr_joy_to_the_world = "Have the Wunjo Rune create another Wunjo Rune",
			ach_entr_suburban_jungle = "Play a Full House while holding a Legendary Joker from Entropy",
			ach_entr_f_x= "Play a Derivate while holding Antiderivative",
			ach_entr_c_sharp = "Discover and Unlock all Vanilla and Entropy Collection entries"
		},
		suits_plural = {
			entr_nilsuit = "Nil",
		},
		suits_singular = {
			entr_nilsuit = "Nil",
		},
		ranks = {
			entr_nilrank = "Nil"
		},
		dictionary = {
			k_corrupted_ex = "Corrupted!",
			k_recovered_ex = "Recovered!",
			cry_demicolon = "Demitrigger!",
			k_ee_hand_1 = "When hand is played, a random card becomes Sunny",
			k_ee_hand_2 = "Cards cannot be debuffed",
			k_ee_hand_3 = "X1.666 to all Joker values when hand played",
			k_ee_hand_4 = "Force-trigger a random Joker",

			k_ee_discard_1 = "Spread discarded card's Edition if 1 card discarded",
			k_ee_discard_2 = "Create Negative Banana copies of played cards",
			k_ee_discard_3 = "Gain an Ascended Tag for each discarded card",
			k_ee_discard_4 = "^3 Mult",


			k_before = "Before scoring:",
			k_pre_joker = "Before Joker scoring:",
			k_joker_main = "During main scoring:",
			k_individual = "When this card triggers:",
			k_pre_discard = "When discarding cards:",
			k_remove_playing_cards = "When playing cards are destroyed:",
			k_setting_blind = "When entering a Blind:",
			k_ending_shop = "When leaving the shop:",
			k_reroll_shop = "When rerolling:",
			k_selling_card = "When a card is sold:",
			k_using_consumeable = "When a consumable is used:",
			k_playing_card_added = "When a playing card is added:",

			k_tmtmult = "+??? Mult",
			k_tmtchips = "+??? Chips",

			k_tmtxmult = "X??? Mult",
			k_tmtxchips = "X??? Chips",

			k_tmtemult = "^??? Mult",
			k_tmtechips = "^??? Chips",

			k_tmtdollars = "+??? Dollars",
			k_tmtjoker_random = "Create a random Joker",
			k_tmtjoker_choose_rarity = "Create a Joker of a random rarity",
			k_tmtedition = "Apply a random Edition to a random Joker",
			k_tmtante = "-??? Ante",
			k_tmtconsumable = "Create a random consumable",
			k_tmtenhancement_play = "One played card gets a new Enhancement",
			k_tmtenhancement_hand = "One card held in hand gets a new Enhancement",
			k_tmtrandom = "Trigger 3 random effects",

			k_entr_entropic = "Entropic",
			k_entr_reverse_legendary = "Legendary?",
			k_entr_void = "Void",
			k_entr_zenith = "Zenith",
			k_entr_reverse_zenith = "Zenith?",
			k_fraud = "Fraud",
			b_fraud_cards = "Fraud Cards",

			k_command = "Command",
			b_command_cards = "Command Cards",

			k_omen = "Omen",
			b_omen_cards = "Omen Cards",

			k_transient = "Transient",
			b_transient_cards = "Transient Cards",

			k_mtx = "MTX",
			b_mtx_cards = "MTX Cards",

			k_inverted = "Inverted",
			k_inverted_pack = "Twisted Pack",
			k_voucher_pack = "Voucher Pack",
			b_inverted_cards = "Inverted Cards",

			entr_code_sudo = "OVERRIDE",
			entr_code_sudo_previous = "OVERRIDE AS PREVIOUS",
			k_cooked_ex = "Cooked!",
			k_entr_asc_tutorial = "Enable Ascension Power tooltip",
			k_entr_faster_ante_scaling = "Scale Blind scores quicker if you have an Entropic Joker",
			k_entr_entropic_music = "Entropic Jokers (Joker in Greek by gemstonez)",
			k_entr_blind_tokens = "Enable Blind Tokens",
			k_entr_profile_prefix = "Enable Custom Profiles for Entropy",
			k_credits = "Credits",
			k_code = "Code",
			k_idea = "Ideas",
			k_art = "Art",
			k_music = "Music",
			k_music_sound = "Music / Sounds",
			k_forcetrigger_ex = "Forcetrigger!",
			k_spoiled_ex = "Spoiled!",
			k_downgrade_ex = "Downgrade!",
			k_backfired_ex = "Backfired!",
			k_skipped_q = "Skipped?",
			k_star = "Star",
			b_star_cards = "Star Cards",	
			k_planet_multiverse = Cryptid_config.family_mode and "Multiverse" or "The Actual Fucking Multiverse",
			k_planet_binary_star = "Binary Star System",
			k_planet_dyson_swarm = "Stellar Megastructure",

			k_entropy = "Entropy",

			k_cblind = "Blind Token",
			b_cblind_cards = "Blind Tokens",
			k_entr_base = "Base",

			k_blind_pack = "Blind Pack",
			b_blind_cards = "Blinds",

			k_reference_pack = "Reference Pack",
			b_reference_cards = "Reference Jokers",
			b_buy_slot = "+Joker Slot",
			b_sell_slot = "-Joker Slot",
			b_transition = "Transition",
			
			b_cant_reroll="Don't even try.",

			ph_blind_score_less_than="Score less than",
			entr_nadir_placeholder = "3X Base",

			ph_no_decks = "No decks bought this run",
			ph_decks_bought = "Decks bought this run",

			ph_cards_defined = "Redefinitions this run",
			ph_definitions = "No redefinitions this run", 
			ph_leftright = "The left card always converts to the right card",
			b_definitions = "Definitions",
			entr_ascended = "Ascended!",
			k_entr_freebird = "Antireal (Freebird by Lynyrd Skynyrd - Copyrighted)",

			entr_opened = "Opened!",
			entr_kiy_banished = "Banished",

			k_saved_heroic = "Not Heroic!",
			k_saved_just = "Not Just!",
			b_on = "Enable",
			b_off = "Disable",
			b_enabled = "Enabled",
			b_disabled = "Disabled",
			b_cycle = "Cycle",
			b_true_endless = "True Endless Mode",
			k_entr_glitched = "Use new Glitched Shader (by cassknows)",
			ph_hand_notreal = "Bad argument to function pokerhand",
			ph_hand_notcorrect = "Incorrect Hand Type Selected",


			cry_notif_antireal_1 = "Antireal Joker",
			cry_notif_antireal_2 = "Copyright Notice",
			cry_notif_antireal_d1 = 'Antireal Joker plays the song "Freebird",',
			cry_notif_antireal_d2 = "which is copyrighted and can't be",
			cry_notif_antireal_d3 = "used for streams and videos.",

			k_entr_corrupted_speed = "Corrupted Deck Cycling Speed (%)",

			k_saved_skullcry = "The power of Zenith Stake saves you",

			b_change_path_1 = "Enter The",
			b_change_path_2 = "Flip-Side",
			b_change_path_3 = "Return",
			b_infinity = "Infinity",

			b_daily_challenge = "Daily Challenge",

			flipside_none = 'None',
			flipside_minimal = 'Minimal',
			flipside_full = 'Full',
			
			flipside_info = 'Inversion display when holding Flipside',
			curses_enabled = "Enable Curses outside of Obsidian Stake",

			b_stat_CBlind = "Blind Token",
			b_stat_Fraud = "Fraud",
			b_stat_Star = "Star",
			b_stat_Omen = "Omen",
			b_stat_Command = "Command",
			k_upgrade_atomikos = "Destroyed!",
			k_destroyed_ex = "Destroyed!",
			k_new = "new();",
			k_ascended_ex = "Ascended",

			k_rune = "Rune",
			k_rune_pack = "Rune Pack",
			b_rune_cards = "Runes",
			k_pact = "Pact",
			k_pact_pack = "Devil Deal",
			b_pact_cards = "Pacts",

			cry_set_music = "Music",

			k_inactive = "Inactive",
			k_inactive_ex = "Inactive!",
			k_randomised = "Randomized!",
			k_saved_algiz = "Saved by Algiz",
			k_undebuffed_ex = "Undebuffed!",
			k_spatial_anomaly = "Spatial Anomaly",

			k_curse_blind = "Curse of The Blind",
			k_curse_blind_desc = "Shop cards may be hidden",

			k_curse_darkness = "Curse of Darkness",
			k_curse_darkness_desc = "Booster Packs have less choices",

			k_curse_lost = "Curse of The Lost",
			k_curse_lost_desc = "No Small Blind",

			k_curse_maze = "Curse of The Maze",
			k_curse_maze_desc = "Blind order is randomized",
			k_level_chips = "Chips per level",
			k_level_mult = "Mult per level",
			k_level_asc = "Ascension Power per level",
			k_star_q = "Star?",
			k_moon = "Moon",
			k_satellite = "Satellite",

			k_joker_in_greek = "Jokers in Greek",
			k_mirrored_in_crimson = "Mirrored in Crimson",
			k_freebird = "Freebird",
			k_ruby_reference = "Mors Caloris",
			k_entropy_is_endless = "Entropy Is Endless",
			k_snd_ominous = "snd_ominous",
			k_ee_goodmusic = "A Fervent Dreamers Lovesong",
			k_ee_badmusic = "Utmost Devotion",
			k_2 = "2%",

			k_plus_rune = "+1 Rune",
			k_plus_star = "+1 Star",
			k_plus_pact = "+1 Pact",
			k_plus_omen = "+1 Omen",
			k_plus_tag = "+1 Tag",
			k_plus_inverted = "+1 Inverted Card",
			k_plus_discard = "+1 Discard",

			k_switch_ex = "Switch!",
			k_bounce_ex = "Bounce!",
			b_challenge_me = "CHALLENGE",

			k_ee_fracture_select = "CHOOSE YOUR FATE",

			ph_red_1 = "???",
			ph_red_2 = "???",

			k_entr_sensitive_content = "Hide potentially disturbing content",

			k_banished_ex = "Banished!"
		},
		v_dictionary = {
			card_art = "Card Art: #1#",
			shader = "Shader: #1#",
			wish = "Wish: #1#",
			cry_art = { "Art: #1#" },
			cry_code = { "Code: #1#" },
			cry_idea = { "Idea: #1#" },
			a_eqmult = { "Mult = #1#" },
			a_twisted = {"+#1# Inverted"},

            entr_void_desc = {
                "Permanently {C:entr_void}Invert{} all future",
                "instances of the Jokers listed",
                "below into {C:entr_void}#1#{}:",
                "{s:0.1} "
            }
		},
		gfb_quips = {
			{"32 ANTES", "AND WHAT DO YOU", "HAVE TO SHOW FOR IT"},
			{"MATHISFUN", "SEAL OF", "APPROVAL"},
			{"NOW WITH", "20% EXTRA", "[server moderation]"},
			{"WOULDNT YOU", "LIKE TO KNOW", "WEATHERBOY"},
			{"MORE", "VOUCHOIDS", "TOMORROW"},
			{"WOOF WOOF", "BARK BARK"},
			{"HEY MY", "VOUCHERS ARE", "UP HERE BUDDY"},
			{"6", "", "7"},
			{"YOU ALREADY", "BOUGHT ONE", "YOU GREEDY BASTARD"},
			{"VOUCHER?", "I HARDLY KNOW HER"},
			{"", ":sun_with_face:"},
			{"I HAVE", "NO VOUCHER", "AND I MUST SCREAM"},
			{"THIS", "HEXES", "ME"},
			{"WE OUTTA", "", "VOUCHER"},
			{"GREETINGS", "VOUCHERS OF", "BALATRO"},
			{"QUANTUM RANKS", "PR MERGED", "TOMORROW"},
			{"LETS", "TAKE A", "LOOK"},
			{"ATTEMPT TO INDEX", "GLOBAL 'VOUCHER'", "(A NIL VALUE)"},
			{"", "SPONSORED BY RAID", "SHADOW LEGENDS"},
			{"NOTHING", "EVER", "HAPPENS"},
			{"AT THE SHOP", "WHERE THE VOUCHERS AT", "REDEEM WANT BOING BOING"},
			{"", "=0 VOUCHERS", ""},
			{"SILLY", "AHH", "VOUCHABLES"},
			{"|   | |", "------", "| |   | _"},
			{"SORRY JIMBO, I CAN'T GIVE CREDIT,", "MAYBE COME BACK WHEN YOU'RE A LITTLE", "MMMMMMMMMMRICHER"},
			{"I'M SURPRISED THAT", "YOU READ ALL", "OF THESE QUIPS"},
			{"YOU COULD SAY", "IT'S A BIT", "ENTROPIC"},
			{"", "TS ENTROPYING ME"},
			{"I CAN", "TANK IT"},
			{"HOT SINGLE", "BOSS BLINDS IN", "YOUR AREA"},
			{"ENDLESS ENTROPY", "WANTS TO CHAT"},
			{"WHY", "SO", "SERIOUS?"},
			{"GONE", "REDUCED TO", "ATOMS"},
			{"VOUCHER?", "MORE LIKE", "VOUCHEEKS"},
			{"GUARANTEE", "MAGIC TRICK", "NEXT ANTE"},
			{"", "BOO", ""},
			{"TRUST ME BRO", "ANTIMATTER", "NEXT ANTE"},
			{"NEVER GONNA GIVE YOU UP", "NEVER GONNA LET YOU DOWN", "NEVER GONNA RUN AROUND AND DESERT YOU"},
			{":chud:"},
			{"TODAY", "WE", "FEAST"},
			{ "YOU", "MIGHT BE", "COOKED" },
			{ "BREAD", ">", "KEY" },
			{ "LOL", "lmao,", "even" },
			{ "SHOULD HAVE", "GOT THE", "SKIP TAG" },
			{ "WTF", "IS", "A KILOMETER" },
			{ "500", "CONSUMABLE", "SLOTS" },
			{ "AUGUST", "12TH", "2036" },
			{ "MODS,", "GIVE THEM", "THE PLANT" },
			{ "DEEZ", "NUTS", "haha gottem" },
			{ "LOREM", "IPSUM", "DOLOR SIT" },
			{ "NO VOUCHERS?", ":megamind:", "" },
			{ "PLEASE SPEED", "I NEED THIS", "" },
			{ "SCARY", "CHILDRENDERS", "CREEPYPASTA" }, -- this is an injoke from another friendgroup lol
			{ "", "RE R", "" }, -- another injoke of the same nature
			{ "", "EMPLOYMENT", "" },
			{ "", "IMG_4750.png", "" },
			{ "TS", "VOUCHERSLOP", "" },
			{ "1.1", "TOMORROW", "(trust)" },
			{"TODO:", "WRITE MORE QUIPS"},
			{"yo voucher", "voucher: yo"},
			{"VOUCHERSLOP"},
			{"SMODS.JimboQuip"},
			{"VOUCHER", "I HARDLY", "KNOW HER"},
			{"RUBY", "'ENTROPY'", "CRIMSONFANG"}
		},
		labels = {
			banana = "Banana",
			entr_pinned = "Invariant",
			entr_marked = "Marked",
			entr_death_mark = "Marked for Death",
			void_temporary = "Temporary",
			entr_hotfix = "Hotfixed",
			temporary = "Temporary",
			entr_pseudorandom = "Pseudorandom",
			link = "Linked",
			superego = "Projected",
			entr_sunny = "Sunny",
			entr_solar = "Solar",
			entr_neon = "Neon",
			entr_lowres = "Low-Res",
			entr_kaleidoscopic = "Kaleidoscopic",
			entr_gilded = "Gilded",
			entr_fractured = "Fractured",
			entr_freaky = "Freaky",
			entr_yellow_sign = "Yellow Sign",
			scarred = "Scarred",
			desync = "Desynced",
			entr_aleph = "Aleph",
			entr_pure = "Pure",
			entr_crimson_seal = "Crimson Seal",
			entr_sapphire_seal = "Sapphire Seal",
			entr_silver_seal = "Silver Seal",
			entr_pink_seal = "Pink Seal",
			entr_verdant_seal = "Verdant Seal",
			entr_cerulean_seal = "Cerulean Seal",
			entr_ornate_seal = "Ornate Seal",
			entr_amber_seal = "Amber Seal",
			entr_mini_seal = "Mini Seal",
			entr_sharp_seal = "Sharp Seal",
			entr_vantablack_seal = "Vantablack Seal",
		},
		poker_hands = {
			["entr_All"] = Cryptid_config.family_mode and "All" or "Literally Fucking Everything",
			["entr-Flesh"] = "Flesh",
			["entr-Straight_Flesh"] = "Straight Flesh",
			["entr-Flesh_House"] = "Flesh House",
			["entr-Flesh_Five"] = "Flesh Five",
			["entr_derivative"] = "Derivative"
		},
		poker_hand_descriptions = {
			entr_All = {
				"A hand that contains every single",
				"card found in a 52-card deck,",
				"plus an entire full set of Optics",
				"and Nils, plus one Nil rank of each suit",
				Cryptid_config.family_mode and "God is Dead" or "Fuck You, God is Dead",
			},
			entr_derivative = {
				"5 Non-Standard Ranks or Suits"
			}
		},
		challenge_names = {
			c_entr_lifelight = "Lifelight",
			c_entr_vesuvius = "Vesuvius",
			c_entr_hyperaccelerated_bongcloud_opening = "Hyperaccelerated Bongcloud Opening",
			c_entr_hyperbolic_chamber = "Hyperbolic Hell-Tier Chamber",
			c_entr_daily = "Daily Challenge",
			c_entr_paycheck_to_paycheck = "Paycheck to Paycheck",
			c_entr_riffle_shuffle = "Riffle Shuffle",
			c_entr_variety_content = "Variety Content",
			c_entr_phantom_hand_syndrome = "Phantom Hand Syndrome",
			c_entr_eco_friendly = "Eco-Friendly",
		},
		v_text = {
			ch_c_entr_no_planets = { "No Planets in the shop" },
			ch_c_entr_starting_ante_mten = { "Start on Ante -10" },
			ch_c_entr_reverse_redeo = { "Invert Redeo's Ante change" },
			ch_c_entr_set_seed = {"Set Seed: #1#"}
		},
		quips={
			entr_lq_ee_1={
                "Skill Issue"
            },
            entr_lq_ee_2={
                "If you wish",
				"to defeat me,",
				"you must train",
				"for 1000 years!"
            },
            entr_lq_ee_3={
                "Should have",
				"held R!"
            },
            entr_lq_ee_4={
                "And in the end,",
				"everything succumbs",
				"to Entropy.."
            },
            entr_lq_ee_5={
                "Looks like you",
				"werent entropic",
				"enough!"
            },
            entr_lq_ee_6={
                "Maybe you should",
				"have gotten a",
				"few more retriggers!"
            },
            entr_lq_ee_7={
                "Maybe try adding",
				"a few other mods!"
            },
            entr_lq_ee_8={
                "Dont cry, its",
				"just a game...",
            },
            entr_lq_ee_9={
                "Were you even",
				"trying?"
            },
			entr_lq_ee_10={
                "Maybe you should",
				"stop trying to",
				"beat me!"
            },
			entr_lq_ee_revived = {
				"Did you really",
				"think that would",
				"work?"
			},
			entr_tq_ee_half = {
				"Is that",
				"all you got?"
			},
			entr_wq_ee_1={
                "Huh?",
            },
            entr_wq_ee_2={
                "What!?"
            },
            entr_wq_ee_3={
                "How..."
            },
            entr_wq_ee_4={
                "Reveal your",
				"secrets!"
            },
            entr_wq_ee_5={
                "Well that was",
				"entropious!"
            },

			entr_lq_1 = {
				"Look like fate",
				"caught up to you."
			},
			entr_lq_2 = {
				"An inevitability."
			},
			entr_lq_3 = {
				"Just one",
				"more run?"
			},
			entr_lq_4 = {
				"Better luck",
				"next time..."
			},

			entr_wq_1 = {
				"You really are",
				"something, huh?"
			},
			entr_wq_2 = {
				"The power of entropy",
				"shines within you!"
			},
			entr_wq_3 = {
				"I was right to",
				"believe in you!"
			},
			entr_wq_4 = {
				"Good job... now do",
				"Iridium Stake!"
			},
		}
	},
}
local CBlind = {}
for i, v in pairs(decs.descriptions.Blind) do 
	local text = {}
	for i2, v2 in pairs(v.text or {}) do text[#text+1]=v2 end
	CBlind["c_entr_"..i] = {
		name=(v.name or "Blind").." Token",
		text={
			"Use to change the",
			"upcoming or current",
			"Blind"
		}
	}
end
for i, v in pairs(G.localization.descriptions.Blind) do 
	local text = {}
	for i2, v2 in pairs(v.text or {}) do text[#text+1]=v2 end
	CBlind["c_entr_"..i] = {
		name=(type(v.name) ~= "table" and v.name or "Blind").." Token",
		text={
			"Use to change the",
			"upcoming or current",
			"Blind"
		}
	}
end
decs.descriptions.CBlind = CBlind
return decs
