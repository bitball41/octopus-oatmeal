local pack = {
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    order = -1006,
    key = "twisted_pack_normal",
    set = "Booster",
    config = { extra = 3, choose = 1 },
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                card.ability.choose,
                card.ability.extra,
                colours = {
                    HEX("851628")
                }
            },
        }
    end,
    attributes = {"inverted", "normal"},
    atlas = 'booster', pos = { x = 0, y = 0 },
    group_key = "k_inverted_pack",
    cost = 4,
    draw_hand = true,
    get_weight = function()
        return 0.5 * (G.GAME.entr_alt and 2 or 1)
    end,
    kind = "Inverted",
    create_card = function (self, card, i) 
        if G.GAME.round_resets.ante == 2 and G.GAME.round_resets.blind_states["Small"] == "Defeated" and not G.SETTINGS.entropy_tutorial_complete and i == 1 then
            return SMODS.create_card{key = "c_entr_charm", skip_materialize = true}
        end
        return create_inverted_card()
    end,
    ease_background_colour = function(self)
		ease_colour(G.C.DYN_UI.MAIN, HEX("851628"))
		ease_background_colour({ new_colour = HEX("3c020b"), special_colour = HEX("3c020b"), contrast = 2 })
	end,
    cry_digital_hallucinations = {
		colour = G.C.RED,
		loc_key = "k_twisted_pack",
		create = function()
			local ccard = create_inverted_card()
			ccard:set_edition({ negative = true }, true)
			ccard:add_to_deck()
			G.consumeables:emplace(ccard)
		end,
	},
    slib_credits = {art = {"LFMoth"}}
}
local pack2 = SMODS.shallow_copy(pack)
SMODS.Booster(pack)
pack2.pos.y = 1
pack2.slib_credits = {art = {"Lil. Mr. Slipstream"}}
pack2.key = "twisted_pack_normal_2"
pack2.order = -1005
SMODS.Booster(pack2)
local jumbo = {
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    order = -1004,
    key = "twisted_pack_jumbo",
    set = "Booster",
    config = { extra = 5, choose = 1 },
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                card.ability.choose,
                card.ability.extra,
                colours = {
                    HEX("851628")
                }
            },
        }
    end,
    attributes = {"inverted", "jumbo"},
    atlas = 'booster', pos = { x = 1, y = 0 },
    group_key = "k_inverted_pack",
    cost = 6,
    draw_hand = true,
    kind = "Inverted",
    get_weight = function()
        return 0.3 * (G.GAME.entr_alt and 2.25 or 1)
    end,
    create_card = function (self, card, i) 
        return create_inverted_card()
    end,
    ease_background_colour = function(self)
		ease_colour(G.C.DYN_UI.MAIN, HEX("851628"))
		ease_background_colour({ new_colour = HEX("3c020b"), special_colour = HEX("3c020b"), contrast = 2 })
	end,
    cry_digital_hallucinations = {
		colour = G.C.RED,
		loc_key = "k_twisted_pack",
		create = function()
			local ccard = create_inverted_card()
			ccard:set_edition({ negative = true }, true)
			ccard:add_to_deck()
			G.consumeables:emplace(ccard)
		end,
	},
    slib_credits = {art = {"Lil. Mr. Slipstream"}}
}
local jumbo2 = SMODS.shallow_copy(jumbo)
SMODS.Booster(jumbo)
jumbo2.pos.y = 1
jumbo2.slib_credits = {art = {"Callirhoe"}}
jumbo2.key = "twisted_pack_jumbo_2"
jumbo2.order = -1003
SMODS.Booster(jumbo2)

local mega = {
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    order = -1002,
    key = "twisted_pack_mega",
    set = "Booster",
    config = { extra = 5, choose = 2 },
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                card.ability.choose,
                card.ability.extra,
                colours = {
                    HEX("851628")
                }
            },
        }
    end,
    attributes = {"inverted", "mega"},
    atlas = 'booster', pos = { x = 2, y = 0 },
    group_key = "k_inverted_pack",
    cost = 8,
    draw_hand = true,
    get_weight = function()
        return 0.2 * (G.GAME.entr_alt and 2.5 or 1)
    end,
    kind = "Inverted",
    create_card = function (self, card, i) 
        return create_inverted_card()
    end,
    ease_background_colour = function(self)
		ease_colour(G.C.DYN_UI.MAIN, HEX("851628"))
		ease_background_colour({ new_colour = HEX("3c020b"), special_colour = HEX("3c020b"), contrast = 2 })
	end,
    cry_digital_hallucinations = {
		colour = G.C.RED,
		loc_key = "k_twisted_pack",
		create = function()
			local ccard = create_inverted_card()
			ccard:set_edition({ negative = true }, true)
			ccard:add_to_deck()
			G.consumeables:emplace(ccard)
		end,
	},
    slib_credits = {art = {"Lil. Mr. Slipstream"}}
}
local mega2 = SMODS.shallow_copy(mega)
SMODS.Booster(mega)
mega2.pos.y = 1
mega2.key = "twisted_pack_mega_2"
mega2.order = -1001
SMODS.Booster(mega2)

function Entropy.get_rare_inversion(seed)
    local pool = {}
    for i, k in pairs(Entropy.RareInversions) do
        local v = G.P_CENTERS[k]
        if not (G.GAME.used_jokers[v.key] and not SMODS.showman(v.key) and not v.can_repeat_soul) and SMODS.add_to_pool(v, {}) then
            pool[#pool+1] = k
        end
    end
    if #pool > 0 then
        return pseudorandom_element(pool, pseudoseed(seed or "entr_twisted_rare")), pool
    end
end

function create_inverted_card(area, seed)
    local num = pseudorandom("twisted_rare")
    if G.GAME.interpolate_cards and #G.GAME.interpolate_cards > 0 then
        for i, v in pairs(G.GAME.interpolate_cards) do
            local num = pseudorandom("twisted_interpolate")
            if num <= 0.03 then
                local c = v
                return create_card(G.P_CENTERS[c].set, area or G.pack_cards, nil, nil, true, true, c)
            end
        end
    end
    if pseudorandom("entr_twisted_corrupted") < 0.01 then -- 1% chance
        if num - 0.003 <= 0 or (Entropy.has_rune("rune_entr_oss") and not Entropy.has_rune("rune_entr_oss").triggered) then
            if c then
                if not (num - 0.003 <= 0) then
                    calculate_runes({generate_rare_consumable = true})
                    Entropy.has_rune("rune_entr_oss").triggered = true
                end
                return SMODS.create_card{key = "j_entr_nyx", skip_materialize = true, area = G.pack_cards}
            end
        end
        return SMODS.create_card{set = "Joker", rarity = "entr_void"}
    end
    if num - 0.003 <= 0 or (Entropy.has_rune("rune_entr_oss") and not Entropy.has_rune("rune_entr_oss").triggered) then
        local c = Entropy.get_rare_inversion(not (num - 0.003 <= 0) and "rune_entr_oss" or nil)
        if c then
            if not (num - 0.003 <= 0) then
                calculate_runes({generate_rare_consumable = true})
                Entropy.has_rune("rune_entr_oss").triggered = true
            end
            return SMODS.create_card{key = c.key, skip_materialize = true, area = G.pack_cards}
        end
    else
        if Entropy.has_rune("rune_entr_mannaz") and (Entropy.has_rune("rune_entr_mannaz").num_triggered or 0) <= 1 then
            Entropy.has_rune("rune_entr_mannaz").num_triggered = (Entropy.has_rune("rune_entr_mannaz").num_triggered or 0) + 1
            if Entropy.has_rune("rune_entr_mannaz").num_triggered > 1 or not G.GAME.providence then
                Entropy.has_rune("rune_entr_mannaz").num_triggered = 2
                Entropy.has_rune("rune_entr_mannaz").triggered = true
            end
            G.entr_dont_calculate = true
            return SMODS.create_card{set = "Spectral", key_append = "rune_entr_mannaz", skip_materialize = true, area = G.pack_cards}
        end
    end
    if G.GAME.modifiers.entr_parakmi then
        return SMODS.create_card{set = Entropy.get_random_set(G.GAME.modifiers.entr_parakmi)}
    end
    local rune
    if pseudorandom("entr_generate_rune") < 0.06 then rune = true end
    if G.GAME.entr_diviner then
        if pseudorandom("entr_generate_rune") < 0.06 then rune = true end
    end
    if rune then
        return SMODS.create_card{set = "Pact", skip_materialize = true, area = G.pack_cards}
    end
    return SMODS.create_card{attributes = {"inverted_consumable"}, types = {"Consumeables"}, skip_materialize = true, area = G.pack_cards}
end

SMODS.Booster{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    order = -990.1,
    key = "voucher_pack",
    set = "Booster",
    config = { extra = 5, choose = 2 },
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                card.ability.choose,
                card.ability.extra,
                colours = {
                    HEX("ff00cd")
                }
            },
        }
    end,
    attributes = {"voucher", "normal"},
    atlas = 'booster', pos = { x = 6, y = 0 },
    group_key = "k_voucher_pack",
    cost = 10,
    draw_hand = false,
    weight = 0,
    kind = "Voucher",
    in_pool = function() return false end,
    create_card = function (self, card, i) 
        return create_card("Voucher", G.pack_cards)
    end,
    ease_background_colour = function(self)
		ease_colour(G.C.DYN_UI.MAIN, HEX("ff00cd"))
		ease_background_colour({ new_colour = HEX("ff00cd"), special_colour = HEX("ff00cd"), contrast = 2 })
	end,
    cry_digital_hallucinations = {
		colour = HEX("ff00cd"),
		loc_key = "k_voucher_pack",
		create = function()
			local ccard = create_card("Voucher", G.pack_cards)
			ccard:set_edition({ negative = true }, true)
			ccard:add_to_deck()
			G.consumeables:emplace(ccard)
		end,
	},
}