function Entropy.register_blinds()
    local bl = {}
    for i, v in pairs(G.P_BLINDS) do
        if not v.original_mod then
            bl[#bl+1] = {
                key = "entr_"..i,
                set = "CBlind",
                pixel_size = { w = 34, h = 34 },
                display_size = { w = 68, h = 68 },
                config = {
                    blind = i,
                    pos = v.pos,
                },
                order=order,
                dependencies = {
                    items = {
                        "set_entr_entropic"
                    }
                },
                weight = 0,
                no_doe = true,
                blpos = v.pos,
                blatlas = v.atlas,
                pos = {x = 9999, y = 9999},
                --soul_pos = { x = 5, y = 0},
                use = function(self, card, area, copier,amt)
                    local bl = "Small"
                    for i, v in pairs(G.GAME.round_resets.blind_states) do
                        if v == "Select" or v == "Current" then bl = i end
                    end
                    G.GAME.round_resets.blind_choices[bl] = self.config.blind
                    if G.blind_select then        
                        G.blind_select:remove()
                        G.blind_prompt_box:remove()
                        G.STATE_COMPLETE = false
                    else
                        G.GAME.blind:disable()
                        G.GAME.blind.loc_debuff_lines = {}
                        G.FUNCS.HUD_blind_debuff(G.HUD_blind:get_UIE_by_ID('HUD_blind_debuff'))
                        G.GAME.blind:set_blind(G.P_BLINDS[self.config.blind])
                    end
                end,
                can_use = function(self, card)
                    if not G.GAME.round_resets then return false end
                    if Entropy.is_ee_or_buildup() then return false end
                    if G.STATE ~= G.STATES.BLIND_SELECT and G.STATE ~= G.STATES.SELECTING_HAND then return false end
                    for i, v in pairs(G.GAME.round_resets.blind_states or {}) do
                        if v == "Select" or (not SMODS.Mods.NotJustYet or (not SMODS.Mods.NotJustYet.can_load and v == "Current")) then return true end
                    end
                    return false
                end,
                loc_vars = function(self,q,c)
                    if self.config.blind ~= "bl_small" and self.config.blind ~= "bl_big" then
                        q[#q+1]={set="Blind",key=self.config.blind}
                    end
                end,
                set_sprites = function(self, card, front, gc)
                    local pos = self.blpos
                    if card.ability and card.ability.glitched_crown then
                        pos = G.P_CENTERS[card.ability.glitched_crown[card.glitched_index] or self.key].blpos
                    end
                    if not pos then
                        pos = {x = 0, y = 0}
                    end
                    if not self.discovered then
                        pos = {x = 9999, y = 9999}
                    end
                    card.children.center.atlas = G.ANIMATION_ATLAS["blind_chips"]
                    card.children.center:set_sprite_pos({x=pos.x or 0, y=pos.y or 0})
                    if gc then card.children.center.T.h = 2 end
                end,
                demicoloncompat = true,
                force_use = function(self, card, area)
                    self:use(card, area)
                end,
                order = (v.cry_order or v.order or 0) - 1000,
                allow_duplicates = true
            }
        end
    end
    for i, v in pairs(SMODS.Blind.obj_table) do
        if not Entropy.BlindTokenBlacklist[i] and not v.no_collection and not v.no_token then
            bl[#bl+1] = {
                dependencies = {
                    items = {
                        "set_entr_entropic"
                    }
                },
                key = "entr_"..i,
                set = "CBlind",
                --atlas="entr_consumables",
                pixel_size = { w = 34, h = 34 },
                display_size = { w = 68, h = 68 },
                pos = {x = 9999, y = 9999},
                blpos = v.pos,
                blatlas = v.atlas,
                config = {
                    blind = i,
                    pos = v.pos,
                    atlas = v.atlas,
                },
                weight = 0,
                no_doe = true,
                --soul_pos = { x = 5, y = 0},
                use = function(self, card, area, copier,amt)
                    local bl = "Small"
                    for i, v in pairs(G.GAME.round_resets.blind_states) do
                        if v == "Select" or v == "Current" then bl = i end
                    end
                    G.GAME.round_resets.blind_choices[bl] = self.config.blind
                    if G.blind_select then        
                        G.blind_select:remove()
                        G.blind_prompt_box:remove()
                        G.STATE_COMPLETE = false
                    else
                        G.GAME.blind:disable()
                        G.GAME.blind.loc_debuff_lines = {}
		                G.FUNCS.HUD_blind_debuff(G.HUD_blind:get_UIE_by_ID('HUD_blind_debuff'))
                        G.GAME.blind:set_blind(G.P_BLINDS[self.config.blind])
                    end
                end,
                can_use = function(self, card)
                    if not G.GAME.round_resets then return false end
                    if Entropy.is_ee_or_buildup() then return false end
                    if G.STATE ~= G.STATES.BLIND_SELECT and G.STATE ~= G.STATES.SELECTING_HAND then return false end
                    for i, v in pairs(G.GAME.round_resets.blind_states or {}) do
                        if v == "Select" or (not SMODS.Mods.NotJustYet or (not SMODS.Mods.NotJustYet.can_load and v == "Current")) then return true end
                    end
                    return false
                end,
                loc_vars = function(self,q,c)
                    if self.config.blind ~= "bl_entr_small" and self.config.blind ~= "bl_entr_big" then
                        local bl = G.P_BLINDS[self.config.blind]
                        local func = bl.collection_loc_vars or bl.loc_vars or function() end
                        local ret = func(bl, {}, G.GAME.Blind)
                        q[#q+1]={set="Blind",key=self.config.blind, vars = ret and ret.vars}
                    end
                end,
                slib_credits = v.slib_credits,
                cry_credits = v.cry_credits,
                set_sprites = function(self, card, front, gc)
                    local pos = self.blpos
                    local atlas = self.blatlas
                    if card.ability and card.ability.glitched_crown then
                        pos = G.P_CENTERS[card.ability.glitched_crown[card.glitched_index] or self.key].blpos
                        atlas = G.P_CENTERS[card.ability.glitched_crown[card.glitched_index] or self.key].blatlas
                    end
                    if not pos then
                        pos = {x = 9999, y = 9999}
                    end
                    if not self.discovered then
                        pos = {x = 9999, y = 9999}
                    end
                    card.children.center:remove()
                    card.children.center = SMODS.create_sprite(0, 0, 1, 1, atlas or "blind_chips", {x=pos.x or 0, y=pos.y or 0})
                    card.children.center.states.hover = card.states.hover
                    card.children.center.states.click = card.states.click
                    card.children.center.states.drag = card.states.drag
                    card.children.center.states.collide.can = false
                    card.children.center:set_role({major = card, role_type = 'Glued', draw_major = card})
                    if gc then card.children.center.T.h = 2 end
                end,
                set_badges = function(self, card, badges)
                    if v.original_mod then badges[#badges+1] = create_badge(v.original_mod.name, v.original_mod.badge_colour, G.C.WHITE, 1 ) end
                end,
                demicoloncompat = true,
                force_use = function(self, card, area)
                    self:use(card, area)
                end,
                order = (v.cry_order or v.order or 0) + (v.mod or {priority = 0}).priority,
                allow_duplicates = true
            }
        end
    end
    table.sort(bl, function(a, b) return a.order < b.order end)
    for i, v in pairs(bl) do
        v.cry_order = v.order
        v.order = nil
        SMODS.Consumable(v)
    end
end

local set_spritesref = Card.set_sprites
function Card:set_sprites(_center, _front)
    set_spritesref(self,_center,_front)
    if _center and _center.set_sprites and _center.set == "CBlind" then
        _center:set_sprites(self, _front)
    end
end


local card_hoverref = Card.draw
function Card:draw(layer)
    local ref = card_hoverref(self, layer)    
    if self.config.center.set_sprites and self.children and self.children.floating_sprite and self.config.center.set == "CBlind" then
        local scale_mod = 0.6
        local rotate_mod = 0

        self.children.floating_sprite.role.draw_major = self
        self.children.floating_sprite:draw_shader(
            (G.P_CENTERS[self.edition and self.edition.key or ""] or {shader="dissolve"}).shader or "dissolve",
            0,
            nil,
            nil,
            self.children.center,
            scale_mod,
            rotate_mod,
            0.85,
            1.3,
            nil,
            0.6
        )
        self.children.floating_sprite:draw_shader(
            (G.P_CENTERS[self.edition and self.edition.key or ""] or {shader="dissolve"}).shader or "dissolve",
            nil,
            nil,
            nil,
            self.children.center,
            scale_mod,
            rotate_mod,
            0.85,
            1.3
        )
    end
    return ref
end