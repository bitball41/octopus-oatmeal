SMODS.Shader({
    key="solar",
    path="solar.fs"
})

Entropy.Edition{
	order = 9000+1,
    key="solar",
    shader="solar",
    config = {
        sol = 1.2
    },
	sound = {
		sound = "entr_e_solar",
		per = 1,
		vol = 0.4,
	},
	dependencies = {
        items = {
          "set_entr_misc"
        }
    },
	extra_cost = 6,
	in_shop = true,
	weight = 0.4,
    badge_color = HEX("fca849"),
	disable_base_shader=true,
    loc_vars = function(self,q,card)
		Entropy.ensure_ascpow_tutorial(q)
        return {vars={card and card.edition and card.edition.sol or 1.4}}
    end,
    calculate = function(self, card, context)
		if
			(
				context.edition
				and context.cardarea == G.jokers
				and card.config.trigger
			) or (
				context.main_scoring
				and context.cardarea == G.play
			)
		then
			return { x_asc = card and card.edition and card.edition.sol or 1.4 }
		end
		if context.joker_main then
			card.config.trigger = true
		end

		if context.after then
			card.config.trigger = nil
		end
	end,
	slib_credits = {
		custom={key="shader",text="cassknows"}
	},
}


SMODS.Shader({
    key="fractured",
    path="fractured.fs"
})

Entropy.Edition{
	order = 9000+2,
    key="fractured",
    shader="fractured",
    config = {
        retrig = 3
    },
	sound = {
		sound = "entr_e_fractured",
		per = 1,
		vol = 0.8,
	},
	dependencies = {
        items = {
          "set_entr_misc"
        }
    },
	extra_cost = 8,
	in_shop = true,
	weight = 0.2,
    badge_color = HEX("fca849"),
	disable_base_shader=true,
    loc_vars = function(self,q,card)
        return {vars={card and card.edition and card.edition.retrig or 3}}
    end,
	draw = function(self, card, layer)
		card.children.center:draw_shader(G.P_CENTERS.e_entr_fractured.shader, nil, card.ARGS.send_to_shader)
		if card.children.front and card.ability.effect ~= 'Stone Card' and not card.config.center.replace_base_card then
			card.children.front:draw_shader("dissolve")
		end
	end,
    calculate = function(self, card, context)
		if context.joker_main then
			card.config.trigger = true
		end

		if context.after then
			card.config.trigger = nil
		end
		if (
			context.edition
			and context.cardarea == G.jokers
			and card.config.trigger
		) or (
			context.main_scoring
			and context.cardarea == G.play
		) then
			return Entropy.random_forcetrigger(card, card and card.edition and card.edition.retrig or 3, context)
		end
	end,
	slib_credits = {
		custom={key="shader",text="cassknows"},
		idea = {"cassknows"}
	},
}
SMODS.Shader({
    key="sunny",
    path="sunny.fs"
})
Entropy.Edition{
	order = 9000-1,
    key="sunny",
    shader="sunny",
    config = {
        sol = 2
    },
	extra_cost = 4,
	sound = {
		sound = "entr_e_solar",
		per = 1,
		vol = 0.4,
	},
	dependencies = {
        items = {
          "set_entr_misc"
        }
    },
	in_shop = true,
	weight = 0.8,
	extra_cost = 2,
    badge_color = HEX("fca849"),
	disable_base_shader=true,
    loc_vars = function(self,q,card)
		Entropy.ensure_ascpow_tutorial(q)
        return {vars={card and card.edition and card.edition.sol or 4}}
    end,
    calculate = function(self, card, context)
		if
			(
				context.edition
				and context.cardarea == G.jokers
				and card.config.trigger
			) or (
				context.main_scoring
				and context.cardarea == G.play
			)
		then
			return { plus_asc = card and card.edition and card.edition.sol or 1.4 }
		end
		if context.joker_main then
			card.config.trigger = true
		end

		if context.after then
			card.config.trigger = nil
		end
	end,
	slib_credits = {
		custom={key="shader",text="cassknows"}
	}
}

SMODS.Shader({
    key="freaky",
    path="freaky.fs"
})

Entropy.Edition{
	order = 9000+3,
    key="freaky",
    shader="freaky",
	sound = {
		sound = "entr_e_rizz",
		per = 1,
		vol = 0.4,
	},
	config = {
		log_base = 69
	},
	dependencies = {
        items = {
          "set_entr_misc"
        }
    },
	extra_cost = 6,
	in_shop = true,
	weight = 0.5,
    badge_color = HEX("fca849"),
	disable_base_shader=true,
    loc_vars = function(self,q,card)
		return {vars={card and card.edition and card.edition.log_base or 69}}
    end,
    calculate = function(self, card, context)
		if
			(
				context.edition
				and context.cardarea == G.jokers
				and card.config.trigger
			) or (
				context.main_scoring
				and context.cardarea == G.play
			)
		then
			return { xlog_chips = card and card.edition and card.edition.log_base or 69}
		end
		if context.joker_main then
			card.config.trigger = true
		end

		if context.after then
			card.config.trigger = nil
		end
	end,
	slib_credits = {
		custom={key="shader",text="cassknows"},
		idea = {"cassknows"}
	},
}

if AurinkoAddons then
	AurinkoAddons.entr_solar = function(card, hand, instant, amount)
		if to_big(G.GAME.hands[hand].AscensionPower or 0) > to_big(0) then
            local handname = hand
            local used_consumable = card
            local c
            local m
            local chips = Entropy.ascend_hand(G.GAME.hands[handname].chips, handname)
            local mult = Entropy.ascend_hand(G.GAME.hands[handname].mult, handname)
            if not instant then
                c = copy_table(G.C.UI_CHIPS)
                m = copy_table(G.C.UI_MULT)
                delay(0.4)
                update_hand_text(
                    { sound = "button", volume = 0.7, pitch = 0.8, delay = 0.3 },
                    { handname = localize(handname,'poker_hands'), chips = "...", mult = "...", level = "..." }
                )
            end
            local amt = G.GAME.hands[handname].AscensionPower
            G.GAME.hands[handname].AscensionPower = to_big((G.GAME.hands[handname].AscensionPower or 0)) * (to_big(card.edition.sol) ^ (amount or 1))
			amt = G.GAME.hands[handname].AscensionPower - amt
            chips = Entropy.ascend_hand(G.GAME.hands[handname].chips, handname) - chips
            mult = Entropy.ascend_hand(G.GAME.hands[handname].mult, handname) - mult
            if G.entr_add_to_stats then
                SMODS.Scoring_Parameters.chips.current = SMODS.Scoring_Parameters.chips.current + chips
                SMODS.Scoring_Parameters.mult.current = SMODS.Scoring_Parameters.mult.current + mult
            end
            if not instant then
                delay(1.0)
                G.E_MANAGER:add_event(Event({
                    trigger = "after",
                    delay = 0.2,
                    func = function()
                    play_sound("tarot1")
                    ease_colour(G.C.UI_CHIPS, HEX("ffb400"), 0.1)
                    ease_colour(G.C.UI_MULT, HEX("ffb400"), 0.1)
                    Cryptid.pulse_flame(0.01, sunlevel)
                    if used_consumable and used_consumable.juice_up then used_consumable:juice_up(0.8, 0.5) end
                    G.E_MANAGER:add_event(Event({
                        trigger = "after",
                        blockable = false,
                        blocking = false,
                        delay = 1.2,
                        func = function()
                        ease_colour(G.C.UI_CHIPS, c, 1)
                        ease_colour(G.C.UI_MULT, m, 1)
                        return true
                        end,
                    }))
                    return true
                    end,
                }))
            end
            if not instant then
                update_hand_text({ sound = "button", volume = 0.7, pitch = 0.9, delay = 0 }, { level ="X"..number_format((to_big(card.edition.sol) ^ (amount or 1))) })
                delay(1.6)
            end
            if not instant then
                delay(1.6)
                update_hand_text(
                    { sound = "button", volume = 0.7, pitch = 1.1, delay = 0 },
                    { mult = 0, chips = 0, handname = "", level = "" }
                )
                delay(1)
            end
            G.hand:parse_highlighted()
            G.GAME.current_round.current_hand.cry_asc_num = 0
            G.GAME.current_round.current_hand.cry_asc_num_text = ""
		end
	end
	AurinkoAddons.entr_sunny = function(card, hand, instant, amount)
		local amt = 2*(amount or 1)
            local handname = hand
            local used_consumable = card
            local c
            local m
            local chips = Entropy.ascend_hand(G.GAME.hands[handname].chips, handname)
            local mult = Entropy.ascend_hand(G.GAME.hands[handname].mult, handname)
            if not instant then
                c = copy_table(G.C.UI_CHIPS)
                m = copy_table(G.C.UI_MULT)
                delay(0.4)
                update_hand_text(
                    { sound = "button", volume = 0.7, pitch = 0.8, delay = 0.3 },
                    { handname = localize(handname,'poker_hands'), chips = "...", mult = "...", level = "..." }
                )
            end
            G.GAME.hands[handname].AscensionPower = to_big((G.GAME.hands[handname].AscensionPower or 0)) + to_big(amt)
            chips = Entropy.ascend_hand(G.GAME.hands[handname].chips, handname) - chips
            mult = Entropy.ascend_hand(G.GAME.hands[handname].mult, handname) - mult
            if G.entr_add_to_stats then
                SMODS.Scoring_Parameters.chips.current = SMODS.Scoring_Parameters.chips.current + chips
                SMODS.Scoring_Parameters.mult.current = SMODS.Scoring_Parameters.mult.current + mult
            end
            if not instant then
                delay(1.0)
                G.E_MANAGER:add_event(Event({
                    trigger = "after",
                    delay = 0.2,
                    func = function()
                    play_sound("tarot1")
                    ease_colour(G.C.UI_CHIPS, HEX("ffb400"), 0.1)
                    ease_colour(G.C.UI_MULT, HEX("ffb400"), 0.1)
                    Cryptid.pulse_flame(0.01, sunlevel)
                    if used_consumable and used_consumable.juice_up then used_consumable:juice_up(0.8, 0.5) end
                    G.E_MANAGER:add_event(Event({
                        trigger = "after",
                        blockable = false,
                        blocking = false,
                        delay = 1.2,
                        func = function()
                        ease_colour(G.C.UI_CHIPS, c, 1)
                        ease_colour(G.C.UI_MULT, m, 1)
                        return true
                        end,
                    }))
                    return true
                    end,
                }))
            end
            if not instant then
                update_hand_text({ sound = "button", volume = 0.7, pitch = 0.9, delay = 0 }, { level = (to_big(amt) > to_big(0) and "+" or "")..number_format(to_big(amt) ) })
                delay(1.6)
            end
            if not instant then
                delay(1.6)
                update_hand_text(
                    { sound = "button", volume = 0.7, pitch = 1.1, delay = 0 },
                    { mult = 0, chips = 0, handname = "", level = "" }
                )
                delay(1)
            end
            G.hand:parse_highlighted()
            G.GAME.current_round.current_hand.cry_asc_num = 0
            G.GAME.current_round.current_hand.cry_asc_num_text = ""
	end
	AurinkoAddons.entr_freaky = function(card, hand, instant, amount)
		local hand_chips = G.GAME.hands[hand].chips
		local mult = math.max(Entropy.approximate_log_recursion(hand_chips, card.edition.log_base, amount), hand_chips)/hand_chips
		hand_chips = math.max(Entropy.approximate_log_recursion(hand_chips, card.edition.log_base, amount), hand_chips)
		G.GAME.hands[hand].chips = hand_chips
		if not instant then
			G.E_MANAGER:add_event(Event({
				trigger = "after",
				delay = 0.2,
				func = function()
					play_sound("entr_e_rizz", 0.7)
					card:juice_up(0.8, 0.5)
					return true
				end,
			}))
			update_hand_text(
				{ delay = 1.3 },
				{ chips = "X"..number_format(mult), StatusText = true }
			)
			G.E_MANAGER:add_event(Event({
				trigger = "after",
				delay = 0.2,
				func = function()
					play_sound("entr_e_rizz")
					card:juice_up(0.8, 0.5)
					return true
				end,
			}))
		end
	end
end

if Entropy.config.override_glitched then

	SMODS.Shader({
		key="entr_glitched",
		path="entr_glitched.fs"
	})

	SMODS.Edition:take_ownership("cry_glitched", {
		shader = "entr_glitched"
	}, true)

end

SMODS.Shader({
    key="neon",
    path="neon.fs"
})

Entropy.Edition{
	order = 9000-2,
    key="neon",
    shader="neon",
	sound = {
		sound = "entr_e_neon",
		per = 1,		
	},
	config = {
		cost_fac = 0.9,
		cost_fac_playing = 0.95
	},
	dependencies = {
        items = {
          "set_entr_misc"
        }
    },
	in_shop = true,
	weight = 0.5,
    badge_color = HEX("fca849"),
	disable_base_shader=true,
    loc_vars = function(self,q,card)
		if G.GAME.modifiers.entr_gfb then
			return {key = "e_entr_neon_gfb"}
		end
		return {vars={card and card.edition and (card.is_playing_card and card:is_playing_card() and card.edition.cost_fac_playing or card.edition.cost_fac) or 0.9}}
    end,
	slib_credits = {
		custom={key="shader",text="cassknows"},
		idea = {"cassknows"}
	},
	on_apply = function(card)
		if G.GAME.modifiers.entr_gfb then
			change_shop_size(1)
		end
	end,
	on_remove = function(card)
		if G.GAME.modifiers.entr_gfb then
			change_shop_size(-1)
		end	
	end,
}

local set_cost_ref = Card.set_cost
function Card:set_cost()
	set_cost_ref(self)
	if not G.GAME.modifiers.entr_gfb then
		for i, v in pairs(G.I.CARD) do
			if v.edition and v.edition.key == "e_entr_neon" and v.area and v.area.config.type ~= "shop" and not v.debuff then
				self.cost = self.cost * (v:is_playing_card() and v.edition.cost_fac_playing or v.edition.cost_fac) or 1
			end
		end
	end
	if Entropy.has_rune("rune_entr_avarice") then
	    local cost_fac = 0.25 ^ #Entropy.find_runes("rune_entr_avarice")
        self.sell_cost = self.sell_cost * cost_fac
        self.sell_cost_label = self.facing == 'back' and '?' or number_format(self.sell_cost)
	end
	if G.GAME.entr_booster_cost and self.config.center.set == "Booster" then
		self.cost = self.cost * G.GAME.entr_booster_cost
	end
	if G.GAME.modifiers.entr_platinum and self.config.center.set == "Joker" then
		self.cost = math.floor(self.cost * G.GAME.modifiers.entr_platinum)
	end
	if self.config.center.key == "j_entr_recursive_joker" and not self.ability.cost_set then
		self.ability.cost_set = true
		self.sell_cost = self.cost
		self.sell_cost_label = self.facing == 'back' and '?' or number_format(self.sell_cost)
	end
	if next(SMODS.find_card("j_entr_kitchenjokers")) and self:is_food() then
		local val = 1
		for i, v in pairs(SMODS.find_card("j_entr_kitchenjokers")) do
			val = val * v.ability.off_perc
		end
		self.cost = self.cost * val
	end
end


SMODS.Shader({
    key="lowres",
    path="lowres.fs"
})

Entropy.Edition{
	order = 9000-1.75,
    key="lowres",
    shader="lowres",
	sound = {
		sound = "entr_e_lowres",
		per = 1,
		vol = 1,
	},
	config = {
		triggers = 2,
		factor = 0.25
	},
	dependencies = {
        items = {
          "set_entr_misc"
        }
    },
	extra_cost = 5,
	in_shop = true,
	weight = 0.45,
    badge_color = HEX("fca849"),
    loc_vars = function(self,q,card)
		return {vars={card and card.edition and card.edition.triggers or 2, card and card.edition and card.edition.factor or 0.25}}
    end,
    calculate = function(self, card, context)
		if context.other_card == card and ((context.repetition and (context.cardarea == G.play or context.cardarea == G.hand)) or (context.retrigger_joker_check and not context.retrigger_joker)) then
			return {
				message = localize("k_again_ex"),
				repetitions = card.edition.triggers,
				card = card,
			}
		end
	end,
	on_apply = function(card)
		if not card.edition or not card.edition.lowres then
			Cryptid.manipulate(card, {
				value = 0.25
			}, nil, true)
		end
	end,
	on_remove = function(card)
		Cryptid.manipulate(card, { value = 4 }, nil, true)		
	end,
	slib_credits = {
		custom={key="shader",text="cassknows"},
		idea = {"cassknows"}
	},
}

SMODS.Shader({
    key="kaleidoscopic",
    path="kaleidoscopic.fs"
})


Entropy.Edition{
	order = 9000+4,
    key="kaleidoscopic",
    shader="kaleidoscopic",
	sound = {
		sound = "entr_e_kaleidoscopic",
		per = 1,
		vol = 0.8,
	},
	config = {
		cards = 2
	},
	dependencies = {
        items = {
          "set_entr_misc"
        }
    },
	extra_cost = 5,
	in_shop = true,
	weight = 0.45,
    badge_color = HEX("fca849"),
    loc_vars = function(self,q,card)
		return {vars={card and card.edition and card.edition.triggers or 2, card and card.edition and card.edition.cards or 2}}
    end,
    calculate = function(self, card, context)
		if context.edition or context.main_scoring and not context.kaleidoscopic then
			local cards = {}
			for i, v in pairs(card.area.cards) do cards[#cards+1] = v; end
			pseudoshuffle(cards, pseudoseed('kaleidoscopic_cards'))
			local actual = {}
			for i = 1, card.edition and card.edition.cards or 2 do
				actual[i] = cards[i]
			end
			for i, v in pairs(actual) do
				context.kaleidoscopic = true
				context.edition = nil
				local eval, post = eval_card(v, context)
				eval = eval or {}
				local effects = {eval}
				if context.main_scoring then 
					eval.chips = v:get_chip_bonus() or 0
					SMODS.calculate_context({individual = true, other_card=v, cardarea = v.area})
				end
				for _,v in ipairs(post or {}) do effects[#effects+1] = v end
				SMODS.trigger_effects(effects, v)
				context.kaleidoscopic = nil
			end
		end
	end,
	slib_credits = {
		custom={key="shader",text="cassknows"},
		idea = {"cassknows"}
	},
}

SMODS.Shader({
    key="gilded",
    path="gilded.fs"
})

Entropy.Edition{
	order = 9000+5,
    key="gilded",
    shader="gilded",
	sound = {
		sound = "entr_e_gilded",
		per = 1,
	},
	dependencies = {
        items = {
          "set_entr_misc"
        }
    },
	extra_cost = 3,
	in_shop = true,
	weight = 0.75,
    badge_color = HEX("ff7900"),
    loc_vars = function(self,q,card)
		return {vars={card and card.edition and card.edition.triggers or 2, card and card.edition and card.edition.cards or 2}, key = card and card.ability and card.ability.consumeable and "e_entr_gilded_consumable" or nil}
    end,
    calculate = function(self, card, context)
		if (context.retrigger_joker_check or context.repetition) and context.other_card == card then
			return {
				repetitions = 1
			}
		end
		if context.pre_using_self and context.consumeable == card then
			card.delay_dissolve = {type = "after_after", delay = 1.5}
            G.E_MANAGER:add_event(Event{
				trigger = "after",
				delay = 0.5,
				func = function()
					G.E_MANAGER:add_event(Event{
						trigger = "after",
						delay = 1,
						func = function()
							Spectrallib.forcetrigger({
                                card = Entropy.get_dummy(card.config.center, G.consumeables, card),
                                context = context,
								silent = true
                            })
							return true
						end
					})
					return true
				end
			})
        end
	end,
}

local card_click = Card.click
function Card:click(...)
	if G.GAME.entr_dating_start then 
		return
	end
	if G.SETTINGS.paused and self.edition and G.P_CENTERS[self.edition.key] and G.P_CENTERS[self.edition.key].sound then
		play_sound(G.P_CENTERS[self.edition.key].sound.sound, G.P_CENTERS[self.edition.key].sound.volume)
	end
	if self.config.center.key == "j_entr_title_card" then
		G.back_to_main = true
		G.FUNCS["openModUI_entr"]()
		G.back_to_main = nil
	end
	if G.SETTINGS.paused and self.config and self.config.center_key == "j_entr_amaryllis" then
		self.ability.colour = ({
			white = "red",
			red = "pink",
			pink = "orange",
			orange = "purple",
			purple = "yellow",
			yellow = "white"
		})[self.ability.colour]
		self:juice_up()
		local x_map = {
			red = 5,
			white = 4,
			pink = 6,
			orange = 7,
			purple = 8,
			yellow = 9
		}
		self.children.center:set_sprite_pos({x = x_map[self.ability.colour], y = 16})
	end
	return card_click(self, ...)
end
