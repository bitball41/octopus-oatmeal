Entropy.Consumable{
    order = 1000 + 1,
    key = "flipside",
    atlas = "consumables",
    pos = {x = 3, y = 0},
    dependencies = {
        items={"set_entr_inversions"}
    },
    config = {
        select = 1
    },
    set = "Spectral",
    can_use = function(self, card)
        local cards = {}
        for i, v in pairs(G.I.CARD) do
            if getmetatable(v) == Card then
                cards[#cards+1] = v
            end
        end
        local cards = Entropy.get_highlighted_cards({cards}, card, 1, card.ability.select)
        cards = Entropy.filter_table(cards, function(card)
            return Entropy.inversion(card) or card.config.center.key == "c_entr_flipside"
        end)
        return #cards > 0 and #cards <= card.ability.select
    end,
    use = function(self, card)
        local cards = {}
        for i, v in pairs(G.I.CARD) do
            if getmetatable(v) == Card then
                cards[#cards+1] = v
            end
        end
        local cards = Entropy.get_highlighted_cards({cards}, card, 1, card.ability.select)
        local actual = Entropy.filter_table(cards, function(card)
            return Entropy.inversion(card)
        end)
        Entropy.invert(cards, true, true)
    end,
    can_be_inverted = true,
    calculate = function(self, card, context)
        if context.being_inverted then
            local cards2 = {}
            for i, card in pairs(G.I.CARD) do
                if Entropy.inversion(card) and card.config.center.key ~= "c_entr_flipside" then
                    cards2[#cards2+1] = card
                end
            end
            card:start_dissolve()
            Entropy.invert(cards2, true, true)
            return {
                prevent_inversion = true
            }
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.select,
            }
        }
    end,
    can_be_pulled = true,
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    order = 7023,
    key = "flipside_omen",
    atlas = "consumables2",
    pos={x=4,y=3},
    dependencies = {
        items={"set_entr_inversions"}
    },
    config = {
        select = 1
    },
    set = "Omen",
    inversion = "c_entr_flipside",
    can_use = function(self, card)
        return G.P_CENTERS.c_entr_flipside:can_use(card)
    end,
    use = function(self, card)
        return G.P_CENTERS.c_entr_flipside:use(card)
    end,
    can_be_inverted = true,
    calculate = function(self, card, context)
        return G.P_CENTERS.c_entr_flipside:calculate(card, context)
    end,
    loc_vars = function(self, q, card)
        return G.P_CENTERS.c_entr_flipside:loc_vars(q, card)
    end,
    can_be_pulled = true,
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    key = "shatter",
    set = "Spectral",
    
    order = 900+37,
    config = {limit = 1, csl = 1},
    atlas = "consumables",
    pos = {x=5,y=8},
    dependencies = {
        items = {
          "set_entr_spectrals"
        }
    },
    use = function(self, card, area, copier)
        Entropy.flip_then(Entropy.get_highlighted_cards({G.hand}, card, 1, card.ability.limit), function(card)
            card:set_edition("e_entr_fractured")
        end)
        Entropy.change_selection_limit(-card.ability.csl)
    end,
    can_use = function(self, card)
        local num = #Entropy.get_highlighted_cards({G.hand}, card, 1, card.ability.limit)
        return num > 0 and num <= card.ability.limit
	end,
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.e_entr_fractured
        return {vars={
            card.ability.limit,
            card.ability.csl
        }}
    end,
    slib_credits = {
        idea = {"cassknows"},
        art = {"cassknows"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    key = "destiny",
    set = "Spectral",
    
    order = 900+36,
    atlas = "consumables",
    immutable = true,
    pos = {x=5,y=7},
    dependencies = {
        items = {
          "set_entr_spectrals"
        }
    },
    use = function(self, card, area, copier)
        local remove = {}
        local highlighted = Entropy.get_highlighted_cards({G.hand}, card, 5, 5)
        for i, v in pairs(highlighted) do
            if v.config.center.key ~= "c_base" or pseudorandom("crafting") < 0.4 then
                SMODS.destroy_cards{v}
            else
                Entropy.discard_specific({v})
            end
        end
        add_joker(Entropy.get_recipe(highlighted))
    end,
    keep_on_use = function(self, card)
        return Entropy.deck_or_sleeve("crafting")
    end,
    can_use = function(self, card)
        local highlighted = Entropy.get_highlighted_cards({G.hand}, card, 5, 5)
        return G.hand and #highlighted == 5
	end,
    loc_vars = function(self, q, card)
        local jok = G.hand and Entropy.get_recipe(G.hand.highlighted)
        local highlighted = Entropy.get_highlighted_cards({G.hand}, card, 5, 5)
        if G.hand and #highlighted == 5 then
            q[#q+1] = jok and G.P_CENTERS[jok] or nil
        end
        
        return {vars={
            G.hand and #highlighted == 5 and localize({type = "name_text", set = "Joker", key = jok}) or "none"
        }}
    end,
    no_doe = true,
    in_pool = function()
        return not Entropy.deck_or_sleeve("crafting")
    end,
    weight = 0,    
}

Entropy.Consumable{
    key = "lust",
    set = "Spectral",
    
    order = 900+38,
    config = {limit = 1},
    atlas = "consumables",
    pos = {x=4,y=Cryptid_config.family_mode and 8 or 7},
    dependencies = {
        items = {
          "set_entr_spectrals"
        }
    },
    use = function(self, card, area, copier)
        local cards = {}
        local rcards = {}
        for i, v in pairs(G.hand.cards) do if not v.edition then cards[#cards+1] = v end end
        pseudoshuffle(cards, pseudoseed("entr_lust"))
        for i = 1, math.min(#cards, card.ability.limit) do rcards[#rcards+1] = cards[i] end
        Entropy.flip_then(rcards, function(card)
            card:set_edition("e_entr_freaky")
        end)
    end,
    can_use = function(self, card)
        return G.hand and #G.hand.cards > 0
	end,
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.e_entr_freaky
        return {vars={
            card.ability.limit
        }}
    end,
    slib_credits = {
        art = {"missingnumber"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}
local ref = Cryptid.reload_localization
function Cryptid.reload_localization()
    SMODS.handle_loc_file(Entropy.path)
    if G.P_CENTERS.c_entr_lust then
        G.P_CENTERS.c_entr_lust.pos = {x=4,y=Cryptid_config.family_mode and 8 or 7}

        G.P_CENTERS.j_entr_bloodletting.pos = Entropy.config.hide_sensitive_content and {x=3,y=19} or {x=0,y=18}
        for i, v in ipairs(G.I.CARD) do
            if v.config.center_key == "c_entr_lust" then
                v.children.center:set_sprite_pos({x=4,y=Cryptid_config.family_mode and 8 or 7})
            end
            if v.config.center_key == "j_entr_bloodletting" then
                v.children.center:set_sprite_pos(Entropy.config.hide_sensitive_content and {x=3,y=19} or {x=0,y=18})
            end
        end
    end
    if ref then
        return ref()
    else
        Entropy.config.family_mode = Cryptid_config.family_mode
        return init_localization()
    end
end


Entropy.Consumable{
    key = "null",
    set = "Spectral",
    
    order = 900+39,
    config = {create = 5},
    atlas = "consumables",
    pos = {x=3,y=7},
    dependencies = {
        items = {
          "set_entr_spectrals"
        }
    },
    use = function(self, card, area, copier)
        local destroyed_cards = {}
        destroyed_cards[#destroyed_cards+1] = pseudorandom_element(G.hand.cards, pseudoseed('random_destroy'))
        G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.4, func = function()
            play_sound('tarot1')
            card:juice_up(0.3, 0.5)
            return true 
        end }))
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.1,
            func = function() 
                for i=#destroyed_cards, 1, -1 do
                    local card = destroyed_cards[i]
                    if card.ability.name == 'Glass Card' then 
                        card:shatter()
                    else
                        card:start_dissolve(nil, i ~= #destroyed_cards)
                    end
                end
                return true 
            end 
        }))
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.7,
            func = function() 
                local cards = {}
                for i=1, card.ability.create do
                    cards[i] = true
                    local _suit, _rank = nil, nil
                    _rank = "entr_nilrank"
                    _suit = "entr_nilsuit"
                    local cen_pool = {}
                    for k, v in pairs(G.P_CENTER_POOLS["Enhanced"]) do
                        if v.key ~= 'm_stone' then 
                            cen_pool[#cen_pool+1] = v
                        end
                    end
                    create_playing_card({front = G.P_CARDS[_suit..'_'.._rank], center = pseudorandom_element(cen_pool, pseudoseed('spe_card'))}, G.hand, nil, i ~= 1, {G.C.SECONDARY_SET.Spectral})
                end
                playing_card_joker_effects(cards)
                return true 
            end 
        }))
        for i = 1, #G.jokers.cards do
            G.jokers.cards[i]:calculate_joker({remove_playing_cards = true, removed = destroyed_cards})
        end
    end,
    can_use = function(self, card)
        return G.hand and #G.hand.cards > 0
	end,
    loc_vars = function(self, q, card)
        return {vars={
            card.ability.create
        }}
    end,
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    key = "antithesis",
    set = "Spectral",
    order = 1000+2,
    atlas = "consumables2",
    pos = {x=1,y=3},
    soul_pos = {x = 3, y = 3, extra = {x = 2, y = 3}},
    dependencies = {
        items = {
          "set_entr_spectrals"
        }
    },
    hidden = true,
    soul_set = "Spectral",
    use = function(self, card, area, copier)
        G.GAME.entr_antithesis_active = true
        G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.2, func = function()
                play_sound('tarot1')
                if card and card.juice_up then card:juice_up(0.8, 0.5) end
                G.TAROT_INTERRUPT_PULSE = true
                return true end }))
        delay(1)
    end,
    can_use = function(self, card)
        return true
	end,
    slib_credits = {
        idea = {"cassknows"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_runes",
          "entr_ornate"
        }
    },
    order = 900+40,
    key = "enchant",
    set = "Spectral",
    
    atlas = "consumables2",
    config = {
        highlighted = 1
    },
    pos = {x=1,y=0},
    use = Entropy.modify_hand_card_NF({seal="entr_ornate"}),
    can_use = function(self, card)
        local cards = Entropy.get_highlighted_cards({G.hand}, card, 1, card.ability.highlighted)
        return #cards > 0 and #cards <= card.ability.highlighted
    end,
    loc_vars = function(self, q, card)
        q[#q+1] = {key = "entr_ornate_seal", set="Other"}
        return {
            vars = {
                card.ability.highlighted,
            }
        }
    end,
    slib_credits = slib_credits,
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_spectrals",
        }
    },
    order = 900+41,
    key = "manifest",
    set = "Spectral",
    
    atlas = "consumables",
    pos = {x=2,y=7},
    use = function()
        add_tag(Tag(Entropy.AscendedTags[G.GAME.round_resets.blind_tags.Small] or G.GAME.round_resets.blind_tags.Small))
        add_tag(Tag(Entropy.AscendedTags[G.GAME.round_resets.blind_tags.Big] or G.GAME.round_resets.blind_tags.Big))
    end,
    can_use = function(self, card)
        return true
    end,
    loc_vars = function(self, q, card)
        if G.GAME.round_resets and G.GAME.round_resets.blind_tags then
            q[#q+1] = G.P_TAGS[Entropy.AscendedTags[G.GAME.round_resets.blind_tags.Small] or G.GAME.round_resets.blind_tags.Small]
            q[#q+1] = G.P_TAGS[Entropy.AscendedTags[G.GAME.round_resets.blind_tags.Big] or G.GAME.round_resets.blind_tags.Big]
        end
    end,
    slib_credits = slib_credits,
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}