Entropy.Back{
    order = 7000,
    dependencies = {
      items = {
        "set_entr_inversions",
        "set_entr_decks"
      }
    },
    name = "Twisted Deck",
    key = "twisted",
    pos = { x = 0, y = 0 },
    atlas = "decks",
    apply = function()
        G.GAME.modifiers.entr_twisted = true
        G.GAME.round_resets.path_toggled = true
        G.GAME.entr_alt = not G.GAME.entr_alt
        ease_background_colour{new_colour = Spectrallib.get_bg_colour(), contrast = 1}
        if G.ARGS.spin then G.ARGS.spin.real = (G.SETTINGS.reduced_motion and 0 or 1)*(G.GAME.entr_alt and 0.3 or -0.3) end
    end,
    slib_credits = {art = {"Lil. Mr. Slipstream"}}
}

Entropy.Back{
    order = 7001,
    dependencies = {
      items = {
        "set_entr_decks"
      }
    },
    name = "CCD 2.0",
    key = "ccd2",
    pos = { x = 1, y = 0 },
    atlas = "decks",
    apply = function(self)
        G.GAME.modifiers.ccd2 = true
    end,
    slib_credits = {art = {"Lil. Mr. Slipstream"}}
}


Entropy.Back{
  order = 7003,
  dependencies = {
    items = {
      "set_entr_decks"
    }
  },
  name = "Deck of Destiny",
  key = "crafting",
  pos = { x = 3, y = 0 },
  atlas = "decks",
  apply = function(self)
    G.GAME.modifiers.crafting = true
    if not G.GAME.JokerRecipes then G.GAME.JokerRecipes = {} end
    --G.hand.config.highlighted_limit = 
    G.GAME.joker_rate = 0
    if not G.GAME.banned_keys then G.GAME.banned_keys = {} end
    G.GAME.banned_keys["p_bufoon_normal_1"] = true
    G.GAME.banned_keys["p_bufoon_normal_2"] = true
    G.GAME.banned_keys["p_bufoon_jubmo_1"] = true
    G.GAME.banned_keys["p_bufoon_mega_1"] = true
    G.E_MANAGER:add_event(Event({
      trigger = 'after',
      func = function()
        local c = create_card("Spectral", G.consumeables, nil, nil, nil, nil, "c_entr_destiny") 
        c.ability.cry_absolute = true
        c.ability.entr_aleph = true
        c:add_sticker("eternal", true)
        c:add_to_deck()
        G.consumeables:emplace(c)
        c:set_edition("e_negative")
        return true
      end}))
  end,
  config = { vouchers = { "v_magic_trick", "v_illusion" } },
  slib_credits = {
    art = {"Lil. Mr. Slipstream"}
  }
}


Entropy.Back{
  order = 7004,
  dependencies = {
    items = {
      "set_entr_decks"
    }
  },
  key = "ambisinister",
  pos = { x = 5, y = 0 },
  atlas = "decks",
  apply = function()
    G.GAME.starting_params.joker_slots = G.GAME.starting_params.joker_slots + 3
    Entropy.last_csl = nil
    Entropy.last_slots = nil
  end,
  slib_credits = {
      idea = {"cassknows"},
      art = {"Lil. Mr. Slipstream"}
  },
}

Entropy.Back{
  order = 7005,
  dependencies = {
    items = {
      "set_entr_decks"
    }
  },
  config = { joker_slot = -2 },
  key = "butterfly",
  pos = { x = 4, y = 0 },
  atlas = "decks",
  loc_vars = function() 
    local n, d = SMODS.get_probability_vars(card, 1, 2, "entr_butterfly")
    return {vars = {n, d}}
  end
}

Entropy.Back{
  order = 7006,
  dependencies = {
    items = {
      "set_entr_decks"
    }
  },
  config = { },
  key = "gemstone",
  pos = { x = 6, y = 0 },
  atlas = "decks",
  loc_vars = function() 
    local n, d = SMODS.get_probability_vars(card, 1, 3, "entr_gemstone")
    return {vars = {n, d}}
  end,
  calculate = function(self, back, context)
    if context.using_consumeable and context.consumeable.config.center.set ~= "Rune" then
        G.GAME.gemstone_amount = (G.GAME.gemstone_amount or 0) + 1
        if G.GAME.gemstone_amount == 2 then
          G.GAME.gemstone_amount = 0
          G.E_MANAGER:add_event(Event{
            func = function()
              if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                SMODS.add_card{
                  set = "Rune",
                  area = G.consumeables,
                  key_append = "entr_gemstone_deck"
                }
              end
              return true
            end
          })
          return {
            message = localize("k_plus_rune")
          }
        else
          return {
            message = G.GAME.gemstone_amount.."/2"
          }
        end
    end
  end,
  slib_credits = {
    art = {"mailingway"}
  }
}
local update_ref = Card.update
function Card:update(dt, ...)
    if self.ability.glitched_crown then
      self.last_dt = self.last_dt or 0
      if not self.glitched_dt then
        local soul_layer
        for i, v in pairs(self.ability.glitched_crown) do
          if G.P_CENTERS[v].soul_pos then soul_layer = true end
        end
        if soul_layer and not self.children.floating_sprite then
          local _center = G.P_CENTERS[self.ability.glitched_crown[1]]
          self.children.floating_sprite = Sprite(self.T.x, self.T.y, self.T.w, self.T.h, G.ASSET_ATLAS[_center[G.SETTINGS.colourblind_option and 'hc_atlas' or 'lc_atlas'] or _center.atlas or _center.set], self.config.center.soul_pos or {x=9999,y=9999})
          self.children.floating_sprite.role.draw_major = self
          self.children.floating_sprite.states.hover.can = false
          self.children.floating_sprite.states.click.can = false
        end
      end
      self.glitched_dt = (self.glitched_dt or 0) + (G.TIMERS.REAL - self.last_dt) * 2.5 * (Entropy.config.corrupted_speed/100)
      self.last_dt = G.TIMERS.REAL
      if self.glitched_dt > 3 / #self.ability.glitched_crown then
          self.glitched_dt = 0
          self.glitched_index = 1 + (self.glitched_index or 1)
          if self.glitched_index > #self.ability.glitched_crown then self.glitched_index = 1 end
          local _center = G.P_CENTERS[self.ability.glitched_crown[self.glitched_index]]
          self.children.center.atlas = G.ASSET_ATLAS[(_center.atlas or (_center.set == 'Joker' or _center.consumeable or _center.set == 'Voucher') and _center.set) or 'centers']
          self.children.center:set_sprite_pos(_center.pos)
          if self.children.floating_sprite then
            self.children.floating_sprite.atlas = G.ASSET_ATLAS[_center[G.SETTINGS.colourblind_option and 'hc_atlas' or 'lc_atlas'] or _center.atlas or _center.set]
            self.children.floating_sprite:set_sprite_pos(_center.soul_pos or {x=9999,y=9999})
          end
          if self.config.center.set_sprites then
              self.config.center:set_sprites(self, self.children.front, true)
          end
          if self.states.hover.is then
              self:stop_hover()
              self:hover()
          end
      end
    end
    return update_ref(self, dt, ...)
end

local generate_UIBox_ability_tableref = Card.generate_UIBox_ability_table
function Card:generate_UIBox_ability_table(vars_only)
    if self.ability.glitched_crown and G.P_CENTERS[self.ability.glitched_crown[self.glitched_index]] then
        local a = self.ability
        local conf = self.config.center
        local center = G.P_CENTERS[self.ability.glitched_crown[self.glitched_index]]
        self.ability = center.config
        self.config.center = center
        self.ability.name = center.name
        self.ability.set = center.set
        local ret = generate_UIBox_ability_tableref(self, vars_only)
        self.ability = a
        self.config.center = conf
        if ret then
            return ret
        else
            return generate_UIBox_ability_tableref(self, vars_only)
        end
    else
        return generate_UIBox_ability_tableref(self, vars_only)
    end
end

local get_type_colourref = get_type_colour
function get_type_colour(_c, card)
    if Entropy.is_EE() and card.debuff then
      return Entropy.reverse_legendary_gradient
    end
    if card and card.ability and card.ability.glitched_crown and G.P_CENTERS[card.ability.glitched_crown[card.glitched_index]] then
        return get_type_colourref(G.P_CENTERS[card.ability.glitched_crown[card.glitched_index]], card)
    end
    return get_type_colourref(_c, card)
end

local can_use_ref = G.FUNCS.can_use_consumeable
G.FUNCS.can_use_consumeable = function(e)
  local card = e.config.ref_table
  if card.ability.glitched_crown and G.P_CENTERS[card.ability.glitched_crown[card.glitched_index]] then
    if Card.can_use_consumeable(Entropy.get_dummy(G.P_CENTERS[card.ability.glitched_crown[card.glitched_index]], card.area, card)) then
      e.config.colour = G.C.RED
      e.config.button = 'use_card'
    else
      e.config.colour = G.C.UI.BACKGROUND_INACTIVE
      e.config.button = nil
    end
  else
    can_use_ref(e)
  end
end

local buy_and_use_ref = G.FUNCS.can_buy_and_use
G.FUNCS.can_buy_and_use = function(e)
  local card = e.config.ref_table
  if card.ability.glitched_crown and G.P_CENTERS[card.ability.glitched_crown[card.glitched_index]] then
    if (((to_big(e.config.ref_table.cost) > to_big(G.GAME.dollars - G.GAME.bankrupt_at)) and (to_big(e.config.ref_table.cost) > to_big(0))) or (not Card.can_use_consumeable(Entropy.get_dummy(G.P_CENTERS[card.ability.glitched_crown[card.glitched_index]], card.area, card)))) then
        e.UIBox.states.visible = false
        e.config.colour = G.C.UI.BACKGROUND_INACTIVE
        e.config.button = nil
    else
        if e.config.ref_table.highlighted then
          e.UIBox.states.visible = true
        end
        e.config.colour = G.C.SECONDARY_SET.Voucher
        e.config.button = 'buy_from_shop'
    end
  else  
    buy_and_use_ref(e)
  end
end

Entropy.Back{
  order = 7007,
  dependencies = {
    items = {
      "set_entr_decks"
    }
  },
  key = "corrupted",
  pos = { x = 7, y = 0 },
  atlas = "decks",
  apply = function()
    change_shop_size(-1)
    G.GAME.modifiers.glitched_items = (G.GAME.modifiers.glitched_items or 1) + 1
  end,
  slib_credits = {
    art = {"LFMoth"}
  }
}

Entropy.Back{
  order = 7008,
  dependencies = {
    items = {
      "set_entr_decks"
    }
  },
  config = { },
  key = "discordant",
  pos = { x = 8, y = 0 },
  atlas = "decks",
  apply = function()
    G.GAME.modifiers.entr_reroll_fac = 2
    G.GAME.modifiers.entr_parakmi = true
  end,
}

local crc_ref = calculate_reroll_cost
function calculate_reroll_cost(...)
    local ret = crc_ref(...)
    G.GAME.current_round.reroll_cost = G.GAME.current_round.reroll_cost + G.GAME.current_round.reroll_cost_increase * ((G.GAME.modifiers.entr_reroll_fac or 1) - 1)
    return ret
end

Entropy.Back{
    order = 7009,
    dependencies = {
      items = {
        "set_entr_decks"
      }
    },
	name = "Deck of Containment",
	key = "doc",
	pos = { x = 2, y = 0 },
	atlas = "decks",
	apply = function(self)
		G.GAME.entropy = 0
	end,
  in_pool = function() return next(SMODS.find_card("j_entr_parakmi")) end, --redeem stuff
	calculate = function(self,back,context)
		if context.final_scoring_step and number_format(0.002 + (0.998^(G.GAME.entropy/2))) ~= "1" then
			if not ({
				["High Card"]=true,
				["Pair"]=true,
				["Three of a Kind"]=true,
				["Two Pair"]=true,
				["Four of a Kind"]=true,
				["Flush"]=true,
				["Straight"]=true,
				["Straight Flush"]=true,
				["Full House"]=true
			})[context.scoring_name] or to_big(G.GAME.hands[context.scoring_name].AscensionPower or 0) > to_big(0) then
				ease_entropy(G.GAME.hands[context.scoring_name].level + (G.GAME.hands[context.scoring_name].AscensionPower or 0) or 1)
			end
			G.E_MANAGER:add_event(Event({
				func = function()
					play_sound(Talisman and "talisman_echip" or "slib_echips", 1)
					attention_text({
						scale = 1.4,
						text = "^"..tostring(number_format(0.002 + (0.998^(G.GAME.entropy/2)))).." Chips",
						hold = 2,
						align = "cm",
						offset = { x = 0, y = -2.7 },
						major = G.play,
					})
					return true
				end,
			}))
			return {
				Echip_mod = 0.01 + (0.998^(G.GAME.entropy/2)),
				colour = G.C.DARK_EDITION,
			}
		end
		if context.individual and context.cardarea == G.play then
			if context.other_card and (context.other_card.edition or context.other_card.ability.set == "Enhanced") then
				if context.other_card.edition and context.other_card.ability.set == "Enhanced" then ease_entropy(2) else ease_entropy(1) end
			end
		end
		if context.after then
			for i, v in pairs(G.jokers.cards) do
				if v.edition and v.edition.key then ease_entropy(2) end
				if i > G.jokers.config.card_limit then ease_entropy(1) end
			end
		end
  end,
	loc_vars = function()
		return {
			key = not (SMODS.Mods.Cryptid or {}).can_load and "b_entr_doc_cryptidless" or nil
		}
  end,
}

if CardSleeves then
    CardSleeves.Sleeve {
      key = "twisted",
      atlas = "sleeves",
      pos = { x = 0, y = 0 },
      apply = function()
        G.GAME.modifiers.entr_twisted = true
        G.GAME.round_resets.path_toggled = true
        G.GAME.entr_alt = not G.GAME.entr_alt
        ease_background_colour{new_colour = Spectrallib.get_bg_colour(), contrast = 1}
        if G.ARGS.spin then
          G.ARGS.spin.real = (G.SETTINGS.reduced_motion and 0 or 1)*(G.GAME.entr_alt and 0.3 or -0.3)
        end
      end,
      slib_credits = {art = {"Lil. Mr. Slipstream"}}
    }
    CardSleeves.Sleeve {
      key = "ccd2",
      atlas = "sleeves",
      pos = { x = 1, y = 0 },
      apply = function()
        G.GAME.modifiers.ccd2 = true
      end,
      slib_credits = {art = {"Lil. Mr. Slipstream"}}
    }

    CardSleeves.Sleeve {
      key = "crafting",
      atlas = "sleeves",
      pos = { x = 3, y = 0 },
      config = { vouchers = { "v_magic_trick", "v_illusion" } },
      apply = function()
        G.GAME.modifiers.crafting = true
        if not G.GAME.JokerRecipes then G.GAME.JokerRecipes = {} end
        --G.hand.config.highlighted_limit = 
        G.GAME.joker_rate = 0
        if not G.GAME.banned_keys then G.GAME.banned_keys = {} end
        G.GAME.banned_keys["p_bufoon_normal_1"] = true
        G.GAME.banned_keys["p_bufoon_normal_2"] = true
        G.GAME.banned_keys["p_bufoon_jubmo_1"] = true
        G.GAME.banned_keys["p_bufoon_mega_1"] = true
        G.E_MANAGER:add_event(Event({
          trigger = 'after',
          func = function()
            local c = create_card("Spectral", G.consumeables, nil, nil, nil, nil, "c_entr_destiny") 
            c.ability.cry_absolute = true
            c.ability.entr_aleph = true
            c:add_sticker("eternal", true)
            c:add_to_deck()
            G.consumeables:emplace(c)
            c:set_edition("e_negative")
            return true
          end}))
      end,
      slib_credits = {art = {"Lil. Mr. Slipstream"}}
    }

  CardSleeves.Sleeve {
    key = "ambisinister",
    atlas = "sleeves",
    pos = { x = 4, y = 0 },
    config = {joker_slot=3},
    apply = function()
      G.GAME.starting_params.joker_slots = G.GAME.starting_params.joker_slots + 3
      Entropy.last_csl = nil
      Entropy.last_slots = nil
    end,
    slib_credits = {art = {"Lil. Mr. Slipstream"}}
  }


  CardSleeves.Sleeve {
    key = "butterfly",
    atlas = "sleeves",
    pos = { x = 5, y = 0 },
    apply = function()
      G.GAME.starting_params.joker_slots = G.GAME.starting_params.joker_slots - 2
    end,
  loc_vars = function() 
    local n, d = SMODS.get_probability_vars(card, 1, 2, "entr_butterfly")
    return {vars = {n, d}}
  end
  }

  CardSleeves.Sleeve {
    key = "gemstone",
    atlas = "sleeves",
    pos = { x = 6, y = 0 },
    calculate = function(self, back, context)
      if context.using_consumeable and context.consumeable.config.center.set ~= "Rune" then
          G.GAME.gemstone_amount = (G.GAME.gemstone_amount or 0) + 1
          if G.GAME.gemstone_amount == 2 then
            G.GAME.gemstone_amount = 0
            G.E_MANAGER:add_event(Event{
              func = function()
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                  SMODS.add_card{
                    set = "Rune",
                    area = G.consumeables,
                    key_append = "entr_gemstone_deck"
                  }
                end
                return true
              end
            })
            return {
              message = localize("k_plus_rune")
            }
          else
            return {
              message = G.GAME.gemstone_amount.."/2"
            }
          end
      end
    end,
    loc_vars = function() 
      local n, d = SMODS.get_probability_vars(card, 1, 3, "entr_gemstone")
      return {vars = {n, d}}
    end
  }

  CardSleeves.Sleeve {
    key = "corrupted",
    atlas = "sleeves",
    pos = { x = 7, y = 0 },
    apply = function()
		change_shop_size(-1)
		G.GAME.modifiers.glitched_items = (G.GAME.modifiers.glitched_items or 0) + 2
    end,
    slib_credits = {art = {"LFMoth"}}
  }

  CardSleeves.Sleeve {
    key = "doc",
    atlas = "sleeves",
    pos = { x = 2, y = 0 },
    loc_vars = function()
		return {
			key = not (SMODS.Mods.Cryptid or {}).can_load and "sleeve_entr_doc_cryptidless" or nil
		}
    end,
    in_pool = function() return next(SMODS.find_card("j_entr_parakmi")) end, --redeem stuff
    apply = function()
		if G.GAME.selected_back and G.GAME.selected_back.effect.center.original_key == "doc" then
			G.E_MANAGER:add_event(Event({
			trigger = 'after',
			func = function()
				SMODS.add_card({
				rarity = "entr_entropic",
				area = G.jokers,
				set = "Joker",
				key_append = "entr_doc_combo"
				})
				return true
			end
			}))
		else
			G.GAME.entropy = 0
		end
    end,
    calculate = function(self,back,context)
		if context.final_scoring_step and number_format(0.002 + (0.998^(G.GAME.entropy/2))) ~= "1" then
			if not ({
				["High Card"]=true,
				["Pair"]=true,
				["Three of a Kind"]=true,
				["Two Pair"]=true,
				["Four of a Kind"]=true,
				["Flush"]=true,
				["Straight"]=true,
				["Straight Flush"]=true,
				["Full House"]=true
			})[context.scoring_name] or to_big(G.GAME.hands[context.scoring_name].AscensionPower or 0) > to_big(0) then
				ease_entropy(G.GAME.hands[context.scoring_name].level + (G.GAME.hands[context.scoring_name].AscensionPower or 0) or 1)
			end
			G.E_MANAGER:add_event(Event({
				func = function()
					play_sound(Talisman and "talisman_echip" or "slib_echips", 1)
					attention_text({
						scale = 1.4,
						text = "^"..tostring(number_format(0.002 + (0.998^(G.GAME.entropy/2)))).." Chips",
						hold = 2,
						align = "cm",
						offset = { x = 0, y = -2.7 },
						major = G.play,
					})
					return true
				end,
			}))
			return {
				Echip_mod = 0.01 + (0.998^(G.GAME.entropy/2)),
				colour = G.C.DARK_EDITION,
			}
		end
		if context.individual and context.cardarea == G.play then
			if context.other_card and (context.other_card.edition or context.other_card.ability.set == "Enhanced") then
				if context.other_card.edition and context.other_card.ability.set == "Enhanced" then ease_entropy(2) else ease_entropy(1) end
			end
		end
		if context.after then
			for i, v in pairs(G.jokers.cards) do
				if v.edition and v.edition.key then ease_entropy(2) end
				if i > G.jokers.config.card_limit then ease_entropy(1) end
			end
		end
    end
    }
end