Entropy.Joker{
    order = 1,
    
    key = "surreal_joker",
    config = {
        qmult = 8
    },
    rarity = 1,
    cost = 3,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 0, y = 0 },
    atlas = "jokers",
    demicoloncompat = true,
    pools = { ["Meme"] = true },
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                " "..card.ability.qmult
            },
        }
    end,
    calculate = function (self, card, context)
        if context.joker_main or context.forcetrigger then
            G.GAME.current_round.current_hand.mult = card.ability.qmult
            update_hand_text({delay = 0}, {chips = G.GAME.current_round.current_hand.chips and hand_chips, mult = card.ability.qmult})
            return {
                Eqmult_mod = (not Entropy.blind_is("bl_entr_theta") or G.GAME.blind.disabled) and card.ability.qmult,
                Eqchips_mod = (Entropy.blind_is("bl_entr_theta") and not G.GAME.blind.disabled) and card.ability.qmult
            }
        end
    end,
    attributes = {"eqmult"},
}

Entropy.Joker{
    order = 2,
    
    key = "tesseract",
    config = {
        degrees = 90
    },
    rarity = 1,
    cost = 3,
    
    pools = { ["Meme"] = true },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 1, y = 0 },
    atlas = "jokers",
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                number_format(card.ability.degrees),
                G.GAME.modifiers.entr_gfb and number_format(card.ability.degrees_mod) or nil
            },
            key = G.GAME.modifiers.entr_gfb and "j_entr_tesseract_gfb" or nil
        }
    end,
    calculate = function(self, card, context)
        if G.GAME.modifiers.entr_gfb then
             if context.before and not context.blueprint and #context.full_hand == 4 then
                SMODS.scale_card(card, {
                    ref_table = card.ability,
                    ref_value = "degrees",
                    scalar_value = "degrees_mod",
                    message_colour = G.C.CHIPS
                })
                return nil, true
            end
        end
    end,
    attributes = {"passive"},
}

Entropy.Joker{
    order = 4,
    
    key = "strawberry_pie",
    rarity = 3,
    cost = 10,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    config = {
        num = 2,
        denom = 3
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 2, y = 1 },
    atlas = "jokers",
    demicoloncompat = true,
    pools = { ["Food"] = true },
    attributes = {"hands", "food", "passive"},
}

Entropy.Joker{
    order = 5,
    
    key = "recursive_joker",
    config = {
        used_this_round = false
    },
    rarity = 1,
    cost = 4,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 3, y = 1 },
    atlas = "jokers",
    demicoloncompat = true,
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                card.ability.used_this_round and "Inactive" or "Active"
            },
            key = G.GAME.modifiers.entr_gfb and "j_entr_recursive_joker_gfb" or nil
        }
    end,
    calculate = function(self, card, context)
        if context.end_of_round then
            card.ability.used_this_round = false
        end
        if (context.selling_card and context.card == card and not card.ability.used_this_round) or context.forcetrigger then
            card.ability.used_this_round = true
            card.ability.cost_set = false
            local card = copy_card(card)
            if context.forcetrigger and card.ability.desync then
                card.ability.context = Entropy.random_context()
            end
            card:add_to_deck()
            G.jokers:emplace(card)
        end
    end,
    attributes = {"on_sell", "joker", "generation"},
}
Entropy.Joker{
    order = 6,
    
    key = "dr_sunshine",
    config = {
        plus_asc = 0,
        plus_asc_mod = 0.25
    },
    rarity = 3,
    cost = 10,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 4, y = 1 },
    atlas = "jokers",
    pools = { ["Sunny"] = true, ["Music"] = true },
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        Entropy.ensure_ascpow_tutorial(q)
        return {
            vars = {
                number_format(card.ability.plus_asc_mod),
                number_format(card.ability.plus_asc),
            },
        }
    end,
    calculate = function(self, card, context)
        if context.remove_playing_cards and not context.blueprint or context.forcetrigger then
            if context.removed and #context.removed > 0 then
                SMODS.scale_card(card, {ref_table = card.ability, ref_value = "plus_asc", scalar_value = "plus_asc_mod", operation = function(ref_table, ref_value, initial, change)
                    ref_table[ref_value] = initial + (context.removed and #context.removed or 1)*change
                end})
            end
        end
        if (context.joker_main or context.forcetrigger) and to_big(card.ability.plus_asc) > to_big(0) then
            return {
                plus_asc = card.ability.plus_asc
            }
        end
    end,
    attributes = {"asc", "scaling"},
}

Entropy.Joker{
    order = 7,
    
    key = "sunny_joker",
    config = {
        plus_asc = 2
    },
    rarity = 2,
    cost = 5,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    pixel_size = { h = 70 },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 5, y = 1 },
    atlas = "jokers",
    demicoloncompat = true,
    pools = { ["Meme"] = true, ["Sunny"] = true, },
    loc_vars = function(self, q, card)
        Entropy.ensure_ascpow_tutorial(q)
        return {
            vars = {
                number_format(card.ability.plus_asc),
            },
        }
    end,
    calculate = function(self, card, context)
        if context.joker_main or context.forcetrigger then
            return {
                plus_asc = card.ability.plus_asc
            }
        end
    end,
    slib_credits = {
        idea = {"cassknows"}
    },
    attributes = {"asc", "sunny"},
}

Entropy.Joker{
    order = 8,
    
    key = "antidagger",
    rarity = 3,
    cost = 8,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    immutable = true,
    eternal_compat = true,
    pos = { x = 6, y = 0 },
    atlas = "jokers",
    demicoloncompat = true,
    config = { extra = { odds = 6 } },
    loc_vars = function(self, info_queue, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds)
        return {
            vars = {
                numerator,
                denominator
            },
        }
    end,
    calculate = function(self, card, context)
        if context.setting_blind or context.forcetrigger then
            local keys = {}
            for i, v in pairs(G.GAME.banned_keys) do
                keys[#keys+1]=i
            end
            if #keys > 0 then
                local key = pseudorandom_element(keys, pseudoseed("antidagger"))
                while not G.P_CENTERS[key] or G.P_CENTERS[key].set ~= "Joker" do
                    key = pseudorandom_element(keys, pseudoseed("antidagger"))
                end
                G.GAME.banned_keys[key] = nil
                local c = SMODS.create_card({
                    area = G.jokers,
                    set="Joker",
                    key = key
                })
                c:add_to_deck()
                G.jokers:emplace(c)
            end
            if SMODS.pseudorandom_probability(card, 'antidagger', 1, card.ability.extra.odds) then
                    G.GAME.banned_keys["j_entr_antidagger"] = true
                    SMODS.calculate_context({banishing_card = true, card = card, cardarea = card.area, banisher = card})
                    SMODS.destroy_cards{card}
                    play_sound("slice1", 0.96 + math.random() * 0.08)
            end
        end
    end,
    slib_credits = {
        idea = {"cassknows"},
        art = {"cassknows"}
    },
    attributes = {"generation", "destroy_card", "joker", "chance", "banish"},
}

Entropy.Joker{
    order = 9,
    
    key = "solar_dagger",
    rarity = 3,
    cost = 8,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 6, y = 1 },
    atlas = "jokers",
    demicoloncompat = true,
    config = { x_asc = 0 },
    pools = { ["Sunny"] = true, },
    loc_vars = function(self, q, card)
        Entropy.ensure_ascpow_tutorial(q)
        return {
            vars = {
                number_format(card.ability.x_asc)
            },
        }
    end,
    calculate = function(self, card, context)
        if (context.setting_blind and not (context.blueprint_card or self).getting_sliced) or context.forcetrigger then
            local check
            for i, v in pairs(G.jokers.cards) do
                if v == card and G.jokers.cards[i+1] and not SMODS.is_eternal(G.jokers.cards[i+1]) then check = i+1 end
            end
            if check then
                local sliced_card = G.jokers.cards[check]
                sliced_card.getting_sliced = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        card:juice_up(0.8, 0.8)
                        SMODS.destroy_cards(sliced_card)
                        play_sound("slice1", 0.96 + math.random() * 0.08)
                        return true
                    end,
                }))
                SMODS.scale_card(card, {ref_table = card.ability, ref_value = "x_asc", scalar_table = {sell_cost = sliced_card.sell_cost * 0.25}, scalar_value = "sell_cost"})
            end
        end
        if context.joker_main then
            return {
                plus_asc = card.ability.x_asc
            }
        end
    end,
    slib_credits = {
        idea = {"cassknows"},
        art = {"cassknows", "Strum"}
    },
    attributes = {"asc", "destroy_card", "joker", "sell_value", "sunny", "scaling"},
}

Entropy.Joker{
    order = 10,
    
    key = "insatiable_dagger",
    rarity = 3,
    cost = 8,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    config = {
        perc = 15,
        perc_mod = 3
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    immutable = true,
    pos = { x = 4, y = 2 },
    atlas = "jokers",
    demicoloncompat = true,
    calculate = function(self, card, context)
        if G.GAME.modifiers.entr_gfb then
            if context.ending_shop then
                local check
                for i, v in pairs(G.jokers.cards) do
                    if v == card and G.jokers.cards[i+1] then check = i+1 end
                end
                if check then
                    Spectrallib.manipulate(G.jokers.cards[check], {
                        value = card.ability.perc
                    })
                end
                return {
                    message = localize("k_upgrade_ex")
                }
            end
        else
            if (context.setting_blind and not (context.blueprint_card or self).getting_sliced) or context.forcetrigger then
                local check
                for i, v in pairs(G.jokers.cards) do
                    if v == card and G.jokers.cards[i-1] then check = i-1 end
                end
                if check and not SMODS.is_eternal(G.jokers.cards[#G.jokers.cards]) then
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            local sliced_card = G.jokers.cards[#G.jokers.cards]
                            sliced_card.getting_sliced = true
                            card:juice_up(0.8, 0.8)
                            SMODS.destroy_cards(sliced_card)
                            G.GAME.banned_keys[sliced_card.config.center.key] = true
                            eval_card(sliced_card, {banishing_card = true, banisher = card, card = sliced_card, cardarea = sliced_card.area})
                            play_sound("slice1", 0.96 + math.random() * 0.08)
                            local check2
                            if not Card.no(G.jokers.cards[check], "immutable", true) then
                                Cryptid.manipulate(G.jokers.cards[check], { value = sliced_card.sell_cost * (card.ability.perc / 100) + 1 })
                                check2 = true
                            end
                            if check2 then
                                card_eval_status_text(
                                    G.jokers.cards[check],
                                    "extra",
                                    nil,
                                    nil,
                                    nil,
                                    { message = localize("k_upgrade_ex"), colour = G.C.GREEN }
                                )
                            end
                            return true
                        end,
                    }))
                    SMODS.scale_card(card, {ref_table = card.ability, ref_value = "perc", scalar_value = "perc_mod", operation = "-", no_message = true})
                    if card.ability.perc <= 0 then
                        SMODS.destroy_cards(card, true, nil, true)
                    end
                end
            end
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.perc,
                card.ability.perc_mod
            },
            key = G.GAME.modifiers.entr_gfb and "j_entr_insatiable_dagger_gfb" or nil
        }
    end,
    slib_credits = {
        idea = {"cassknows"},
	    art = {"Lyman"}
    },
    attributes = {"value_manip", "destroy_card", "joker", "sell_value", "scaling"},
}

Entropy.Joker{
    order = 11,
    
    key = "rusty_shredder",
    rarity = 2,
    cost = 5,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    immutable = true,
    eternal_compat = true,
    pos = { x = 7, y = 1 },
    atlas = "jokers",
    config = {extra = {odds = 3}},
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue + 1] = {key = 'e_negative_playing_card', set = 'Edition', config = {extra = 1}}
        info_queue[#info_queue+1] = {key = "temporary", set = "Other"}
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds)
        return {
            vars = {
                numerator,
                denominator
            },
        }
    end,
    calculate = function (self, card, context)
        if (context.pre_discard) then
            for i, v in pairs(G.hand.highlighted) do
                if SMODS.pseudorandom_probability(card, 'rusty_shredder', 1, card.ability.extra.odds) then
                    local c = copy_card(v)
                    c.ability.temporary = true
                    c:add_to_deck()
                    G.hand:emplace(c)
                    c:set_edition("e_negative")
                end
            end
        end
    end,
    slib_credits = {
        idea = {"cassknows"},
        art = {"LFMoth"}
    },
    attributes = {"generation", "modify_card", "chance", "discard",},
}

Entropy.Joker{
    order = 12,
    
    key = "chocolate_egg",
    rarity = 2,
    cost = 5,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 0, y = 2 },
    atlas = "jokers",
    demicoloncompat = true,
    pools = { ["Food"] = true, ["Candy"] = true, ["Sunny"]=true },
    calculate = function(self, card, context)
        if (context.banishing_card and context.cardarea == G.jokers) or context.forcetrigger then
            card_eval_status_text(
                card,
                "extra",
                nil,
                nil,
                nil,
                { message = localize("entr_opened"), colour = G.C.GREEN }
            )
            card.ability.no_destroy = true
            local c = create_card("Joker", G.jokers, nil, (SMODS.Mods["Cryptid"] or {}).can_load and "cry_epic" or 3)
            c:add_to_deck()
            G.jokers:emplace(c)
            c:set_edition("e_entr_sunny")
        end
        if context.selling_self then card.ability.no_destroy = true end
        if context.card_being_destroyed and context.card == card then
            card_eval_status_text(
                self,
                "extra",
                nil,
                nil,
                nil,
                { message = localize("entr_opened"), colour = G.C.GREEN }
            )
            local c = create_card("Joker", G.jokers, nil, "Rare")
            c:add_to_deck()
            G.jokers:emplace(c)
            c:set_edition("e_entr_sunny")
        end
    end,
    slib_credits = {
        idea = {"cassknows"},
        art = {"missingnumber"}
    },
    loc_vars = function()
        return {
            key = (SMODS.Mods["Cryptid"] or {}).can_load and "j_entr_chocolate_egg" or "j_entr_chocolate_egg_cryptidless"
        }
    end,
    attributes = {"generation", "joker", "sunny"},
}

Entropy.Joker{
    order = 13,
    
    key = "lotteryticket",
    rarity = 2,
    cost = 3,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    demicoloncompat=true,
    eternal_compat = true,
    pos = { x = 9, y = 0 },
    atlas = "jokers",
    config = {extra = {odds = 5, odds2 = 5, lose=1, payoutsmall = 20, payoutlarge = 50}},
    loc_vars = function(self, info_queue, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds)
        local numerator2, denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds * card.ability.extra.odds2)
        return {
            vars = {
                numerator,
                denominator,
                numerator2,
                denominator2,
                card.ability.extra.lose,
                card.ability.extra.payoutsmall,
                card.ability.extra.payoutlarge
            },
        }
    end,
    calculate = function (self, card, context)
        if context.end_of_round and not context.individual and not context.blueprint and not context.repetition then            
            return {
                dollars = -card.ability.extra.lose
            }
        end
        if context.forcetrigger then
            ease_dollars(card.ability.extra.payoutlarge-card.ability.extra.lose)
        end
    end,
    calc_dollar_bonus = function(self, card)
        if SMODS.pseudorandom_probability(card, 'lottery', 1, card.ability.extra.odds) then
            if SMODS.pseudorandom_probability(card, 'lottery', 1, card.ability.extra.odds2) then
                return card.ability.extra.payoutlarge
            else
                return card.ability.extra.payoutsmall
            end
        end
    end,
    attributes = {"chance", "econ"},
}

Entropy.Joker{
    order = 14,
    
    key = "devilled_suns",
    rarity = 2,
    cost = 3,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    demicoloncompat=true,
    eternal_compat = true,
    pos = { x = 1, y = 2 },
    atlas = "jokers",
    pools = { ["Sunny"] = true, ["Meme"] = true},
    config = { base = 1, per_sunny = 1},
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue+1] = G.P_CENTERS.e_entr_sunny
        return {
            vars = {
                card.ability.base,
                card.ability.per_sunny
            },
        }
    end,
    calculate = function (self, card, context)
        if (context.individual and context.other_card.config.center.key == "m_gold" and context.cardarea == G.play) or context.forcetrigger then
            local sunnys = 0
            for i, v in pairs(G.jokers.cards) do
                if v:is_sunny() and v ~= card then sunnys = sunnys + 1 end
            end
            return {
                plus_asc = card.ability.base + card.ability.per_sunny * sunnys
            }
        end
    end,
    slib_credits = {
        art = {"Grahkon"},
        idea = {"Grahkon"}
    },
    attributes = {"asc", "sunny"},
}

Entropy.Joker{
    order = 15,
    
    key = "eden",
    name="entr-eden",
    config = {
        asc=2.5
    },
    rarity = 2,
    cost = 4,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 2, y = 2 },
    atlas = "jokers",
    demicoloncompat = true,
    pools = { ["Sunny"] = true, ["Meme"] = true },
    loc_vars = function(self, info_queue, center)
        if not center.edition or (center.edition and center.edition.key ~= "e_entr_sunny") then
			info_queue[#info_queue + 1] = G.P_CENTERS.e_entr_sunny
		end
        return {
            vars = {
                number_format(center.ability.asc)
            },
        }
    end,
    calculate = function(self, card, context)
		if
			(context.other_joker
			and context.other_joker.edition
			and context.other_joker:is_sunny()
			and card ~= context.other_joker)
		then
			if not Entropy.should_skip_animations() then
				G.E_MANAGER:add_event(Event({
					func = function()
						context.other_joker:juice_up(0.5, 0.5)
						return true
					end,
				}))
			end
			return {
				plus_asc = lenient_bignum(card.ability.asc),
			}
		end
		if context.individual and context.cardarea == G.play then
			if context.other_card.edition and context.other_card:is_sunny() then
				return {
					plus_asc = lenient_bignum(card.ability.asc),
					card = card,
				}
			end
		end
		if
			(context.individual
			and context.cardarea == G.hand
			and context.other_card.edition
			and context.other_card:is_sunny()
			and not context.end_of_round)
		then
			if context.other_card.debuff then
				return {
					message = localize("k_debuffed"),
					colour = G.C.RED,
					card = card,
				}
			else
				return {
					plus_asc = lenient_bignum(card.ability.asc),
					card = card,
				}
			end
		end
        if context.forcetrigger then
            return {
                plus_asc = lenient_bignum(card.ability.asc),
                card = card,
            }
        end
	end,
    slib_credits = {
        idea = {"cassknows"},
        art = {"cassknows"}
    },
    attributes = {"asc", "sunny"},
}

Entropy.Joker{
    order = 16,
    
    key = "seventyseven",
    config = {
        chips=100
    },
    rarity = 1,
    cost = 4,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 3, y = 2 },
    atlas = "jokers",
    demicoloncompat = true,
    pools = { ["Meme"] = true, },
    loc_vars = function(self, info_queue, center)
        return {
            vars = {
                number_format(center.ability.chips)
            },
        }
    end,
    calculate = function(self, card, context)
		if context.joker_main or context.forcetrigger then
            return {
                eq_chips = card.ability.chips
            }
        end
	end,
    attributes = {"eqchips"},
}

Entropy.Joker{
    order = 17,
    
    key = "skullcry",
    config = {
        base=10,
        percent = 5
    },
    rarity = 3,
    cost = 10,
    
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    pixel_size = { h = 70 },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 8, y = 2 },
    atlas = "jokers",
    demicoloncompat = true,
    pools = { ["Meme"] = true, },
    loc_vars = function(self, info_queue, center)
        return {
            vars = {
                number_format(center.ability.base),
                number_format(center.ability.percent)
            },
        }
    end,
    calculate = function(self, card, context)
		if context.game_over and to_big(G.GAME.chips) > to_big(math.log(G.GAME.blind.chips, card.ability.base)) then
            G.GAME.saved_message = localize("k_saved_skullcry")
            if to_big(math.abs(G.GAME.chips - math.log(G.GAME.blind.chips, card.ability.base))) > to_big(math.log(G.GAME.blind.chips, card.ability.base) * card.ability.percent/100) then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.destroy_cards(card)
                        return true
                    end
                }))
            end
            return {
                message = localize('k_saved_ex'),
                saved = localize("k_saved_skullcry"),
                colour = G.C.RED
            }
        end
	end,
    slib_credits = {
        custom = {key="wish", text="denserver10"}
    },
    attributes = {"prevents_death", "destroy_card"},
}
Entropy.Joker{
    order = 18,
    
    key = "dating_simbo",
    config = {
        chips = 0
    },
    rarity = 2,
    cost = 5,
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 9, y = 2 },
    atlas = "jokers",
    demicoloncompat = true,
    loc_vars = function(self, info_queue, center)
        return {
            vars = {
                number_format(center.ability.chips)
            },
        }
    end,
    calculate = function(self, card, context)
        if context.destroying_card and not context.blueprint and context.cardarea == G.play then
            if context.destroying_card:is_suit("Hearts") then
                local card2 = context.destroying_card
                G.E_MANAGER:add_event(Event({
					trigger = "after",
					func = function()
                        card2:juice_up()
                        return true
                    end
                }))
                SMODS.scale_card(card, {ref_table = card.ability, ref_value = "chips", scalar_table = context.destroying_card.base, scalar_value = "nominal"})
                if context.destroying_card.ability.bonus then
                    SMODS.scale_card(card, {ref_table = card.ability, ref_value = "chips", scalar_table = context.destroying_card.ability, scalar_value = "bonus", no_message = true})
                end
                if context.destroying_card.ability.suit_bonus then
                    SMODS.scale_card(card, {ref_table = card.ability, ref_value = "chips", scalar_table = context.destroying_card.ability, scalar_value = "suit_bonus", no_message = true})
                end
                return { remove = not SMODS.is_eternal(context.destroying_card) }
            end
        end
        if context.joker_main or context.forcetrigger then
            return {
                chips = card.ability.chips
            }
        end
	end,
    slib_credits = {
        idea = {"CapitalChirp"},
        art = {"Lyman"}
    },
    attributes = {"suit", "hearts", "chips", "destroy_card", "scaling"},
}

Entropy.Joker{
    order = 19,
    
    key = "sweet_tooth",
    config = {
        chips = 20,
        chip_mul = 1.25
    },
    rarity = 3,
    cost = 8,
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 0, y = 3 },
    atlas = "jokers",
    demicoloncompat = true,
    loc_vars = function(self, info_queue, center)
        return {
            vars = {
                number_format(center.ability.chips),
                number_format(center.ability.chip_mul)
            },
        }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            return {
                chips = card.ability.chips
            }
        end
        if context.ending_shop and not context.blueprint then
            local check
            for i, v in ipairs(G.jokers.cards) do
                if Cryptid.safe_get(v.config.center, "pools", "Candy") or v:is_food() then
                    SMODS.destroy_Cards(v)
                    check = true
                end
            end
            if check then
                SMODS.scale_card(card, {ref_table = card.ability, ref_value = "chips", scalar_value = "chip_mul", operation = function(ref_table, ref_value, initial, change)
                    ref_table[ref_value] = initial * change
                end})
            end
        end
	end,
    slib_credits = {
        idea = {"Lyman"},
        art = {"Lyman"}
    },
    attributes = {"destroy_card", "joker", "chips", "scaling"},
}


Entropy.Joker{
    order = 20,
    
    key = "bossfight",
    config = {
        chips = 20,
        cards = 4
    },
    rarity = 3,
    cost = 8,
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 1, y = 3 },
    soul_pos = {x = 2, y = 3},
    atlas = "jokers",
    demicoloncompat = true,
    loc_vars = function(self, info_queue, center)
        return {
            vars = {
                number_format(math.floor(center.ability.cards)),
                number_format(center.ability.chips)
            },
        }
    end,
    calculate = function(self, card, context)
        if context.after or context.forcetrigger then
            local cards = #G.play.cards
            if cards == math.floor(card.ability.cards) or context.forcetrigger then
                Entropy.flip_then(G.hand.cards, function(card2)
                    card2.ability.bonus = (card2.ability.bonus or 0) + card.ability.chips
                end)
            end
        end
	end,
    slib_credits = {
        idea = {"CapitalChirp"},
        art = {"Lyman"}
    },
    attributes = {"modify_card", "chips"},
}

Entropy.Joker{
    order = 21,
    
    key = "phantom_shopper",
    config = {
        rarity = "Common",
        progress = 0,
        needed_progress = 5
    },
    rarity = 2,
    cost = 8,
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    pos = { x = 3, y = 3 },
    atlas = "jokers",
    demicoloncompat = true,
    loc_vars = function(self, info_queue, center)
        return {
            vars = {
                localize("k_"..string.lower(center.ability.rarity)),
                number_format(center.ability.needed_progress),
                number_format(center.ability.needed_progress - center.ability.progress),
            },
        }
    end,
    calculate = function(self, card, context)
        if context.selling_self or context.forcetrigger then
            G.GAME.entr_parakmi_bypass = true
            SMODS.add_card{
                set="Joker",
                area = G.jokers,
                rarity = card.ability.rarity,
                legendary = card.ability.rarity == "Legendary",
                key_append = "entr_phantom_shopper"
            }
            G.GAME.entr_parakmi_bypass = nil
        end
        if (context.ending_shop and not context.blueprint and not context.retrigger_joker) or context.forcetrigger then
            card.ability.progress = card.ability.progress + 1
            if card.ability.progress >= card.ability.needed_progress then
                card.ability.progress = 0
                card.ability.rarity = ({
                    Common = "Uncommon",
                    Uncommon = "Rare",
                    Rare = (SMODS.Mods["Cryptid"] or {}).can_load and "cry_epic" or "Legendary",
                    cry_epic = "Legendary"
                })[card.ability.rarity] or card.ability.rarity
                card.ability.needed_progress = card.ability.needed_progress + 1
            else
                card_eval_status_text(
                    card,
                    "extra",
                    nil,
                    nil,
                    nil,
                    { message = number_format(card.ability.progress).."/"..number_format(card.ability.needed_progress), colour = G.C.FILTER }
                )
            end
        end
	end,
    slib_credits = {
        idea = {"Lyman"},
        art = {"Lyman"}
    },
    attributes = {"joker", "generation", "scaling", "on_sell"},
}

Entropy.Joker{
    order = 21.5,
    
    key = "sunny_side_up",
    config = {
        asc = 12,
        asc_mod = 2
    },
    rarity = 2,
    cost = 6,
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 5, y = 3 },
    atlas = "jokers",
    demicoloncompat = true,
    pools = {
        ["Sunny"] = true,
        ["Food"] = true
    },
    loc_vars = function(self, q, center)
        Entropy.ensure_ascpow_tutorial(q)
        return {
            vars = {
                number_format(center.ability.asc),
                number_format(center.ability.asc_mod),
            },
        }
    end,
    calculate = function(self, card, context)
        if context.joker_main or context.forcetrigger then
            local asc = card.ability.asc
            if not context.blueprint then SMODS.scale_card(card, {ref_table = card.ability, ref_value = "asc", scalar_value = "asc_mod", operation = "-",
                scaling_message = {
                    message = localize("k_downgrade_ex"),
                    colour = G.C.RED
                }
            }) end
            if to_big(card.ability.asc) > to_big(0) then
                return {
                    plus_asc = asc
                }
            else    
				SMODS.destroy_cards(card, true, nil, true)
            end
        end
	end,
    slib_credits = {
        idea = {"footlongdingledong"},
        art = {"footlongdingledong"}
    },
    attributes = {"food", "scaling", "asc"},
}

Entropy.Joker{
    order = 23,
    
    key = "sunflower_seeds",
    rarity = 2,
    cost = 6,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        needed = 3,
        left = 3
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 7, y = 3 },
    atlas = "jokers",
    demicoloncompat = true,
    pools = {
        ["Sunny"] = true,
        ["Food"] = true
    },
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue+1] = G.P_CENTERS.e_entr_sunny
        return {
            vars = {
                number_format(card.ability.needed),
                number_format(card.ability.left)
            }
        }
    end,
    calculate = function(self, card, context)
        if context.after and ((G.GAME.current_round.current_hand.cry_asc_num or 0) + (G.GAME.asc_power_hand or 0)) ~= 0 then
            card.ability.left = card.ability.left - 1
            if card.ability.left <= 0 then
                local cards = {}
                for i, v in ipairs(G.jokers.cards) do
                    if not v.edition and v ~= card then cards[#cards+1] = v end
                end
                local jcard = pseudorandom_element(cards, pseudoseed("code_m"))
                Entropy.flip_then({jcard}, function(card)
                    card:set_edition("e_entr_sunny")
                end)
                SMODS.destroy_cards(card, true, nil, true)
				return {
					message = localize("k_eaten_ex"),
					colour = G.C.FILTER,
				}
            end
            return {
                message = number_format(card.ability.needed-card.ability.left).."/"..number_format(card.ability.needed),
                colour = G.C.GOLD,
            }
        end
	end,
    in_pool = function()
		if G.GAME.cry_asc_played and G.GAME.cry_asc_played > 0 then
			return true
		end
        return false
    end,
    slib_credits = {
        idea = {"cassknows"}
    },
    attributes = {"modify_card", "food"},
}

Entropy.Joker{
    order = 23.5,
    
    key = "tenner",
    rarity = 1,
    cost = 4,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        dollars = 10
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 8, y = 3 },
    atlas = "jokers",
    demicoloncompat = true,
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                number_format(card.ability.dollars),
            }
        }
    end,
    calculate = function(self, card, context)
        if context.joker_main or context.forcetrigger then
            G.E_MANAGER:add_event(Event({
                trigger = "after",
                delay = 0.3,
                blockable = false,
                func = function()
                    G.GAME.dollars = 0
                    ease_dollars(card.ability.dollars)
                    return true
                end
            }))
            return {
                message = localize("$").." = "..number_format(card.ability.dollars),
                colour = G.C.GOLD,
            }
        end
	end,
    slib_credits = {
        art = {"missingnumber"},
        idea = {"missingnumber", "cassknows"}
    },
    attributes = {"eqmoney"},
}


Entropy.Joker{
    order = 24,
    
    key = "sticker_sheet",
    rarity = 2,
    cost = 5,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        per_sticker = 2
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 9, y = 3 },
    atlas = "jokers",
    demicoloncompat = true,
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                number_format(card.ability.per_sticker),
                number_format(card.ability.per_sticker * Entropy.count_stickers(card))
            }
        }
    end,
    calculate = function(self, card2, context)
        if context.joker_main or context.forcetrigger then
            local stickers = {
                "eternal",
                "banana",
                "perishable",
                "cry_rigged",
                "cry_global_sticker",
                "rental",
                "entr_hotfix",
                "scarred",
                "pinned",
                "entr_pseudorandom",
                "entr_pure",
                "desync"
            }
            local card = pseudorandom_element(G.play.cards, pseudoseed("sticker_sheet"))
            local sticker = pseudorandom_element(stickers, pseudoseed("sticker_sheet_sticker"))
            card.ability[sticker] = true
            if sticker == "perishable" then card.ability.perish_tally = 5 end
            card:juice_up()
            return {
                mult = card2.ability.per_sticker * Entropy.count_stickers(card)
            }
        end
	end,
    attributes = {"modify_card", "mult"},
}


Entropy.Joker{
    order = 25,
    
    key = "fourbit",
    rarity = 2,
    cost = 5,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        needed = 16,
        left = 16
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 1, y = 4 },
    pixel_size = { w = 53, h = 53 },
    atlas = "jokers",
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                number_format(card.ability.needed),
                number_format(card.ability.left)
            }
        }
    end,
    calculate = function(self, card2, context)
        if context.joker_main and not context.blueprint then
            local text, loc_disp_text, poker_hands, scoring_hand, disp_text =
            G.FUNCS.get_poker_hand_info(G.play.cards)
            for i, card in pairs(scoring_hand) do
                card2.ability.left = card2.ability.left - 1
                if to_big(card2.ability.left) <= to_big(0) then
                    card2.ability.left = card2.ability.needed
                    Entropy.flip_then({card}, function(card)
                        card:set_ability(Entropy.Get4bit())
                    end)
                    card_eval_status_text(
                        card2,
                        "extra",
                        nil,
                        nil,
                        nil,
                        { message = localize("k_upgrade_ex"), colour = G.C.GREEN }
                    )
                else
                    card_eval_status_text(
                        card2,
                        "extra",
                        nil,
                        nil,
                        nil,
                        { message = number_format(card2.ability.needed - card2.ability.left) .."/"..number_format(card2.ability.needed), colour = G.C.GREEN }
                    )
                end
            end
        end
	end,
    slib_credits = {
        idea = {"cassknows"}
    },
    attributes = {"modify_card", "ccd"},
}

Entropy.Joker{
    order = 26,
    
    key = "crimson_flask",
    rarity = 2,
    cost = 5,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 7, y = 4 },
    atlas = "jokers",
    demicoloncompat = true,
    config = {
        xmult = 1,
        xmult_joker = 0.25,
        xmult_card = 0.05
    },
    loc_vars = function(self, q, card) return {vars = {number_format(card.ability.xmult_joker), number_format(card.ability.xmult_card), number_format(card.ability.xmult)}} end,
    calculate = function(self, card, context)
        if context.joker_debuffed or context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "xmult", scalar_value = "xmult_joker", message_key = "a_xmult", message_colour = G.C.RED})
        end
        if context.debuffed_card_drawn or context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "xmult", scalar_value = "xmult_card", message_key = "a_xmult", message_colour = G.C.RED})
        end
        if context.setting_blind or context.forcetrigger then
            local cards = {}
            for i, v in pairs(G.jokers.cards) do if v ~= card then cards[#cards+1] = v end end
            if #cards > 0 then
                pseudorandom_element(cards, pseudoseed("crimson_flask_card")):set_debuff(true)
            end
        end
        if context.joker_main or context.forcetrigger then
            return {
                xmult = card.ability.xmult
            }
        end
    end,
    slib_credits = {
        idea = {"cassknows"},
        art = {"missingnumber"}
    },
    attributes = {"modify_card", "xmult"," joker"},
}

local card_dissolveref = Card.start_dissolve
function Card:start_dissolve(...)
    self.dissolved = true
    return card_dissolveref(self, ...)
end

local card_sellref = Card.sell_card
function Card:sell_card(...)
    self.dissolved = true
    G.GAME.last_sold_card = self.config.center.key
    return card_sellref(self, ...)
end

local card_debuffref = Card.set_debuff
function Card:set_debuff(debuff)
    if self.area == G.jokers and (debuff or (self.ability.perishable and (self.ability.perish_tally or 0) <= 0)) and self.config.center.set == "Joker" and not self.debuff and not self.dissolved then
        SMODS.calculate_context{joker_debuffed = true, card = self}
    end
    return card_debuffref(self, debuff)
end

local cardarea_emplaceref = CardArea.emplace
function CardArea:emplace(card, ...)
    if self == G.hand and G.hand and self.debuff then
        SMODS.calculate_context{debuffed_card_drawn = true, card = self}
    end
    return cardarea_emplaceref(self, card, ...)
end

Entropy.Joker{
    order = 27,
    
    key = "grotesque_joker",
    rarity = 3,
    cost = 10,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
            "m_entr_flesh"
        }
    },
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 1, y = 6 },
    atlas = "jokers",
    demicoloncompat = true,
    config = {
        xmult = 1,
        xmult_mod = 0.1,
        xchips = 1,
        xchips_mod = 0.1
    },
    in_pool = function()
        for i, v in pairs(G.playing_cards) do
            if v.config and v.config.center_key == "m_entr_flesh" then return true end
        end
    end,
    loc_vars = function(self, q, card) return {vars = {
        number_format(card.ability.xmult_mod), 
        number_format(card.ability.xchips_mod), 
        number_format(card.ability.xmult),
        number_format(card.ability.xchips)
    }} 
    end,
    calculate = function(self, card, context)
        if context.remove_playing_cards then
            for i, v in pairs(context.removed) do
                if v.config.center.key == "m_entr_flesh" then
                    SMODS.scale_card(card, {ref_table = card.ability, ref_value = "xchips", scalar_value = "xchips_mod", message_key = "a_xchips", message_colour = G.C.BLUE})
                end
            end
        end
        if context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "xchips", scalar_value = "xchips_mod", message_key = "a_xchips", message_colour = G.C.BLUE})
        end
        if (context.setting_ability and not context.unchanged and context.new == "m_entr_flesh") or context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "xmult", scalar_value = "xmult_mod", message_key = "a_xmult", message_colour = G.C.RED})
        end
        if context.joker_main or context.forcetrigger then
            return {
                xmult = card.ability.xmult,
                xchips = card.ability.xchips
            }
        end
    end,
    slib_credits = {
        idea = {"user324897"},
        art = {"LFMoth", "Lil. Mr. Slipstream"}
    },
    attributes = {"enhancements", "xmult", "xchips"},
}

Entropy.Joker{
    order = 28,
    
    key = "dog_chocolate",
    rarity = SMODS.Mods.Cryptid and SMODS.Mods.Cryptid.can_load and "cry_candy" or 2,
    cost = 6,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
            "tag_entr_dog"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 4, y = 4 },
    atlas = "jokers",
    demicoloncompat = true,
    pools = {Food = true},
    calculate = function(self, card, context)
        if (context.tags_merged and (context.first_tag.key == "tag_entr_dog" or context.first_tag.key == "tag_entr_ascendant_dog")) or context.forcetrigger then
            if SMODS.Mods.Cryptid and SMODS.Mods.Cryptid.can_load then
                local card = SMODS.add_card{
                    set="Joker",
                    rarity="cry_candy",
                    area=G.jokers,
                    key_append = "entr_dog_chocolate"
                }
            else    
                local card = SMODS.add_card{
                    set="Food",
                    area=G.jokers,
                    key_append = "entr_dog_chocolate"
                }
            end
            if context.first_tag.key == "tag_entr_ascendant_dog" then
                card:set_edition("e_negative")
            end
            return true
        end
    end,
    attributes = {"generation", "joker", "passive"},
}

Entropy.Joker{
    order = 29,
    
    key = "nucleotide",
    rarity = 3,
    cost = 10,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 8, y = 6 },
    atlas = "jokers",
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.first_hand_drawn then
            G.GAME.current_round.discarded_cards = 0
            local eval = function() return G.GAME.current_round.discarded_cards == 0 and not G.RESET_JIGGLES end
            juice_card_until(card, eval, true)
        end
        if context.pre_discard and (G.GAME.current_round.discarded_cards or 0) <= 0 then
            local card 
            for i, v in pairs(G.hand.cards) do
                if v.highlighted then card = v; break end
            end
            G.E_MANAGER:add_event(Event({
                func = function()
                    local new_card = SMODS.create_card{
                        key = card.config.center.key,
                        set = card.config.center.set
                    }
                    SMODS.change_base(new_card, Entropy.get_inverse_suit(card.base.suit), Entropy.get_inverse_rank(card.base.id))
                    local jkr = card
                    local found_index = 1
                    if jkr.edition then
                        for i, v in ipairs(G.P_CENTER_POOLS.Edition) do
                            if v.key == jkr.edition.key then
                                found_index = i
                                break
                            end
                        end
                    end
                    found_index = found_index + 1
                    if found_index > #G.P_CENTER_POOLS.Edition then
                        found_index = found_index - #G.P_CENTER_POOLS.Edition
                    end
                    new_card:set_edition(G.P_CENTER_POOLS.Edition[found_index].key)
                    G.hand:emplace(new_card)
                    table.insert(G.playing_cards, new_card)
                    SMODS.destroy_cards{card}
                    return true
                end
            }))
            G.GAME.current_round.discarded_cards = (G.GAME.current_round.discarded_cards or 0) + #G.hand.highlighted
        end
    end,
    attributes = {"modify_card", "generation", "discard"},
}

Entropy.Joker{
    order = 30,
    
    key = "afterimage",
    rarity = 2,
    cost = 5,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 5, y = 4 },
    atlas = "jokers",
    demicoloncompat = true,
    config = {
        extra = {
            odds = 3
        }
    },
    loc_vars = function(self, q, card)
        q[#q+1] = {set="Other", key="perishable", vars={5, 5}}
        q[#q+1] = {set="Other", key="banana", vars={1, 10}}
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds)
        return {
            vars = {
                numerator,
                denominator
            }
        }
    end,
    calculate = function(self, card, context)
        if context.after then
            local text, loc_disp_text, poker_hands, scoring_hand, disp_text =
            G.FUNCS.get_poker_hand_info(G.play.cards)
            for i, v in pairs(scoring_hand) do
                local old_card = v
                if SMODS.pseudorandom_probability(card, 'afterimage', 1, card.ability.extra.odds) then
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            local new_card = copy_card(old_card)
                            new_card.ability.banana = true
                            new_card:add_sticker("perishable", true)
                            G.hand:emplace(new_card)
                            table.insert(G.playing_cards, new_card)
                            return true
                        end
                    }))
                end
            end
        end
    end,
    slib_credits = {
        idea = {"cassknows"}
    },
    attributes = {"generation", "modify_card"},
}

Entropy.Joker{
    order = 31,
    
    key = "qu",
    rarity = 3,
    cost = 8,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 6, y = 4 },
    atlas = "jokers",
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.first_hand_drawn or context.forcetrigger then
            local card = pseudorandom_element(G.hand.cards, pseudoseed("qu_card"))
            Entropy.flip_then({card}, function(card)
                local elem = G.P_CENTERS[SMODS.poll_object({attributes = {"inverted_consumable"}, types = {"Consumeables"},})]
                card:set_ability(elem)
            end)
            G.E_MANAGER:add_event(Event({
                blocking = false,
                trigger = "after",
                func = function()
                    save_run()
                    return true
                end
            }))
            return {
                message = localize("k_upgrade_ex")
            }
        end
    end,
    attributes = {"ccd", "modify_card"},
}

Entropy.Joker{
    order = 32,
    
    key = "memento_mori",
    pools = {Music = true},
    rarity = 2,
    cost = 5,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 8, y = 4 },
    atlas = "jokers",
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.setting_blind and not context.repetition and not context.blueprint then
            local eval = function() return not card.ability.triggered and not G.RESET_JIGGLES end
            juice_card_until(card, eval, true)
        end
        if context.destroy_card then
            if not card.ability.triggered then
                local dcard = G.play.cards[1]
                if dcard and dcard == context.destroy_card then
                    card.ability.triggered = true
                    return {remove = not SMODS.is_eternal(dcard)}
                end
            end
        end
        if context.end_of_round and not context.individual then card.ability.triggered = false end
    end,
    slib_credits = {
        art = {"Lil. Mr. Slipstream"}
    },
    attributes = {"destroy_card", "hands"},
}


Entropy.Joker{
    order = 33,
    
    key = "broadcast",
    rarity = 3,
    cost = 10,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    eternal_compat = true,
    pos = { x = 0, y = 5 },
    atlas = "jokers",
    demicoloncompat = true,
    config = {
        extra = 1
    },
    immutable = true,
    loc_vars = function(self, q, card)
        local suffix = "th"
        if card.ability.extra == 1 then suffix = "st" end
        if card.ability.extra == 2 then suffix = "nd" end
        if card.ability.extra == 3 then suffix = "rd" end
        local other_joker = G.jokers and G.jokers.cards[card.ability.extra]
        local compatible = other_joker and other_joker ~= card and other_joker.config.center.blueprint_compat
        local main_end = {
            {
                n = G.UIT.C,
                config = { align = "bm", minh = 0.4 },
                nodes = {
                    {
                        n = G.UIT.C,
                        config = {
                            ref_table = card,
                            align = "m",
                            colour = compatible and mix_colours(G.C.GREEN, G.C.JOKER_GREY, 0.8)
                                or mix_colours(G.C.RED, G.C.JOKER_GREY, 0.8),
                            r = 0.05,
                            padding = 0.06,
                        },
                        nodes = {
                            {
                                n = G.UIT.T,
                                config = {
                                    text = " "
                                        .. localize("k_" .. (compatible and "compatible" or "incompatible"))
                                        .. " ",
                                    colour = G.C.UI.TEXT_LIGHT,
                                    scale = 0.32 * 0.8,
                                },
                            },
                        },
                    },
                },
            },
        }
        return {
            vars = {
                card.ability.extra,
                suffix
            },
            main_end = main_end
        }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.blueprint and not context.repetition and not context.individual then
            card.ability.extra = card.ability.extra + 1
            if card.ability.extra > #G.jokers.cards then
                card.ability.extra = 1
            end
        elseif G.jokers.cards[card.ability.extra] then 
            local ret = SMODS.blueprint_effect(card, G.jokers.cards[card.ability.extra], context)
            return ret
        end
    end,
    attributes = {"copying", "joker"},
}

Entropy.Joker{
    order = 34,
    
    key = "milk_chocolate",
    rarity = 2,
    cost = 5,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    pos = { x = 3, y = 6 },
    atlas = "jokers",
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue + 1] = { key = 'tag_coupon', set = 'Tag' }
        return { vars = { localize { type = 'name_text', set = 'Tag', key = 'tag_coupon' } } }
    end,
    pools = {["Food"] = true},
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    calculate = function(self, card, context)
        if context.selling_self or context.forcetrigger then
            G.E_MANAGER:add_event(Event({
                func = (function()
                    add_tag(Tag('tag_coupon'))
                    play_sound('generic1', 0.9 + math.random() * 0.1, 0.8)
                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                    return true
                end)
            }))
            return nil, true -- This is for Joker retrigger purposes
        end
    end,
    attributes = {"on_sell", "economy"},
}

Entropy.Joker{
    order = 35,
    
    key = "insurance_fraud",
    rarity = 2,
    cost = 5,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
            "set_entr_inversions"
        }
    },
    eternal_compat = true,
    pos = {x = 9, y = 7},
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    calculate = function(self, card, context)
        if (context.selling_card and context.card.config.center.set == "Tarot") or context.forcetrigger then
            G.E_MANAGER:add_event(Event({
                func = (function()
                    if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit + 1  then
                        SMODS.add_card{
                            set="Fraud",
                            area = G.consumeables,
                            key_append = "entr_insurance_fraud"
                        }
                    end
                    return true
                end)
            }))
            return nil, true -- This is for Joker retrigger purposes
        end
    end,
    attributes = {"inverted", "on_sell", "fraud", "generation"},
}

Entropy.Joker{
    order = 36,
    
    key = "free_samples",
    rarity = 2,
    cost = 5,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    eternal_compat = true,
    perishable_compat = true,
    blueprint_compat = true,
    pos = { x = 4, y = 6 },
    atlas = "jokers",
    config = {
        extra = {
            odds = 4
        }
    },
    loc_vars = function(self, q, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card and card.ability.extra and card.ability.extra.odds or 4)
        return {vars = {
            numerator,
            denominator,
        }} 
    end,
    calculate = function(self, card, context)
        if context.open_booster then
            if SMODS.pseudorandom_probability(
                card,
                "entr_free_samples",
                1,
                card and card.ability.extra.odds or self.config.extra.odds
            ) and (not context.card.area or context.card.area ~= G.consumeables) then
                G.E_MANAGER:add_event(Event({
                    func = (function()
                        if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit + 1  then
                            SMODS.add_card{
                                key=context.card.config.center.key,
                                area = G.consumeables,
                                key_append = "entr_free_samples"
                            }
                        end
                        return true
                    end)
                }))
            end
        end
    end,
    attributes = {"generation", "chance"},
}

Entropy.Joker{
    order = 37,
    
    key = "fused_lens",
    rarity = 2,
    cost = 5,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
            "set_entr_inversions"
        }
    },
    eternal_compat = true,
    pos = {x = 1, y = 8},
    atlas = "jokers",
    config = {
        extra = {
            odds = 4
        }
    },
    loc_vars = function(self, q, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds)
        return {vars = {
            numerator,
            denominator,
        }} 
    end,
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    calculate = function(self, card, context)
        if (context.after and SMODS.pseudorandom_probability(
            card,
            "entr_fused_lens",
            1,
            card and card.ability.extra.odds or self.config.extra.odds
        )) or context.forcetrigger then
            local star_card
            for i, v in pairs(G.P_CENTER_POOLS.Star) do
                if v.config.handname == context.scoring_name then
                    star_card = v.key
                end
            end
            G.E_MANAGER:add_event(Event({
                func = (function()
                    if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit + 1  then
                        SMODS.add_card{
                            key=star_card,
                            set = "Star",
                            area = G.consumeables,
                            key_append = "entr_fused_lens"
                        }
                    end
                    return true
                end)
            }))
            return {
                message = localize("k_plus_star")
            }
        end
    end,
    attributes = {"star", "chance"},
}

Entropy.Joker{
    order = 38,
    
    key = "opal",
    rarity = 2,
    cost = 7,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    eternal_compat = true,
    perishable_compat = true,
    blueprint_compat = true,
    pos = { x = 5, y = 6 },
    atlas = "jokers",
    calculate = function(self, card, context)
        if context.repetition
        and Spectrallib.true_suitless(context.other_card)
        then
            return {
                message = localize("k_again_ex"),
                repetitions = 1,
                card = card,
            }
        end
    end,
    slib_credits = {
        art = {"mailingway"}
    },
    attributes = {"nilsuit", "retrigger", "passive"},
}

Entropy.Joker{
    order = 39,
    
    key = "inkbleed",
    rarity = 2,
    cost = 4,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    eternal_compat = true,
    perishable_compat = true,
    pos = { x = 7, y = 6 },
    atlas = "jokers",
    slib_credits = {
        art = {"LFMoth"}
    },
    attributes = {"enhancements", "suit", "rank", "passive"},
}

Entropy.Joker{
    order = 40,
    
    key = "roulette",
    rarity = 3,
    cost = 9,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        mult_gain = 3,
        extra = {
            odds = 3,
        },
        card = 6,
        immutable = {
            curr_card = 0
        }
    },
    eternal_compat = true,
    perishable_compat = true,
    blueprint_compat = true,
    pos = {x = 0, y = 8},
    atlas = "jokers",
    loc_vars = function(self, q, card)
        local num, denom = SMODS.get_probability_vars(card, 1, card.ability.extra.odds)
        return {
            vars = {
                num,
                denom,
                number_format(card.ability.mult_gain),
                number_format(math.floor(card.ability.card))
            }
        }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(
                card,
                "entr_roulette",
                1,
                card and card.ability.extra.odds or self.config.extra.odds
            ) then
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.mult_gain
                return {
                    message = localize("k_upgrade_ex"),
                    colour = G.C.RED
                }
            end
        end
        if context.after then
            local check
            for i, v in pairs(G.play.cards) do
                card.ability.immutable.curr_card = card.ability.immutable.curr_card + 1
                if to_big(card.ability.immutable.curr_card) == to_big(math.floor(card.ability.card)) then
                    G.E_MANAGER:add_event(Event{
                        func = function()
                            card.ability.immutable.curr_card = 0
                            SMODS.destroy_cards{v}
                            return true
                        end
                    })
                    check = true
                end
            end
            if check then
                return {
                    message = localize("k_destroyed_ex"),
                    colour = G.C.RED
                }
            end
        end
    end,
    attributes = {"chance", "destroy_card", "mult", "modify_card"},
}

Entropy.Joker{
    order = 41,
    
    key = "debit_card",
    rarity = 2,
    cost = 7,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    eternal_compat = true,
    pos = { x = 6, y = 6 },
    atlas = "jokers",
    config = {
        amount = 1,
        needed = 40,
        current_spent = 0,
        current = 0
    },
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                number_format(card.ability.amount),
                number_format(card.ability.needed),
                number_format(card.ability.needed-card.ability.current_spent),
                number_format(card.ability.current),
            }
        }
    end,
    calculate = function(self, card, context)
        if context.money_altered and to_big(context.amount) < to_big(0) and not context.blueprint and context.from_shop then
            card.ability.current_spent = card.ability.current_spent - context.amount
            local check 
            while to_big(card.ability.current_spent) >= to_big(card.ability.needed) do
                card.ability.current_spent = card.ability.current_spent - card.ability.needed
                SMODS.scale_card(card, {ref_table = card.ability, ref_value = "current", scalar_value = "amount"})
                check = true
            end
            if not check then
                return {
                    message = number_format(card.ability.current_spent).."/"..number_format(card.ability.needed)
                }
            end
        end
        if context.forcetrigger then
            ease_dollars(card.ability.current)
        end
    end,
    calc_dollar_bonus = function(self, card)
        if to_big(card.ability.current) > to_big(0) then
            return card.ability.current
        end
    end,
    slib_credits = {
        art = {"Lil. Mr. Slipstream"}
    },
    attributes = {"economy", "scaling"},
}

Entropy.Joker{
    order = 42,
    
    key = "birthday_card",
    rarity = 2,
    cost = 6,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    eternal_compat = true,
    pixel_size = { h = 80 },
    pos = { x = 9, y = 6 },
    atlas = "jokers",
    config = {
        xmult = 2,
        consumables = 2
    },
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                number_format(card.ability.xmult),
                number_format(card.ability.consumables),
            }
        }
    end,
    perishable_compat = true,
    blueprint_compat = true,
    calculate = function(self, card, context)
        if Overflow then
            if context.joker_main and G.consumeables:get_total_count() >= card.ability.consumables then
                return {
                    xmult = card.ability.xmult
                }
            end
        else
            if context.joker_main and #G.consumeables.cards >= card.ability.consumables then
                return {
                    xmult = card.ability.xmult
                }
            end
        end
        if context.forcetrigger then
            return {
                xmult = card.ability.xmult
            }
        end
    end,
    attributes = {"xmult"},
}

Entropy.Joker{
    
    key = "ruby",
    order = 300,
    rarity = 4,
    cost = 20,
    atlas = "ruby_atlas",
    pos = {x=1, y=0},
    soul_pos = {x = 0, y = 0},
    config = {
        jokers_needed = 2,
        jokers = 0,
        already_triggered = false
    },
    demicoloncompat = true,
    blueprint_compat = true,
    pronouns = "she_her",
    calculate = function(self, card, context)
        if context.buying_card and context.card.config.center.set == "Joker" then
            if context.blueprint then
                local off = 0
                for i = 1, #G.jokers.cards do
                    if G.jokers.cards[i] == context.blueprint_card then off = 1; break end
                    if G.jokers.cards[i] == card then break end
                end
                if card.ability.jokers + off == card.ability.jokers_needed then
                    add_tag(Tag(get_next_tag_key()))
                    return {
                        message = localize("k_plus_tag")
                    }
                end
                return {
                    message = number_format(card.ability.jokers + off).."/"..number_format(card.ability.jokers_needed)
                }
            else
                card.ability.jokers = card.ability.jokers + 1
                local add
                if card.ability.jokers >= card.ability.jokers_needed then
                    add_tag(Tag(get_next_tag_key()))
                    G.E_MANAGER:add_event(Event{
                        func = function()
                            card.ability.jokers = 0
                            return true
                        end
                    })
                    add = true
                end
                if add then
                    return {
                        message = localize("k_plus_tag")
                    }
                else
                    return {
                        message = number_format(card.ability.jokers).."/"..number_format(card.ability.jokers_needed)
                    }
                end
            end
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                number_format(card.ability.jokers_needed),
                number_format(card.ability.jokers_needed - card.ability.jokers)
            }
        }
    end,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"generation", "joker"},
}

SMODS.draw_ignore_keys.center2 = true
SMODS.DrawStep({
	key = "ruby",
	order = 25,
	func = function(self)
        local card = self.ability.glitched_crown and self.ability.glitched_crown[self.glitched_index] or self.config.center_key
        if (card ~= "j_entr_ruby" and card ~= "j_entr_ybur") or not G.P_CENTERS[card].discovered or not G.P_CENTERS[card].unlocked then return end


        if not self.children.center2 then 
            self.children.center2 = SMODS.create_sprite(0, 0, G.CARD_W, G.CARD_H, "entr_ruby_atlas", {x=G.P_CENTERS[card].pos.x+1, y = 0})
        end
        local sprite = self.children.center2
        self.children.center:draw_shader('voucher', nil, self.ARGS.send_to_shader)
        sprite.role.draw_major = self
        local edition = self.delay_edition or self.edition
        local shader = "dissolve"
        if edition then
            shader = (G.P_CENTERS[edition.key or ""] or {}).shader
        end
        sprite:draw_shader(shader, nil, nil, nil, self.children.center)
	end,
	conditions = { vortex = false, facing = "front" },
})

Entropy.Joker{
    
    key = "slipstream",
    order = 301,
    rarity = 4,
    cost = 20,
    atlas = "ruby_atlas",
    pos = {x=0, y=1},
    soul_pos = {x = 1, y = 1},
    config = {
        xmult = 2,
    },
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    pronouns = "he_they",
    calculate = function(self, card, context)
        if context.setting_blind then
            if G.GAME.consumeable_buffer + #G.consumeables.cards < G.consumeables.config.card_limit then
                G.E_MANAGER:add_event(Event{
                    func = function()
                        G.GAME.consumeable_buffer = 0
                        SMODS.add_card{
                            set = "Omen",
                            area = G.consumeables,
                            key_append = "entr_slipstream"
                        }         
                        return true
                    end
                })
                G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                return {
                    message = localize("k_plus_omen")
                }
            end
        end
        if context.joker_main or context.forcetrigger then
            for i, v in pairs(G.consumeables.cards) do
                if v.config.center.set == "Omen" then 
                    local num = v.getQty and v:getQty() or 1
                    for i = 1, num do
                        G.E_MANAGER:add_event(Event{
                            func = function()
                                card:juice_up()
                                return true
                            end
                        })
                    end
                    SMODS.calculate_effect({xmult = card.ability.xmult}, v)
                end
            end
            return nil, true
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                number_format(card.ability.xmult)
            }
        }
    end,
    slib_credits = {art = {"Lil. Mr. Slipstream"}, idea = {"Lil. Mr. Slipstream"}},
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"omen", "inverted", "xmult", "generation"},
}

Entropy.Joker{
    
    key = "cass",
    order = 302,
    rarity = 4,
    cost = 20,
    atlas = "ruby_atlas",
    pos = {x=0, y=2},
    soul_pos = {x = 1, y = 2},
    config = {
        hand_size = 0,
        selection_limit = 0,
        hands = 0,
        discards = 0,
        consumable_slots = 0,
        shop_slots = 0,
        mod = 0.5
    },
    demicoloncompat = true,
    blueprint_compat = true,
    pronouns = "she_her",
    calculate = function(self, card, context)
        if context.using_consumeable and (context.consumeable.config.center.set == "Planet" or context.consumeable.config.center.set == "Star") then
            card.ability.mod = math.min(card.ability.mod, 20)
            local result = pseudorandom(pseudoseed("entr_cass"), 1, 6)
            if result == 1 then
                local old = card.ability.hand_size
                SMODS.scale_card(card, {ref_table = card.ability, ref_value = "hand_size", scalar_value = "mod"})
                Entropy.handle_card_limit(G.hand, card.ability.hand_size - old)
            elseif result == 2 then
                SMODS.scale_card(card, {ref_table = card.ability, ref_value = "selection_limit", scalar_value = "mod"})
                Entropy.change_selection_limit(card.ability.mod)
            elseif result == 3 then 
                SMODS.scale_card(card, {ref_table = card.ability, ref_value = "hands", scalar_value = "mod"})
                G.GAME.round_resets.hands = G.GAME.round_resets.hands + card.ability.mod
                ease_hands_played(card.ability.mod)
            elseif result == 4 then
                SMODS.scale_card(card, {ref_table = card.ability, ref_value = "discards", scalar_value = "mod"})
                G.GAME.round_resets.discards = G.GAME.round_resets.discards + card.ability.mod
                ease_discard(card.ability.mod)
            elseif result == 5 then
                local old = card.ability.consumable_slots
                SMODS.scale_card(card, {ref_table = card.ability, ref_value = "consumable_slots", scalar_value = "mod"})
                Entropy.handle_card_limit(G.consumeables, card.ability.consumable_slots - old)
            elseif result == 6 then
                if to_big(card.ability.shop_slots) < to_big(4) then
                    SMODS.scale_card(card, {ref_table = card.ability, ref_value = "shop_slots", scalar_value = "mod"})
                    if to_big(card.ability.shop_slots) > to_big(4) then
                        card.ability.shop_slots = 4
                    else
                        local diff = math.min(card.ability.mod, 4-card.ability.mod)
                        G.E_MANAGER:add_event(Event({
                            func = function() --card slot
                                -- why is this in an event?
                                change_shop_size(to_number(math.min(diff, 20)))
                                return true
                            end,
                        }))
                    end
                end
            end
        end
    end,
    remove_from_deck = function(self, card)        
        Entropy.handle_card_limit(G.hand, -card.ability.hand_size)
        Entropy.change_selection_limit(-card.ability.selection_limit)
        if to_big(card.ability.hands) > to_big(0) then
            G.GAME.round_resets.hands = G.GAME.round_resets.hands - card.ability.hands
            ease_hands_played(-card.ability.hands)
        end
        if to_big(card.ability.discards) > to_big(0) then
            G.GAME.round_resets.discards = G.GAME.round_resets.discards - card.ability.discards
            ease_discard(-card.ability.discards)
        end
        Entropy.handle_card_limit(G.consumeables, -card.ability.consumable_slots)        
        G.E_MANAGER:add_event(Event({
            func = function() --card slot
                -- why is this in an event?
                change_shop_size(-to_number(math.min(card.ability.shop_slots, 10)))
                return true
            end,
        }))
    end,
    add_to_deck = function(self, card)
        Entropy.handle_card_limit(G.hand, card.ability.hand_size)
        Entropy.change_selection_limit(card.ability.selection_limit)
        if to_big(card.ability.hands) > to_big(0) then
            G.GAME.round_resets.hands = G.GAME.round_resets.hands + card.ability.hands
            ease_hands_played(card.ability.hands)
        end
        if to_big(card.ability.discards) > to_big(0) then
            G.GAME.round_resets.discards = G.GAME.round_resets.discards + card.ability.discards
            ease_discard(card.ability.discards)
        end
        Entropy.handle_card_limit(G.consumeables, card.ability.consumable_slots)
        G.E_MANAGER:add_event(Event({
            func = function() --card slot
                -- why is this in an event?
                change_shop_size(to_number(math.min(card.ability.shop_slots, 20)))
                return true
            end,
        }))
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                number_format(card.ability.hand_size),
                number_format(card.ability.selection_limit),
                number_format(card.ability.hands),
                number_format(card.ability.discards),
                number_format(card.ability.consumable_slots),
                number_format(card.ability.shop_slots),
                number_format(math.min(card.ability.mod, 20)),
            }
        }
    end,
    slib_credits = {art = {"Lil. Mr. Slipstream"}},
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    slib_credits = {
        idea = {"cassknows"},
        art = {"Lil. Mr. Slipstream"}
    },
    attributes = {"star", "planet", "hand_size", "hands", "discards"},
}

Entropy.Joker{
    
    key = "hexa",
    order = 304,
    rarity = 4,
    cost = 20,
    atlas = "ruby_atlas",
    pos = {x=0, y=4},
    soul_pos = {x = 1, y = 4},
    config = {
        asc_fac = 3,
        csl = 3
    },
    demicoloncompat = true,
    perishable_compat = true,
    add_to_deck = function(self, card)
        Entropy.change_selection_limit(card.ability.csl)
    end,
    remove_from_deck = function(self, card)
        Entropy.change_selection_limit(-card.ability.csl)
    end,
    loc_vars = function(self, q, card)
        return {
            key = (SMODS.Mods["Cryptid"] or {}).can_load and "j_entr_hexa_cryptid" or nil,
            vars = {
                number_format(card.ability.csl)
            }
        }
    end,
    slib_credits = {art = {"HexaCryonic"}, idea = {"HexaCryonic"}},
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    pronouns = "she_her",
    attributes = {"asc", "generation"},
}

Entropy.Joker{
    
    key = "grahkon",
    order = 305,
    rarity = 4,
    cost = 20,
    atlas = "grahkon_atlas",
    pos = {x=0, y=0},
    soul_pos = {x = 1, y = 0},
    config = {
        blind_size = 800,
        value_inc = 1.08,
        left = 1,
        left_mod = 1,
        cards = 4
    },
    demicoloncompat = true,
    perishable_compat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.blind_size,
                card.ability.value_inc,
                card.ability.cards,
                card.ability.left_mod,
                card.ability.left,
            }
        }
    end,
    slib_credits = {art = {"Lil. Mr. Slipstream"}, idea = {"Grahkon"}},
    dependencies = {
        items = {
            "set_entr_actives",
        }
    },
    pronouns = "he_him",

    calculate = function(self, card, context)
        if (context.end_of_round and not context.blueprint and not context.individual and not context.repetition) or context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", scaling_message = {message = "+"..number_format(card.ability.left_mod)}})
        end
        if context.remove_playing_cards and not context.blueprint then
            for i, v in pairs(context.removed) do
                SMODS.scale_card(card, {
                    ref_table = card.ability,
                    ref_value = "blind_size",
                    scalar_value = "value_inc",
                    operation = function(ref_table, ref_value, initial, change)
                        ref_table[ref_value] = initial * change
                    end,
                })
            end
        end
        if (context.setting_blind and not context.blueprint and not card.getting_sliced) or context.forcetrigger then
            G.GAME.blind.chips = G.GAME.blind.chips - card.ability.blind_size
            G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
            G.HUD_blind:recalculate()
        end
    end,
    can_use = function(self, card)
        return to_big(card.ability.left) > to_big(0) and G.hand and #G.hand.cards > 0
    end,
    use = function(self, card)
        card.ability.left = card.ability.left - 1
        local cards = {}
        for i, v in pairs(G.hand.cards) do
            if not SMODS.is_eternal(v) then
                cards[#cards+1] = v
            end
        end
        local a_cards = {}
        pseudoshuffle(cards, pseudoseed("entr_grahkon"))
        for i = 1, card.ability.cards do
            a_cards[#a_cards+1] = cards[i]
        end
        SMODS.destroy_cards(a_cards)
    end,
    attributes = {"activated", "blindsize", "destroy_card"},
}

Entropy.Joker{
    order = 43,
    
    key = "sandpaper",
    rarity = 2,
    cost = 6,
    dependencies = {
        items = {
            "set_entr_runes",
        }
    },
    eternal_compat = true,
    pos = { x = 0, y = 7 },
    atlas = "jokers",
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.m_stone
    end,
    perishable_compat = true,
    blueprint_compat = true,
    calculate = function(self, card, context)
        if context.after then
            local stones = {}
            for i, v in pairs(G.play.cards) do
                if v.config.center.key == "m_stone" then
                    stones[#stones+1] = v
                end
            end
            if #stones > 0 then
                G.E_MANAGER:add_event(Event{
                    trigger = "after",
                    blocking = false,
                    func = function()
                        SMODS.destroy_cards(stones)
                        if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                            SMODS.add_card{
                                set = "Rune",
                                area = G.consumeables,
                                key_append = "entr_sandpaper"
                            }
                        end
                        return true
                    end
                })
                return {
                    message = localize("k_plus_rune")
                }
            end
        end
        if context.forcetrigger then
            G.E_MANAGER:add_event(Event{
                trigger = "after",
                blocking = false,
                func = function()
                    SMODS.add_card{
                        set = "Rune",
                        area = G.consumeables,
                        key_append = "entr_sandpaper"
                    }
                    return true
                end
            })
        end
    end,
    attributes = {"enhancements", "rune", "generation", "destroy_card"},
}

Entropy.Joker{
    order = 44,
    
    key = "purple_joker",
    rarity = 2,
    cost = 6,
    dependencies = {
        items = {
            "set_entr_runes",
        }
    },
    eternal_compat = true,
    pos = { x = 1, y = 7 },
    atlas = "jokers",
    demicoloncompat = true,
    blueprint_compat = true,
    config = {
        xmult_mod = 0.2,
        xmult = 1
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                number_format(card.ability.xmult_mod),
                number_format(card.ability.xmult)
            }
        }
    end,
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.rune_triggered and not context.blueprint then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "xmult", scalar_value = "xmult_mod", message_key = "a_xmult", message_colour = G.C.RED})
        end
        if context.joker_main or context.forcetrigger then
            return {
                xmult = card.ability.xmult
            }
        end
    end,
    attributes = {"rune", "xmult"},
}

function Entropy.sum_pacts()
    local total = 0
    for i, v in pairs(G.runes or {}) do
        if G.P_RUNES[v.key].is_pact then
            total = total + v.ability.count or 1
        end
    end
    return total
end

Entropy.Joker{
    order = 45,
    
    key = "chalice_of_blood",
    rarity = 3,
    cost = 8,
    dependencies = {
        items = {
            "set_entr_runes",
            "set_entr_inversions"
        }
    },
    eternal_compat = true,
    pos = { x = 2, y = 7 },
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    config = {
        xmult_mod = 0.75,
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                number_format(card.ability.xmult_mod),
                number_format(1 + card.ability.xmult_mod * Entropy.sum_pacts())
            },
            key = G.GAME.modifiers.entr_gfb and "j_entr_chalice_of_blood_gfb" or nil
        }
    end,
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.joker_main or context.forcetrigger then
            return {
                xmult = 1 + card.ability.xmult_mod * Entropy.sum_pacts()
            }
        end
    end,
    attributes = {"pact", "xmult"},
}

Entropy.Joker{
    order = 46,
    
    key = "torn_photograph",
    rarity = 2,
    cost = 8,
    dependencies = {
        items = {            
            "set_entr_inversions"
        }
    },
    eternal_compat = true,
    blueprint_compat = true,
    pos = { x = 3, y = 7 },
    pixel_size = { h = 95 / 1.2 },
    atlas = "jokers",
    demicoloncompat = true,
    config = {
        xmult_mod = 0.2,
        xmult = 1
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                number_format(card.ability.xmult_mod),
                number_format(card.ability.xmult)
            }
        }
    end,
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.selling_card and Entropy.is_inverted(context.card) and not context.blueprint then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "xmult", scalar_value = "xmult_mod", message_key = "a_xmult", message_colour = G.C.RED})
        end
        if context.joker_main or context.forcetrigger then
            return {
                xmult = card.ability.xmult
            }
        end
    end,
    attributes = {"on_sell", "inverted", "xmult"},
}

Entropy.Joker{
    order = 47,
    
    key = "chuckle_cola",
    rarity = 3,
    cost = 8,
    dependencies = {
        items = {            
            "set_entr_inversions"
        }
    },
    pos = { x = 4, y = 7 },
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    config = {
        triggers = 10,
        xchip_mod = 1.5
    },
    pools = {Food = true},
    loc_vars = function(self, q, card)
        return {
            vars = {
                number_format(card.ability.xchip_mod),
                number_format(card.ability.triggers)
            }
        }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not card.eaten then
            card.ability.triggers = card.ability.triggers - 1
            context.other_card.ability.bonus = (context.other_card.ability.bonus or 0) + context.other_card:get_chip_bonus() * (card.ability.xchip_mod - 1)
            if card.ability.triggers <= 0 then
                SMODS.destroy_cards(card, true, nil, true)
                card.eaten = true
				return {
					message = localize("k_eaten_ex"),
					colour = G.C.FILTER,
				}
            else
                return {
                    message = localize("k_upgrade_ex"),
                    colour = G.C.BLUE,
                    card = context.other_card
                }
            end
        end
    end,
    slib_credits = {
        art = {"Lyman"},
        idea = {"Lyman"}
    },
    attributes = {"modify_card", "chips"},
}

Entropy.Joker{
    order = 48,
    
    key = "antiderivative",
    rarity = 3,
    cost = 10,
    dependencies = {
        items = {            
            "set_entr_misc_jokers"
        }
    },
    eternal_compat = true,
    perishable_compat = true,
    pos = { x = 5, y = 7 },
    atlas = "jokers",
    attributes = {"suit", "rank", "passive"},
}

function Entropy.get_suit_id(suit)
    if suit == "Diamonds" then return 11 end
    if suit == "Clubs" then return 12 end
    if suit == "Hearts" then return 13 end
    if suit == "Spades" then return 14 end
    for i, v in pairs(SMODS.Suit.obj_buffer) do
        if v == suit then return 15-i end 
    end
end

local is_faceref = Card.is_face
function Card:is_face(...)
    if next(SMODS.find_card("j_entr_antiderivative")) then
        local suit = self.base.suit
        if suit == "Diamonds" or suit == "Clubs" or suit == "Hearts" then return true end
    end
    return is_faceref(self, ...)
end

local get_idref = Card.get_id
function Card:get_id(...)
    if not self.antiderivative_bypass and next(SMODS.find_card("j_entr_antiderivative")) then
        if SMODS.has_no_suit(self) then return -9999 end
        return Entropy.get_suit_id(self.base.suit)
    end
    return get_idref(self,...)
end

local is_suitref = Card.is_suit
function Card:is_suit(suit, ...)
    if next(SMODS.find_card("j_entr_antiderivative")) then
        self.antiderivative_bypass = true
        local ret = type(self.get_id) == "function" and self:get_id() == Entropy.get_suit_id(suit) or nil
        self.antiderivative_bypass = nil
        return ret
    end
    return is_suitref(self, suit, ...)
end

if SpectrumAPI then
    SMODS.PokerHandPart:take_ownership("spa_spectrum_part", {
        func = function(hand)
            if next(SMODS.find_card("j_entr_antiderivative")) then
                local eligible_cards = {}
                local suits = {}
                local num_suits = 0
                for i, card in ipairs(hand) do
                    card.antiderivative_bypass = true
                    if not suits[card:get_id()] and not SMODS.has_no_rank(card) then --card.ability.name ~= "Gold Card"
                        suits[card:get_id()] = true
                        num_suits = num_suits + 1
                    end
                    card.antiderivative_bypass = nil
                    eligible_cards[#eligible_cards + 1] = card
                end
                local num = 5
                if SpectrumAPI.configuration.misc.four_fingers_spectrums then
                    num = SMODS.four_fingers() or 5
                end
                if num_suits >= num then
                    return { eligible_cards }
                end
                return {}
            else    
                local eligible_cards = {}
                local suits = {}
                local num_suits = 0
                for i, card in ipairs(hand) do
                    if not suits[SpectrumAPI.get_suit(card)] and not SMODS.has_no_suit(card) then --card.ability.name ~= "Gold Card"
                        suits[SpectrumAPI.get_suit(card)] = true
                        num_suits = num_suits + 1
                    end
                    eligible_cards[#eligible_cards + 1] = card
                end
                local num = 5
                if SpectrumAPI.configuration.misc.four_fingers_spectrums then
                    num = SMODS.four_fingers() or 5
                end
                if num_suits >= num then
                    return { eligible_cards }
                end
                return {}
            end
        end
    }, true)
end

local get_flushref = get_flush
function get_flush(hand)
    if next(SMODS.find_card("j_entr_antiderivative")) then
        local ret = {}
        local four_fingers = SMODS.four_fingers()
            local suits = {}
            suits[#suits + 1] = 'cry_abstract'
            
            for i,v in pairs(SMODS.Rank.obj_table) do
                suits[#suits + 1] = v.id
            end
        if #hand < four_fingers then return ret else
        for j = 1, #suits do
            local t = {}
            local suit = suits[j]
            local flush_count = 0
            for i=1, #hand do
                hand[i].antiderivative_bypass = true
                if hand[i]:get_id() == suit and not SMODS.has_no_rank(hand[i]) then flush_count = flush_count + 1;  t[#t+1] = hand[i] end
                hand[i].antiderivative_bypass = nil
            end
            if flush_count >= four_fingers then
            table.insert(ret, t)
            return ret
            end
        end
        return {}
        end
    end
    return get_flushref(hand)
end

Entropy.Joker{
    order = 49,
    
    key = "alles",
    rarity = 2,
    cost = 6,
    dependencies = {
        items = {            
            "set_entr_misc_jokers"
        }
    },
    config = {
        dollars = 8
    },
    eternal_compat = true,
    perishable_compat = true,
    pos = { x = 6, y = 7 },
    pixel_size = {h = 46},
    atlas = "jokers",
    calculate = function(self, card, context)
        if context.setting_blind then
            card.ability.hands_played = nil
        end
        if context.before then
            card.ability.hands_played = (card.ability.hands_played or 0) + 1
        end
    end,
    calc_dollar_bonus = function(self, card)
        if (card.ability.hands_played or 0) > 1 then
            return card.ability.dollars
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                number_format(card.ability.dollars)
            }
        }
    end,
    attributes = {"economy", "hands"}, 
}

Entropy.Joker{
    order = 51,
    
    key = "neuroplasticity",
    rarity = 2,
    cost = 8,
    dependencies = {
        items = {            
            "set_entr_misc_jokers"
        }
    },    
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 3, y = 8},
    atlas = "jokers",
    add_to_deck = function(self, card, from_debuff)
        if not G.GAME.randomised_hand_map then
            local map = {}
            local blacklist = {cry_Declare0 = true, cry_Declare1 = true, cry_Declare2 = true, cry_Clusterfuck = true, cry_WholeDeck = true}
            for i, v in pairs(G.handlist) do
                if not blacklist[v] then                    
                    map[#map+1] = v
                end
            end
            G.GAME.randomised_hand_map = {}
            local map_shuffled = copy_table(map)
            pseudoshuffle(map_shuffled, pseudoseed("entr_neuroplasticity"))
            for i, v in pairs(map) do
                G.GAME.randomised_hand_map[v] = map_shuffled[i]
            end
        end
    end,
    remove_from_deck = function(self, card)
        for i,v in pairs(SMODS.find_card("j_entr_neuroplasticity")) do
            if v ~= card then return end
        end
        G.GAME.randomised_hand_map = {}
    end,
    calculate = function(self, card, context)
        if context.end_of_round then
            local map = {}
            local blacklist = {cry_Declare0 = true, cry_Declare1 = true, cry_Declare2 = true, cry_Clusterfuck = true, cry_WholeDeck = true}
            for i, v in pairs(G.handlist) do
                if not blacklist[v] then                    
                    map[#map+1] = v
                end
            end
            G.GAME.randomised_hand_map = {}
            local map_shuffled = copy_table(map)
            pseudoshuffle(map_shuffled, pseudoseed("entr_neuroplasticity"))
            for i, v in pairs(map) do
                G.GAME.randomised_hand_map[v] = map_shuffled[i]
            end
        end
    end,
    slib_credits = {
        art = {"Lil. Mr. Slipstream"}
    },
    attributes = {"hand_type", "passive"},
}

Entropy.Joker{
    order = 52,
    
    key = "dragonfruit",
    rarity = 2,
    cost = 6,
    dependencies = {
        items = {            
            "set_entr_misc_jokers"
        }
    },    
    pos = {x = 2, y = 8},
    atlas = "jokers",
    config = {
        left = 5,
        left_mod = 1
    },
    perishable_compat = true,
    pools = {Food = true},
    add_to_deck = function(self, card, from_debuff)
        Entropy.change_selection_limit(card.ability.left)
    end,
    remove_from_deck = function(self, card, from_debuff)
        Entropy.change_selection_limit(-card.ability.left)
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.left,
                card.ability.left_mod
            }
        }
    end,
    calculate = function(self, card, context)
        if context.after and not context.repetition and not context.blueprint then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", operation = "-", no_message = true})
            if not card.ability.entr_pure then
                Entropy.change_selection_limit(- card.ability.left_mod)
            end
            if card.ability.left <= 0 then
                SMODS.destroy_cards(card, true, nil, true)
                return {
                    message = localize("k_eaten_ex"),
                    colour = G.C.FILTER,
                }
            end
            return {
                message = msg or "-"..number_format(card.ability.left_mod),
                colour = G.C.RED,
            }
        end
    end,
    attributes = {"card_selection_limit", "food", "scaling"},
}


Entropy.Joker{
    order = 53,
    
    key = "jestradiol",
    rarity = 2,
    cost = 6,   
    eternal_compat = true,
    pos = {x = 4, y = 8},
    atlas = "jokers",
    config = {
        left = 3,
        left_mod = 1
    },
    dependencies = {
        items = {
            "set_entr_actives",
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.left,
                card.ability.left_mod
            }
        }
    end,
    demicoloncompat = true,
    calculate = function(self, card, context)
        if (context.end_of_round and not context.blueprint and not context.individual and G.GAME.blind_on_deck == "Boss" and not context.repetition) or context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", scaling_message = {message = "+"..number_format(card.ability.left_mod)}})
        end
    end,
    use_button_config = {
        key = "b_transition",
    },
    can_use = function(self, card)
        local cards = Entropy.get_highlighted_cards({G.hand}, card, 1, card.ability.left)
        return to_big(card.ability.left) > to_big(0) and #cards > 0 and #cards <= card.ability.left
    end,
    use = function(self, card)
        local cards = Entropy.get_highlighted_cards({G.hand}, card, 1, card.ability.left)
        for i, v in pairs(cards) do
            if to_big(card.ability.left) > to_big(0) then
                card.ability.left = card.ability.left - 1
            end
        end
        card.ability.left = math.max(card.ability.left, 0)
        Entropy.flip_then(cards, function(card)
            SMODS.change_base(card, nil, "Queen")
        end)
        G.hand:unhighlight_all()
    end,
    attributes = {"activated", "modify_card", "scaling"},
}

Entropy.Joker{
    order = 54,
    
    key = "penny",
    rarity = 3,
    cost = 10,   
    eternal_compat = true,
    pos = {x = 5, y = 8},
    atlas = "jokers",
    config = {
        extra = {
            chips = 8
        }
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.chips
            }
        }
    end,
    pixel_size = { w = 32, h = 32 },
    demicoloncompat = true,
    blueprint_compat = true,
    calculate = function(self, card, context)
        if (context.end_of_round and not context.blueprint and not context.individual and G.GAME.blind_on_deck == "Boss" and not context.repetition) or context.forcetrigger then
            card.ability.extra.chips = to_big(card.ability.extra.chips) * 2
            return {
                message = localize("k_upgrade_ex"),
                chips = context.forcetrigger and card.ability.extra.chips or nil
            }
        end
        if context.joker_main then
            return {
                chips = card.ability.extra.chips
            }
        end
    end,
    attributes = {"scaling", "chips"},
}

Entropy.Joker{
    order = 55,
    
    key = "slothful_joker",
    rarity = 1,
    cost = 5,   
    eternal_compat = true,
    pos = {x = 6, y = 8},
    atlas = "jokers",
    config = {
        smult = 3
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.smult
            }
        }
    end,
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    calculate = function(self, card, context)
        if (context.individual and Entropy.true_suitless(context.other_card) and context.cardarea == G.play) or context.forcetrigger then
            return {
                mult = card.ability.smult
            }
        end
    end,
    attributes = {"suit", "mult", "nilsuit"},
}

Entropy.Joker{
    order = 56,
    
    key = "radar",
    rarity = 2,
    cost = 6,   
    eternal_compat = true,
    pos = {x = 7, y = 8},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                G.GAME.last_hand_played and G.GAME.hands[G.GAME.last_hand_played] and G.GAME.hands[G.GAME.last_hand_played].level or 0
            }
        }
    end,
    perishable_compat = true,
    calc_dollar_bonus = function(self, card)
        return G.GAME.last_hand_played and G.GAME.hands[G.GAME.last_hand_played] and G.GAME.hands[G.GAME.last_hand_played].level
    end,
    slib_credits = {
        art = {"mailingway"}
    },
    attributes = {"economy", "hand_type"},
}

Entropy.Joker{
    order = 57,
    
    key = "abacus",
    rarity = 1,
    cost = 5,   
    eternal_compat = true,
    pos = {x = 8, y = 8},
    atlas = "jokers",
    config = {
        dollar_mult = 1
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    calculate = function(self, card, context)
        if (context.individual and context.other_card.base.nominal and to_big(context.other_card:get_chip_bonus()) > to_big(0) and context.cardarea == G.play) or context.forcetrigger then
            if not context.other_card then
                return {
                    mult = 5
                }
            end
            local id = context.other_card:get_id()
            if id <= 10 or id > 14 and not SMODS.has_no_rank(context.other_card) then
                return {
                    mult = math.ceil((context.other_card:get_chip_bonus()) / 2)
                }
            end
        end
    end, 
    attributes = {"rank", "mult"},
}

Entropy.Joker{
    order = 58,
    
    key = "matryoshka_dolls",
    rarity = 1,
    cost = 6,   
    eternal_compat = true,
    pos = {x = 9, y = 8},
    atlas = "jokers",
    config = {
        mult = 4
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.mult
            },
            key = G.GAME.modifiers.entr_gfb and "j_entr_matryoshka_dolls_gfb"
        }
    end,
    calculate = function(self, card, context)
        if context.joker_main or context.forcetrigger then
            return {
                mult = not G.GAME.modifiers.entr_gfb and card.ability.mult or nil,
                xchips = G.GAME.modifiers.entr_gfb and card.ability.mult or nil
            }
        end
        if context.setting_blind then
            if G.GAME.joker_buffer + #G.jokers.cards < G.jokers.config.card_limit then
                G.E_MANAGER:add_event(Event{
                    func = function()
                        local ncard = SMODS.add_card{
                            key = "j_entr_matryoshka_dolls",
                            area = G.jokers
                        }
                        ncard.ability.mult = card.ability.mult - (G.GAME.modifiers.entr_gfb and 0.5 or 1)
                        G.GAME.joker_buffer = 0
                        return true
                    end
                })
                G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                return nil, true
            end
        end
    end,
    slib_credits = {
        idea = {"Corobo"}
    },
    attributes = {"generation", "mult", "joker"},
}

Entropy.Joker{
    order = 59,
    
    key = "menger_sponge",
    rarity = 1,
    cost = 6,   
    eternal_compat = true,
    pos = {x = 0, y = 9},
    atlas = "jokers",
    config = {
        chips = 10,
        chips_mod = 3,
        base_chips = 10
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.chips,
                card.ability.chips_mod
            },
            key = G.GAME.modifiers.entr_gfb and "j_entr_menger_sponge_gfb" or nil
        }
    end,
    calculate = function(self, card, context)
        if context.joker_main or context.forcetrigger then
            local chips = card.ability.chips
            return {
                chips = card.ability.chips
            }
        end
        if (context.end_of_round and not context.individual and not context.repetition) then
            if G.GAME.modifiers.entr_gfb then
                card.ability.chips = card.ability.chips * (math.sin(card.ability.chips) + 1)*card.ability.chips_mod
                return {
                    message = localize("k_upgrade_ex")
                }
            else
                if G.GAME.blind_on_deck == "Boss" then
                    card.ability.chips = card.ability.base_chips
                    return {
                        message = localize("k_reset")
                    }
                else    
                    SMODS.scale_card(card, {
                        ref_table = card.ability,
                        ref_value = "chips",
                        scalar_value = "chips_mod",
                        operation = "X"
                    })
                end
            end
        end
    end,
    attributes = {"scaling", "mult", "reset"},
}

Entropy.Joker{
    order = 60,
    
    key = "arbitration",
    rarity = 1,
    cost = 5,   
    eternal_compat = true,
    pos = {x = 1, y = 9},
    atlas = "jokers",
    config = {
        chips = 10,
        chips_mod = 3,
        base_chips = 10
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.c_judgement
        q[#q+1] = G.P_CENTERS.m_glass
    end,
    calculate = function(self, card, context)
        if context.remove_playing_cards or context.forcetrigger then
            local glasses = 0
            for k, v in ipairs(context.removed) do
                if v.shattered then
                    if G.GAME.consumeable_buffer + #G.consumeables.cards < G.consumeables.config.card_limit then
                        G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                        G.E_MANAGER:add_event(Event{
                            func = function()
                                SMODS.add_card{
                                    area = G.consumeables,
                                    key = "c_judgement"
                                }
                                G.GAME.consumeable_buffer = 0
                                return true
                            end
                        })
                    end
                end
            end
            return nil, true
        end
    end,
    attributes = {"generation", "enhancements", "tarot"},
}

Entropy.Joker{
    order = 60.5,
    
    key = "masterful_gambit",
    rarity = 1,
    cost = 4,   
    eternal_compat = true,
    pos = {x = 2, y = 9},
    atlas = "jokers",
    config = {
        dollars = 3
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    calculate = function(self, card, context)
        if (context.joker_main and #G.play.cards == 1) or context.forcetrigger then
            return {
                dollars = card.ability.dollars
            }
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.dollars
            }
        }
    end,
    attributes = {"hands", "economy"},
}

Entropy.Joker{
    order = 61,
    
    key = "fourty_benadryls",
    rarity = 1,
    cost = 5,   
    eternal_compat = true,
    pos = {x = 3, y = 9},
    atlas = "jokers",
    config = {
        chip_mod = 15
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    pixel_size = { h = 95 / 1.2 },
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    calculate = function(self, card, context)
        if not G.GAME.modifiers.entr_gfb then
            if context.joker_main or context.forcetrigger then
                return {
                    chips = card.ability.chip_mod * G.GAME.round_resets.ante
                }
            end
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.chip_mod,
                card.ability.chip_mod * G.GAME.round_resets.ante
            },
            key = G.GAME.modifiers.entr_gfb and "j_entr_fourty_benadryls_gfb" or nil
        }
    end,
    add_to_deck = function()
        if G.GAME.modifiers.entr_gfb then
            ease_ante(32 - G.GAME.round_resets.ante)
        end
    end,
    attributes = {"chips"},
}

Entropy.Joker{
    order = 62,
    
    key = "red_fourty",
    rarity = 1,
    cost = 6,   
    pos = {x = 4, y = 9},
    atlas = "jokers",
    config = {
        mult = 20,
        mult_mod = 2
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    pools = {["Food"] = true},
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.mult,
                card.ability.mult_mod
            }
        }
    end,
    calculate = function(self, card, context)
        if context.money_altered and context.from_shop and to_big(context.amount) < to_big(0) then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "mult", scalar_value = "mult_mod", operation = "-", no_message = true})
            if card.ability.mult <= 0 then
                SMODS.destroy_cards(card, true, nil, true)
                return {
                    message = localize("k_eaten_ex"),
                    colour = G.C.FILTER,
                }
            end
            if not msg or type(msg) == "string" then
                return {
                    message = msg or "-"..number_format(card.ability.mult_mod),
                    colour = G.C.RED,
                }
            end
        end
        if context.joker_main then
            return {
                mult = card.ability.mult
            }
        end
    end,
    attributes = {"mult", "scaling", "food"},
}

Entropy.Joker{
    order = 63,
    
    key = "promotion",
    rarity = 1,
    cost = 6,   
    eternal_compat = true,
    pos = {x = 5, y = 9},
    atlas = "jokers",
    config = {
        mult = 20,
        mult_mod = 2
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    calculate = function(self, card, context)
        if (context.end_of_round and not context.individual and not context.repetition) or context.forcetrigger then
            if G.GAME.blind_on_deck == "Boss" or context.forcetrigger then
                if G.GAME.consumeable_buffer + #G.consumeables.cards < G.consumeables.config.card_limit then
                    G.E_MANAGER:add_event(Event{
                        func = function()
                            SMODS.add_card{
                                set = "Booster",
                                area = G.consumeables,
                                key_append = "entr_promotion"
                            }
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    })
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                end
                return nil, true
            end
        end
    end,
    attributes = {"generation"},
}

Entropy.Joker{
    order = 64,
    
    key = "offbrand",
    rarity = 1,
    cost = 6,   
    eternal_compat = true,
    pos = {x = 7, y = 9},
    atlas = "jokers",
    config = {
        mult = 6,
        dollars = 6
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    pools = {["Food"] = true},
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.mult,
                card.ability.dollars
            }
        }
    end,
    calculate = function(self, card, context)
        if context.joker_main or context.forcetrigger then
            if context.forcetrigger then
                ease_dollars(card.ability.dollars)
            end
            return {
                mult = -card.ability.mult
            }
        end
    end,
    calc_dollar_bonus = function(self, card)
        return card.ability.dollars
    end,
    attributes = {"economy", "mult"},
}

Entropy.Joker{
    order = 65,
    
    key = "girldinner",
    rarity = 1,
    cost = 4,   
    eternal_compat = true,
    pos = {x = 8, y = 9},
    atlas = "jokers",
    config = {
        mult = 8,
        chips = 60
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    pools = {["Food"] = true},
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.mult,
                card.ability.chips
            }
        }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and context.other_card:get_id() == 12 and (not card.ability.used or card.ability.used == context.other_card) then
            card.ability.used = context.other_card
            return {
                mult = card.ability.mult,
                chips = card.ability.chips
            }
        end
        if (context.end_of_round and not context.individual and not context.repetition) then
            card.ability.used = nil
        end
    end,
    slib_credits = {
        idea = {
            "cassknows"
        }
    },
    attributes = {"mult", "chips", "rank", "queen"},
}

Entropy.Joker{
    order = 66,
    
    key = "recycling_bin",
    rarity = 1,
    cost = 5,   
    eternal_compat = true,
    pos = {x = 9, y = 9},
    atlas = "jokers",
    config = {
        mult = 0,
        mult_mod = 1
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.mult_mod,
                card.ability.mult,
            }
        }
    end,
    calculate = function(self, card, context)
        if context.discard then
            SMODS.scale_card(card, {
                ref_table = card.ability,
                ref_value = "mult",
                scalar_value = "mult_mod",
                message_key = "a_mult",
                message_colour = G.C.RED
            })
        end
        if context.joker_main or context.forcetrigger then
            return {
                mult = card.ability.mult,
            }
        end
        if (context.end_of_round and not context.individual and not context.repetition) then
            card.ability.mult = 0
            return {
                message = localize("k_reset")
            }
        end
    end,
    slib_credits = {
        idea = {"Youh !"}
    },
    attributes = {"mult", "discard", "reset"},
}

Entropy.Joker{
    order = 67,
    
    key = "gold_bar",
    rarity = 1,
    cost = 6,   
    eternal_compat = true,
    pos = {x = 0, y = 10},
    atlas = "jokers",
    config = {
        dollars = 8,
        dollars_mod = 1
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    pools = {["Food"] = true},
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.dollars,
                card.ability.dollars_mod,
            }
        }
    end,
    calc_dollar_bonus = function(self, card)
        local dollars = card.ability.dollars
        SMODS.scale_card(card, {
            ref_table = card.ability,
            ref_value = "dollars",
            scalar_value = "dollars_mod",
            operation = "-",
            scaling_message = {
                message = dollars == card.ability.dollars_mod and localize("k_eaten_ex") or "-"..number_format(card.ability.dollars_mod),
                colour = dollars >= card.ability.dollars_mod and G.C.RED or G.C.FILTER
            }
        })
        if to_big(card.ability.dollars) <= to_big(0) then
            SMODS.destroy_cards(card, true, nil, true)
        end
        return dollars
    end,
    attributes = {"economy", "food", "scaling"},
}

Entropy.Joker{
    order = 68,
    
    key = "scribbled_joker",
    rarity = 1,
    cost = 5,   
    eternal_compat = true,
    pos = {x = 1, y = 10},
    atlas = "jokers",
    config = {
        chips = 60
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.chips
            }
        }
    end,
    calculate = function(self, card, context)
        if context.joker_main or context.forcetrigger then
            local enhanced = 0
            for i, v in pairs(context.full_hand) do
                if SMODS.in_scoring(v, context.scoring_hand) and v.config.center.set == "Enhanced" then
                    enhanced = enhanced + 1
                end
            end
            if enhanced > 0 or context.forcetrigger then
                return {
                    chips = card.ability.chips
                }
            end
        end
    end,
    slib_credits = {
        idea = {"user324897"}
    },
    attributes = {"enhancements", "chips"},
}

Entropy.Joker{
    order = 68.5,
    
    key = "jokers_against_humanity",
    rarity = 1,
    cost = 5,   
    eternal_compat = true,
    pos = {x = 2, y = 10},
    atlas = "jokers",
    config = {
        chips = 15,
        mult = 2
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    demicoloncompat = true,
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        q[#q+1] = {set = "Other", key = "eternal"}
        return {
            vars = {
                card.ability.chips,
                card.ability.mult
            }
        }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            if not card.ability.used then
                context.other_card:add_sticker("eternal", true)
                context.other_card:juice_up()
                card.ability.used = true
            end
            if context.other_card.ability.eternal then
                return {
                    chips = card.ability.chips,
                    mult = card.ability.mult
                }
            end
        end
        if context.after then
            card.ability.used = nil
        end
    end,
    slib_credits = {
        idea = {"user324897"}
    },
    attributes = {"mult", "chips", "modify_card"},
}

Entropy.Joker{
    order = 69,
    
    key = "blind_collectible_pack",
    rarity = 1,
    cost = 6,
    pos = {x = 3, y = 10},
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    calculate = function(self, card, context)
        if context.selling_self or context.forcetrigger then
            if G.GAME.consumeable_buffer + #G.consumeables.cards < G.consumeables.config.card_limit then
                G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                G.E_MANAGER:add_event(Event{
                    func = function()
                        SMODS.add_card{
                            set = "CBlind",
                            area = G.consumeables,
                            --key_append = "entr_bcp",
                            key = G.GAME.modifiers.entr_gfb and "c_entr_bl_plant" or nil
                        }
                        G.GAME.consumeable_buffer = 0
                        return true
                    end
                })
            end
        end
    end,
    slib_credits = {
        idea = {"user324897"}
    },
    loc_vars = function()
        return {
            key = G.GAME.modifiers.entr_gfb and "j_entr_blind_collectible_pack_gfb" or nil
        }
    end,
    attributes = {"generation", "on_sell"},
}

Entropy.Joker{
    order = 70,
    
    key = "prayer_card",
    rarity = 1,
    cost = 6,   
    eternal_compat = true,
    pos = {x = 4, y = 10},
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    config = {
        amount = 100
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    calculate = function(self, card, context)
        if context.setting_blind or context.forcetrigger then
            card.gone = false
			G.GAME.blind.chips = G.GAME.blind.chips - card.ability.amount * G.GAME.round_resets.ante
			G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
			G.HUD_blind:recalculate()
            return nil, true
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.amount,
                card.ability.amount * G.GAME.round_resets.ante
            }
        }
    end,
    slib_credits = {
        idea = {"user324897"}
    },
    attributes = {"blindsize"},
}

Entropy.Joker{
    order = 71,
    
    key = "desert",
    rarity = 1,
    cost = 6,   
    eternal_compat = true,
    pos = {x = 5, y = 10},
    atlas = "jokers",
    demicoloncompat = true,
    blueprint_compat = true,
    config = {
        asc = 0,
        asc_mod = 0.05
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    calculate = function(self, card, context)
        if context.before and #G.play.cards == 1 then
            SMODS.scale_card(card, {
                ref_table = card.ability,
                ref_value = "asc",
                scalar_value = "asc_mod"
            })
        end
        if context.joker_main then
            return {
                plus_asc = card.ability.asc
            }
        end
    end,
    loc_vars = function(self, q, card)
        Entropy.ensure_ascpow_tutorial(q)
        return {
            vars = {
                card.ability.asc_mod,
                card.ability.asc
            }
        }
    end,
    attributes = {"scaling", "hands", "asc"},
}

Entropy.Joker{
    order = 72,
    
    key = "rugpull",
    rarity = 1,
    cost = 4,   
    eternal_compat = true,
    pos = {x = 6, y = 10},
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    config = {
        multiplier = 1.25
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {card.ability.multiplier}
        }
    end,
    attributes = {"economy", "scaling", "passive"},
}

Entropy.Joker{
    order = 73,
    
    key = "grape_juice",
    rarity = 1,
    cost = 6,   
    eternal_compat = true,
    pos = {x = 7, y = 10},
    atlas = "jokers",
    demicoloncompat = true,
    config = {
        left = 3,
        left_mod = 1
    },
    dependencies = {
        items = {
            "set_entr_actives",
        }
    },
    pools = {
        Food = true
    },
    loc_vars = function(self, q, card)
        return {
            vars = {card.ability.left, card.ability.left_mod}
        }
    end,
    can_use = function(self, card) return to_big(card.ability.left) > to_big(0) and #G.hand.cards > 0 end,
    use = function(self, card)
        card.ability.left = card.ability.left - 1
        local card = pseudorandom_element(G.hand.cards, pseudoseed("entr_grape_juice"))
        local enhancement = pseudorandom_element({"m_bonus", "m_wild", "m_mult"}, pseudoseed("entr_grape_juice"))
        Entropy.flip_then({card}, function(card) card:set_ability(G.P_CENTERS[enhancement]) end)
    end,
    calculate = function(self, card, context)
        if (context.end_of_round and not context.blueprint and not context.individual and G.GAME.blind_on_deck == "Boss" and not context.repetition) or context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", scaling_message = {message = "+"..number_format(card.ability.left_mod)}})
        end
    end,
    attributes = {"activated", "scaling", "modify_card", "enhancements"},
}

Entropy.Joker{
    order = 74,
    
    key = "petrichor",
    rarity = 1,
    cost = 5,   
    eternal_compat = true,
    pos = {x = 8, y = 10},  
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    config = {
        chips = 25
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {card.ability.chips}
        }
    end,
    calculate = function(self, card, context)
        if (context.individual and context.cardarea == "unscored") or context.forcetrigger then
            return {
                chips = card.ability.chips
            }
        end
    end,
    attributes = {"chips", "hands"},
}

Entropy.Joker{
    order = 75,
    
    key = "otherworldly_joker",
    rarity = 1,
    cost = 5,   
    eternal_compat = true,
    pos = {x = 9, y = 10},  
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    dependencies = {
        items = {
            "set_entr_inversions",
        }
    },
    calculate = function(self, card, context)
        if (context.skipping_booster) or context.forcetrigger then
            if G.GAME.consumeable_buffer + #G.consumeables.cards < G.consumeables.config.card_limit then
                G.E_MANAGER:add_event(Event{
                    func = function()
                        SMODS.add_card{
                            area = G.consumeables,
                            attributes = {"inverted_consumable"},
                            types = {"Consumeables"},
                            key_append = "entr_otherworldly"
                        }
                        G.GAME.consumeable_buffer = 0
                        return true
                    end
                })
                G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
            end
            return {
                message = localize({ type = "variable", key = "a_twisted", vars = { 1 } }),
                colour = G.C.RED
            }
        end
    end,
    attributes = {"inverted", "generation"},
}

Entropy.Joker{
    order = 76,
    
    key = "error",
    rarity = 1,
    cost = 4,   
    eternal_compat = true,
    pos = {x = 0, y = 11},  
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"passive"},
}

Entropy.Joker{
    order = 77,
    
    key = "thirteen_of_stars",
    rarity = 1,
    cost = 5,   
    eternal_compat = true,
    pos = {x = 1, y = 11},  
    atlas = "jokers",
    demicoloncompat = true,
    blueprint_compat = true,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(self, q, card) Entropy.ensure_ascpow_tutorial(q) end,
    calculate = function(self, card, context)
        if (context.joker_main) or context.forcetrigger then
            local text = G.FUNCS.get_poker_hand_info(G.play.cards)
            if text and G.GAME.hands[text] then
                return {
                    plus_asc = G.GAME.hands[text].level/4
                }
            end
        end
    end,
    attributes = {"asc", "hand_type"},
}

Entropy.Joker{
    order = 78,
    
    key = "diode",
    rarity = 1,
    cost = 6,
    eternal_compat = true,
    pos = {x = 2, y = 11},  
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    config = {
        mult = 6,
        chips = 40
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    calculate = function(self, card, context)
        if context.after then
            card.ability.blue = not card.ability.blue
            return {
                message = localize("k_switch_ex"),
                colour = G.C.dark_edition
            }
        end
        if (context.joker_main) or context.forcetrigger then
            return {
                chips = card.ability.blue and card.ability.chips or nil,
                mult = not card.ability.blue and card.ability.mult or nil
            }
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.blue and card.ability.chips or card.ability.mult
            },
            key = card.ability.blue and "j_entr_diode_blue" or "j_entr_diode_red"
        }
    end,
    attributes = {"mult", "chips"},
}

Entropy.Joker{
    order = 79,
    
    key = "prismatic_shard",
    rarity = 1,
    cost = 6,
    eternal_compat = true,
    pos = {x = 0, y = 0},
    soul_pos = {x = 0, y = 1},
    atlas = "prismatic_shard",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    config = {
        mult = 2,
        chips = 8,
        plus_asc = 0.15
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    calculate = function(self, card, context)
        if (context.individual and context.cardarea == G.play) or context.forcetrigger then
            local etype = pseudorandom_element({"mult", "chips", "plus_asc"}, pseudoseed("prismatic_shard"))
            return {
                [etype] = card.ability[etype]
            }
        end
    end,
    loc_vars = function(self, q, card)
        Entropy.ensure_ascpow_tutorial(q)
        return {
            vars = {
                card.ability.mult,
                card.ability.chips,
                card.ability.plus_asc
            }
        }
    end,
    attributes = {"chips", "mult", "asc"},
}

function Entropy.get_chameleon()
    local enhs = {}
    for i, v in pairs(G.P_CENTER_POOLS.Enhanced) do
        if not v.original_mod or v.demicoloncompat then
            if v.key ~= "m_wild" then
                enhs[#enhs+1] = v.key
            end
        end
    end
    return pseudorandom_element(enhs, pseudoseed("entr_chameleon_enh"))
end

Entropy.Joker{
    order = 80,
    
    key = "chameleon",
    rarity = 1,
    cost = 6,
    eternal_compat = true,
    pos = {x = 9, y = 11},
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    calculate = function(self, card, context)
        if context.joker_main then
            local rand = Entropy.get_chameleon()
            return Entropy.trigger_enhancement(rand)
        end
    end,
    slib_credits = {
        art = {"LFMoth"}
    },
    attributes = {"enhancements", "copying"},
}

Entropy.Joker{
    order = 81,
    
    key = "thanatophobia",
    rarity = 1,
    cost = 7,
    eternal_compat = true,
    pos = {x = 0, y = 12},
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    calculate = function(self, card, context)
        if context.joker_main or context.forcetrigger then
            if G.GAME.accumulated_sell_value then
                return {
                    mult = G.GAME.accumulated_sell_value
                }
            end
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                G.GAME.accumulated_sell_value or 0
            }
        }
    end,
    slib_credits = {
        art = {"LFMoth"}
    },
    attributes = {"sell_value", "mult"},
}

local start_dissolveref = Card.start_dissolve
function Card:start_dissolve(...)
    if self.config and self.config.center and self.config.center.set == "Joker" and G.jokers then
        G.GAME.accumulated_sell_value = (G.GAME.accumulated_sell_value or 0) + self.sell_cost / 2
    end
    return start_dissolveref(self, ...)
end

local destroy_cardsref = SMODS.destroy_cards
function SMODS.destroy_cards(c, ...)
    if c.config and c.config.center and c.config.center.set == "Joker" and G.jokers then
        G.GAME.accumulated_sell_value = (G.GAME.accumulated_sell_value or 0) + c.sell_cost / 2
    end
    return destroy_cardsref(c, ...)
end

Entropy.Joker{
    order = 82,
    
    key = "redkey",
    rarity = 2,
    cost = 8,
    eternal_compat = true,
    pos = {x = 3, y = 12},
    atlas = "jokers",
    demicoloncompat = true,
    config = {
        left = 1,
        left_mod = 1
    },
    dependencies = {
        items = {
            "set_entr_actives",
            "bl_entr_red"
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {card.ability.left, card.ability.left_mod}
        }
    end,
    can_use = function(self, card) return to_big(card.ability.left) > to_big(0) and not G.GAME.round_resets.red_room and G.blind_select end,
    use = function(self, card)
        card.ability.left = card.ability.left - 1
        G.GAME.round_resets.red_room = true
        G.GAME.round_resets.blind_states['Red'] = "Select"
        if G.blind_select then        
            G.blind_select:remove()
            G.blind_prompt_box:remove()
            G.STATE_COMPLETE = false
        end
    end,
    calculate = function(self, card, context)
        if (context.end_of_round and not context.blueprint and not context.individual and G.GAME.blind_on_deck == "Boss" and not context.repetition) or context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", scaling_message = {message = "+"..number_format(card.ability.left_mod)}})
        end
    end,
    attributes = {"activated", "scaling"},
}

Entropy.Joker{
    order = 83,
    
    key = "polaroid",
    rarity = 3,
    cost = 10,
    eternal_compat = true,
    pos = {x = 3, y = 11},
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    config = {
        left = 1,
        left_mod = 1,
        immutable = {
            target = -1
        }
    },
    dependencies = {
        items = {
            "set_entr_actives",
        }
    },
    can_use = function(self, card) 
        if G.GAME.modifiers.entr_gfb then
            return G.GAME.joker_buffer + #G.jokers.cards < G.jokers.config.card_limit and card.ability.left > 0
        else
            return #Entropy.get_highlighted_cards({G.jokers}, card, 1, 1) > 0 and card.ability.left > 0
        end
    end,
    use = function(self, card)
        card.ability.left = card.ability.left - 1
        if G.GAME.modifiers.entr_gfb then
            SMODS.add_card { key = "j_photograph" }
        else
            local cards = Entropy.get_highlighted_cards({G.jokers}, card, 1, 1)
            for i, v in pairs(cards) do
                card.ability.immutable.target = v.sort_id
            end
        end
        card:juice_up()
        play_sound("entr_polaroid")
    end,
    loc_vars = function(self, q, card)
        if G.GAME.modifiers.entr_gfb then
            q[#q+1] = G.P_CENTERS.j_photograph
            return {
                vars = {
                    card.ability.left,
                    card.ability.left_mod
                },
                key = card.edition and card.edition.negative and "j_entr_polaroid_gfbn" or "j_entr_polaroid_gfb"
            }
        end
        local other_joker = G.jokers and Entropy.get_by_sortid(card.ability.immutable.target)
        local compatible = other_joker and other_joker ~= card and other_joker.config.center.blueprint_compat
        local main_end = {
            {
                n = G.UIT.C,
                config = { align = "bm", minh = 0.4 },
                nodes = {
                    {
                        n = G.UIT.C,
                        config = {
                            ref_table = card,
                            align = "m",
                            colour = compatible and mix_colours(G.C.GREEN, G.C.JOKER_GREY, 0.8)
                                or mix_colours(G.C.RED, G.C.JOKER_GREY, 0.8),
                            r = 0.05,
                            padding = 0.06,
                        },
                        nodes = {
                            {
                                n = G.UIT.T,
                                config = {
                                    text = " "
                                        .. (compatible and localize { type = 'name_text', set = other_joker.config.center.set, key = other_joker.config.center.key } or localize("k_incompatible"))
                                        .. " ",
                                    colour = G.C.UI.TEXT_LIGHT,
                                    scale = 0.32 * 0.8,
                                },
                            },
                        },
                    },
                },
            },
        }
        return {
            vars = {
                card.ability.left,
                card.ability.left_mod
            },
            main_end = main_end,
        }
    end,
    calculate = function(self, card, context)
        if (context.end_of_round and not context.blueprint and not context.individual and not context.repetition) or context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", scaling_message = {message = "+"..number_format(card.ability.left_mod)}})
        end
        if (card.ability.immutable.target or -1) > -1 then 
            local target = Entropy.get_by_sortid(card.ability.immutable.target)
            if target then
                local ret = SMODS.blueprint_effect(card, target, context)
                return ret
            end
        end
    end,
    attributes = {"activated", "scaling", "copying", "joker"},
}

function Entropy.overclock(v, card)
    if v.config.center.use or v.ability.consumeable then
        if v.ability.consumeable then
            v.ability.cry_multiuse = v.ability.cry_multiuse or 1
            SMODS.scale_card(v, {
                ref_table = v.ability, 
                ref_value = "cry_multiuse", 
                scalar_table = card.ability,
                scalar_value = "uses_mod", 
                scaling_message = {message = "+"..number_format(card.ability.uses_mod)}
            })
        elseif v.ability.left and v.ability.left_mod then
            SMODS.scale_card(v, {
                ref_table = v.ability, 
                ref_value = "left", 
                scalar_table = card.ability,
                scalar_value = "uses_mod", 
                scaling_message = {message = "+"..number_format(card.ability.uses_mod)}
            })
        end
    end
end

Entropy.Joker{
    order = 84,
    
    key = "car_battery",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 4, y = 11},
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    config = {
        uses_mod = 1
    },
    dependencies = {
        items = {
            "set_entr_actives",
        }
    },
    calculate = function(self, card, context)
        if (context.end_of_round and not context.individual and G.GAME.blind_on_deck == "Boss" and not context.repetition) or context.forcetrigger then
            for i, v in pairs(G.jokers.cards) do
                Entropy.overclock(v, card)
            end
            for i, v in pairs(G.consumeables.cards) do
                Entropy.overclock(v, card)
            end
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.uses_mod
            }
        }
    end,
    attributes = {"scaling", "joker"},
}

Entropy.Joker{
    order = 85,
    
    key = "chair",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 5, y = 11},
    atlas = "jokers",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    config = {
        uses_mod = 1
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
            "e_entr_freaky"
        }
    },
    calculate = function(self, card, context)
        if (context.before and context.scoring_name == "Three of a Kind") then
            if #context.scoring_hand > 2 then
                context.scoring_hand[3]:set_edition("e_entr_freaky")
            end
        end
    end,
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.e_entr_freaky
    end,
    attributes = {"modify_card", "hand_type"},
}

Entropy.Joker{
    order = 86,
    
    key = "captcha",
    rarity = 2,
    cost = 8,
    eternal_compat = true,
    pos = {x = 6, y = 11},
    atlas = "jokers",
    demicoloncompat = true,
    config = {
        left = 1,
        left_mod = 1
    },
    dependencies = {
        items = {
            "set_entr_actives",
        }
    },
    can_use = function(self, card) return G.hand and #G.hand.cards > 0 and card.ability.left > 0 end,
    use = function(self, card)
        card.ability.left = card.ability.left - 1
        local cards = {}
        for i, v in pairs(G.hand.cards) do
            if v ~= card then cards[#cards+1] = v end 
        end
        pseudoshuffle(cards, pseudoseed("entr_captcha"))
        Entropy.flip_then({cards[1]}, function(c)
            c:set_ability(G.P_CENTERS[SMODS.poll_object({set = Entropy.get_random_set()})])
        end)
        card:juice_up()
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.left,
                card.ability.left_mod
            },
        }
    end,
    calculate = function(self, card, context)
        if (context.end_of_round and not context.blueprint and not context.individual and not context.repetition) or context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", scaling_message = {message = "+"..number_format(card.ability.left_mod)}})
        end
    end,
    attributes = {"activated", "ccd", "scaling", "modify_card"},
}

Entropy.Joker{
    order = 87,
    
    key = "deck_enlargement_pills",
    rarity = 3,
    cost = 10,
    pos = {x = 2, y = 12},
    atlas = "jokers",
    demicoloncompat = true,
    config = {
        rounds = 2,
        max_rounds = 2
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.max_rounds,
                card.ability.rounds
            },
            key = G.GAME.modifiers.entr_gfb and "j_entr_deck_enlargement_pills_gfb"
        }
    end,
    needs_use_button = function()
        return G.GAME.modifiers.entr_gfb
    end,
    can_use = function()
        return true
    end,
    use = function(self, card)
        for i, v in pairs(SMODS.shallow_copy(G.hand.cards)) do
            G.playing_card = (G.playing_card and G.playing_card + 1) or 1
            local _card = copy_card(v, nil, nil, G.playing_card)
            _card:add_to_deck()
            G.deck.config.card_limit = G.deck.config.card_limit + 1
            table.insert(G.playing_cards, _card)
            G.hand:emplace(_card)
            _card.states.visible = nil

            G.E_MANAGER:add_event(Event({
                func = function()
                    _card:start_materialize()
                    return true
                end
            })) 
        end
        for i, v in pairs(G.deck.cards) do
            G.playing_card = (G.playing_card and G.playing_card + 1) or 1
            local _card = copy_card(v, nil, nil, G.playing_card)
            _card:add_to_deck()
            G.deck.config.card_limit = G.deck.config.card_limit + 1
            table.insert(G.playing_cards, _card)
            G.hand:emplace(_card)
            _card.states.visible = nil

            G.E_MANAGER:add_event(Event({
                func = function()
                    _card:start_materialize()
                    return true
                end
            })) 
        end
        for i, v in pairs(G.discard.cards) do
            G.playing_card = (G.playing_card and G.playing_card + 1) or 1
            local _card = copy_card(v, nil, nil, G.playing_card)
            _card:add_to_deck()
            G.deck.config.card_limit = G.deck.config.card_limit + 1
            table.insert(G.playing_cards, _card)
            G.hand:emplace(_card)
            _card.states.visible = nil

            G.E_MANAGER:add_event(Event({
                func = function()
                    _card:start_materialize()
                    return true
                end
            })) 
        end
        SMODS.calculate_effect({message = "Bad Luck.", colour = G.C.RED, card = card})
        G.E_MANAGER:add_event(Event{
            func = function()
                SMODS.destroy_cards(card)
                return true
            end
        })
    end,
    calculate = function(self, card, context)
        if G.GAME.modifiers.entr_gfb then return end
        if (context.end_of_round and not context.blueprint and not context.individual and not context.repetition) or context.forcetrigger then
            card.ability.rounds = card.ability.rounds - 1
            if to_big(card.ability.rounds) <= to_big(0) then
                card.ability.rounds = 0
                if not card.ability.juiced then
                    local eval = function(card) return true end
                    juice_card_until(card, eval, true)
                    card.ability.juiced = true
                end
            end
            if not context.forcetrigger then
                return {
                    message = to_big(card.ability.rounds) > to_big(0) and number_format(card.ability.max_rounds - card.ability.rounds).."/"..number_format(card.ability.max_rounds)
                    or localize("k_active_ex")
                }
            end
        end
        if (context.selling_self and to_big(card.ability.rounds) <= to_big(0) and not context.blueprint) or context.forcetrigger then
            G.E_MANAGER:add_event(Event{
                trigger = "after",
                func = function()
            
                    local area
                    if G.STATE == G.STATES.HAND_PLAYED then
                        if not G.redeemed_vouchers_during_hand then
                            G.redeemed_vouchers_during_hand =
                                CardArea(G.play.T.x, G.play.T.y, G.play.T.w, G.play.T.h, { type = "play", card_limit = 5 })
                        end
                        area = G.redeemed_vouchers_during_hand
                    else
                        area = G.play
                    end
                    G.GAME.entr_parakmi_bypass = true
                    local card = create_card("RedeemableBacks", G.play, nil, nil, nil, nil, nil, "entr_large_deck")
                    G.GAME.entr_parakmi_bypass = nil
                    if card.config.center.key == "j_joker" then
                        card:set_ability(G.P_CENTERS.b_red)
                    end
                    card:add_to_deck()
                    area:emplace(card)
                    card.cost = 0
                    card:redeem_deck()
                    return true
                end
            })
            return nil, true
        end
    end,
    attributes = {"on_sell"},
}

Entropy.Joker{
    order = 88,
    
    key = "photocopy",
    rarity = 2,
    cost = 7,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 8, y = 11},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"suit", "rank"},
}

function Entropy.most_common_card()
    local ranks = {}
    local suits = {}
    for i, v in pairs(G.playing_cards) do
        ranks[v.base.value] = (ranks[v.base.value] or 0) + 1
        suits[v.base.suit] = (suits[v.base.suit] or 0) + 1
    end
    local r = {}
    local s = {}
    for i, v in pairs(ranks) do r[#r+1] = {rank = i, num = v} end
    for i, v in pairs(suits) do s[#s+1] = {suit = i, num = v} end
    table.sort(r, function(a, b) return a.num > b.num end)
    table.sort(s, function(a, b) return a.num > b.num end)
    return {
        id = r[1].rank,
        suit = s[1].suit
    }
end

SMODS.Booster:take_ownership_by_kind("Standard", {
    create_card = function(self, card, i)
        local key
        if pseudorandom("entr_rare_standard") < 0.003 or Entropy.has_rune("rune_entr_oss") then
            if Entropy.has_rune("rune_entr_oss") then 
                Entropy.has_rune("rune_entr_oss").triggered = true 
            end
            calculate_runes({generate_rare_consumable = true})
            key = "m_entr_ethereal"
        end
        card = create_card((pseudorandom(pseudoseed('stdset'..G.GAME.round_resets.ante)) > 0.6) and "Enhanced" or "Base", G.pack_cards, nil, nil, nil, true, key, 'sta')
        if key then
            card:set_ability(G.P_CENTERS[key])
        end
        local edition_rate = 2
        local edition = poll_edition('standard_edition'..G.GAME.round_resets.ante, edition_rate, true)
        card:set_edition(edition)
        card:set_seal(SMODS.poll_seal({mod = 10}), true, true)
        if next(SMODS.find_card("j_entr_photocopy")) and i == 1 then
            local most_common = Entropy.most_common_card()
            SMODS.change_base(card, most_common.suit, most_common.id)
        end
        return card
    end
}, true)

Entropy.Joker{
    order = 89,
    
    key = "enlightenment",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 1, y = 12},
    atlas = "jokers",
    slib_credits = {
        art = {"LFMoth"}
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"tarot", "fraud", "inverted"},
}

Entropy.Joker{
    order = 90,
    
    key = "black_rose_green_sun",
    pools = { ["Music"] = true },
    rarity = 1,
    cost = 5,
    eternal_compat = true,
    perishable_compat = true,
    blueprint_compat = true,
    pos = {x = 6, y = 12},
    atlas = "jokers",
    config = {
        asc_pow = 0.05
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    demicoloncompat = true,
    calculate = function(self, card, context)
        if (context.individual and context.cardarea == G.hand and (context.other_card:is_suit("Spades") or context.other_card:is_suit("Clubs")) and not context.end_of_round) or context.forcetrigger then
            return {
                plus_asc = card.ability.asc_pow
            }
        end
    end,
    loc_vars = function(self, q, card)
        Entropy.ensure_ascpow_tutorial(q)
        return {
            vars = {
                card.ability.asc_pow
            }
        }
    end,
    attributes = {"asc", "suit", "spades", "clubs"},
}


Entropy.Joker{
    order = 91,
    
    key = "jack_off",
    rarity = 1,
    cost = 7,
    eternal_compat = true,
    perishable_compat = true,
    blueprint_compat = true,
    pos = {x = 6, y = 13},
    atlas = "jokers",
    demicoloncompat = true,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    calculate = function(self, card, context)
        if (context.individual and context.cardarea == G.play and (context.other_card:get_id() == SMODS.Ranks.Jack.id)) or context.forcetrigger then
            local any_selected = nil
            local _cards = {}
            for _, playing_card in ipairs(G.hand.cards) do
                if not playing_card.highlighted then
                    _cards[#_cards + 1] = playing_card
                end
            end
            if G.hand.cards[1] then
                local selected_card, card_index = pseudorandom_element(_cards, 'jacking_off')
                if selected_card then
                    G.hand:add_to_highlighted(selected_card, true)
                    table.remove(_cards, card_index)
                    any_selected = true
                    play_sound('card1', 1)
                end
            end
            if any_selected then G.FUNCS.discard_cards_from_highlighted(nil, true) end
        end
    end,
    slib_credits = {
        idea = {"cassknows"},
        art = {"LFMoth"}
    },
    attributes = {"rank", "jack", "discard"},
}

Entropy.Joker{
    order = 92,
    
    key = "fast_food",
    rarity = 2,
    cost = 7,
    eternal_compat = true,
    perishable_compat = true,
    blueprint_compat = true,
    pos = {x = 8, y = 14},
    atlas = "jokers",
    loc_vars = function(self, q, card)
        q[#q+1] = {set = "Other", key = "perishable", vars = {5, 5}}
    end,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.setting_blind or context.forcetrigger then
            if G.GAME.joker_buffer + #G.jokers.cards < G.jokers.config.card_limit then
                G.E_MANAGER:add_event(Event{
                    func = function()
                        local ncard = SMODS.add_card{
                            set = "Food",
                            area = G.jokers
                        }
                        ncard:set_perishable(true)
                        G.GAME.joker_buffer = 0
                        return true
                    end
                })
                G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                return nil, true
            end
        end
    end,
    attributes = {"food", "generation"},
}

Entropy.Joker{
    order = 93,
    
    key = "antipattern",
    rarity = 2,
    cost = 7,
    eternal_compat = true,
    blueprint_compat = true,
    pos = {x = 4, y = 12},
    atlas = "jokers",
    loc_vars = function(self, q, card)
        local hands_after_last_played = {}
        local hands = {}
        for i = 1, 13 do hands_after_last_played[i] = "" end
        local last_played = card.ability.last_hand
        for _,hand_pair in ipairs(card.ability.hand_pairs) do
            -- hand_pair[1] is last-played, hand_pair[2] is currently-played
            if hand_pair[1] == last_played then
                hands[#hands+1] = localize(hand_pair[2], "poker_hands")
            end
        end
        for i, v in pairs(hands) do hands_after_last_played[i+1] = v end
        if card.ability.last_hand ~= "" then
            hands_after_last_played[1] = localize(card.ability.last_hand, "poker_hands")
            q[#q+1] = {set = "Other", key = "antipattern_pair", vars = hands_after_last_played}
        end
        return {
            vars = {
                card.ability.xchips_mod,
                card.ability.xchips
            }
        }
    end,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        hand_pairs = {

        },
        last_hand = "",
        xchips = 1,
        xchips_mod = 0.1
    },
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.joker_main or context.forcetrigger then
            if card.ability.last_hand ~= "" then
                local pair = {card.ability.last_hand, context.scoring_name}
                local scale = true
                for i, v in pairs(card.ability.hand_pairs) do
                    if v[1] == pair[1] and v[2] == pair[2] then scale = false; break end
                end
                if scale then
                    SMODS.scale_card(card, {
                        ref_table = card.ability,
                        ref_value = "xchips",
                        scalar_value = "xchips_mod"
                    })
                    card.ability.hand_pairs[#card.ability.hand_pairs+1] = pair
                end
            end
            card.ability.last_hand = context.scoring_name
            return {
                xchips = card.ability.xchips
            }
        end
    end,
    slib_credits = {
        idea = {"cassknows"}
    },
    attributes = {"hand_type", "xchips", "scaling"},
}

Entropy.Joker{
    order = 94,
    
    key = "spiral_of_ants",
    rarity = 1,
    cost = 5,
    eternal_compat = true,
    perishable_compat = true,
    blueprint_compat = true,
    pos = {x = 5, y = 12},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.chips_mod,
                card.ability.chips
            }
        }
    end,
    pools = {Music = true},
    config = {
        last_card = 9999,
        chips = 0,
        chips_mod = 50
    },
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.joker_main or context.forcetrigger then
            if #G.play.cards < card.ability.last_card then
                SMODS.scale_card(card, {
                    ref_table = card.ability,
                    ref_value = "chips",
                    scalar_value = "chips_mod"
                })
                card.ability.last_card = #G.play.cards
            else
                card.ability.last_card = 9999
                card.ability.chips = 0
                card_eval_status_text(
                    card,
                    "extra",
                    nil,
                    nil,
                    nil,
                    { message = localize("k_reset") }
                )
            end
            return {
                chips = card.ability.chips
            }
        end
    end,
    slib_credits = {
        idea = {"cassknows"}
    },
    attributes = {"hands", "scaling", "chips", "reset"},
}

Entropy.Joker{
    order = 95,
    
    key = "fork_bomb",
    rarity = 1,
    cost = 2,
    eternal_compat = true,
    perishable_compat = true,
    blueprint_compat = true,
    pos = {x = 7, y = 12},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.setting_blind or context.forcetrigger then
            if (#SMODS.find_card("j_entr_fork_bomb") + (G.GAME.fork_bomb_buffer or 0) < 16) or G.GAME.modifiers.entr_gfb then
                G.GAME.fork_bomb_buffer = (G.GAME.fork_bomb_buffer or 0) + 1
                G.E_MANAGER:add_event(Event{
                    func = function()
                        local card2 = copy_card(card)
                        card.area:emplace(card2)
                        card2:add_to_deck()
                        G.GAME.fork_bomb_buffer = 0
                        return true
                    end
                })
                return {
                    message = ":(){ :|: & };:"
                }
            end
        end
    end,
    slib_credits = {
        idea = {"cassknows"}
    },
    loc_vars = function()
        return {
            key = G.GAME.modifiers.entr_gfb and "j_entr_fork_bomb_gfb" or nil
        }
    end,
    attributes = {"generation", "joker"},
}

Entropy.Joker{
    order = 96,
    
    key = "solar_panel",
    rarity = 1,
    cost = 6,
    eternal_compat = true,
    perishable_compat = true,
    blueprint_compat = true,
    pos = {x = 8, y = 12},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        money = 4
    },
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.e_entr_sunny
        q[#q+1] = G.P_CENTERS.m_entr_radiant
        return {
            vars = {
                card.ability.money
            }
        }
    end,
    demicoloncompat = true,
    calculate = function(self, card, context)
        if (context.discard and context.other_card:is_sunny()) or context.forcetrigger then
            return {
                dollars = card.ability.money
            }
        end
    end,
    in_pool = function()
        for i, v in pairs(G.playing_cards) do
            if v.edition and v.edition.key == "entr_sunny" or v.config.center.key == "m_radiant" then return true end
        end
    end,
    attributes = {"economy", "discard"},
}

Entropy.Joker{
    order = 97,
    
    key = "kintsugi",
    rarity = 1,
    cost = 6,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 0, y = 13},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
            "m_entr_ceramic"
        }
    },
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.m_entr_ceramic
        q[#q+1] = G.P_CENTERS.m_gold 
    end,
    in_pool = function()
        local any_ceramic
        for i, v in pairs(G.playing_cards) do
            if v.config.center.key == "m_entr_ceramic" then
                return true
            end
        end
    end,
    attributes = {"generation", "enhancements"},
}

Entropy.Joker{
    order = 98,
    
    key = "blooming_crimson",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 0, y = 2},
    soul_pos = {x = 1, y = 1},
    atlas = "prismatic_shard",
    demicoloncompat = true,
    perishable_compat = true,
    blueprint_compat = true,
    config = {
        xmult = 1.15,
        xchips = 1.15,
        asc = 1.05
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
            "j_entr_prismatic_shard"
        }
    },
    calculate = function(self, card, context)
        if (context.individual and context.cardarea == G.play) or context.forcetrigger then
            local etype = pseudorandom_element({"xmult", "xchips", "asc"}, pseudoseed("blooming_crimson"))
            return {
                [etype] = card.ability[etype]
            }
        end
    end,
    loc_vars = function(self, q, card)
        Entropy.ensure_ascpow_tutorial(q)
        return {
            vars = {
                card.ability.xmult,
                card.ability.xchips,
                card.ability.asc
            }
        }
    end,
    in_pool = function()
        return G.GAME.pool_flags.prismatic_shard_gone
    end,
    attributes = {"xmult", "xchips", "xasc"},
}

Entropy.Joker{
    order = 99,
    
    key = "overpump",
    rarity = 2,
    cost = 8,
    eternal_compat = true,
    pos = {x = 1, y = 14},
    atlas = "jokers",
    demicoloncompat = true,
    blueprint_compat = true,
    config = {
        xmult = 0,
        xmult_mod = 1.5,
        played = {},
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    calculate = function(self, card, context)
        if context.joker_main or context.forcetrigger then
            if not card.ability.played[context.scoring_name] then
                SMODS.scale_card(card, {
                    ref_table = card.ability,
                    ref_value = "xmult",
                    scalar_value = "xmult_mod"    
                })
                card.ability.played[context.scoring_name] = true
            end
            if context.forcetrigger or G.GAME.current_round.hands_left <= 0 then
                return {
                    xmult = card.ability.xmult
                }
            end
        end
        if context.end_of_round and not context.individual and not context.blueprint and not context.repetition then  
            card.ability.played = {}
            card.ability.xmult = 0
            return {
                message = localize("k_reset")
            }
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.xmult,
                card.ability.xmult_mod
            }
        }
    end,
    slib_credits = {
        idea = {"cassknows"}
    },
    attributes = {"xmult", "scaling", "hand_type", "reset"},
}

Entropy.Joker{
    order = 100,
    
    key = "shadow_crystal",
    rarity = 2,
    cost = 7,
    eternal_compat = true,
    pos = {x = 1, y = 13},
    atlas = "jokers",
    perishable_compat = true,
    config = {
        extra = {
            odds = 2
        }
    },
    dependencies = {
        items = {
            "set_entr_inversions",
        }
    },
    loc_vars = function(self, q, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds)
        return {
            vars = {
                numerator,
                denominator
            }
        }
    end,
    attributes = {"inverted", "chance"},
}

Entropy.Joker{
    order = 101,
    
    key = "miracle_berry",
    rarity = 2,
    cost = 7,
    pos = {x = 2, y = 13},
    atlas = "jokers",
    pools = {
        Food = true
    },
    perishable_compat = true,
    blueprint_compat = true,
    config = {
        uses = 4
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.uses
            }
        }
    end,
    calculate = function(self, card, context)
        if context.get_consumable_type and not card.getting_sliced and not context.hidden and context.set ~= "Spectral" and context.set ~= "Omen" then
            local pool = G.P_CENTER_POOLS[context.set]
            local inverted = pool and pool[1] and Entropy.is_inverted(pool[1])
            if G.GAME.modifiers.entr_twisted then inverted = not inverted end
            SMODS.scale_card(card, {
                ref_table = card.ability,
                ref_value = "uses",
                scalar_table = {mod = 1},
                scalar_value = "mod",
                operation = "-",
                scaling_message = {
                    message = localize("k_downgrade_ex"),
                    colour = G.C.RED
                }
            })
            if card.ability.uses <= 0 then
                SMODS.destroy_cards(card, true, nil, true)
                card.getting_sliced = true
            end
            return {
                set = inverted and "Omen" or "Spectral"
            }
        end
    end,
    attributes = {"spectral"},
}

Entropy.Joker{
    order = 102,
    
    key = "meridian",
    rarity = 1,
    cost = 5,
    eternal_compat = true,
    pos = {x = 3, y = 13},
    atlas = "jokers",
    perishable_compat = true,
    blueprint_compat = true,
    config = {
        multiplier = 5
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(self, q, card)
        local index = Entropy.in_table(card.area.cards, card)
        return {
            vars = {
                card.ability.multiplier * index
            }
        }
    end,
    calculate = function(self, card, context)
        if context.joker_main or context.forcetrigger then
            local index = Entropy.in_table(card.area.cards, card)
            return {
                mult = card.ability.multiplier * index
            }
        end
    end,
    attributes = {"mult", "joker_slot"},
}

Entropy.Joker{
    order = 103,
    
    key = "mango",
    rarity = 2,
    cost = 7,
    pos = {x = 4, y = 13},
    atlas = "jokers",
    pools = {
        Food = true
    },
    perishable_compat = true,
    blueprint_compat = true,
    config = {
        hands_left = 5
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.hands_left
            }
        }
    end,
    calculate = function(self, card, context)
        if context.before and not card.getting_sliced then
            local card2 = G.play.cards[1]
            if card2 then
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                local _card = copy_card(card2, nil, nil, G.playing_card)
                _card:add_to_deck()
                G.deck.config.card_limit = G.deck.config.card_limit + 1
                table.insert(G.playing_cards, _card)
                G.hand:emplace(_card)
                _card.states.visible = nil

                G.E_MANAGER:add_event(Event({
                    func = function()
                        _card:start_materialize()
                        return true
                    end
                })) 
                card.ability.hands_left = card.ability.hands_left - 1
                if to_big(card.ability.hands_left) <= to_big(0) then
                    SMODS.destroy_cards(card, true, nil, true)
                    card.getting_sliced = true
                end
                return {
                    message = card.getting_sliced and localize('k_eaten_ex') or localize("k_copied_ex"),
                    playing_cards_created = {_card}
                }
            end
        end
    end,
    attributes = {"generation", "food", "scaling"},
}

Entropy.Joker{
    order = 104,
    
    key = "kitchenjokers",
    rarity = 2,
    cost = 5,
    eternal_compat = true,
    pos = {x = 5, y = 13},
    atlas = "jokers",
    config = {
        off_perc = 0.25,
    },
    perishable_compat = true,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.e_entr_lowres
        return {
            vars = {
                card.ability.off_perc,
            }
        }
    end,
    slib_credits = {
        idea = {"cassknows", "user324897"}
    },
    attributes = {"passive", "food", "modify_card"},
}

Entropy.Joker{
    order = 105,
    
    key = "hash_miner",
    rarity = 2,
    cost = 7,
    eternal_compat = true,
    pos = {x = 9, y = 13},
    atlas = "jokers",
    config = {
        destroy_odds = 2,
        revive_odds = 10,
        per_corrupted = 2,
        extra_value = 0
    },
    perishable_compat = true,
    blueprint_compat = true,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(self, q, card)
        local corrupted = 0
        for i, v in pairs(G.GAME.badarg or {}) do
            corrupted = corrupted + 1
        end
        local n, d = SMODS.get_probability_vars(card, 1, card.ability.destroy_odds, "hash_miner")
        local n2, d2 = SMODS.get_probability_vars(card, 1, card.ability.revive_odds, "hash_miner")
        return {
            vars = {
                n, d,
                n2, d2,
                card.ability.per_corrupted,
            }
        }
    end,
    calculate = function(self, card, context)
        if context.after then
            if SMODS.pseudorandom_probability(card, 'hash_miner', 1, card.ability.destroy_odds) then
                if not G.GAME.badarg then G.GAME.badarg = {} end
                G.GAME.badarg[context.scoring_name] = true
                card_eval_status_text(
					card,
					"extra",
					nil,
					nil,
					nil,
					{ message = localize("k_corrupted_ex"), colour = G.C.RED }
				)
            end
            for i, v in pairs(G.GAME.badarg or {}) do
                if SMODS.pseudorandom_probability(card, 'hash_miner', 1, card.ability.revive_odds) then
                    G.GAME.badarg[i] = nil
                    card_eval_status_text(
                        card,
                        "extra",
                        nil,
                        nil,
                        nil,
                        { message = localize("k_recovered_ex"), colour = G.C.RED }
                    )
                end
            end
        end
        if context.end_of_round and not context.individual and not context.blueprint and not context.repetition then     
            local corrupted = 0
            for i, v in pairs(G.GAME.badarg or {}) do
                corrupted = corrupted + 1
            end
            SMODS.scale_card(card, {
                ref_table = card.ability,
                ref_value = "extra_value",
                scalar_value = "per_corrupted",
                operation = function(ref_table, ref_value, initial, change)
                    ref_table[ref_value] = initial + (corrupted)*change
                end,
                scaling_message = {
                    message = localize('k_val_up'),
                    colour = G.C.MONEY
                }
            })
            card:set_cost()
        end
    end,
    slib_credits = {
        idea = {"cassknows"},
        art = {"candycanearter"}
    },
    attributes = {"hand_type", "econ"},
}

Entropy.Joker{
    order = 107,
    
    key = "bell_curve",
    rarity = 1,
    cost = 6,
    eternal_compat = true,
    pos = {x = 7, y = 13},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play then
            local index = 0
            for i, v in pairs(G.play.cards) do
                if v == context.other_card then index = i; break end
            end
            if index ~= 1 and index ~= #G.play.cards then
                return {
                    repetitions = 1
                }
            end
        end
    end,
    attributes = {"retrigger", "hands"},
}

Entropy.Joker{
    order = 108,
    
    key = "pineapple",
    rarity = 2,
    cost = 7,
    pos = {x = 0, y = 15},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    config = {
        rounds = 5
    },
    pools = {Food = true},
    perishable_compat = true,
    blueprint_compat = true,
    demicoloncompat = true,
    calculate = function(self, card, context)
        if (context.end_of_round and not context.individual and not context.blueprint and not context.repetition) or context.forcetrigger then
            local rcard = pseudorandom_element(G.playing_cards, "entr_pineapple")          
            rcard.ability.perma_repetitions = rcard.ability.perma_repetitions + 1
            if not context.forcetrigger then
                if card.ability.rounds - 1 <= 0 then
                    SMODS.destroy_cards(card, true, nil, true)
                    return {
                        message = localize('k_eaten_ex'),
                        colour = G.C.FILTER
                    }
                else
                    card.ability.rounds = card.ability.rounds - 1
                end
            end
            return {
                message = localize("k_upgrade_ex")
            }
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.rounds
            }
        }
    end,
    attributes = {"scaling", "food", "retrigger", "modify_card"},
}

Entropy.Joker{
    order = 109,
    
    key = "rubber_ball",
    rarity = 1,
    cost = 4,
    eternal_compat = true,
    pos = {x = 6, y = 14},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers"
        }
    },
    config = {
        odds = 3,
    },
    perishable_compat = true,
    loc_vars = function(self, q, card)
        local n, d = SMODS.get_probability_vars(card, 1, card.ability.odds, "rubber_ball")
        return {
            vars = {
                n, d
            }
        }
    end,
    attributes = {"retrigger", "chance"},
}

Entropy.Joker{
    order = 110,
    
    key = "stand_arrow",
    rarity = 2,
    cost = 8,
    eternal_compat = true,
    pos = {x = 8, y = 13},
    atlas = "jokers",
    config = {
        left = 1,
        left_mod = 1,
        odds = 2,
    },
    dependencies = {
        items = {
            "set_entr_actives",
            "e_entr_sunny",
            "e_entr_solar",
            "e_entr_freaky",
            "e_entr_fractured"
        }
    },
    perishable_compat = true,
    loc_vars = function(self, q, card)
        local options = {
            "e_polychrome",
            "e_negative",
            "e_entr_sunny",
            "e_entr_solar",
            "e_entr_freaky",
            "e_entr_fractured"
        }
        for i, v in pairs(options) do
            q[#q+1] = G.P_CENTERS[v]
        end
        local n, d = SMODS.get_probability_vars(card, 1, card.ability.odds, "stand_arrow")
        return {
            vars = {
                card.ability.left,
                card.ability.left_mod,
                n, d
            }
        }
    end,
    demicoloncompat = true,
    calculate = function(self, card, context)
        if (context.end_of_round and not context.blueprint and not context.individual and not context.repetition) or context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", scaling_message = {message = "+"..number_format(card.ability.left_mod)}})
        end
    end, 
    can_use = function(self, card)
        local num = Entropy.get_highlighted_cards({G.jokers}, card, 1, 1)
        local no_ed = false
        for i, v in pairs(num) do
            if not v.edition then no_ed = true end
        end
        if not no_ed then return end
        return #num > 0 and #num <= 1 and to_big(card.ability.left) > to_big(0) 
    end,
    use = function(self, card)
        card.ability.left = card.ability.left - 1
        local cards = Entropy.get_highlighted_cards({G.jokers}, card, 1, 1)
        for i, v in pairs(cards) do
            if SMODS.pseudorandom_probability(v, 'stand_arrow', 1, card.ability.odds) and not SMODS.is_eternal(v) then
                SMODS.destroy_cards(v)
            elseif not v.edition then
                local edition = SMODS.poll_edition({
                    key = "entr_stand_arrow",
                    options = {
                        {name ="e_polychrome", weight = 1},
                        {name ="e_negative", weight = 1},
                        {name ="e_entr_sunny", weight = 1},
                        {name ="e_entr_solar", weight = 1},
                        {name ="e_entr_freaky", weight = 1},
                        {name ="e_entr_fractured", weight = 1},
                    },
                    guaranteed = true
                })
                v:set_edition(edition)
            end
        end
    end,
    attributes = {"modify_card", "activated", "destroy_card", "chance", "scaling", "joker"},
}

Entropy.Joker{
    order = 111,
    
    key = "dancer",
    rarity = 1,
    cost = 5,
    eternal_compat = true,
    pos = {x = 3, y = 15},
    atlas = "jokers",
    config = {
        csl = 2,
        discards = 1
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    perishable_compat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.csl,
                -card.ability.discards
            }
        }
    end,
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.forcetrigger then
            Entropy.change_selection_limit(card.ability.csl)
            G.GAME.round_resets.discards = G.GAME.round_resets.discards - card.ability.discards
            ease_discard(-card.ability.discards)
        end
    end, 
    add_to_deck = function(self, card)
        Entropy.change_selection_limit(card.ability.csl)
        G.GAME.round_resets.discards = G.GAME.round_resets.discards - card.ability.discards
        ease_discard(-card.ability.discards)
    end,
    remove_from_deck = function(self, card)
        Entropy.change_selection_limit(-card.ability.csl)
        G.GAME.round_resets.discards = G.GAME.round_resets.discards + card.ability.discards
        ease_discard(card.ability.discards)
    end,
    slib_credits = {
        idea = {"cassknows"},
        art = {"Lil. Mr. Slipstream"}
    },
    attributes = {"card_selection_limit", "passive"},
}

Entropy.Joker{
    order = 112,
    
    key = "kings_scepter",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 2, y = 15},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    perishable_compat = true,
    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.debuff and context.destroy_card.area == G.play then
            return {remove = not SMODS.is_eternal(context.destroy_card)}
        end
    end, 
    slib_credits = {
        idea = {"cassknows"}
    },
    attributes = {"destroy_card"},
}

Entropy.Joker{
    order = 113,
    
    key = "monkeys_paw",
    atlas = "jokers",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 1, y = 15},
    config = {
        left = 3,
    },
    dependencies = {
        items = {
            "set_entr_actives",
            "set_entr_inversions",
            "set_entr_runes"
        }
    },
    perishable_compat = true,
    loc_vars = function(self, q, card)
        q[#q+1] = {set = "Other", key = "eternal"}
        return {
            vars = {
                card.ability.left,
            }
        }
    end,
    can_use = function(self, card)
        return to_big(card.ability.left) > to_big(0) and #G.consumeables.cards < G.consumeables.config.card_limit
    end,
    use = function(self, card)
        card.ability.left = card.ability.left - 1
        SMODS.add_card {
            set = "Pact",
            area = G.consumeables,
            key_append = "entr_monkeys_paw"
        }:add_sticker("eternal", true)
    end,
    attributes = {"activated", "scaling", "pact", "inverted"},
}

Entropy.Joker{
    order = 114,
    
    key = "magic_skin",
    rarity = 3,
    cost = 6,
    eternal_compat = true,
    pos = {x = 0, y = 14},
    atlas = "jokers",
    config = {
        left = 0,
        left_mod = 1,
        cards = 2
    },
    dependencies = {
        items = {
            "set_entr_actives",
        }
    },
    perishable_compat = true,
    loc_vars = function(self, q, card)
        local loc = G.STATE == G.STATES.SMODS_BOOSTER_OPENED and SMODS.OPENED_BOOSTER and Entropy.kind_to_set(SMODS.OPENED_BOOSTER.config.center.kind)
        if loc == "ERROR" or (SMODS.OPENED_BOOSTER and not Entropy.kind_to_set(SMODS.OPENED_BOOSTER.config.center.kind) and SMODS.OPENED_BOOSTER.config.center.create_card) then
            loc = SMODS.OPENED_BOOSTER.config.center.group_key
        end
        if G.STATE ~= G.STATES.SMODS_BOOSTER_OPENED or (SMODS.OPENED_BOOSTER and (not Entropy.kind_to_set(SMODS.OPENED_BOOSTER.config.center.kind) and not SMODS.OPENED_BOOSTER.config.center.create_card)) or SMODS.OPENED_BOOSTER.config.center.kind == "Standard" then
            loc = "none"
        end
        loc = loc or "ERROR"
        if SMODS.OPENED_BOOSTER and SMODS.OPENED_BOOSTER.config.center.no_magic_skin then
            loc = "none"
        end
        return {
            vars = {
                card.ability.left,
                localize("k_"..string.lower(loc)) ~= "ERROR" and localize("k_"..string.lower(loc)) or localize(string.lower(loc)),
                card.ability.cards,
                card.ability.left_mod
            }
        }
    end,
    can_use = function(self, card)
        if SMODS.OPENED_BOOSTER and SMODS.OPENED_BOOSTER.config and SMODS.OPENED_BOOSTER.config.center.kind == "Standard" then
            return
        end
        return to_big(card.ability.left) > to_big(0) and G.STATE == G.STATES.SMODS_BOOSTER_OPENED and (Entropy.kind_to_set(SMODS.OPENED_BOOSTER.config.center.kind) or SMODS.OPENED_BOOSTER.config.center.create_card)
    end,
    use = function(self, card)
        card.ability.left = card.ability.left - 1
        G.GAME.magic_skin_uses = (G.GAME.magic_skin_uses or 0) + 1
        if G.GAME.magic_skin_uses > 1 then
            G.GAME.magic_skin_prob = (10 - (100/(G.GAME.magic_skin_uses+10)))/20
            G.GAME.magic_skin_prob = G.GAME.magic_skin_prob * (G.GAME.magic_skin_prob ^ 0.75)
        end
        for i = 1, card.ability.cards do
            if SMODS.OPENED_BOOSTER and not SMODS.OPENED_BOOSTER.config.center.no_magic_skin then
                local k = SMODS.OPENED_BOOSTER and Entropy.kind_to_set(SMODS.OPENED_BOOSTER.config.center.kind, true)
                if not k and SMODS.OPENED_BOOSTER.config.center.create_card and type(SMODS.OPENED_BOOSTER.config.center.create_card) == "function" then
                    local _card_to_spawn = SMODS.OPENED_BOOSTER.config.center:create_card(SMODS.OPENED_BOOSTER, i)
                    local spawned
                    if type((_card_to_spawn or {}).is) == 'function' and _card_to_spawn:is(Card) then
                        spawned = _card_to_spawn
                    else
                        spawned = SMODS.create_card(_card_to_spawn)
                    end
                    if spawned.config.center.set == "Joker" then
                        G.jokers:emplace(spawned)
                    else    
                        G.consumeables:emplace(spawned)
                    end
                    spawned:set_edition("e_negative")
                else
                    if k == "Planet" or k == "Tarot" then
                        local rune
                        local rare_rune
                        if pseudorandom("entr_generate_rune") < 0.06 then rune = true end
                        if G.GAME.entr_diviner then
                            if pseudorandom("entr_generate_rune") < 0.06 then rune = true end
                        end
                        if rune then
                            k = "Rune"
                        end
                    end
                    SMODS.add_card {
                        set = k or "Joker",
                        area = k == "Twisted" and G.consumeables or nil,
                        key_append = "entr_magic_skin",
                        edition = "e_negative"
                    }
                end
            end
        end
    end,
    calculate = function(self, card, context)
        if (context.end_of_round and not context.blueprint and not context.individual and not context.repetition) or context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", scaling_message = {message = "+"..number_format(card.ability.left_mod)}})
        end
    end, 
    slib_credits = {idea = {"Athebyne"}},
    attributes = {"joker", "modify_card", "generation", "activated", "scaling"},
}

Entropy.Joker{
    order = 115,
    
    key = "lambda_calculus",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 2, y = 14},
    atlas = "jokers",
    config = {
        chips = 0
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    perishable_compat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.chips
            }
        }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local chips = card.ability.chips
            card.ability.chips = 0
            return {
                chips = chips
            }
        end
        if context.post_trigger and context.other_card ~= card then
            local change = Entropy.gather_values(context.other_card)
            if to_big(change) > to_big(0) then
                card.ability.chips = card.ability.chips + change
                card_eval_status_text(
                    card,
                    "extra",
                    nil,
                    nil,
                    nil,
                    { message = number_format(card.ability.chips), colour = G.C.BLUE }
                )
            end
        end
    end, 
    attributes = {"chips"},
}

Entropy.Joker{
    order = 116,
    
    key = "elderberries",
    rarity = 2,
    cost = 6,
    pos = {x = 3, y = 14},
    atlas = "jokers",
    config = {
        spectrals = 2
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    pools = {Food = true},
    perishable_compat = true,
    blueprint_compat = true,
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                math.min(card.ability.spectrals, 100)
            },
            key = G.GAME.modifiers.entr_gfb and "j_entr_elderberries_gfb" or nil
        }
    end,
    calculate = function(self, card, context)
        if context.selling_self or context.forcetrigger then
            G.E_MANAGER:add_event(Event{
                trigger = "after",
                func = function()
                    local area
                    if G.STATE == G.STATES.HAND_PLAYED then
                        if not G.redeemed_vouchers_during_hand then
                            G.redeemed_vouchers_during_hand =
                                CardArea(G.play.T.x, G.play.T.y, G.play.T.w, G.play.T.h, { type = "play", card_limit = 5 })
                        end
                        area = G.redeemed_vouchers_during_hand
                    else
                        area = G.play
                    end
                    for i = 1, (G.GAME.modifiers.entr_gfb and 1 or card.ability.spectrals) do
                        local card = create_card("Spectral", G.play, nil, nil, nil, nil, nil, "entr_large_deck")
                        if card.config.center.key == "j_joker" then
                            card:set_ability(G.P_CENTERS.c_aura)
                        end
                        if G.GAME.modifiers.entr_gfb then
                            if pseudorandom("elderberries_gfb") < 0.3 / 100 then
                                card:set_ability(G.P_CENTERS.c_soul)
                            else
                                card:set_ability(G.P_CENTERS.c_ankh)
                            end
                        end
                        card:add_to_deck()
                        area:emplace(card)

                        local top_dynatext = nil
                        
                        G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.4, func = function()
                                top_dynatext = DynaText({string = localize{type = 'name_text', set = card.config.center.set, key = card.config.center.key}, colours = {G.C.WHITE}, rotate = 1,shadow = true, bump = true,float=true, scale = 0.9, pop_in = 0.6/G.SPEEDFACTOR, pop_in_rate = 1.5*G.SPEEDFACTOR})
                                card:juice_up(0.3, 0.5)
                                play_sound('card1')
                                play_sound('coin1')
                                card.children.top_disp = UIBox{
                                    definition =    {n=G.UIT.ROOT, config = {align = 'tm', r = 0.15, colour = G.C.CLEAR, padding = 0.15}, nodes={
                                                        {n=G.UIT.O, config={object = top_dynatext}}
                                                    }},
                                    config = {align="tm", offset = {x=0,y=0},parent = card}
                                }
        
                            return true end }))
                        --G.GAME.current_round.voucher = nil


                        delay(0.6)
                        G.E_MANAGER:add_event(Event({trigger = 'after', delay = 2.6, func = function()
                            top_dynatext:pop_out(4)
                            return true end }))
                        G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.5, func = function()
                            card.children.top_disp:remove()
                            card.children.top_disp = nil
                        return true end }))

                        Spectrallib.forcetrigger({
                            card = card, 
                            silent = true
                        })
                        G.E_MANAGER:add_event(Event{
                            trigger = "after",
                            func = function()
                                card:start_dissolve()
                                return true
                            end
                        })
                    end
                    return true
                end
            })
            return nil, true
        end
    end, 
    attributes = {"forcetrigger", "spectral"},
}

Entropy.Joker{
    order = 118,
    
    key = "blood_orange",
    rarity = 2,
    cost = 6,
    pos = {x = 7, y = 14},
    atlas = "jokers",
    config = {
        cards = 10
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
            "set_entr_inversions"
        }
    },
    pools = {Food = true},
    perishable_compat = true,
    blueprint_compat = true,
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.cards
            }
        }
    end,
    calculate = function(self, card, context)
        if context.remove_playing_cards or context.forcetrigger then
            local eated
            for i, v in pairs(context.removed or {true}) do
                if G.GAME.consumeable_buffer + #G.consumeables.cards < G.consumeables.config.card_limit then
                    card.ability.cards = card.ability.cards - 1
                    if card.ability.cards <= 0 then
                        SMODS.destroy_cards(card, true, nil, true)
                        eated = true
                    end
                    G.E_MANAGER:add_event(Event{
                        func = function()
                            G.GAME.consumeable_buffer = 0
                            SMODS.add_card{
                                attributes = {"inverted_consumable"},
                                types = {"Consumeables"},
                                area = G.consumeables,
                                key_append = "entr_blood_orange"
                            }         
                            return true
                        end
                    })
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    card_eval_status_text(
                        card,
                        "extra",
                        nil,
                        nil,
                        nil,
                        { message = eated and localize("k_eaten_ex") or localize("k_plus_inverted"), colour = G.C.RED }
                    )
                end
            end
        end
    end, 
    attributes = {"genration", "inverted", "food", "scaling"},
}

Entropy.Joker{
    order = 119,
    
    key = "false_vacuum_collapse",
    rarity = 3,
    cost = 8,
    eternal_compat = true,
    pos = {x = 9, y = 14},
    atlas = "jokers",
    config = {
        cards = 10
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.cards
            }
        }
    end,
    calculate = function(self, card, context)
        if context.before then
            card.area:remove_card(card)
            G.play:emplace(card, "front")
            card:highlight(true)
            SMODS.change_base(card, "entr_nilsuit", "entr_nilrank")
            G.E_MANAGER:add_event(Event{
                trigger = "after",
                blocking = false,
                func = function()
                    G.E_MANAGER:add_event(Event{
                        trigger = "after",
                        func = function()
                            if card.area then
                                card.area:remove_card(card)
                                G.jokers:emplace(card, "front")
                            end
                            return true
                        end
                    })
                    return true
                end
            })
        end
        if context.individual and context.card == card then
            local d
            for i = 2, #G.play.cards do
                if G.play.cards[i] and not G.play.cards[i].getting_sucked and G.play.cards[i] ~= card and not d then
                    G.play.cards[i].getting_sucked = true
                    SMODS.destroy_cards(G.play.cards[i])
                    d = true
                end
            end
        end
    end, 
    attributes = {"joker", "hands", "destroy_card"},
}


local eval_card_ref = eval_card
function eval_card(card, ...)
    if card and type(card) == "table" and not card.getting_sucked then
        return eval_card_ref(card, ...)
    end
    return {}
end

Entropy.Joker{
    order = 120,
    
    key = "mark_of_the_beast",
    rarity = 2,
    cost = 8,
    eternal_compat = true,
    pos = {x = 4, y = 14},
    atlas = "jokers",
    config = {
        cards = 10
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
            "set_entr_inversions"
        }
    },
    perishable_compat = true,
    blueprint_compat = true,
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.p_entr_twisted_pack_mega
    end,
    calculate = function(self, card, context)
        if context.starting_shop and not card.ability.triggered then
            card.ability.triggered = true
            G.E_MANAGER:add_event(Event{
                func = function()
                    card:juice_up()
                    return true
                end
            })
            local card = Card(G.shop_booster.T.x + G.shop_booster.T.w/2,
            G.shop_booster.T.y, G.CARD_W*1.27, G.CARD_H*1.27, G.P_CARDS.empty, G.P_CENTERS["p_entr_twisted_pack_mega"], {bypass_discovery_center = true, bypass_discovery_ui = true})
            card.ability.beast_mark = true
            create_shop_card_ui(card, 'Booster', G.shop_booster)
            card.ability.booster_pos = #G.shop_booster.cards + 1
            card:start_materialize()
            card.cost = 0
            G.shop_booster:emplace(card)
            return nil, true
        end
        if context.forcetrigger then
            G.E_MANAGER:add_event(Event{
                trigger = "after",
                func = function()
                    SMODS.add_card{
                        area = G.consumeables,
                        key = "p_entr_twisted_pack_mega"
                    }
                    return true
            end })
        end
        if context.end_of_round then card.ability.triggered = nil end
        if (context.reroll_shop and Entropy.has_rune("rune_entr_perthro")) then
            G.E_MANAGER:add_event(Event{
                trigger = "after",
                func = function()
                    G.E_MANAGER:add_event(Event{
                        trigger = "after",
                        func = function()
                            card:juice_up()
                            local card = Card(G.shop_booster.T.x + G.shop_booster.T.w/2,
                            G.shop_booster.T.y, G.CARD_W*1.27, G.CARD_H*1.27, G.P_CARDS.empty, G.P_CENTERS["p_entr_twisted_pack_mega"], {bypass_discovery_center = true, bypass_discovery_ui = true})
                            card.ability.beast_mark = true
                            create_shop_card_ui(card, 'Booster', G.shop_booster)
                            card.ability.booster_pos = #G.shop_booster.cards + 1
                            card:start_materialize()
                            card.cost = 0
                            G.shop_booster:emplace(card)
                            return true
                        end})
                    return true
                end
            })
        end
    end, 
    attributes = {"destroy_card", "joker", "inverted"},
}

Entropy.Joker{
    order = 121,
    
    key = "echo_chamber",
    rarity = 3,
    cost = 10,   
    eternal_compat = true,
    blueprint_compat = true,
    pos = {x = 4, y = 15},
    atlas = "jokers",
    config = {
        left = 1,
        left_mod = 1,
        current_spent = 0,
        needed = 30,
        destroyed = {

        }
    },
    dependencies = {
        items = {
            "set_entr_actives",
        }
    },
    loc_vars = function(self, q, card)
        local c1 = card.ability.destroyed[1] and G.P_CENTERS[card.ability.destroyed[1]]
        local c2 = card.ability.destroyed[2] and G.P_CENTERS[card.ability.destroyed[2]]
        local c3 = card.ability.destroyed[3] and G.P_CENTERS[card.ability.destroyed[3]]
        q[#q+1] = c1
        q[#q+1] = c2
        q[#q+1] = c3
        return {
            vars = {
                card.ability.left,
                card.ability.left_mod,
                card.ability.needed,
                card.ability.current_spent,
                c1 and localize{type = "name_text", set = c1.set, key = c1.key} or localize("k_none"),
                c2 and localize{type = "name_text", set = c2.set, key = c2.key} or localize("k_none"),
                c3 and localize{type = "name_text", set = c3.set, key = c3.key} or localize("k_none"),
                colours = {
                    G.C.SECONDARY_SET[c1 and c1.set] or G.C.ORANGE,
                    G.C.SECONDARY_SET[c2 and c2.set] or G.C.ORANGE,
                    G.C.SECONDARY_SET[c3 and c3.set] or G.C.ORANGE,
                }
            }
        }
    end,
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.money_altered and to_big(context.amount) < to_big(0) and not context.blueprint and context.from_shop then
            card.ability.current_spent = card.ability.current_spent - context.amount
            local check 
            while to_big(card.ability.current_spent) >= to_big(card.ability.needed) do
                card.ability.current_spent = card.ability.current_spent - card.ability.needed
                SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod"})
                check = true
            end
            if not check then
                return {
                    message = number_format(card.ability.current_spent).."/"..number_format(card.ability.needed)
                }
            end
        end
    end,
    can_use = function(self, card)
        local cards = Entropy.get_highlighted_cards({G.consumeables, G.hand, G.jokers, G.pack_cards}, card, 1, 1, function(card)
            return card.ability.consumeable and not card.config.center.hidden
        end)
        return #cards == 1 and to_big(card.ability.left) > to_big(0)
    end,
    use = function(self, card)
        local cards = Entropy.get_highlighted_cards({G.consumeables, G.hand, G.jokers, G.pack_cards}, card, 1, 1, function(card)
            return card.ability.consumeable and not card.config.center.hidden
        end)
        if #cards > 0 then
            for i, v in pairs(card.ability.destroyed) do
                G.E_MANAGER:add_event(Event{
                    trigger = "after",
                    func = function()
                        card_eval_status_text(
                            card,
                            "extra",
                            nil,
                            nil,
                            nil,
                            { message = localize{type = "name_text", set = G.P_CENTERS[v].set, key = G.P_CENTERS[v].key} }
                        )
                        return true
                    end
                })
                G.E_MANAGER:add_event(Event{
                    trigger = "after",
                    delay = 0.1,
                    func = function()
                        Spectrallib.forcetrigger({
                            card = Entropy.get_dummy(G.P_CENTERS[v], G.jokers, card),
                            context = context,
                            silent = true
                        })
                        return true
                    end
                })
            end
        end
        for i, v in pairs(cards) do
            table.insert(card.ability.destroyed, 1, v.config.center_key)
            SMODS.destroy_cards(v)
        end
        for i = 4, #card.ability.destroyed do
            card.ability.destroyed[i] = nil
        end
        card.ability.left = card.ability.left - 1
    end,
    attributes = {"forcetrigger", "scaling", "activated", "economy", "destroy_card"},
}

Entropy.Joker{
    order = 122,
    
    key = "milk",
    rarity = 1,
    cost = 6,   
    pos = {x = 2, y = 17},
    atlas = "jokers",
    config = {
        chips = 0,
        chips_mod = 20,
        chips_max = 100
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    demicoloncompat = true,
    blueprint_compat = true,
    pools = {Food = true},
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.j_entr_yogurt
        return {
            vars = {
                card.ability.chips,
                card.ability.chips_mod,
                card.ability.chips_max
            },
            key = G.GAME.modifiers.entr_gfb and "j_entr_milk_gfb" or nil
        }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not context.individual and not context.repetition and not SMODS.last_hand_oneshot then
            SMODS.scale_card(card, {
                ref_table = card.ability,
                ref_value = "chips",
                scalar_value = "chips_mod",
                no_message = card.ability.chips >= card.ability.chips_max - card.ability.chips_mod
            })
            if card.ability.chips >= card.ability.chips_max then
                card.ability.chips = card.ability.chips_max
                Entropy.flip_then({card}, function(c)
                    c:set_ability(G.P_CENTERS.j_entr_yogurt)
                end)
                return {
                    message = localize("k_spoiled_ex")
                }
            end
        end
        if context.joker_main or context.forcetrigger then
            return {
                chips = not G.GAME.modifiers.entr_gfb and card.ability.chips or nil,
                mult = G.GAME.modifiers.entr_gfb and card.ability.chips or nil
            }
        end
    end,
    attributes = {"chips", "food", "scaling"},
}

Entropy.Joker{
    order = 123,
    
    key = "yogurt",
    rarity = 1,
    cost = 6,   
    pos = {x = 3, y = 17},
    atlas = "jokers",
    config = {
        chips = 100,
        chips_mod = 5,
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    demicoloncompat = true,
    blueprint_compat = true,
    pools = {Food = true},
    in_pool = function() return false end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.chips,
                card.ability.chips_mod,
            },
            key = G.GAME.modifiers.entr_gfb and "j_entr_yogurt_gfb" or nil
        }
    end,
    calculate = function(self, card, context)
        if context.entr_chips_calculated and context.other_card ~= card then
            SMODS.scale_card(card, {
                ref_table = card.ability,
                ref_value = "chips",
                scalar_value = "chips_mod",
                no_message = card.ability.chips <= card.ability.chips_mod,
                operation = "-",
                scaling_message = {
                    message = localize("k_downgrade_ex"),
                    colour = G.C.RED
                }
            })
            if card.ability.chips <= card.ability.chips_mod then
                card.ability.chips = 0
                SMODS.destroy_cards(card, true, nil, true)
                return {
                    message = localize("k_spoiled_ex")
                }
            end
        end
        if context.joker_main or context.forcetrigger then
            return {
                chips = not G.GAME.modifiers.entr_gfb and card.ability.chips or nil,
                mult = G.GAME.modifiers.entr_gfb and card.ability.chips or nil
            }
        end
    end,
    attributes = {"chips", "food", "scaling"},
}

Entropy.Joker{
    order = 124,
    
    key = "box_of_chocolates",
    rarity = 1,
    cost = 8,   
    pos = {x = 8, y = 15},
    atlas = "jokers",
    config = {
        uses = 12
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    blueprint_compat = true,
    pools = {Food = true},
    in_pool = function() return false end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.uses
            }
        }
    end,
    calculate = function(self, card, context)
        if context.post_open_booster then
            local ret = {}
            G.E_MANAGER:add_event(Event{
                trigger = "after",
                blocking = false,
                delay = 1,
                func = function()
                    G.E_MANAGER:add_event(Event{
                        trigger = "after",
                        blocking = false,
                        func = function()
                            local card2 = pseudorandom_element(G.pack_cards.cards, pseudoseed("j_entr_chocolates"))
                            Spectrallib.forcetrigger({
                                card = card2,
                                context = context,
                                message_card = card
                            })
                            return true
                        end
                    })
                    return true
                end
            })
            card.ability.uses = card.ability.uses - 1
            if card.ability.uses <= 0 then
                ret.message = localize("k_eaten_ex")
                ret.colour = G.C.FILTER
                SMODS.destroy_cards(card, true, nil, true)
            else
                ret.message = "-1"
                ret.colour = G.C.RED
            end
            ret.card = card
            return ret
        end
    end,
    slib_credits = {
        idea = {"cassknows"},
        art = {"mailingway"}
    },
    attributes = {"forcetrigger", "scaling", "food"},
}

Entropy.Joker{
    order = 125,
    
    key = "carrot_cake",
    rarity = 2,
    cost = 8,   
    pos = {x = 1, y = 17},
    atlas = "jokers",
    config = {
        uses = 10
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    blueprint_compat = true,
    pools = {Food = true},
    in_pool = function() return false end,
    loc_vars = function(self, q, card)
        q[#q+1] = {key = 'e_entr_gilded_consumable', set = 'Edition', config = {}}
        return {
            vars = {
                card.ability.uses
            }
        }
    end,
    calculate = function(self, card, context)
        if context.entr_consumable_created and not context.other_card.will_be_gilded then
            context.other_card:set_edition("e_entr_gilded")
            context.other_card.will_be_gilded = true 
            card.ability.uses = card.ability.uses - 1
            local ret = {}
            if card.ability.uses <= 0 then
                ret.message = localize("k_eaten_ex")
                ret.colour = G.C.FILTER
                SMODS.destroy_cards(card, true, nil, true)
            else
                ret.message = "-1"
                ret.colour = G.C.RED
            end
            ret.card = card
            return ret
        end
    end,    
    attributes = {"modify_card", "scaling", "food"},
}

Entropy.Joker{
    order = 126,
    
    key = "twisted_pair",
    rarity = 2,
    cost = 8,   
    eternal_compat = true,
    pos = {x = 0, y = 16},
    atlas = "jokers",
    config = {
        value_fac = 0.75
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.value_fac
            }
        }
    end,
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play then
            local c = context.other_card
            c.ability.entr_value_fac = (c.ability.entr_value_fac or 1) * card.ability.value_fac
            G.E_MANAGER:add_event(Event{
                func = function()
                    c.ability.entr_value_fac = nil
                    return true
                end
            })
            return {
                repetitions = 1
            }
        end
    end,    
    slib_credits = {
        idea = {"user765984"},
        art = {"mailingway"}
    },
    attributes = {"retrigger", "modify_card"},
}

Entropy.Joker{
    order = 127,
    
    key = "texas_hold_em",
    rarity = 2,
    cost = 8,   
    eternal_compat = true,
    pos = {x = 5, y = 15},
    atlas = "jokers",
    config = {
        cards_added = 3,
        csl = 2,
        added_cards = {}
    },
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    demicoloncompat = true,
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        q[#q+1] = {set = "Other", key = "entr_marked", vars = {}}
        return {
            vars = {
                card.ability.csl,
                card.ability.cards_added,
            }
        }
    end,
    add_to_deck = function(self, card) Entropy.change_selection_limit(-card.ability.csl) end,
    remove_from_deck = function(self, card) Entropy.change_selection_limit(card.ability.csl) end,
    calculate = function(self, card, context)
        if context.first_hand_drawn and context.hand_drawn or context.forcetrigger then
            card.ability.added_cards = {}
            local cards = {}
            for i, v in pairs(context.hand_drawn or G.hand.cards) do
                if not v.ability.entr_marked then cards[#cards+1] = v end
            end
            if #cards > 0 then
                for i = 1, math.min(#(cards or G.hand.cards), card.ability.cards_added) do
                    cards[i].ability.entr_marked = true
                    cards[i]:juice_up()
                end
            end
        end
    end,    
    slib_credits = {
        idea = {"cassknows"},
        art = {"Camostar34"}
    },
    generate_ui = function(self, info_queue, card, desc_nodes, specific_vars, full_UI_table)
        SMODS.Center.generate_ui(self, info_queue, card, desc_nodes, specific_vars, full_UI_table)
        
        local cards = {}
        for i, v in pairs(G.I.CARD) do
            if v.ability and v.ability.entr_marked and not v.ability.entr_marked_bypass then
                local s = v:save()
                local c = Card(0,0, G.CARD_W, G.CARD_H, pseudorandom_element(G.P_CARDS,pseudoseed("")), G.P_CENTERS.c_base)
                c:load(s)
                c.ability = SMODS.shallow_copy(c.ability)
                c.ability.entr_marked_bypass = true
                v.ability.entr_marked_bypass = nil                
                table.insert(cards, c)
            end
        end
        if #cards > 0 then
            Entropy.card_area_preview(G.entrCardsPrev, desc_nodes, {
                cards = cards,
                override = true,
                w = 2.2,
                h = 0.6,
                ml = 0,
                scale = 0.5,
                func_delay = 1.0,
            })
        end
    end,
    attributes = {"modify_card", "hands"},
}

SMODS.Sticker({
        badge_colour = G.C.RED,
        prefix_config = { key = false },
        key = "entr_marked",
        atlas = "marked",
        pos = { x = 0, y = 0 },
        should_apply = false,
        draw = function(self, card) --don't draw shine
            local notilt = nil
            if card.area and card.area.config.type == "deck" then
                notilt = true
            end
            G.shared_stickers[self.key].role.draw_major = card
            G.shared_stickers[self.key]:draw_shader("dissolve", nil, nil, notilt, card.children.center)
        end,
    })

Entropy.Joker{
    order = 128,
    
    key = "fasciation",
    rarity = 3,
    cost = 8,   
    eternal_compat = true,
    pos = {x = 1, y = 16},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    blueprint_compat = true,
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play then
            local reps = 0
            for i, v in pairs(context.scoring_hand) do
                if v == context.other_card then break end
                if (v:is_suit(context.other_card.base.suit) and not SMODS.has_no_suit(context.other_card)) 
                or (context.other_card:is_suit(v.base.suit) and not SMODS.has_no_suit(v)) then
                    reps = reps + 1
                end
            end
            if reps > 0 then
                return {
                    repetitions = reps
                }
            end
        end
    end,    
    slib_credits = {
        art = {"LFMoth"}
    },
    loc_vars = function()
        return {
            name_key = G.GAME.modifiers.entr_gfb and "j_entr_fasciation_gfb"
        }
    end,
    attributes = {"retrigger", "suit"},
}

Entropy.Joker{
    order = 129,
    
    key = "amaryllis",
    rarity = 3,
    cost = 10,   
    eternal_compat = true,
    pos = {x = 4, y = 16},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        colour = "white",
        hands = 3,
        dollars = 20
    },
    demicoloncompat = true,
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        if card.ability.colour == "pink" then
            q[#q+1] = G.P_CENTER_POOLS.e_entr_freaky
        end
        return {
            vars = {
                card.ability.hands,
                card.ability.dollars
            },
            key = "j_entr_amaryllis_"..card.ability.colour
        }
    end,
    calculate = function(self, card, context)
        if context.round_eval and not context.individual and not context.repetition then
            if not card.ability.entr_pure then --:trollgore:
                G.E_MANAGER:add_event(Event{
                    func = function()
                        local colour = pseudorandom_element({
                            "red", "white", "pink", "orange", "purple", "yellow"
                        }, pseudoseed("entr_amaryllis_change"))
                        local colour_map = {
                            red = G.C.RED,
                            white = G.C.BLACK,
                            pink = G.C.Entropy.Omen,
                            orange = G.C.FILTER,
                            purple = G.C.PURPLE,
                            yellow = G.C.GOLD
                        }
                        local x_map = {
                            red = 5,
                            white = 4,
                            pink = 6,
                            orange = 7,
                            purple = 8,
                            yellow = 9
                        }
                        card.ability.colour = colour
                        SMODS.calculate_effect(
                            { message = localize("k_switch_ex"), colour = colour_map[colour], func = function()
                                card.children.center:set_sprite_pos({x = x_map[colour], y = 16})
                                card:juice_up()
                            end},
                            card)
                        return true
                    end
                })
            end
        end
        if card.ability.colour == "red" and context.before then
            Entropy.flip_then(G.play.cards, function(c) SMODS.change_base(c, "Hearts") end)
        end
        if card.ability.colour == "white" and context.setting_blind then
            if G.GAME.consumeable_buffer + #G.consumeables.cards < G.consumeables.config.card_limit then
                G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                G.E_MANAGER:add_event(Event{
                    func = function()
                        SMODS.add_card({
                            set = "Rune"
                        })
                        G.GAME.consumeable_buffer = 0
                        return true
                    end 
                })
                return {
                    message = localize("k_plus_rune"),
                    colour = G.C.PURPLE
                }
            end
        end
        if card.ability.colour == "pink" and context.first_hand_drawn then
            local card = pseudorandom_element(G.hand.cards, pseudoseed("entr_amaryllis_pink"))
            if card then
                card:set_edition("e_entr_freaky")
            end
            return nil, true
        end
        if card.ability.colour == "orange" and context.setting_blind then
             G.E_MANAGER:add_event(Event({
                func = function()
                    ease_hands_played(card.ability.hands)
                    SMODS.calculate_effect(
                        { message = localize { type = 'variable', key = 'a_hands', vars = { card.ability.hands } } },
                        context.blueprint_card or card)
                    return true
                end
            }))
            return nil, true
        end
        if card.ability.colour == "purple" and context.individual and context.other_card:is_face() and context.cardarea == G.hand and not context.end_of_round then
            return {
                balance = true
            }
        end
    end,   
    calc_dollar_bonus = function(self, card)
        if card.ability.colour == "yellow" then
            return card.ability.dollars
        end
    end,
    set_sprites = function(self, card)
        G.E_MANAGER:add_event(Event{
            func = function()
                local x_map = {
                    red = 5,
                    white = 4,
                    pink = 6,
                    orange = 7,
                    purple = 8,
                    yellow = 9
                }
                card.children.center:set_sprite_pos({x = x_map[card.ability.colour], y = 16})
                return true
            end
        })
    end,
    attributes = {"suit", "hearts", "generation", "rune", "modify_card", "hands", "mult", "chips", "face", "economy"},
}

Entropy.Joker{
    order = 130,
    
    key = "cooking_pot",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 4, y = 17},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        foods = {}
    },
    demicoloncompat = true,
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        for i, v in pairs(card.ability.foods) do
            q[#q+1] = G.P_CENTERS[v]
        end
        return {
            vars = {
                card.ability.foods[1] and localize{type = "name_text", set = G.P_CENTERS[card.ability.foods[1]].set, key = card.ability.foods[1]} or localize("k_none"),
                card.ability.foods[2] and localize{type = "name_text", set = G.P_CENTERS[card.ability.foods[2]].set, key = card.ability.foods[2]} or localize("k_none"),
                card.ability.foods[3] and localize{type = "name_text", set = G.P_CENTERS[card.ability.foods[3]].set, key = card.ability.foods[3]} or localize("k_none"),
            },
        }
    end,
    calculate = function(self, card, context)
        if context.entr_food_added then
            card.ability.foods[#card.ability.foods+1] = context.other_card.config.center.key
            if #card.ability.foods > 3 then
                SMODS.destroy_cards(card, true, nil, true)
                return {
                    message = localize("k_destroyed_ex")
                }
            end
            SMODS.destroy_cards(context.other_card, nil, nil, true)
            return {
                message = localize("k_cooked_ex")
            }
        end
        local retted
        for i, v in pairs(card.ability.foods) do
            local dummy = Entropy.get_dummy(G.P_CENTERS[v], G.jokers, card, true)
            local ret, retr = Card.calculate_joker(dummy, context)
            if ret or retr then SMODS.calculate_effect{message =  localize{type = "name_text", set = G.P_CENTERS[v].set, key = v}, card = card} end
            if ret and ret.card == dummy then ret.card = card end
            for index, effect in pairs(ret or {}) do
                SMODS.calculate_individual_effect(ret, dummy, index, effect)
                retted = true
            end
            if retr then retted = true end
        end
        if retted then return nil, true end
    end,   
    attributes = {"food", "destroy_card", "forcetrigger"},
}

Entropy.Joker{
    order = 131,
    
    key = "brownies",
    rarity = 2,
    cost = 6,
    pos = {x = 0, y = 17},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        dollars = 3,
        cards_left = 10,
    },
    demicoloncompat = true,
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.dollars,
                card.ability.cards_left
            }
        }
    end,
    calculate = function(self, card, context)
        if context.using_consumeable or context.forcetrigger then            
            card.ability.cards_left = card.ability.cards_left - 1
            if card.ability.cards_left <= 0 then
                SMODS.destroy_cards(card, true, nil, true)
                return {
                    dollars = card.ability.dollars,
                    message = localize("k_eaten_ex")
                }
            end
            return {
                dollars = card.ability.dollars,
                message = "-1",
                colour = G.C.RED
            }
        end
    end,   
    attributes = {"economy", "food", "scaling"},
}

Entropy.Joker{
    order = 132,
    
    key = "redacted",
    rarity = 2,
    cost = 7,
    eternal_compat = true,
    pos = {x = 6, y = 15},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        mult = 10
    },
    demicoloncompat = true,
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        q[#q+1] = {set = "Other", key = "rental", vars = {3}}
        return {
            vars = {
                card.ability.mult
            }
        }
    end,
    calculate = function(self, card, context)
        if context.setting_blind then            
            local cards = {}
            local cards_not_strict = {}
            for i, v in pairs(G.jokers.cards) do
                if v ~= card then
                    cards_not_strict[#cards_not_strict+1] = v
                    if not v.ability.rental then cards[#cards+1] = v end
                end
            end
            local rcard = pseudorandom_element(cards, pseudoseed("redadcted")) or pseudorandom_element(cards_not_strict, pseudoseed("redacted"))
            if rcard then
                rcard:flip()
                rcard.ability.rental = true
            end
            card:juice_up()
            return nil, true
        end
        if context.joker_main or context.forcetrigger then
            for i, v in pairs(G.jokers.cards) do 
                if v.ability.rental then G.E_MANAGER:add_event(Event{func = function() card:juice_up() return true end}) SMODS.calculate_effect{mult = card.ability.mult, card = v} end
            end
            return nil, true
        end
    end,   
    attributes = {"modify_card", "joker", "mult"},
}

Entropy.Joker{
    order = 133,
    
    key = "void_cradle",
    rarity = 2,
    cost = 8,
    eternal_compat = true,
    pos = {x = 2, y = 16},
    atlas = "jokers",
    config = {
        left = 1,
        left_mod = 1
    },
    dependencies = {
        items = {
            "set_entr_actives",
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.left,
                card.ability.left_mod
            }
        }
    end,
    demicoloncompat = true,
    calculate = function(self, card, context)
        if (context.end_of_round and not context.blueprint and not context.individual and G.GAME.blind_on_deck == "Boss" and not context.repetition) or context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", scaling_message = {message = "+"..number_format(card.ability.left_mod)}})
        end
    end,
    can_use = function(self, card)
        local cards = Entropy.get_highlighted_cards({G.jokers, G.consumeables, G.hand}, card, 1, card.ability.left, function(c) return Entropy.inversion(c) end)
        return to_big(card.ability.left) > to_big(0) and #cards > 0 and #cards <= card.ability.left
    end,
    use = function(self, card)
        local cards = Entropy.get_highlighted_cards({G.jokers, G.consumeables, G,hand}, card, 1, card.ability.left, function(c) return Entropy.inversion(c) end)
        G.GAME.entr_perma_inversions = G.GAME.entr_perma_inversions or {}
        for i, v in pairs(cards) do
            local i = Entropy.inversion(v)
            if i ~= "c_entr_flipside" then
                G.GAME.entr_perma_inversions[v.config.center.key] = i
            end
        end
        Entropy.invert(cards, true, true)
        card.ability.left = math.max(card.ability.left - 1, 0)
    end,
    slib_credits = {art = {"mailingway"}},
    attributes = {"activated", "inverted", "scaling", "modify_card"},
}

Entropy.Joker{
    order = 134,
    
    key = "arachnophobia",
    rarity = 2,
    cost = 8,
    eternal_compat = true,
    pos = {x = 3, y = 16},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        triggers = 0,
        needed_triggers = 5
    },
    demicoloncompat = true,
    blueprint_compat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.needed_triggers
            }
        }
    end,
    calculate = function(self, card, context)
        if context.before then            
            card.ability.triggers = 0
        end
        if context.individual and context.other_card:get_id() == 8 then
            card.ability.triggers = card.ability.triggers + 1
        end
        if context.joker_main and card.ability.triggers >= card.ability.needed_triggers or context.forcetrigger then
            if G.GAME.consumeable_buffer + #G.consumeables.cards < G.consumeables.config.card_limit then
                G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                G.E_MANAGER:add_event(Event{
                    func = function()
                        SMODS.add_card{set = "Omen", area = G.consumables}
                        G.GAME.consumeable_buffer = 0
                        return true
                    end
                })
                return {
                    message = localize("k_plus_omen"),
                    G.C.Entropy.Omen
                }
            end
            return nil, true
        end 
    end,   
    slib_credits = {
        art = {"pangaea47"}
    },
    attributes = {"inverted", "omen", "rank", "8", "generation"},
}

Entropy.Joker{
    order = 135,
    
    key = "pound_of_flesh",
    rarity = 2,
    cost = 8,
    eternal_compat = true,
    pos = {x = 9, y = 15},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },  
    slib_credits = {
        art = {"mailingway"}
    },
    attributes = {"modify_card", "destroy_card"},
}

Entropy.Joker{
    order = 136,
    
    key = "fthof",
    rarity = 3,
    cost = 10,
    eternal_compat = true,
    pos = {x = 7, y = 15},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {odds = 3}
    },
    calculate = function(self, card, context)
        if context.modify_shop_voucher and context.first_of_ante then
            local key = SMODS.poll_object{set = "Joker", rarity = 3}
            G.GAME.entr_parakmi_bypass = true
            local card = context.card
            if card and not (G.GAME.current_round.voucher.editions or {})[card.config.center.key] then
                for i, v in pairs(G.GAME.current_round.voucher) do
                    if v == card.config.center.key then    
                        G.GAME.current_round.voucher.spawn[v] = nil
                        G.GAME.current_round.voucher.spawn[key] = true
                        G.GAME.current_round.voucher[i] = key
                        break
                    end
                end
                card:set_ability(G.P_CENTERS[key])
            else    
                card = SMODS.add_voucher_to_shop(key)
                G.GAME.current_round.voucher[#G.GAME.current_round.voucher+1] = key
                G.GAME.current_round.voucher.spawn[key] = true
            end
            if card then
                card:set_edition("e_entr_gilded")
            end
            G.GAME.current_round.voucher.editions = G.GAME.current_round.voucher.editions or {}
            G.GAME.current_round.voucher.editions[key] = "e_entr_gilded"
            G.GAME.entr_parakmi_bypass = nil
            return nil, true
        end
        if context.buying_card and (card.ability.extra.bought_self or G.GAME.modifiers.entr_gfb) and SMODS.pseudorandom_probability(card, 'entr_fthof', 1, card.ability.extra.odds) then
            card.ability.extra.bought_self = true
            local is_voucher
            for i, v in pairs(G.GAME.current_round.voucher) do
                if v == context.card.config.center_key then
                    is_voucher = true
                    break
                end
            end
            if not is_voucher then
                SMODS.destroy_cards(card, true, nil, true)
                return {
                    message = localize("k_backfired_ex"),
                    colour = G.C.RED
                }
            end
        end
    end,
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.e_entr_gilded
        local n, d = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, "entr_fthof")
        return {
            vars = {
                n, d
            }
        }
    end,
    attributes = {"joker", "modify_card", "economy", "chance"},
}

Entropy.Joker{
    order = 137,
    
    key = "searing_joke",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 5, y = 17},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_inversions",
        }
    },
    config = {
        extra = {xmult = 2, xmult_mod = 1}
    },
    can_be_inverted = true,
    calculate = function(self, card, context)
        if G.GAME.modifiers.entr_gfb then
            if (context.end_of_round and not context.blueprint and not context.individual and G.GAME.blind_on_deck == "Boss" and not context.repetition) or context.forcetrigger then
                SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", scaling_message = {message = "+"..number_format(card.ability.left_mod)}})
            end
        else
            if context.being_inverted then
                SMODS.scale_card(card, {
                    ref_table = card.ability.extra,
                    ref_value = "xmult",
                    scalar_value = "xmult_mod"
                })
                card.ability.extra.upgraded = (card.ability.extra.upgraded or 0) + 1
                return {
                    prevent_inversion = true
                }
            end
            if context.joker_main then
                return {
                    xmult = card.ability.extra.xmult
                }
            end
        end
    end,
    loc_vars = function(self, q, card)
        if G.GAME.modifiers.entr_gfb then
            return {
                vars = {
                    card.ability.left,
                    card.ability.left_mod
                },
                key = "j_entr_searing_joke_gfb"
            }
        else
            return {
                vars = {
                    card.ability.extra.xmult,
                    card.ability.extra.xmult_mod
                }
            }
        end
    end,
    needs_use_button = function()
        return G.GAME.modifiers.entr_gfb
    end,
    use = function(self, card)
        card.ability.left = card.ability.left -1
        Entropy.flip_then(G.hand.cards, function(v)
            if v:get_id() == 2 or v:get_id() == 3 then
                SMODS.destroy_cards(v)
            else
                SMODS.modify_rank(v, -1)
            end
        end)
    end,
    can_use = function(self, card)
        return G.hand and #G.hand.cards > 0 and card.ability.left > 0
    end,
    attributes = {"inverted", "xmult", "scaling"},
}

local function _render_sprite(canvas, x, y, pos)
        local quad = love.graphics.newQuad(43 * pos.x, 9 * pos.y, 43, 9, 142, 95)
        canvas:renderTo(function() love.graphics.draw(G.ASSET_ATLAS["entr_searing"].image, quad, x, y, 0, 1, 1, 0, 0) end)
end

SMODS.draw_ignore_keys.searing_sprite = true
SMODS.DrawStep({
	key = "searing_joke",
	order = 25,
	func = function(self)
        if G.GAME.modifiers.entr_gfb then return end
        if type(self.ability.extra) ~= "table" then return end
        local card = self.ability.glitched_crown and self.ability.glitched_crown[self.glitched_index] or self.config.center_key
        if card ~= "j_entr_searing_joke" or not G.P_CENTERS[card].discovered or not G.P_CENTERS[card].unlocked then return end


        if not self.children.searing_sprite then 
            self.children.searing_sprite = SMODS.CanvasSprite(
                {X=0, Y=0, W=71, H=95, canvasW=71, canvasH=95, canvasScale=1}
            )
        end
        local sprite = self.children.searing_sprite
        love.graphics.push()
        love.graphics.origin()
        sprite.canvas:renderTo(love.graphics.clear, 0, 0, 0, 0)
        local str = number_format(math.floor(self.ability.extra.xmult)):gsub("%,", "")
        local len = string.len(str)
        _render_sprite(sprite.canvas, 8 + 1 * (len - 1), 58, {x = 0, y = math.min(len-1, 4)})
        local char_map = {
            ["0"] = {x = 0, y = 9},
            ["1"] = {x = 0, y = 5},
            ["2"] = {x = 0, y = 6},
            ["3"] = {x = 0, y = 7},
            ["4"] = {x = 0, y = 8},
            ["5"] = {x = 1, y = 5},
            ["6"] = {x = 1, y = 6},
            ["7"] = {x = 1, y = 7},
            ["8"] = {x = 1, y = 8},
            ["9"] = {x = 1, y = 9},
        }

        local u_char_map = {
            ["0"] = {x = 3, y = 3},
            ["1"] = {x = 1, y = 2},
            ["2"] = {x = 1, y = 3},
            ["3"] = {x = 1, y = 4},
            ["4"] = {x = 2, y = 1},
            ["5"] = {x = 2, y = 2},
            ["6"] = {x = 2, y = 3},
            ["7"] = {x = 2, y = 4},
            ["8"] = {x = 3, y = 1},
            ["9"] = {x = 3, y = 2},
        }
        for i = 1, len do
            _render_sprite(sprite.canvas, 8 + 1 * (len - 1) - 3 * ((len - i)), 58, char_map[str:sub(i,i)] or {x = 999, y = 999})
        end


        local str2 = number_format(self.ability.extra.upgraded or 0):gsub("%,", "")
        local len2 = string.len(str2)

        local width = 26 + (self.ability.extra.upgraded and (6 + 8 * len2) or 0)

        _render_sprite(sprite.canvas, 35 - width/2, 5, {x = 1, y = self.ability.extra.upgraded and 1 or 0})
        if self.ability.extra.upgraded then
            for i = 1, len2 do
                _render_sprite(sprite.canvas, 35 + 25 - width/2 + (7 * i), 5, u_char_map[str2:sub(i,i)] or {x = 999, y = 999})
            end
        end
        love.graphics.pop()

        sprite.role.draw_major = self
        sprite:draw_shader("dissolve", nil, nil, nil, self.children.center)
	end,
	conditions = { vortex = false, facing = "front" },
})

Entropy.Joker{
    order = 138,
    
    key = "ancestral_recall",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 6, y = 17},
    atlas = "jokers",
    config = {
        left = 1,
        left_mod = 1,
        hands = -1
    },
    dependencies = {
        items = {
            "set_entr_actives",
        }
    },
    loc_vars = function(self, q, card)
        q[#q+1] = {set = "Other", key = "entr_marked"}
        return {
            vars = {
                card.ability.left,
                card.ability.left_mod,
                card.ability.hands
            }
        }
    end,
    demicoloncompat = true,
    calculate = function(self, card, context)
        if (context.end_of_round and not context.blueprint and not context.individual and not context.repetition) or context.forcetrigger then
            SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", scaling_message = {message = "+"..number_format(card.ability.left_mod)}})
        end
    end,
    can_use = function(self, card)
        local cards = G.deck.cards
        return to_big(card.ability.left) > to_big(0) and #cards > 0 and G.GAME.blind and G.GAME.blind.in_blind
    end,
    use = function(self, card)
        card.ability.left = card.ability.left - 1
        for i = 1, math.min(3, #G.deck.cards) do
            local card = draw_card(G.deck, G.hand, i*100/math.max(3, #G.deck.cards),'up', true)
            local ind = i
            G.E_MANAGER:add_event(Event{
                trigger = "after",
                func = function()
                    local card = SMODS.drawn_cards[ind]
                    if card then
                        card:juice_up()
                        card.ability.entr_marked = true
                    end
                    return true
                end
            })
        end
        ease_hands_played(card.ability.hands)
        if G.GAME.current_round.hands_left <= -card.ability.hands then
            end_round()
        end
        G.E_MANAGER:add_event(Event{
            trigger = "after",
            func = function()
                SMODS.drawn_cards = {}
                return true
            end
        })
    end,
    generate_ui = function(self, info_queue, card, desc_nodes, specific_vars, full_UI_table)
        SMODS.Center.generate_ui(self, info_queue, card, desc_nodes, specific_vars, full_UI_table)
        
        local cards = {}
        for i, v in pairs(G.I.CARD) do
            if v.ability and v.ability.entr_marked and not v.ability.entr_marked_bypass then
                local s = v:save()
                local c = Card(0,0, G.CARD_W, G.CARD_H, pseudorandom_element(G.P_CARDS,pseudoseed("")), G.P_CENTERS.c_base)
                c:load(s)
                c.ability = SMODS.shallow_copy(c.ability)
                c.ability.entr_marked_bypass = true
                v.ability.entr_marked_bypass = nil                
                table.insert(cards, c)
            end
        end
        if #cards > 0 then
            Entropy.card_area_preview(G.entrCardsPrev, desc_nodes, {
                cards = cards,
                override = true,
                w = 2.2,
                h = 0.6,
                ml = 0,
                scale = 0.5,
                func_delay = 1.0,
            })
        end
    end,
    attributes = {"modify_card", "scaling", "hands", "activated"},
}

Entropy.Joker{
    order = 139,
    
    key = "planetarium",
    rarity = 3,
    cost = 8,
    eternal_compat = true,
    pos = {x = 0, y = 0},
    soul_pos = {x = 4, y = 2},
    atlas = "planetarium",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {hand = "none", fullhouse_dollars = 4, fullhouse_mult = 1.5, threeoak_mult = 2, fouroak_discards = 1, straight_dollars = 2,flushhouse_gain = 0.1, flushhouse_loss = 0.1, flushhouse_mult = 1}
    },
    calculate = function(self, card, context)
        if context.using_consumeable then
            local v = context.consumeable
            local hand = v.ability.hand_type or v.ability.handname
            if hand then
                card.ability.extra.hand = hand
                card:juice_up()
            end
        end
        if card.ability.extra.hand == "High Card" then
            if context.after then
                for i, v in pairs(G.play.cards) do
                    local c = v
                    if not SMODS.in_scoring(v, context.scoring_hand) then
                        G.E_MANAGER:add_event(Event{
                            func = function()
                                c:juice_up()
                                c.ability.entr_marked = true
                                return true
                            end
                        })
                    end
                end
            end
            if context.evaluate_poker_hand then
                return {
                    replace_scoring_hand = "High Card",
                    replace_scoring_name = "High Card"
                }
            end
        end
        if card.ability.extra.hand == "Three of a Kind" then
            if context.individual and context.cardarea == G.play then
                local sum = 0
                for i, v in pairs(G.play.cards) do
                    local id = v:get_id()
                    if id > 0 then sum = sum + id end
                end
                if sum % 3 == 0 then
                    return {
                        xmult = card.ability.extra.threeoak_mult
                    }
                end
            end
        end
        if card.ability.extra.hand == "Straight" then
            if context.joker_main then
                local ranks = {}
                local nranks = 0
                for i, v in pairs(G.play.cards) do
                    local id = v:get_id()
                    if id < 0 then id = 0 end
                    if not ranks[id] then
                        ranks[id] = true
                        nranks = nranks + 1
                    end
                end
                return {
                    dollars = card.ability.extra.straight_dollars * nranks
                }
            end
        end
        if card.ability.extra.hand == "Full House" then
            if context.individual and context.cardarea == G.play then
                local ids = {}
                for i, v in pairs(context.scoring_hand) do
                    local id = v:get_id()
                    if id > 0 then ids[#ids+1] = id end
                end
                table.sort(ids)
                return {
                    dollars = context.other_card:get_id() == ids[1] and card.ability.extra.fullhouse_dollars or nil,
                    xmult = context.other_card:get_id() == ids[#ids] and card.ability.extra.fullhouse_mult or nil
                }
            end
        end
        if card.ability.extra.hand == "Straight Flush" then
            if context.before and G.GAME.blind_on_deck == "Boss" then
                return {
                    level_up = -1
                }
            end
        end
        if card.ability.extra.hand == "Four of a Kind" then
            if context.joker_main then
                ease_discard(card.ability.extra.fouroak_discards)
                return {
                    message = localize("k_plus_discard"),
                    colour = G.C.RED
                }
            end
        end
        if card.ability.extra.hand == "Flush House" then
            if context.joker_main then
                return {
                    xmult = card.ability.extra.flushhouse_mult
                }
            end
            if context.end_of_round and not context.individual and not context.repetition and not context.blueprint then
                local num_pairs = 0
                local suits = 0
                local suit_map = {}
                for i, v in pairs(SMODS.Suits) do
                    for _, c in pairs(context.scoring_hand) do
                        if c:is_suit(i) and not suit_map[i] then
                            suit_map[i] = true
                            suits = suits + 1  
                         end
                    end
                end
                for i = 1, #context.scoring_hand - 1 do
                    for j = i + 1, #context.scoring_hand do
                        local m, n = context.scoring_hand[i], context.scoring_hand[j]
                        if m:get_id() == n:get_id() then
                            num_pairs = num_pairs + 1
                        end
                    end
                end
                if num_pairs > 0 then
                    SMODS.scale_card(card, {
                        ref_table = card.ability.extra,
                        ref_value = "flushhouse_mult",
                        scalar_value = "flushhouse_gain",
                        message_key = "a_xmult",
                        message_colour = G.C.RED,
                        operation = function(ref_table, ref_value, initial, change)
                            ref_table[ref_value] = initial + change * num_pairs
                        end
                    })
                end
                if suits > 0 then
                    SMODS.scale_card(card, {
                        ref_table = card.ability.extra,
                        ref_value = "flushhouse_mult",
                        scalar_value = "flushhouse_loss",
                        operation = function(ref_table, ref_value, initial, change)
                            ref_table[ref_value] = initial - change * suits
                        end,
                        message_key = "a_xmult",
                        message_colour = G.C.RED
                    })
                end
            end
        end
        if card.ability.extra.hand == "Five of a Kind" then
            if context.before and #G.play.cards == 5 then
                Entropy.flip_then(context.scoring_hand, function(c)
                    Entropy.randomise_once(c, {
                        "Enhancement","Enhancement","Enhancement","Enhancement",
                        "Seal",
                        "Edition","Edition",
                    }, "entr_planetarium_5oak", true)
                    Entropy.randomize_rank_suit(c, nil, true, "entr_planetarium_5oak_suit")
                end)
            end
        end
        if card.ability.extra.hand == "Flush Five" then
            if context.end_of_round then
                card.ability.extra.inactive = nil
            end
        end
        if card.ability.extra.hand == "entr_derivative" then
            if context.end_of_round and not context.repetition and not context.individual and not context.blueprint then
                local c = G.hand.cards[1]
                if c then
                    Entropy.flip_then({c}, function(c)
                        SMODS.change_base(c, "entr_nilsuit", "entr_nilrank")
                    end)
                end
            end
            if context.repetition and (context.cardarea == G.play or context.cardarea == G.hand) and Entropy.true_suitless(context.other_card) then
                return {
                    repetitions = 1
                }
            end
        end
        if Entropy.Planetarium[card.ability.extra.hand] and Entropy.Planetarium[card.ability.extra.hand].calculate then
            return Entropy.Planetarium[card.ability.extra.hand].calculate(self, card, context)
        end
    end,
    loc_vars = function(self, q, card)
        if card.ability.extra.hand == "High Card" then
            q[#q+1] = {set = "Other", key = "entr_marked"}
        end
        local vars = {}
        if card.ability.extra.hand == "Three of a Kind" then
            vars = {
                card.ability.extra.threeoak_mult
            }
        end
        if card.ability.extra.hand == "Straight" then
            vars = {
                card.ability.extra.straight_dollars
            }
        end
        if card.ability.extra.hand == "Full House" then
            vars = {
                card.ability.extra.fullhouse_dollars,
                card.ability.extra.fullhouse_mult
            }
        end
        if card.ability.extra.hand == "Four of a Kind" then
            vars = {
                card.ability.extra.fouroak_discards
            }
        end
        if card.ability.extra.hand == "Flush House" then
            vars = {
                card.ability.extra.flushhouse_gain,
                card.ability.extra.flushhouse_loss,
                card.ability.extra.flushhouse_mult
            }
        end
        if Entropy.Planetarium[card.ability.extra.hand] and Entropy.Planetarium[card.ability.extra.hand].loc_vars then
            vars = Entropy.Planetarium[card.ability.extra.hand].loc_vars(self, q, card)
        end
        return {
            key = card.ability.extra.hand ~= "none" and "j_entr_planetarium_"..card.ability.extra.hand or nil,
            vars = vars
        }
    end,
    generate_ui = function(self, info_queue, card, desc_nodes, specific_vars, full_UI_table)
        SMODS.Center.generate_ui(self, info_queue, card, desc_nodes, specific_vars, full_UI_table)
        if card.ability.extra.hand == "High Card" then
            
            local cards = {}
            for i, v in pairs(G.I.CARD) do
                if v.ability and v.ability.entr_marked and not v.ability.entr_marked_bypass then
                    local s = v:save()
                    local c = Card(0,0, G.CARD_W, G.CARD_H, pseudorandom_element(G.P_CARDS,pseudoseed("")), G.P_CENTERS.c_base)
                    c:load(s)
                    c.ability = SMODS.shallow_copy(c.ability)
                    c.ability.entr_marked_bypass = true
                    v.ability.entr_marked_bypass = nil                
                    table.insert(cards, c)
                end
            end
            if #cards > 0 then
                Entropy.card_area_preview(G.entrCardsPrev, full_UI_table.multi_box[1], {
                    cards = cards,
                    override = true,
                    w = 2.2,
                    h = 0.6,
                    ml = 0,
                    scale = 0.5,
                    func_delay = 1.0,
                })
            end
        end
    end,
    attributes = {
        "star", "planet", "hand_type", "modify_card",
        "xmult", "hands", "rank", "economy", "suit",
        "discard", "scaling", "generation", "nilsuit",
        "nilrank", "space"
    },
}

SMODS.DrawStep({
	key = "planetarium",
	order = 25,
	func = function(self)
        if self.config.center.key ~= "j_entr_planetarium" then return end
        local pos_map = {
            ["High Card"] = {x = 1, y = 0},
            ["Pair"] = {x = 2, y = 0},
            ["Two Pair"] = {x = 3, y = 0},
            ["Three of a Kind"] = {x = 4, y = 0},
            ["Straight"] = {x = 5, y = 0},

            ["Flush"] = {x = 1, y = 1},
            ["Full House"] = {x = 2, y = 1},
            ["Four of a Kind"] = {x = 3, y = 1},
            ["Straight Flush"] = {x = 4, y = 1},
            ["Five of a Kind"] = {x = 5, y = 1},

            ["Flush House"] = {x = 1, y = 2},
            ["Flush Five"] = {x = 2, y = 2},
            ["entr_derivative"] = {x = 3, y = 2},
        }
        local comp = Entropy.Planetarium[self.ability.extra.hand] or {}
        local pos = comp.pos or pos_map[self.ability.extra.hand] or {x = 4, y = 2}
        if self.ability.extra.pos ~= pos and pos then
            self.ability.extra.pos = pos
            self.children.floating_sprite.atlas = comp.atlas or G.ASSET_ATLAS["entr_planetarium"]
            self.children.floating_sprite:set_sprite_pos(pos)
            self.children.floating_sprite:reset()
        end
	end,
	conditions = { vortex = false, facing = "front" },
})

Entropy.Joker{
    order = 140,
    
    key = "double_down",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 8, y = 17},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    calculate = function(self, card, context)
        if context.individual and not context.other_card.entr_will_be_marked and context.other_card.config.center_key == "m_lucky" and context.cardarea == G.play then
            local c = context.other_card
            c.entr_will_be_marked = true
            G.E_MANAGER:add_event(Event{
                func = function()
                    c.ability.entr_marked = true
                    c.entr_will_be_marked = nil
                    return true
                end
            })
            return nil, true
        end
    end,
    loc_vars = function(self, q)
        q[#q+1] = G.P_CENTERS.m_lucky
        q[#q+1] = {set = "Other", key = "entr_marked"}
    end,
    slib_credits = {
        idea = {"cassknows"}
    },
    generate_ui = function(self, info_queue, card, desc_nodes, specific_vars, full_UI_table)
        SMODS.Center.generate_ui(self, info_queue, card, desc_nodes, specific_vars, full_UI_table)
        
        local cards = {}
        for i, v in pairs(G.I.CARD) do
            if v.ability and v.ability.entr_marked and not v.ability.entr_marked_bypass then
                local s = v:save()
                local c = Card(0,0, G.CARD_W, G.CARD_H, pseudorandom_element(G.P_CARDS,pseudoseed("")), G.P_CENTERS.c_base)
                c:load(s)
                c.ability = SMODS.shallow_copy(c.ability)
                c.ability.entr_marked_bypass = true
                v.ability.entr_marked_bypass = nil                
                table.insert(cards, c)
            end
        end
        if #cards > 0 then
            Entropy.card_area_preview(G.entrCardsPrev, desc_nodes, {
                cards = cards,
                override = true,
                w = 2.2,
                h = 0.6,
                ml = 0,
                scale = 0.5,
                func_delay = 1.0,
            })
        end
    end,
    attributes = {"enhancements", "modify_card"},
}

Entropy.Joker{
    order = 141,
    
    key = "wormwood",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 7, y = 17},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        minus_mult = -0.25,
        asc_power_chips = 0.05
    },
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.minus_mult
            return {
                plus_asc = card.ability.asc_power_chips * context.other_card:get_chip_bonus()
            }
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.minus_mult,
                card.ability.asc_power_chips
            }
        }
    end,
    slib_credits = {
        art = {"pangaea47"}
    },
    attributes = {"asc", "mult"},
}

Entropy.Joker{
    order = 142,
    
    key = "midnight",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x=7,y=19},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        asc = 0.5
    },
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and (context.other_card:is_suit("Diamonds") or context.other_card:is_suit("Spades")) then
            return {
                plus_asc = card.ability.asc
            }
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.asc
            }
        }
    end,
    attributes = {"asc", "suit", "diamonds", "spades"},
}

Entropy.Joker{
    order = 143,
    
    key = "quadrants",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    blueprint_compat = true,
    pos = {x=4,y=19},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            asc = 0.5,
            mult = 5,
            chips = 20,
            dollars = 2
        }
    },
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local suits = 0
            for i, v in pairs(context.scoring_hand) do
                for i, s in pairs(SMODS.Suits) do
                    if v:is_suit(i) then
                        suits = suits + 1
                    end
                end
            end
            if suits > 0 then
                local ret = {}
                local bonuses = {
                    Hearts = "mult",
                    Diamonds = "dollars",
                    Spades = "chips",
                    Clubs = "asc"
                }
                local rets = {}
                for i, v in pairs(bonuses) do
                    if context.other_card:is_suit(i) then ret[v] = card.ability.extra[v] end
                end
                return ret
            end
        end
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.mult,
                card.ability.extra.dollars,
                card.ability.extra.chips,
                card.ability.extra.asc
            }
        }
    end,
    attributes = {"asc", "economy", "chips", "mult", "suit", "diamonds", "spades", "hearts", "clubs", "hand_type"},
}

function get_X_suit(cards, x)
    for s, _ in pairs(SMODS.Suits) do
        local suits = 0
        for i, c in pairs(cards) do
            if c:is_suit(s) then
                suits = suits + 1 
            end
        end
        if suits >= x then
            return cards
        end
    end
    return {}
end

Entropy.Joker{
    order = 144,
    
    key = "complexion",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x=9,y=19},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    calculate = function(self, card, context)
        if context.evaluate_poker_hand then
            if context.scoring_name == "Pair" or context.scoring_name == "Three of a Kind" or context.scoring_name == "Four of a Kind" then
                if next(get_X_suit(context.scoring_hand, #context.scoring_hand)) then
                    return {
                        replace_display_name = (context.scoring_name == "Pair" and "Flush Two")
                        or (context.scoring_name == "Three of a Kind" and "Flush Three") or "Flush Four"
                    }
                end
            end
        end
    end,
    attributes = {"hand_type", "suit"}
}

local asc_hand = Spectrallib.ascend
function Spectrallib.ascend(...)
    local mul = 1
    if next(SMODS.find_card("j_entr_complexion")) then
        local cards = G.STATE == G.STATES.SELECTING_HAND and G.hand.highlighted or G.play.cards
        local text, _, _, scoring_hand = G.FUNCS.get_poker_hand_info(cards)
        if next(get_X_suit(scoring_hand, #scoring_hand)) and
            (text == "Pair" or text == "Three of a Kind" or text == "Four of a Kind")
        then
            for i, v in pairs(SMODS.find_card("j_entr_complexion")) do
                mul = mul * ((text == "Pair" and 2) or (text == "Three of a Kind" and 2.5) or 3)
            end
        end
    end
    return asc_hand(...) * mul
end

Entropy.Joker{
    order = 145,
    
    key = "hidden_gem",
    rarity = 2,
    cost = 8,
    eternal_compat = true,
    pos = {x = 7, y = 18},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            retriggers = 1
        }
    },
    loc_vars = function(self, q, card)
        if not card.ability.entr_temp_retriggers  then
            q[#q+1] = {set = "Other", key = "temporary_retriggers_tooltip_gem", vars = {}}
        end
        return {
            vars = {
                card.ability.extra.retriggers
            }
        }
    end,
    calculate = function(self, card, context)
        if context.setting_blind then
            local cards = {}
            for i, v in pairs(G.jokers.cards) do
                if v ~= card then
                    cards[#cards+1] = v
                end
            end
            pseudoshuffle(cards, pseudoseed("entr_hidden_gem"))
            if cards[1] then
                cards[1].ability.entr_temp_retriggers = (cards[1].ability.entr_temp_retriggers or 0) + card.ability.extra.retriggers
                return {func = function()SMODS.calculate_effect({card = cards[1], message = localize("k_upgrade_ex")})end}
            end
        end
    end,
    attributes = {"joker", "retrigger"}
}

Entropy.Joker{
    order = 146,
    
    key = "bloodletting",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = Entropy.config.hide_sensitive_content and {x=3,y=19} or {x=0,y=18},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            mult = 0,
            mult_mod = 5,
            mult_transform = -15
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.mult,
                card.ability.extra.mult_mod,
                card.ability.extra.mult_transform
            }
        }
    end,
    calculate = function(self, card, context)
        if context.setting_blind then
            if card.ability.extra.mult > (card.ability.extra.mult_transform + card.ability.extra.mult_mod) then
                SMODS.scale_card(card, {
                    ref_table = card.ability.extra,
                    ref_value = "mult",
                    scalar_value = "mult_mod",
                    operation = "-"
                })
            else    
                Entropy.flip_then({card}, function(c)
                    local mult = c.ability.extra.mult
                    c:set_ability(SMODS.poll_object({rarity = 3, set = "Joker"}))
                    c.ability.perma_mult = mult - card.ability.extra.mult_mod
                end)
            end
            return nil, true
        end
        if context.joker_main then
            return {
                mult = card.ability.extra.mult
            }
        end
    end,
    attributes = {"joker", "retrigger"}
}


Entropy.Joker{
    order = 147,
    key = "paranoia",
    rarity = 3,
    cost = 10,
    eternal_compat = true,
    pos = {x = 1, y = 18},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            jokers = 3
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.jokers
            }
        }
    end,
    calculate = function(self, card, context)
        if context.setting_blind then
            for i = 1, card.ability.extra.jokers do
                SMODS.add_card({
                    set = "Joker",
                    key_append = "entr_paranoia"
                }).ability.void_temporary = true
            end
            return nil, true
        end
    end,
    attributes = {"joker", "generation"}
}

SMODS.DrawStep({
	key = "paranoia",
	order = 9e10,
	func = function(self)
        local card = self.ability.glitched_crown and self.ability.glitched_crown[self.glitched_index] or self.config.center_key
        if (card ~= "j_entr_paranoia") or not G.P_CENTERS[card].discovered or not G.P_CENTERS[card].unlocked then return end


        if not self.children.center2 then 
            self.children.center2 = SMODS.create_sprite(0, 0, G.CARD_W, G.CARD_H, "entr_jokers", {x=G.P_CENTERS[card].pos.x+1, y = 18})
        end
        local sprite = self.children.center2
        sprite.VT.x = math.floor(self.children.center.VT.x*3.5)/3.5
        sprite.VT.y = math.floor(self.children.center.VT.y*3.5)/3.5
        sprite.VT.r = 0
        sprite:draw_shader("dissolve", nil, nil, true, nil, nil, 0)
	end,
	conditions = { vortex = false, facing = "front" },
})

Entropy.Joker{
    order = 148,
    key = "antiasceticism",
    rarity = 2,
    cost = 10,
    eternal_compat = true,
    pos = {x=6,y=19},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            dollars = 25,
            threshold = 5
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.dollars,
                card.ability.extra.threshold
            }
        }
    end,
    calculate = function(self, card, context)
        if context.money_altered then
            if G.GAME.dollars + context.amount <= card.ability.extra.threshold 
            and not card.ability.isnt_active 
            and context.amount < 0 
            and G.GAME.dollars >= card.ability.extra.threshold then
                card.ability.isnt_active = true
                return {
                    dollars = card.ability.extra.dollars
                }
            end
        end
        if context.ante_end then
            card.ability.isnt_active = nil
        end
    end,
    attributes = {"joker", "economy"}
}

Entropy.Joker{
    order = 149,
    key = "record_disc",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 3, y = 18},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            times_left = 5
        }
    },
    calculate = function(self, card, context)
       if context.money_altered then
            card.ability.extra.times_left = card.ability.extra.times_left - 1
            if card.ability.extra.times_left <= 0 then
                Entropy.flip_then({card}, function(c) 
                    c:set_ability(G.P_CENTERS.j_entr_broken_record_disc)
                    play_sound("entr_record_scratch")
                end)
            else
                return {
                    message = 5-card.ability.extra.times_left.."/"..5
                }
            end
       end
    end,
    pixel_size = {w = 71, h = 71},
    attributes = {"joker"},
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.times_left
            }
        }
    end,
}

Entropy.Joker{
    order = 149,
    key = "broken_record_disc",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 4, y = 18},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            dollars = 20
        }
    },
    calculate = function(self, card, context)
       if context.selling_self then
            return {
                dollars = -card.ability.extra.dollars
            }
       end
    end,
    pixel_size = {w = 71, h = 71},
    attributes = {"joker"},
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.dollars
            }
        }
    end,
    no_collection = true,
    in_pool = function() return false end
}

Entropy.Joker{
    order = 150,
    key = "exhume",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x = 5, y = 18},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            odds = 2
        }
    },
    loc_vars = function(self, q, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds)
        return {
            vars = {
                numerator,
                denominator
            },
        }
    end,
    attributes = {"discard", "chance"}
}

Entropy.Joker{
    order = 151,
    key = "projesterone",
    rarity = 2,
    cost = 7,
    eternal_compat = true,
    pos = {x = 6, y = 18},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            asc_gain = 0.02,
            asc = 0
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.asc_gain,
                card.ability.extra.asc
            },
        }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            if context.other_card:get_id() == 12 then
                SMODS.scale_card(card, {
                    ref_table = card.ability.extra,
                    ref_value = "asc",
                    scalar_value = "asc_gain"
                })
                return nil, true
            elseif card.ability.extra.asc > 0 then
                context.other_card.ability.perma_plus_asc = (context.other_card.ability.perma_plus_asc or 0) + card.ability.extra.asc
                card.ability.extra.asc = 0
                return {
                    message = localize("k_upgrade_ex"),
                    message_card = context.other_card,
                    card = card
                }
            end
        end
    end,
    attributes = {"asc_pow", "queen", "rank"}
}

Entropy.Joker{
    order = 152,
    key = "catastrophe",
    rarity = 2,
    cost = 10,
    eternal_compat = true,
    pos = {x = 8, y = 18},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    loc_vars = function(_, q, _) 
        q[#q+1] = G.P_CENTERS.e_negative
    end,
    calculate = function(self, card, context)
        if context.setting_blind then
            local jokers = {}
            for i, v in pairs(G.jokers.cards) do
                if not v.getting_sliced and v ~= card and not SMODS.is_eternal(v) then
                    jokers[#jokers+1] = v
                end
            end
            pseudoshuffle(jokers, pseudoseed("entr_catastrophe"))
            if jokers[1] then
                SMODS.destroy_cards(jokers[1])
                jokers[1].getting_sliced = true
            end
            local type = "Star"
            if pseudorandom(pseudoseed("entr_catastrophe_type")) > 0.5 then 
                type = "Planet"
            end
            SMODS.add_card {
                set = type,
                edition = "e_negative",
                area = G.consumeables
            }
            return nil, true
        end
    end,
    attributes = {"joker", "star", "planet", "space"}
}

Entropy.Joker{
    order = 153,
    key = "lycanthropy",
    rarity = 3,
    cost = 10,
    eternal_compat = true,
    pos = {x = 9, y = 18},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            xmult = 1.25
        }
    },
    loc_vars = function(_, q, card) 
        q[#q+1] = G.P_CENTERS.m_mult
        return {
            vars = {
                card.ability.extra.xmult
            }
        }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and SMODS.has_enhancement(context.other_card, "m_mult") then
            return {
                xmult = card.ability.extra.xmult
            }
        end
    end,
    attributes = {"joker", "xmult", "enhancement"},
    in_pool = function()
        for i, v in pairs(G.playing_cards) do
            if SMODS.has_enhancement(v, "m_mult") then return true end
        end
        return false
    end
}

-- Entropy.Joker{
--     order = 154,
--     key = "shovel",
--     rarity = 2,
--     cost = 10,
--     eternal_compat = true,
--     pos = {x = 9, y = 18},
--     atlas = "jokers",
--     config = {
--         left = 1,
--         left_mod = 1
--     },
--     dependencies = {
--         items = {
--             "set_entr_actives",
--         }
--     },
--     loc_vars = function(self, q, card)
--         return {
--             vars = {
--                 card.ability.left,
--                 card.ability.left_mod
--             }
--         }
--     end,
--     demicoloncompat = true,
--     calculate = function(self, card, context)
--         if (context.end_of_round and not context.blueprint and not context.individual and G.GAME.blind_on_deck == "Boss" and not context.repetition) or context.forcetrigger then
--             SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", scaling_message = {message = "+"..number_format(card.ability.left_mod)}})
--         end
--     end,
--     can_use = function(self, card)
--         return to_big(card.ability.left) > to_big(0) and G.GAME.blind.in_blind
--     end,
--     use = function(self, card)
--         card.ability.left = card.ability.left - 1
--         if G.GAME.blind.config.blind.boss then
--             G.entr_shovelarea = CardArea(
--                 G.discard.T.x,
--                 G.discard.T.y,
--                 G.discard.T.w,
--                 G.discard.T.h,
--                 { type = "discard", card_limit = 1e100 }
--             )
--             local hand_count = #G.hand.cards
--             for i = 1, hand_count do
--                 draw_card(G.hand, G.entr_shovelarea, i * 100 / hand_count, "down", nil, nil, 0.07)
--             end
--             G.GAME.current_round.jokers_purchased = 0
--             G.STATE = G.STATES.SHOP
--             G.GAME.SHOVEL_SHOP = true
--             G.GAME.SHOVEL_SHOP_COMPLETE = 0
--             G.GAME.shop_free = nil
--             G.GAME.shop_d6ed = nil
--             G.STATE_COMPLETE = false
--             G.GAME.current_round.used_packs = {}
--         else
--             G.E_MANAGER:add_event(
--                 Event({
--                     trigger = "immediate",
--                     func = function()
--                         if G.STATE ~= G.STATES.SELECTING_HAND then
--                             return false
--                         end
--                         G.GAME.chips =  G.GAME.blind.chips
--                         G.STATE = G.STATES.HAND_PLAYED
--                         G.STATE_COMPLETE = true
--                         end_round()
--                         return true
--                     end,
--                 }),
--             "other")
--         end
--     end,
--     attributes = {"activated", "modify_card", "scaling"},
-- }

-- local gfts = G.FUNCS.toggle_shop
-- G.FUNCS.toggle_shop = function(e)
--     if G.GAME.SHOVEL_SHOP then
--         G.E_MANAGER:add_event(Event({
--             trigger = "after",
--             delay = 0.5,
--             func = function()
--                 G.GAME.SHOVEL_SHOP = false
--                 return true
--             end,
--         }))
--         if G.entr_shovelarea then
--             local hand_count = #G.entr_shovelarea.cards
--             for i = 1, hand_count do
--                 draw_card(G.entr_shovelarea, G.hand, i * 100 / hand_count, "up", true)
--             end
--         end
--         G.E_MANAGER:add_event(Event({
--             trigger = "after",
--             delay = 0.5,
--             func = function()
--                 G.GAME.current_round.used_packs = {}
--                 if G.entr_shovelarea then
--                     G.entr_shovelarea:remove()
--                 end
--                 G.entr_shovelarea = nil
--                 G.STATE = G.STATES.SELECTING_HAND
--                 return true
--             end,
--         }))
--     else
--         gfts(e)
--     end
-- end
-- local gus = Game.update_shop
-- function Game:update_shop(dt)
--     gus(self, dt)
--     if G.GAME.SHOVEL_SHOP and G.STATE_COMPLETE and G.GAME.SHOVEL_SHOP_COMPLETE < 60 then
--         G.shop.alignment.offset.y = -5.3
--         G.GAME.SHOVEL_SHOP_COMPLETE = G.GAME.SHOVEL_SHOP_COMPLETE + 1
--     end
-- end
-- local guis = G.UIDEF.shop
-- function G.UIDEF.shop()
--     local ret = guis()
--     if G.GAME.SHOVEL_SHOP then
--         G.SHOP_SIGN:remove()
--         G.SHOP_SIGN = {
--             remove = function()
--                 return true
--             end,
--             alignment = { offset = { y = 0 } },
--         }
--     end
--     return ret
-- end

Entropy.Joker{
    order = 154,
    key = "hypnotism",
    rarity = 2,
    cost = 10,
    eternal_compat = true,
    pos = {x = 0, y = 0},
    atlas = "hypnotism",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"joker", "passive"},
    demicoloncompat = false,
    blueprint_compat = false,
    loc_vars = function()
        return {
            key = G.GAME.modifiers.entr_gfb and "j_entr_hypnotism_gfb"
        }
    end
}

Entropy.Joker{
    order = 155,
    key = "demon_form",
    rarity = 3,
    cost = 10,
    eternal_compat = true,
    pos = {x=5,y=19},
    atlas = "jokers",
    config = {
        extra = {
            asc_pow = 0.5
        }
    },
    loc_vars = function(_, _, card)
        return {
            vars = {
                card.ability.extra.asc_pow
            }
        }
    end,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"enhanced", "asc_pow"},
    demicoloncompat = false,
    calculate = function(self, card, context)
        if context.before and not card.ability.triggered and #G.play.cards > 0 then
            local enh = {}
            for i, v in pairs(G.play.cards) do
                if v.ability.set == "Enhanced" then
                    enh[#enh+1] = v
                end
            end
            if #enh > 0 then
                card.ability.triggered = true
                Entropy.flip_then({enh[1]}, function(c)
                    c.ability.slib_perma_h_plus_asc = (c.ability.slib_perma_h_plus_asc or 0) + card.ability.extra.asc_pow
                end)
                SMODS.calculate_effect{card = enh[1], message = localize("k_upgrade_ex")}
            end
            return nil, true
        end
        if context.end_of_round and context.main_eval then
            card.ability.triggered = nil
        end
    end
}

Entropy.Joker{
    order = 156,
    key = "broken_god",
    rarity = 2,
    cost = 10,
    eternal_compat = true,
    pos = {x=8,y=19},
    atlas = "jokers",
    config = {
        extra = {
            xmult = 1.5
        }
    },
    loc_vars = function(_, _, card)
        return {
            vars = {
                card.ability.extra.xmult
            }
        }
    end,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"xmult", "generation"},
    demicoloncompat = false,
    calculate = function(self, card, context)
        if context.setting_blind then
            G.playing_card = (G.playing_card and G.playing_card + 1) or 1
            local _card = copy_card(card, nil, nil, G.playing_card)
            _card:add_to_deck()
            G.deck.config.card_limit = G.deck.config.card_limit + 1
            table.insert(G.playing_cards, _card)
            G.hand:emplace(_card)
            _card.states.visible = nil

            G.E_MANAGER:add_event(Event({
                func = function()
                    _card:start_materialize()
                    return true
                end
            })) 
            return {
                message = localize("k_copied_ex"),
                playing_cards_created = {_card}
            }
        end
        if context.individual and context.card == card and context.cardarea == G.play then
            return {
                xmult = card.ability.extra.xmult,
            }
        end
    end
}

Entropy.Joker{
    order = 157,
    key = "rivulet",
    rarity = 3,
    cost = 10,
    eternal_compat = true,
    pos = {x=0,y=20},
    atlas = "jokers",
    config = {
        extra = {
            xchips = 0.2,
            karma = 1,
            karma_max = 5
        }
    },
    loc_vars = function(_, _, card)
        return {
            vars = {
                1+card.ability.extra.xchips * (card.ability.extra.karma-1),
                card.ability.extra.karma,
                card.ability.extra.karma_max,
                card.ability.extra.xchips,
                elements = {
                    SMODS.create_sprite(0, 0, 1, 1, "entr_karma", {x=card.ability.extra.karma-1,y=0})
                }
            },
        }
    end,
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"xchips", "economy"},
    demicoloncompat = false,
    ease_karma = function(self, card, amount)
        if card.ability.extra.karma > 1 and amount < 0 then
            card.ability.extra.karma = card.ability.extra.karma - 1
            play_sound("entr_karma_loss"..(pseudorandom("entr_karma_sound") and "" or "_b"), nil, 2)
            card:juice_up()
        end
        if card.ability.extra.karma < card.ability.extra.karma_max and amount > 0 then
            card.ability.extra.karma = card.ability.extra.karma + 1
            play_sound("entr_karma_gain"..(pseudorandom("entr_karma_sound") and "" or "_b"), nil, 2)
            card:juice_up()
        end
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round then
            return {
                xchips = 1+card.ability.extra.xchips * (card.ability.extra.karma-1)
            }
        end
        if context.reroll_shop and G.GAME.current_round.times_rerolled == 3 then
            self:ease_karma(card, -1)
        end
        if context.modify_final_cashout then
            if G.GAME.interest_amount*math.min(math.floor(G.GAME.dollars/Spectrallib.interest_rate()), G.GAME.interest_cap/Spectrallib.interest_rate()) >= 
                G.GAME.interest_amount*G.GAME.interest_cap/Spectrallib.interest_rate() then
                self:ease_karma(card, 1)
            end
        end
    end
}

local reroll_shop = G.FUNCS.reroll_shop
function G.FUNCS.reroll_shop(e)
    G.GAME.current_round.times_rerolled = G.GAME.current_round.times_rerolled + 1
    return reroll_shop(e)
end

local end_round_ref = end_round
function end_round(...)
    G.GAME.current_round.times_rerolled = 0
    return end_round_ref(...)
end

Entropy.Joker{
    order = 158,
    key = "fragment",
    rarity = 2,
    cost = 10,
    eternal_compat = true,
    pos = {x=1,y=20},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"modify_card"},
    demicoloncompat = false,
    calculate = function(self, card, context)
        if context.card_being_destroyed and not context.card.edition and context.card:is_playing_card() then
            local c = {}
            for i, v in pairs({"e_foil", "e_holo"}) do
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                local _card = copy_card(context.card, nil, nil, G.playing_card)
                _card:add_to_deck()
                G.deck.config.card_limit = G.deck.config.card_limit + 1
                table.insert(G.playing_cards, _card)
                G.hand:emplace(_card)
                _card.states.visible = nil
                _card:set_edition(v)

                G.E_MANAGER:add_event(Event({
                    func = function()
                        _card:start_materialize()
                        return true
                    end
                })) 
                c[#c+1] = _card
            end
            return {
                message = localize("aaaaa"),
                colour = G.C.DARK_EDITION,
                playing_cards_created = c
            }
        end
    end
}

Entropy.Joker{
    order = 159,
    key = "bountiful_harvest",
    rarity = 3,
    cost = 10,
    eternal_compat = true,
    blueprint_compat = false,
    pos = {x=6,y=20},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"modify_card"},
    demicoloncompat = false,
    loc_vars = function(self, q, card)
        local n, d = SMODS.get_probability_vars(card, 1, 3)
        return {
            vars = {
                n, d
            }
        }
    end,
    calculate = function(self, card, context)
        if context.entr_add_boxes and context.center.set == "Joker" and context.card ~= card then
            Spectrallib.generate_ui_multiboxes({ {
                localized_text = G.localization.descriptions.Other.entr_bountiful_harvest,
                loc_vars = function()
                    local n, d = SMODS.get_probability_vars(card, 1, 3)
                    return {
                        vars = {
                            n, d
                        }
                    }
                end
            }})(context.center, context.info_queue, context.card, context.desc_nodes, context.specific_vars, context.full_UI_table, context.cfg)
        end
    end
}

local calculate_joker = Card.calculate_joker
function Card:calculate_joker(context)
    if next(SMODS.find_card("j_entr_bountiful_harvest")) and context.selling_card and context.card.config.center.set == "Joker" and context.card ~= self then
        local num = #SMODS.find_card("j_entr_bountiful_harvest") + (self.config.center.key == "j_entr_bountiful_harvest" and -1 or 0)
        if num > 0 then
            for i = 1, num do
                if SMODS.pseudorandom_probability(card, "entr_bountiful_harvest", 1, 3) then
                    add_tag(Tag(SMODS.poll_object{type = "Tag"}))
                    SMODS.calculate_effect{message = localize("k_plus_tag"), card = self}
                end
            end
        end
    end
    return calculate_joker(self, context)
end

Entropy.Joker{
    order = 160,
    key = "plushy",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x=2,y=20},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"economy"},
    demicoloncompat = true,
    config = {
        extra = {
            dollars = 3
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.dollars
            }
        }
    end,
    calculate = function(self, card, context)
        if (context.card_modified and context.other_card:is_playing_card()) or context.forcetrigger then
            return {
                dollars = card.ability.extra.dollars
            }
        end
    end
}

Entropy.Joker{
    order = 161,
    key = "survivorship_bias",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x=3,y=20},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"economy"},
    demicoloncompat = true,
    config = {
        extra = {
            chips = 0,
            chips_gain = 15
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.chips,
                card.ability.extra.chips_gain
            }
        }
    end,
    calculate = function(self, card, context)
        if context.selling_card and context.card ~= card then
            SMODS.scale_card(card, {
                ref_table = card.ability.extra,
                ref_value = "chips",
                scalar_value = "chips_gain"
            })
            return nil, true
        end
        if context.card_being_destroyed and context.card.config.center.set == "Joker" then
            G.GAME.banned_keys[context.card.config.center.key] = true
            return {
                message = localize("k_banished_ex"),
                colour = G.C.RED
            }
        end
    end
}

Entropy.Joker{
    order = 162,
    key = "rotisserie_chicken",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x=4,y=20},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    immutable = true,
    attributes = {"modify_card", "food"},
    demicoloncompat = true,
    config = {
        extra = {
            temp_values = 1.5
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.temp_values
            }
        }
    end,
    calculate = function(self, card, context)
        if context.card_rearranged then
            if context.old_order[card.last_pos+1] and context.old_order[card.last_pos+1].ability.already_big_and_fat then
                Spectrallib.manipulate(context.old_order[card.last_pos+1], {
                    value = 1/card.ability.extra.temp_values
                })
                context.old_order[card.last_pos+1].ability.already_big_and_fat = nil
            end
            local new_pos = context.card == card and context.new_pos or card.last_pos
            if card.area.cards[new_pos+1] and not card.area.cards[new_pos+1].ability.already_big_and_fat then
                G.E_MANAGER:add_event(Event{
                    func = function()
                        Spectrallib.manipulate(card.area.cards[new_pos+1], {
                            value = card.ability.extra.temp_values
                        })
                        return true
                    end
                })
                card.area.cards[new_pos+1].ability.already_big_and_fat = true
            end
            return nil, true
        end
        if context.card_emplaced then
            local pos = 0
            for i, v in pairs(card.area.cards) do if v == card then pos = i end end
            if card.area.cards[pos+1] ~= card and card.area.cards[pos+1] and not card.area.cards[pos+1].ability.already_big_and_fat then
                Spectrallib.manipulate(card.area.cards[pos+1], {
                    value = card.ability.extra.temp_values
                })
                card.area.cards[pos+1].ability.already_big_and_fat = true
            end
        end
        if context.being_removed then
            local pos = 0
            for i, v in pairs(card.area.cards) do if v == card then pos = i end end
            if card.area.cards[pos+1] ~= card and card.area.cards[pos+1] and card.area.cards[pos+1].ability.already_big_and_fat then
                Spectrallib.manipulate(card.area.cards[pos+1], {
                    value = 1/card.ability.extra.temp_values
                })
                card.area.cards[pos+1].ability.already_big_and_fat = nil
            end
        end
    end
}

local ac = CardArea.align_cards
function CardArea:align_cards(...)
    local order = {}
    for i, v in pairs(self.cards) do
        v.last_pos = i
        order[i] = v
    end
    ac(self, ...)
    if G.jokers then
        for i, v in pairs(self.cards) do
            if i ~= v.last_pos then
                SMODS.calculate_context{card_rearranged = true, old_pos = v.last_pos, new_pos = i, card = v, old_order = order}
            end
        end
    end
end

local emplace = CardArea.emplace
function CardArea:emplace(card, ...)
    local order = {}
    for i, v in pairs(self.cards) do
        order[i] = v
    end
    emplace(self, card, ...)
    if G.jokers then
        SMODS.calculate_context{card_emplaced = true, old_order = order, card = card}
    end
end

local sd = CardArea.remove_card
function CardArea:remove_card(card, ...)
    if G.jokers and card and card.config.center.calculate then
        card.config.center:calculate(card, {being_removed = true, card = card})
    end
    local ret = sd(self, card, ...)
    if G.jokers then
        G.E_MANAGER:add_event(Event{
            trigger = "after",
            func = function()
                for i, v in pairs(self.cards or {}) do
                    if v.ability.already_big_and_fat then
                        Spectrallib.manipulate(v, {
                            value = 1/(self.cards[i-1] and self.cards[i-1].ability.extra and self.cards[i-1].ability.extra.temp_values or 1.5)
                        })
                        v.ability.already_big_and_fat = nil
                    end
                end
                SMODS.calculate_context{card_emplaced = true, old_order = order, card = card}
                return true
            end
        })
    end
    return ret
end

local copy_card_ref = copy_card
function copy_card(card, ...)
    local copy = copy_card_ref(card, ...)
    if copy.ability.already_big_and_fat then
        local pos = 0
        for i, v in pairs(card.area.cards) do if v == card then pos = i end end
        Spectrallib.manipulate(copy, {
            value = 1/(card.area.cards[pos-1] and card.area.cards[pos-1].ability.extra and card.area.cards[pos-1].ability.extra.temp_values or 1.5)
        })
        copy.ability.already_big_and_fat = nil
    end
    return copy
end

Entropy.Joker{
    order = 163,
    key = "immanentize",
    rarity = 2,
    cost = 6,
    eternal_compat = true,
    pos = {x=4,y=21},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    immutable = true,
    attributes = {"passive"},
    demicoloncompat = true,
    config = {
        extra = {
            boosters = 3
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.boosters
            }
        }
    end,
    calculate = function(self, card, context)
        if context.modify_booster_card then
            context.card:set_ability(SMODS.poll_object{type = Entropy.get_random_set(true)})
        end
        if context.open_booster then
            card.ability.extra.boosters = card.ability.extra.boosters - 1
            if card.ability.extra.boosters <= 0 then
                G.E_MANAGER:add_event(Event{
                    func = function()
                        SMODS.destroy_cards(card, nil, true)
                        return true
                    end
                })
            else
                return {
                    message = "-1",
                    colour = G.C.RED
                }
            end
        end
    end
}

Entropy.Joker{
    order = 164,
    key = "big_walk",
    rarity = 1,
    cost = 4,
    eternal_compat = true,
    pos = {x=5,y=20},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    attributes = {"retrigger"},
    demicoloncompat = true,
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play then
            local index = 0
            for i, v in pairs(context.scoring_hand) do
                if v == context.other_card then index = i; break end
            end
            if index == 1 or index == #context.scoring_hand then
                return {
                    repetitions = 1
                }
            end
        end
    end
}

Entropy.Joker{
    order = 165,
    key = "infinite_loop",
    rarity = 2,
    cost = 4,
    eternal_compat = true,
    pos = {x=7,y=20},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            mult = 6
        }
    },
    attributes = {"retrigger"},
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.mult
            }
        }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval then
            card.ability.triggered_this_round = nil
        end
        if ((context.entr_repetition_occured and context.other_card ~= card) or context.joker_main or context.forcetrigger) then
            local t = card.ability.triggered_this_round
            card.ability.triggered_this_round = true
            if G.STATE ~= G.STATES.NEW_ROUND then
                return {
                    message = t and localize("k_again_ex") or nil,
                    extra = {
                        mult = card.ability.extra.mult
                    }
                }
            end
        end
    end
}

Entropy.Joker{
    order = 166,
    key = "prototype",
    rarity = 3,
    cost = 10,
    eternal_compat = true,
    pos = {x=8,y=20},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            
        },
        immutable = {

        }
    },
    attributes = {"copying"},
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        local other_joker = G.jokers and Entropy.get_by_sortid(card.ability.immutable.stored_card)
        local compatible = other_joker and other_joker ~= card and other_joker.config.center.blueprint_compat
        local main_end = {
            {
                n = G.UIT.C,
                config = { align = "bm", minh = 0.4 },
                nodes = {
                    {
                        n = G.UIT.C,
                        config = {
                            ref_table = card,
                            align = "m",
                            colour = compatible and mix_colours(G.C.GREEN, G.C.JOKER_GREY, 0.8)
                                or mix_colours(G.C.RED, G.C.JOKER_GREY, 0.8),
                            r = 0.05,
                            padding = 0.06,
                        },
                        nodes = {
                            {
                                n = G.UIT.T,
                                config = {
                                    text = " "
                                        .. (compatible and localize { type = 'name_text', set = other_joker.config.center.set, key = other_joker.config.center.key } or localize("k_incompatible"))
                                        .. " ",
                                    colour = G.C.UI.TEXT_LIGHT,
                                    scale = 0.32 * 0.8,
                                },
                            },
                        },
                    },
                },
            },
        }
        return {
            vars = {
                card.ability.left,
                card.ability.left_mod
            },
            main_end = main_end,
        }
    end,
    calculate = function(self, card, context)
        if context.setting_blind then
            card.ability.immutable.stored_card = nil
        end
        if context.post_trigger and context.other_card.area == card.area then
            local ret
            if not card.ability.immutable.stored_card then
                ret = SMODS.blueprint_effect(card, context.other_card, context.other_context)
            end
            card.ability.immutable.stored_card = context.other_card.sort_id
            if ret then return ret end
        end
        return SMODS.blueprint_effect(card, Entropy.get_by_sortid(card.ability.immutable.stored_card), context)
    end
}

Entropy.Joker{
    order = 167,
    key = "slime_joker",
    rarity = 2,
    cost = 5,
    eternal_compat = true,
    pos = {x=9,y=20},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            chips_mod = 10
        },
    },
    attributes = {"retrigger"},
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.chips_mod
            }
        }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round then
            SMODS.scale_card(context.other_card, {
                ref_table = context.other_card.ability,
                ref_value = "perma_h_chips",
                scalar_table = card.ability.extra,
                scalar_value = "chips_mod"
            })
            return nil, true
        end
        if context.pre_discard then
            for i, v in pairs(G.hand.highlighted) do
                if v.ability.perma_h_chips > 0 then
                    SMODS.scale_card(v, {
                        ref_table = v.ability,
                        ref_value = "perma_h_chips",
                        scalar_table = {chips_mod = math.min(card.ability.extra.chips_mod, v.ability.perma_h_chips)},
                        scalar_value = "chips_mod",
                        operation = "-",
                        message_key = "a_chips_minus",
                        message_colour = G.C.RED
                    })
                end
            end
            return nil, true
        end
    end
}

Entropy.Joker{
    order = 168,
    key = "bag_of_chips",
    rarity = 1,
    cost = 0,
    eternal_compat = true,
    pos = {x=3,y=21},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            uses = 3
        },
    },
    attributes = {"economy", "food"},
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.uses
            }
        }
    end,
    calculate = function(self, card, context)
        if context.buying_card and context.card.cost > 0 then
            card.ability.extra.uses = card.ability.extra.uses - 1
            return {
                dollars = context.card.cost,
                func = function()
                    if card.ability.extra.uses <= 0 then
                        SMODS.destroy_cards(card, nil, true)
                    end
                end
            }
        end
    end
}

Entropy.Joker{
    order = 169,
    key = "cider",
    rarity = 3,
    cost = 10,
    eternal_compat = true,
    pos = {x=2,y=21},
    atlas = "jokers",
    dependencies = {
        items = {
            "set_entr_misc_jokers",
        }
    },
    config = {
        extra = {
            xmult = 4,
            xmult_dec = 1,
            xmult_inc = 0.2,
        },
    },
    attributes = {"xmult", "food"},
    demicoloncompat = true,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.xmult,
                card.ability.extra.xmult_dec,
                card.ability.extra.xmult_inc,
            }
        }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            return {
                xmult = card.ability.extra.xmult
            }
        end
        if context.after then
            SMODS.scale_card(card, {
                ref_table = card.ability.extra,
                ref_value = "xmult",
                scalar_value  = "xmult_dec",
                operation = "-",
                message_key = "a_xmult",
                message_colour = G.C.RED
            })
            if card.ability.extra.xmult <= 0 then
                SMODS.destroy_card(card, nil, true)
                return {
                    message = localize("k_eaten_ex")
                }
            end
        end
        if context.press_play then
            for i, v in pairs(G.hand.highlighted) do
                if v.config.center.set == "Enhanced" then
                    if card.ability.extra.xmult + card.ability.extra.xmult_inc <= 4 then
                        SMODS.scale_card(card, {
                            ref_table = card.ability.extra,
                            ref_value = "xmult",
                            scalar_value  = "xmult_inc",
                            message_key = "a_xmult",
                            message_colour = G.C.RED
                        })
                    end
                    if card.ability.extra.xmult > 4 then
                        card.ability.extra.xmult = 4
                    end
                end
            end
        end
    end
}

Entropy.Joker{
    order = 170,
    key = "photonegative",
    rarity = 2,
    cost = 4,
    eternal_compat = true,
    pos = {x=1,y=21},
    atlas = "jokers",
    config = {
        left = 1,
        left_mod = 1,
        cards_to_discard = 40,
        cards_discarded = 0
    },
    dependencies = {
        items = {
            "set_entr_actives",
            "set_entr_alt"
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {card.ability.left, card.ability.left_mod, card.ability.cards_to_discard, card.ability.cards_to_discard - card.ability.cards_discarded}
        }
    end,
    can_use = function(self, card) return card.ability.left > 0 and G.blind_select end,
    use = function(self, card)
        card.ability.left = card.ability.left - 1
        G.GAME.entr_alt = not G.GAME.entr_alt
        for i, v in pairs(G.GAME.round_resets.blind_choices) do
            G.GAME.round_resets.blind_choices[i] = SMODS.get_new_blind(string.lower(i))
        end
        if G.blind_select then        
            G.blind_select:remove()
            G.blind_prompt_box:remove()
            G.STATE_COMPLETE = false
        end
        ease_background_colour{new_colour = Spectrallib.get_bg_colour(), contrast = 1}
        if G.ARGS.spin then
          G.ARGS.spin.real = (G.SETTINGS.reduced_motion and 0 or 1)*(G.GAME.entr_alt and 0.3 or -0.3)
        end
    end,
    calculate = function(self, card, context)
        if context.pre_discard then
            card.ability.cards_discarded = card.ability.cards_discarded + #G.hand.highlighted
            if card.ability.cards_discarded >= card.ability.cards_to_discard then
                card.ability.cards_discarded = card.ability.cards_discarded - card.ability.cards_to_discard
                SMODS.scale_card(card, {ref_table = card.ability, ref_value = "left", scalar_value = "left_mod", scaling_message = {message = "+"..number_format(card.ability.left_mod)}})
            end
        end
    end,
    attributes = {"activated", "scaling"},
}

Entropy.Joker{
    order = 171,
    key = "snakebite",
    rarity = 2,
    cost = 7,
    eternal_compat = true,
    pos = {x=0,y=21},
    atlas = "jokers",
    config = {
        blind_mod = 15,
        perc = 100
    },
    dependencies = {
        items = {
            "set_entr_actives",
            "set_entr_alt"
        }
    },
    loc_vars = function(self, q, card)
        return {
            vars = {card.ability.blind_mod}
        }
    end,
    calculate = function(self, card, context)
        if context.pre_discard then
            if #G.hand.highlighted == 1 then
                card.ability.perc = card.ability.perc - card.ability.blind_mod
                if card.ability.perc < 0 then card.ability.perc = 0 end
                local size = get_blind_amount(G.GAME.round_resets.ante)*G.GAME.blind.mult*G.GAME.starting_params.ante_scaling
                size = size * card.ability.perc/100
                ease_blind_chips(size-G.GAME.blind.chips, {{"xchips", nil, 3}, {"chips1", nil, 4}})
            end
        end
        if context.end_of_round and context.main_eval then
            card.ability.perc = 100
        end
    end,
    attributes = {"discard"},
}