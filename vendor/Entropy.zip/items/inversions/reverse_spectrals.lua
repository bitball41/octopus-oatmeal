Entropy.Consumable{
    order = 2000,
    key = "changeling",
    inversion = "c_familiar",
    pos = {x = 6, y = 4},
    dependencies = {
        items = {
            "set_entr_inversions"
        }
    },
    config = { random = 3 },
    atlas = "consumables",
    set = "Omen",
    
    use = function(self, card)
        local cards = {}
        for i, v in pairs(G.hand.cards) do cards[#cards+1]=v end
        pseudoshuffle(cards, pseudoseed('changeling'))
        local actual = {}
        for i = 1, card.ability.random do
            actual[i] = cards[i]
        end
        Entropy.flip_then(actual, function(card)
            card:set_edition(SMODS.poll_edition({guaranteed = true, key = "entr_changeling", no_negative = true}))
            SMODS.change_base(card, nil, pseudorandom_element({"King", "Queen", "Jack"}, pseudoseed("changeling_rank")), nil)
        end)
    end,
    can_use = function()
        return G.hand and #G.hand.cards > 0
    end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.random
            }
        }
    end,
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end,
    slib_credits = {
        art = {"Lil. Mr. Slipstream"}
    },
}

Entropy.Consumable{
    order = 2000 + 1,
    key = "rend",
    inversion = "c_grim",
    pos = {x = 7, y = 4},
    dependencies = {
        items = {
            "set_entr_inversions"
        }
    },
    config = { select = 4 },
    atlas = "consumables",
    set = "Omen",
    
    use = function(self, card)
        Entropy.flip_then(Entropy.get_highlighted_cards({G.hand}, card, 1, card.ability.select), function(card)
            card:set_ability(G.P_CENTERS.m_entr_flesh)
        end)
    end,
    can_use = function(self, card)
        local cards = Entropy.get_highlighted_cards({G.hand}, card, 1, card.ability.select)
        return #cards > 0 and #cards <= card.ability.select
    end,
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.m_entr_flesh
        return {
            vars = {
                card.ability.select
            }
        }
    end,
    slib_credits = {
        art = {"Lil. Mr. Slipstream"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}
Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 2,
    key = "inscribe",
    set = "Omen",
    
	
    inversion = "c_incantation",
    atlas = "consumables",
    config = {
        chipmult = 3
    },
	pos = {x=8,y=4},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card2, area, copier)
        Entropy.flip_then(Entropy.filter_table(G.hand.cards, function(card) return not card:is_face() and card.base.value ~= "Ace" end), function(card, area)
            card.base.nominal = card.base.nominal * card2.ability.chipmult
            card.ability.debuff_timer = 1
            card.ability.debuff_timer_max = 1
            card:set_debuff(true)
        end)
    end,
    can_use = function(self, card)
        return G.hand and #G.hand.cards > 0
	end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.chipmult
            }
        }
    end,
    slib_credits = {
        art = {"Lil. Mr. Slipstream"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}
Entropy.seal_spectral("insignia", {x=9,y=4}, "entr_silver", 2000+3, "c_talisman", {art = {"Lil. Mr. Slipstream"}})
Entropy.seal_spectral("rendezvous", {x=10,y=5}, "entr_crimson",2000+10.5, "c_deja_vu")
Entropy.seal_spectral("eclipse", {x=12,y=5}, "entr_sapphire",2000+12, "c_trance", {art = {"Lil. Mr. Slipstream"}})
Entropy.seal_spectral("calamity", {x=6,y=6}, "entr_pink",2000+13, "c_medium",{art = {"Lil. Mr. Slipstream"}})

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 4,
    key = "siphon",
    set = "Omen",
    
    inversion = "c_aura",

    atlas = "consumables",
    config = {
        cards = 3
    },
	pos = {x=10,y=4},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card2, area, copier)
        local lower = Entropy.find_previous_in_pool(G.jokers.highlighted[1].edition.key, "Edition", "e_negative")
        local cards = {}
        local rcards = {}
        for i, v in pairs(G.hand.cards) do if not v.edition then cards[#cards+1] = v end end
        pseudoshuffle(cards, pseudoseed("entr_siphon"))
        for i = 1, math.min(#cards, card2.ability.cards) do rcards[#rcards+1] = cards[i] end
        Entropy.flip_then(rcards, function(card, area)
            card:set_edition(lower)
        end)
        if not SMODS.is_eternal(G.jokers.highlighted[1]) then
            G.jokers.highlighted[1]:start_dissolve() 
        end
    end,
    can_use = function(self, card)
        return G.jokers 
        and #G.jokers.highlighted == 1 
        and G.jokers.highlighted[1] 
        and G.jokers.highlighted[1].edition 
        and not SMODS.is_eternal(G.jokers.highlighted[1])
	end,
    loc_vars = function(self, q, card)
        local str = localize("k_none")
        if G.jokers and #G.jokers.highlighted > 0 and G.jokers.highlighted[1].edition and Entropy.find_previous_in_pool(G.jokers.highlighted[1].edition.key, "Edition", "e_negative") then
            str = G.localization.descriptions.Edition[Entropy.find_previous_in_pool(G.jokers.highlighted[1].edition.key, "Edition", "e_negative")].name
        end
        return {
            vars = {
                str,
                card.ability.cards
            }
        }
    end,
    slib_credits = {
        idea = {"user324897"}
    },
    --TODO figure this shit out when force used
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 5,
    key = "ward",
    set = "Omen",
    inversion = "c_wraith",
    atlas = "consumables",
    config = {
        sellmult = 3,
        rounds = 3
    },
	pos = {x=11,y=4},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card, area, copier)
        local joker = pseudorandom_element(G.jokers.cards, pseudoseed("entr_ward"))
        local total = joker.sell_cost
        joker.ability.debuff_timer = (joker.ability.debuff_timer or 0) + card.ability.rounds
        joker.ability.debuff_timer_max = (joker.ability.debuff_timer_max or 0) + card.ability.rounds 
        joker:set_debuff(true)
        joker:juice_up()
        ease_dollars(total * card.ability.sellmult)
    end,
    can_use = function(self, card)
        return G.jokers and #G.jokers.cards > 0
	end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.sellmult,
                card.ability.rounds
            }
        }
    end,
    slib_credits = {
        idea = {"CapitalChirp"},
        art = {"Lil. Mr. Slipstream"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 6,
    key = "disavow",
    set = "Omen",
    inversion = "c_sigil",
    atlas = "consumables",
	pos = {x=12,y=4},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card, area, copier)
        local cards = Entropy.get_highlighted_cards({G.hand}, card, 1, 1)
        local enh = cards[1] and cards[1].config.center_key or "m_base"
        Entropy.flip_then(G.hand.cards, function(card, area, ind)
            if card == cards[1] then
                card:set_ability(G.P_CENTERS["m_entr_disavowed"])
            else
                card:set_ability(G.P_CENTERS[enh])
            end
        end)
    end,
    can_use = function(self, card)
        local cards = #Entropy.get_highlighted_cards({G.hand}, card, 1, 1)
        return cards > 0 and cards <= 1
	end,
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.m_entr_disavowed
    end,
    slib_credits = {
        idea = {"CapitalChirp"},
        art = {"Lil. Mr. Slipstream"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
          "link"
        }
    },
    
    order = 2000 + 7,
    key = "pact",
    set = "Omen",

    inversion = "c_ouija",

    atlas = "consumables",
    config = {
        selected = 3
    },
	pos = {x=6,y=5},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card, area, copier)
        local linktxt
        local cards = Entropy.get_highlighted_cards({G.hand}, card, 1, card.ability.selected)
        for i, v in pairs(cards) do
            if v.ability.link then linktxt = v.ability.link end
        end
        linktxt = linktxt or Entropy.string_random(8)
        for i, v in pairs(cards) do
            for i, v2 in pairs(G.hand.cards) do
                if v2 ~= v and v.ability.link and v.ability.link == v2.ability.link then
                    v2.ability.link = linktxt
                end
            end
            for i, v2 in pairs(G.deck.cards) do
                if v2 ~= v and v.ability.link and v.ability.link == v2.ability.link then
                    v2.ability.link = linktxt
                end
            end
            v.ability.link = linktxt
            v:juice_up()
        end

    end,
    can_use = function(self, card)
        local num = Entropy.get_highlighted_cards({G.hand}, card, 1, card.ability.selected)
        return #num <= card.ability.selected and #num > 0
	end,
    loc_vars = function(self, q, card)
        q[#q+1] = {set="Other",key="link", vars = {"[LINK_KEY]"}}
        return {
            vars = {
                card.ability.selected
            }
        }
    end,
    slib_credits = {
        art = {"Lil. Mr. Slipstream"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Sticker{
    atlas = "entr_stickers",
    pos = { x = 1, y = 1 },
    key = "link",
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    order = 2500 + 0,
    no_sticker_sheet = true,
    prefix_config = { key = false },
    badge_colour = HEX("59ffe8"),
    should_apply = false,
    loc_vars = function(self,q,card)
        return {
            vars = {
                card.ability.link
            }
        }
    end,
    apply = function(self,card,val) 
        if not G.GAME.link then
            G.GAME.link = Entropy.string_random(8)
        end
        card.ability.link = G.GAME.link
    end,
    draw = function(self, card) --don't draw shine
        local notilt = nil
        if card.area and card.area.config.type == "deck" then
            notilt = true
        end
        G.shared_stickers[self.key].role.draw_major = card
        G.shared_stickers[self.key]:draw_shader("dissolve", nil, nil, notilt, card.children.center)
    end,
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 8,
    key = "ichor",
    set = "Omen",
    
    inversion="c_ectoplasm",

    atlas = "consumables",
    config = {
        num = 1
    },
	pos = {x=7,y=5},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card, area, copier)
        local joker = pseudorandom_element(G.jokers.cards, pseudoseed("entr_ichor"))
        Entropy.handle_card_limit(G.jokers, 1)
        if joker then
            joker:juice_up()
            joker.ability.extra_slots_used = joker.ability.extra_slots_used + 1
        end
    end,
    can_use = function(self, card)
        return G.jokers
	end,
    loc_vars = function(self, q, card)
        q[#q+1] = G.P_CENTERS.e_negative
        return {
            vars = {
                card.ability.num
            }
        }
    end,
    slib_credits = {
        idea = {"cassknows"},
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 9,
    key = "rejuvenate",
    set = "Omen",
    
    inversion = "c_immolate",

    atlas = "consumables",
    config = {
        dollars = -10,
        num = 2
    },
	pos = {x=8,y=5},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card2, area, copier)
        local cards = {}
        for i, v in pairs(G.hand.cards) do if not v.highlighted then cards[#cards+1]=v end end
        pseudoshuffle(cards, pseudoseed('immolate'))
        local actual = {}
        for i = 1, card2.ability.num do
            actual[i] = cards[i]
        end
        local ed = SMODS.poll_edition({guaranteed = true, key = "entr_rejuvenate_ed", no_negative = true})
        local enh = G.P_CENTERS[SMODS.poll_enhancement({guaranteed = true})]
        local seal = SMODS.poll_seal{guaranteed = true, key = "rejuvenate"}
        local card = Entropy.get_highlighted_cards({G.hand}, card2, 1, 1)[1] or pseudorandom_element(G.hand.cards, pseudoseed("rejuvenate"), 1, 1)
        card:set_edition(ed)
        card:set_ability(enh)
        card:set_seal(seal)
        Entropy.flip_then(actual, function(card3, area)
                copy_card(card,card3)
                card3:set_edition(ed)
                card3:set_ability(enh)
                card3:set_seal(seal)
        end)

        ease_dollars(card2.ability.dollars)
    end,
    can_use = function(self, card)
        local num = #Entropy.get_highlighted_cards({G.hand}, card, 1, 1)
        return num <= 1 and num > 0
	end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.num,
                Entropy.format_dollar_value(card.ability.dollars)
            }
        }
    end,
    slib_credits = {
        idea = {"user324897"},
        art = {"Lil. Mr. Slipstream"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 10,
    key = "crypt",
    set = "Omen",
    inversion = "c_ankh",
    atlas = "consumables",
    config = {
        select = 2,
    },
	pos = {x=9,y=5},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card2, area, copier)
        local jokers = Entropy.get_highlighted_cards({G.jokers}, card2, 1, card2.ability.select)
        local selected = pseudorandom_element(jokers, pseudoseed("entr_crypt"))
        Entropy.flip_then(jokers, function(v, area)
            if v ~= selected and v and selected then            
                copy_card(selected, v)
                if v.edition and v.edition.key == "e_negative" then
                    v:set_edition()
                end
            end
        end)

    end,
    can_use = function(self, card)
        local cards = Entropy.get_highlighted_cards({G.jokers}, card, 1, card.ability.select)
        return #cards > 1 and #cards <= card.ability.select
	end,
    loc_vars = function(self, q, card)
        local main_end = {}
        if G.jokers and G.jokers.cards then
            for _, joker in ipairs(G.jokers.cards) do
                if joker.edition and joker.edition.negative then
                    localize { type = 'other', key = 'remove_negative', nodes = main_end, vars = {} }
                    break
                end
            end
        end
        return {
            vars = {
                card.ability.select,
            },
            main_end = main_end[1]
        }
    end,
    slib_credits = {
        art = {"Lil. Mr. Slipstream"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 11,
    key = "charm",
    set = "Omen",
    
	inversion = "c_hex",

    atlas = "consumables",
    config = {
        select = 1,
    },
	pos = {x=11,y=5},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card2, area, copier)
        local editions = {}
        for i, v in pairs(G.P_CENTER_POOLS.Edition) do
            if v.key ~= "e_negative" and v.key ~= "e_base" then
                editions[#editions+1] = {
                    weight = 1,
                    name = v.key
                }
            end
        end
        for i, v in pairs(Entropy.get_highlighted_cards({G.jokers}, card2, 1, card2.ability.select)) do
            local edition = SMODS.poll_edition({
                key = "entr_charm",
                options = editions,
                guaranteed = true
            })
            v:set_edition(edition)
            v:add_sticker("eternal", true)

        end
    end,
    can_use = function(self, card)
        local cards = Entropy.get_highlighted_cards({G.jokers}, card, 1, card.ability.select)
        return #cards <= card.ability.select and #cards > 0
	end,
    loc_vars = function(self, q, card)
        q[#q+1] = {key="eternal",set="Other"}
        return {
            vars = {
                card.ability.select,
            }
        }
    end,
    slib_credits = {
        idea = {"user324897"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 14,
    key = "entropy",
    set = "Omen",
    
    inversion = "c_cryptid",

    atlas = "consumables",
    config = {
        select = 2,
    },
	pos = {x=7,y=6},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card2, area, copier)
        Entropy.flip_then(Entropy.get_highlighted_cards({G.hand}, card2, 1, card2.ability.select), function(card,area)
            local edition = SMODS.poll_edition({guaranteed = true, key = "entr_entropy"})
            local enhancement_type = pseudorandom_element({"Enhanced","Enhanced","Enhanced","Joker","Consumeables","Voucher","Booster"}, pseudoseed("entropy"))
            local enhancement = pseudorandom_element(G.P_CENTER_POOLS[enhancement_type], pseudoseed("entropy")).key
            while G.P_CENTERS[enhancement].no_doe or G.GAME.banned_keys[enhancement] or (enhancement_type == "Joker" and SMODS.Rarities[G.P_CENTERS[enhancement].rarity]
                and (
                    SMODS.Rarities[G.P_CENTERS[enhancement].rarity].get_weight
                    or (SMODS.Rarities[G.P_CENTERS[enhancement].rarity].default_weight and SMODS.Rarities[G.P_CENTERS[enhancement].rarity].default_weight > 0)
                )) do
                enhancement = pseudorandom_element(G.P_CENTER_POOLS[enhancement_type], pseudoseed("entropy")).key
            end
            local seal = SMODS.poll_seal{guaranteed = true, key = "entropy"}
            card:set_edition(edition)
            card:set_ability(G.P_CENTERS[enhancement])
            card:set_seal(seal)
            Entropy.randomize_rank_suit(card, true, true, "entropy")

        end)
    end,
    can_use = function(self, card)
        local num = #Entropy.get_highlighted_cards({G.hand}, card, 1, card.ability.select)
        return num <= card.ability.select and num > 0
	end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.select,
            }
        }
    end,
    slib_credits = {
        art = {"Lil. Mr. Slipstream"},
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

SMODS.Shader({
    key="rainbow",
    path="rainbow.fs"
})

SMODS.ScreenShader({
    key="vignette",
    path="vignette.fs",
    send_vars = function (sprite, card)
        return {
            power = G.GAME.entr_vignette_power or 2
        }
    end,
    should_apply = function()
        return G.GAME.entr_vignette_power or G.entr_invert_enabled
    end
})
	--TODO: special thanks in credits to lily for these two shaders
SMODS.ScreenShader {
    key = "flashlight",
    path = "flashlight.fs",
    send_vars = function(self)
		local t = G.TIMERS.REAL or 0
		t = t - 5000*math.floor(t/5000)
        return {
            center_pos = G.entr_flashlight_center or { love.graphics.getWidth() / 2, love.graphics.getHeight() / 2 },
            dist = G.entr_flashlight_distance or 500,
			time = t or 0
        }
    end,
    should_apply = function(self)
        return G.entr_flashlight_enabled
    end,
}

SMODS.ScreenShader {
    key = "invert",
    path = "invertradius.fs",
    send_vars = function(self)
        local t = G.TIMERS.REAL or 0
        t = t - 5000*math.floor(t/5000)
        return {
            center_pos = G.entr_invert_center or { love.graphics.getWidth() / 2, love.graphics.getHeight() / 2 },
            dist = G.entr_invert_distance or 500,
            time = t or 0
        }
    end,
    should_apply = function(self)
        return G.entr_invert_enabled
    end,
    order = 7
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 15,
    key = "fervour",
    set = "Omen",
    
    inversion = "c_soul",
    
    atlas = "consumables",
	name = "entr-Fervour",
    soul_rate = 0,
    hidden = true, 
	pos = {x=4,y=0},
    soul_set = "Fraud",
    tsoul_pos = {x=5,y=0},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card, area, copier)
        if G.GAME.entropy and G.GAME.entropy > 100 then
            G.entr_flashlight_distance = Entropy.max_diagonal()
            G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.5, func = function()
                --play_sound('tarot1')
                --if card and card.juice_up then card:juice_up(0.8, 0.5) end
                --G.TAROT_INTERRUPT_PULSE = true
                G.entr_flashlight_enabled = true
                local card_position = Entropy.get_card_pixel_pos(card)
                G.entr_flashlight_center = card_position
                G.E_MANAGER:add_event(Event({
                    trigger = 'ease',
                    ease = 'inexpo',
                    ref_table = G,
                    ref_value = 'entr_flashlight_distance',
                    ease_to = 100,
                    delay = 0.5,
                    timer = "REAL",
                    func = (function(t) return t end),
                    blockable = false,
                }))
                return true end 
            }))
            delay(1.75)
            G.E_MANAGER:add_event(Event({trigger = 'after', delay = .6, func = function()
                play_sound('tarot1')
                if card and card.juice_up then card:juice_up(0.8, 0.5) end
                G.TAROT_INTERRUPT_PULSE = true
                G.E_MANAGER:add_event(Event({
                    trigger = 'ease',
                    ease = 'inexpo',
                    ref_table = G,
                    ref_value = 'entr_flashlight_distance',
                    ease_to = G.entr_flashlight_distance * 3,
                    delay = 0.5,
                    timer = "REAL",
                    func = (function(t) return t end),
                    blockable = false,
                }))
                return true end 
            }))
            G.E_MANAGER:add_event(Event({trigger = 'after', delay = 1.2, func = function()
                G.E_MANAGER:add_event(Event({
                    trigger = 'ease',
                    ease = 'inexpo',
                    ref_table = G,
                    ref_value = 'entr_flashlight_distance',
                    ease_to = G.entr_flashlight_distance / 1.35,
                    delay = 0.75,
                    timer = "REAL",
                    func = (function(t) return t end),
                    blockable = false,
                }))
                return true end 
            }))
            delay(1.75)
            G.E_MANAGER:add_event(Event({trigger = 'after', delay = .6, func = function()
                play_sound('tarot1')
                if card and card.juice_up then card:juice_up(0.8, 0.5) end
                G.TAROT_INTERRUPT_PULSE = true
                G.E_MANAGER:add_event(Event({
                    trigger = 'ease',
                    ease = 'inexpo',
                    ref_table = G,
                    ref_value = 'entr_flashlight_distance',
                    ease_to = G.entr_flashlight_distance * 3,
                    delay = 0.5,
                    timer = "REAL",
                    func = (function(t) return t end),
                    blockable = false,
                }))
                return true end 
            }))
            G.E_MANAGER:add_event(Event({trigger = 'after', delay = 1.2, func = function()
                G.E_MANAGER:add_event(Event({
                    trigger = 'ease',
                    ease = 'inexpo',
                    ref_table = G,
                    ref_value = 'entr_flashlight_distance',
                    ease_to = G.entr_flashlight_distance / 1.35,
                    delay = 0.75,
                    timer = "REAL",
                    func = (function(t) return t end),
                    blockable = false,
                }))
                return true end 
            }))
            delay(1.75)
            G.E_MANAGER:add_event(Event({trigger = 'after', delay = .6, func = function()
                play_sound('tarot1')
                if card and card.juice_up then card:juice_up(0.8, 0.5) end
                G.TAROT_INTERRUPT_PULSE = true
                G.E_MANAGER:add_event(Event({
                    trigger = 'ease',
                    ease = 'inexpo',
                    ref_table = G,
                    ref_value = 'entr_flashlight_distance',
                    ease_to = G.entr_flashlight_distance * 3,
                    delay = 0.5,
                    timer = "REAL",
                    func = (function(t) return t end),
                    blockable = false,
                }))
                return true end 
            }))
            G.E_MANAGER:add_event(Event({trigger = 'after', delay = 1.2, func = function()
                G.E_MANAGER:add_event(Event({
                    trigger = 'ease',
                    ease = 'inexpo',
                    ref_table = G,
                    ref_value = 'entr_flashlight_distance',
                    ease_to = G.entr_flashlight_distance / 1.35,
                    delay = 0.75,
                    timer = "REAL",
                    func = (function(t) return t end),
                    blockable = false,
                }))
                return true end 
            }))
            delay(1.75)
            G.E_MANAGER:add_event(Event({
                trigger = "after",
                delay = 1.6,
                func = function()
                    local card
                    play_sound("entr_entropic_summon", nil, 2)
                    G.GAME.entr_parakmi_bypass = true
                    card = create_card("Joker", G.jokers, nil, "entr_entropic", nil, nil, nil, "entr_fervour")
                    G.GAME.entr_parakmi_bypass = nil
                    ease_entropy(-G.GAME.entropy)
                    card:add_to_deck()
                    G.jokers:emplace(card)
                    card:juice_up(0.3, 0.5)
                    G.entr_invert_enabled = true
                    local card_position = Entropy.get_card_pixel_pos(card)
                    G.entr_invert_center = card_position
                    G.entr_invert_distance = 0
                     G.E_MANAGER:add_event(Event({
                        trigger = 'ease',
                        ease = 'outexpo',
                        ref_table = G,
                        ref_value = 'entr_flashlight_distance',
                        ease_to = 100000,
                        delay = 2,
                        timer = "REAL",
                        func = (function(t) return t end),
                        blockable = false,
                    }), "other")
                    G.E_MANAGER:add_event(Event({
                        trigger = 'ease',
                        ease = 'insine',
                        ref_table = G,
                        ref_value = 'entr_invert_distance',
                        ease_to = Entropy.max_diagonal(),
                        delay = 8,
                        timer = "REAL",
                        func = (function(t) return t end),
                        blockable = false,
                    }), "other")
                    return true
                end,
            }))
            G.E_MANAGER:add_event(Event({
                trigger = "after",
                delay = 1.6,
                func = function()
                    G.E_MANAGER:add_event(Event({
                        trigger = "after",
                        delay = 4,
                        func = function()
                            G.entr_flashlight_enabled = false
                            return true
                        end
                    }), "other")
                    G.E_MANAGER:add_event(Event({
                        trigger = "after",
                        delay = 4,
                        func = function()
                            G.entr_invert_enabled = false
                            return true
                        end
                    }), "other")
                    return true
                end
            }))
            delay(1.75)
        else    
            G.E_MANAGER:add_event(Event({
                trigger = "after",
                delay = 0.4,
                func = function()
                    play_sound("timpani")
                    G.GAME.entr_parakmi_bypass = true
                    local card = create_card("Joker", G.jokers, nil, "entr_reverse_legendary", nil, nil, nil, "entr_fervour")
                    G.GAME.entr_parakmi_bypass = nil
                    card:add_to_deck()
                    G.jokers:emplace(card)
                    card:juice_up(0.3, 0.5)
                    return true
                end,
            }))
            delay(0.6)
        end
    end,
    can_use = function(self, card)
        return G.jokers and #G.jokers.cards < G.jokers.config.card_limit
	end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                colours = {
                    {3,3,3,3}
                }
            }
        }
    end,
    no_select = true,
    slib_credits = {
        custom = {key="card_art", text="gudusername_53951"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 16,
    key = "quasar",
    set = "Omen",
    
    inversion = "c_black_hole",

    atlas = "consumables",
    no_select = true,
    soul_rate = 0,
    hidden = true, 
	pos = {x=7,y=3},
    soul_set = "Star",
    --soul_pos = { x = 5, y = 0},
    use = function(self, card, area, copier,amt)
        local amt = amt or 1
        local used_consumable = copier or card
        delay(0.4)
        local max=0
        update_hand_text(
          { sound = "button", volume = 0.7, pitch = 0.8, delay = 0.3 },
          { handname = localize("k_all_hands"), chips = "...", mult = "...", level = "" }
        )
        for i, v in pairs(G.GAME.hands) do
            G.GAME.hands[i].AscensionPower = to_big(G.GAME.hands[i].AscensionPower or 0) + to_big(G.GAME.hands[i].level) * to_big(amt) * to_big(0.5)
        end
        delay(1.0)
        G.E_MANAGER:add_event(Event({
          trigger = "after",
          delay = 0.2,
          func = function()
            play_sound("tarot1")
            ease_colour(G.C.UI_CHIPS, copy_table(Entropy.get_asc_colour(to_big(1) * to_big(amt) * to_big(0.5))), 0.1)
            ease_colour(G.C.UI_MULT, copy_table(Entropy.get_asc_colour(to_big(1) * to_big(amt) * to_big(0.5))), 0.1)
            Cryptid.pulse_flame(0.01, sunlevel)
            used_consumable:juice_up(0.8, 0.5)
            G.E_MANAGER:add_event(Event({
              trigger = "after",
              blockable = false,
              blocking = false,
              delay = 1.2,
              func = function()
                ease_colour(G.C.UI_CHIPS, G.C.BLUE, 1)
                ease_colour(G.C.UI_MULT, G.C.RED, 1)
                return true
              end,
            }))
            return true
          end,
        }))
        update_hand_text({ sound = "button", volume = 0.7, pitch = 0.9, delay = 0 }, { level = "+ ..." })
        delay(1.0)
        delay(2.6)
        update_hand_text(
          { sound = "button", volume = 0.7, pitch = 1.1, delay = 0 },
          { mult = 0, chips = 0, handname = "", level = "" }
        )
    end,
    bulk_use = function(self,card,area,copier,amt)
        self.use(self,card,area,copier,amt)
    end,
    can_use = function(self, card)
        return true
	end,
    no_select = true,
    slib_credits = {
        art = {"Lil. Mr. Slipstream"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

SMODS.Rank {
    key = 'nilrank',
    card_key = 'nilrank',
    pos = {x = 0},
    nominal = 1,
    face_nominal = 1,
    shorthand = "nil",
    hc_atlas = 'hc_nilr',
    lc_atlas = 'lc_nilr',
    suit_map = { Hearts = 0, Clubs = 1, Diamonds = 2, Spades = 3, entr_nilsuit = 9999 },
    in_pool = function(self, args)
        return false
    end
}
SMODS.Suit {
    key = 'nilsuit',
    card_key = 'nilsuit',
    shorthand="nil",
    hc_atlas = 'hc_nils',
    lc_atlas = 'lc_nils',
    pos = { y = 0 },
    ui_pos = {x=99,y=99},
    in_pool = function(self, args)
        return false
    end
}

if Engulf then
    Engulf.SpecialFuncs = {
        c_entr_pulsar = function(card, hand, instant, amount)
            if card.edition then
                for i, v in pairs(G.GAME.hands) do
                    Engulf.EditionHand(card, i, card.edition, Engulf.config.stackeffects and amount or 1, true)
                end
            end
        end,
        c_entr_quasar = function(card, hand, instant, amount)
            if card.edition then
                Engulf.EditionHand(card, hand, card.edition, Engulf.config.stackeffects and amount or 1, instant)
            end
        end
    }
    --Engulf.SpecialWhitelist["c_entr_pulsar"] = true
    --Engulf.SpecialWhitelist["c_entr_quasar"] = true
    --Engulf.SpecialWhitelist["Omen"] = true
end

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 32,
    key = "ruin",
    set = "Omen",
    
    inversion = "c_entr_destiny",
	
    atlas = "consumables2",
    config = {
        extra = {
            create = 4,
            limit = 1
        }
    },
	pos = {x=0,y=4},
    use = function(self, card, area, copier)
        local num = card.ability.extra.create
        local card = pseudorandom_element(G.playing_cards, pseudoseed("entr_ruin"))
        for i = 1, num do
            if G.hand and #G.hand.cards > 0 then
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                local _card = copy_card(card, nil, nil, G.playing_card)
                _card:add_to_deck()
                _card:set_edition(SMODS.poll_object{type = "Edition", guaranteed = true, no_negative = true})
                _card:set_ability(SMODS.poll_object{type = "Enhanced", guaranteed = true})
                G.deck.config.card_limit = G.deck.config.card_limit + 1
                table.insert(G.playing_cards, _card)
                G.hand:emplace(_card)
                _card.states.visible = nil

                G.E_MANAGER:add_event(Event({
                    func = function()
                        _card:start_materialize()
                        return true
                    end
                })) 
            else
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                local _card = copy_card(card, nil, nil, G.playing_card)
                _card:add_to_deck()
                _card:set_edition(SMODS.poll_object{type = "Edition", guaranteed = true, no_negative = true})
                _card:set_ability(SMODS.poll_object{type = "Enhanced", guaranteed = true})
                G.deck.config.card_limit = G.deck.config.card_limit + 1
                table.insert(G.playing_cards, _card)
                G.deck:emplace(_card)
            end
        end
        SMODS.destroy_cards(Entropy.get_highlighted_cards({G.jokers}, card, 1, num))
    end,
    can_use = function(self, card)
        local num = #Entropy.get_highlighted_cards({G.jokers}, card, 1, card.ability.extra.limit)
        return num > 0 and num <= card.ability.extra.limit
	end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.extra.create,
                card.ability.extra.limit
            }
        }
    end,
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 33,
    key = "regenerate",
    set = "Omen",
    
    inversion = "c_entr_shatter",
	
    atlas = "consumables",
    config = {
        limit = 2
    },
	pos = {x=8,y=8},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card, area, copier)
        local cards = Entropy.get_highlighted_cards({G.hand, G.jokers, G.consumeable}, card, 1, card.ability.limit)
        Entropy.flip_then(cards, function(card)
            card.ability.bypass_aleph = true
            if card.config.center.set == "Enhanced" then
                if card.config.center.key == "m_entr_disavowed" then
                    card.ability.disavow = false
                end
                card:set_ability(G.P_CENTERS.c_base)
            else
                card:set_ability(G.P_CENTERS[card.config.center.key])
            end
            card.seal = nil
            card:set_edition()
            for i, v in pairs(SMODS.Sticker.obj_table) do
                if i ~= "absolute" then card.ability[i] = nil end
            end
            if card.base.suit == "entr_nilsuit" or card.base.value == "entr_nilrank" then
                Entropy.randomize_rank_suit(card, true, true, "regenerate")
            end
            card:set_debuff()
            card.ability.bypass_aleph = nil
        end)
    end,
    can_use = function(self, card)
        local num = #Entropy.get_highlighted_cards({G.hand, G.jokers, G.consumeable}, card, 1, card.ability.limit)
        return num > 0 and num <= card.ability.limit
	end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.limit
            }
        }
    end,
    slib_credits = {
        art = {"Lil. Mr. Slipstream"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.Sticker{
    dependencies = {
        items = {
          "set_entr_inversions"
        }
    },
    order = 2500+4,
    atlas = "entr_stickers",
    pos = { x = 8, y = 1 },
    key = "entr_pure",
    no_sticker_sheet = true,
    prefix_config = { key = false },
    badge_colour = HEX("fd56e9"),
    should_apply = false,
    apply = function(self,card,val)
        card.ability.entr_pure = true
    end,
    draw = function(self, card) --don't draw shine
        local notilt = nil
        if card.area and card.area.config.type == "deck" then
            notilt = true
        end
        G.shared_stickers[self.key].role.draw_major = card
        G.shared_stickers[self.key]:draw_shader("dissolve", nil, nil, notilt, card.children.center)
    end,
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 34,
    key = "purity",
    set = "Omen",
    
    inversion = "c_entr_lust",
	
    atlas = "consumables",
    config = {
        limit = 2
    },
	pos = {x=9,y=8},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card, area, copier)
        for i, v in pairs(Entropy.get_highlighted_cards({G.jokers}, card, 1, card.ability.limit)) do
            v:add_sticker("entr_pure", true)
            v:juice_up()
        end

    end,
    can_use = function(self, card)
        local num = #Entropy.get_highlighted_cards({G.jokers}, card, 1, card.ability.limit)
        return num > 0 and num <= card.ability.limit
	end,
    loc_vars = function(self, q, card)
        q[#q+1] = {set = "Other", key = "entr_pure"}
        return {
            vars = {
                card.ability.limit
            }
        }
    end,
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

local misprintize = Cryptid.misprintize
function Cryptid.misprintize(card, ...)
    if not card.ability.entr_pure then
        return misprintize(card, ...)
    end
end

local calculate_jokerref = Card.calculate_joker
function Card:calculate_joker(...)
    local abil
    if self.ability.entr_pure then
        abil = copy_table(self.ability)        
    end
    local ret = calculate_jokerref(self, ...)
    if self.ability.entr_pure then
        self.ability = abil
    end
    return ret
end

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 35,
    key = "transcend",
    set = "Omen",
    
    inversion = "c_entr_null",
	
    atlas = "consumables",
    config = {
        limit = 1
    },
	pos = {x=11,y=7},
    --soul_pos = { x = 5, y = 0},
    use = function(self, card, area, copier)
        Entropy.flip_then(Entropy.get_highlighted_cards({G.consumeables, G.hand, G.pack_cards, G.shop_jokers, G.shop_vouchers, G.shop_booster, G.jokers}, card, 1, card.ability.limit), function(card)
            if card.config.center.key == "j_entr_parakmi" then
                check_for_unlock({ type = "parakmi_transcend" })
            end            
            card:set_ability(G.P_CENTERS[SMODS.poll_object{set = Entropy.get_random_set(true)}])
            if card.area.config.type == "shop" then create_shop_card_ui(card) end
        end)
    end,
    can_use = function(self, card)
        local num = #Entropy.get_highlighted_cards({G.consumeables, G.hand, G.pack_cards, G.shop_jokers, G.shop_vouchers, G.shop_booster, G.jokers}, card, 1, card.ability.limot)
        return num > 0 and num <= card.ability.limit
	end,
    loc_vars = function(self, q, card)
        return {
            vars = {
                card.ability.limit
            }
        }
    end,
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end,
    slib_credits = {
        idea = {"cassknows"}
    },
}

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 7024,
    key = "weld",
    set = "Omen",
    
    inversion = "c_entr_antithesis",

    atlas = "consumables",
    config = {
        select = 1,
    },
	pos = {x=10,y=8},
    hidden = true,
    soul_rate = 0,
    no_select = true,
    --soul_pos = { x = 5, y = 0},
    use = function(self, card, area, copier)
        for i, card in pairs(Entropy.get_highlighted_cards({G.jokers}, card, 1, card.ability.select)) do
            card.ability.entr_aleph = true
            card:set_edition("e_negative")
            card:juice_up()

        end
    end,
    can_use = function(self, card)
        local cards = Entropy.get_highlighted_cards({G.jokers}, card, 1, card.ability.select)
        return #cards > 0 and #cards <= card.ability.select
	end,
    loc_vars = function(self, q, card)
        q[#q+1] = {set="Other", key = "entr_aleph"}
        q[#q+1] = G.P_CENTERS.e_negative
        return {
            vars = {
                card.ability.select,
            }
        }
    end,
    slib_credits = {
        art = {"Lil. Mr. Slipstream"}
    },
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}

Entropy.seal_spectral("malediction", {x=2,y=0}, "entr_amber", 2000+37, "c_entr_enchant", nil, "consumables2")

Entropy.Consumable{
    dependencies = {
        items = {
          "set_entr_inversions",
        }
    },
    
    order = 2000 + 38,
    key = "idyll",
    set = "Omen",
    
    inversion = "c_entr_manifest",

    atlas = "consumables",
	pos = {x=2,y=8},
    use = function(self, card, area, copier)
        if G.GAME.last_tag then
            add_tag(Tag(G.GAME.last_tag))
            add_tag(Tag(Entropy.AscendedTags[G.GAME.last_tag] or G.GAME.last_tag))
        end
    end,
    can_use = function(self, card)
        return G.GAME.last_tag
	end,
    loc_vars = function(self, q, card)
        if G.GAME.last_tag then
            q[#q+1] = G.P_TAGS[G.GAME.last_tag]
            q[#q+1] = G.P_TAGS[Entropy.AscendedTags[G.GAME.last_tag] or G.GAME.last_tag]
        end
    end,
    demicoloncompat = true,
    force_use = function(self, card)
        self:use(card)
    end
}