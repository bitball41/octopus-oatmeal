if (SMODS.Mods["Bunco"] or {}).can_load then

    --TODO: commented out because banishing playing cards is a fuck. Somebody else's problem.
    --[[
    local disturbance = {
        dependencies = {
            items = {
                "set_entr_inversions",
            }
        },
        order = -900 + 34,
        key = "disturbance",
        set = "Fraud",

        inversion = "c_bunc_adjustment",

        atlas = "crossmod_consumables",
        config = {
            select = 3
        },
        pos = {x=8,y=0},
        use = function(self, card2)
            local cards = Entropy.get_highlighted_cards({G.hand}, card2, 1, card2.ability.select)
            for i, v in pairs(cards) do
                local card = cards[i]
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.GAME.banned_keys[card.config.center.key] = true
                        return true
                    end
                }))
            end

        end,
        can_use = function(self, card)
            local num = #Entropy.get_highlighted_cards({G.hand}, card, 1, card.ability.select)
            return num > 0 and num <= card.ability.select
        end,
        loc_vars = function(self, q, card)
            return {
                vars = {
                    card.ability.select
                }
            }
        end,
        slib_credits = {
            idea = {"Athebyne"}
        },

        demicoloncompat = true,
        force_use = function(self, card)
            self:use(card)
        end
    }
    ]]--


    --TODO: commented out because boosters that come from a consumable are a fuck, especially with multiple at once. Somebody else's problem.
    --[[
    local avarice = {
        dependencies = {
            items = {
                "set_entr_inversions",
            }
        },
        order = -900 + 35,
        key = "avarice",
        set = "Fraud",

        inversion = "c_bunc_lust",

        atlas = "crossmod_consumables",
        config = {
            boosters = 3
        },
        pos = {x=10,y=0},
        use = function(self, card)
            for i = 1, math.min(card.ability.boosters, 20) do
                G.E_MANAGER:add_event(Event({
                    trigger = "before",
                    blocking = false,
                    func = function()
                        if ((G.STATE == G.STATES.SMODS_BOOSTER_OPENED) or G.pack_cards) then return false end
                        local key = "p_standard_normal_1"
                        local booster = Card(
                                G.play.T.x + G.play.T.w / 2 - G.CARD_W * 1.27 / 2,
                                G.play.T.y + G.play.T.h / 2 - G.CARD_H * 1.27 / 2,
                                G.CARD_W * 1.27,
                                G.CARD_H * 1.27,
                                G.P_CARDS.empty,
                                G.P_CENTERS[key],
                                { bypass_discovery_center = true, bypass_discovery_ui = true }
                        )
                        booster.cost = 0
                        booster.from_tag = true
                        G.FUNCS.use_card({ config = { ref_table = booster } })
                        booster:start_materialize()
                        return true
                    end,
                }))
            end
        end,
        can_use = function(self, card)
            return not (G.STATE == G.STATES.SMODS_BOOSTER_OPENED)
        end,
        loc_vars = function(self, q, card) return {vars = {math.min(card.ability.boosters, 20)}} end,
        slib_credits = {
            idea = {"Athebyne"}
        },

        demicoloncompat = true,
        force_use = function(self, card)
            self:use(card)
        end
    }
    ]]--

    Entropy.Consumable{
        dependencies = {
            items = {
                "set_entr_inversions",
            }
        },
        order = -900 + 36,
        key = "muse",
        set = "Fraud",

        inversion = "c_bunc_art",

        atlas = "crossmod_consumables",
        config = {
            min_highlighted = 2,
            max_highlighted = 2
        },
        pos = {x=9,y=0},
        use = function(self, card)
            link_cards(G.hand.highlighted, self.key)
            card:juice_up(0.3, 0.5)
            end,
        can_use = function(self, card)
            if G.hand then
                local cards = G.hand.highlighted
                -- Group check:
                for i = 1, #cards do
                    if cards[i].ability.group then return false end
                end
                if #cards > 1 and #cards <= card.ability.max_highlighted then
                    return true
                end
            end
            return false
        end,
        loc_vars = function(self, info_queue, card)
            return {
                vars = {
                    card.ability.min_highlighted
                }
            }
        end,
        slib_credits = {
            idea = {"Athebyne"}
        },

        demicoloncompat = true,
        force_use = function(self, card)
            self:use(card)
        end
    }

    Entropy.Consumable{
        dependencies = {
            items = {
                "set_entr_inversions",
            }
        },
        order = -900 + 37,
        key = "garden",
        set = "Fraud",

        inversion = "c_bunc_universe",

        atlas = "crossmod_consumables",
        config = {
            min_highlighted = 3,
            max_highlighted = 3
        },
        pos = {x=11,y=0},
        use = function(self, card)
            local new_suit = pseudorandom_element(SMODS.Suits, pseudoseed('microcosm')).key
            local new_rank = pseudorandom_element(SMODS.Ranks, pseudoseed('microcosm')).key
            for _, playing_card in ipairs(G.hand.cards) do
                if playing_card.highlighted then
                    G.E_MANAGER:add_event(Event({delay = 0.2, trigger = 'before', func = function()
                        i = i and (i + 1) or 1
                        play_sound('card1', 0.85 + (i * 0.05))
                        playing_card:juice_up(0.7)
                        SMODS.change_base(playing_card, new_suit, new_rank)
                        return true end}))
                end
            end
        end,
        can_use = function(self, card)
            if G.hand and #G.hand.highlighted <= card.ability.max_highlighted and #G.hand.highlighted >= card.ability.min_highlighted then
                return true
            end
        end,
        loc_vars = function(self, info_queue, card)
            return {
                vars = {
                    card.ability.max_highlighted
                }
            }
        end,
        slib_credits = {
            idea = {"Athebyne"}
        },

        demicoloncompat = true,
        force_use = function(self, card)
            self:use(card)
        end
    }

    Entropy.Consumable{
        dependencies = {
            items = {
                "set_entr_inversions",
            }
        },
        order = -900 + 38,
        key = "desert",
        set = "Fraud",

        inversion = "c_bunc_sky",

        atlas = "crossmod_consumables",
        config = {
            -- consistent with bunco's exotic suits, buffs to them are stronger than buffs to the standard four.
            per_level = 15
        },
        pos = {x=8,y=1},
        use = function(self, card2)
            Entropy.level_suit("bunc_Fleurons", card2, 1, card2.ability.per_level)
        end,
        bulk_use = function(self, card2, _, _, amount)
            Entropy.level_suit("bunc_Fleurons", card2, amount, card2.ability.per_level)
        end,
        can_use = function(self, card)
            return true
        end,
        loc_vars = function(self, q, card)
            if not G.GAME.SuitBuffs then G.GAME.SuitBuffs = {} end
            if not G.GAME.SuitBuffs["bunc_Fleurons"] then G.GAME.SuitBuffs["bunc_Fleurons"] = {} end
            return {
                vars = {
                    G.GAME.SuitBuffs["bunc_Fleurons"].level or 1,
                    "",
                    localize("bunc_Fleurons",'suits_plural'),
                    card.ability.per_level,
                    colours = {
                        to_big(G.GAME.SuitBuffs["bunc_Fleurons"].level or 1) < to_big(2) and G.C.BLACK or G.C.HAND_LEVELS[to_number(math.min(7, G.GAME.SuitBuffs["bunc_Fleurons"].level or 1))]
                    }
                }
            }
        end,
        in_pool = function(self)
            return BUNCOMOD.funcs.exotic_in_pool()
        end,
        slib_credits = {
            idea = {"Athebyne"}
        },
        demicoloncompat = true,
        force_use = function(self, card)
            self:use(card)
        end
    }

    Entropy.Consumable{
        dependencies = {
            items = {
                "set_entr_inversions",
            }
        },
        order = -900 + 39,
        key = "wastes",
        set = "Fraud",

        inversion = "c_bunc_abyss",

        atlas = "crossmod_consumables",
        config = {
            -- consistent with bunco's exotic suits, buffs to them are stronger than buffs to the standard four.
            per_level = 15
        },
        pos = {x=9,y=1},
        use = function(self, card2)
            Entropy.level_suit("bunc_Halberds", card2, 1, card2.ability.per_level)
        end,
        bulk_use = function(self, card2, _, _, amount)
            Entropy.level_suit("bunc_Halberds", card2, amount, card2.ability.per_level)
        end,
        can_use = function(self, card)
            return true
        end,
        loc_vars = function(self, q, card)
            if not G.GAME.SuitBuffs then G.GAME.SuitBuffs = {} end
            if not G.GAME.SuitBuffs["bunc_Halberds"] then G.GAME.SuitBuffs["bunc_Halberds"] = {} end
            return {
                vars = {
                    G.GAME.SuitBuffs["bunc_Halberds"].level or 1,
                    "",
                    localize("bunc_Halberds",'suits_plural'),
                    card.ability.per_level,
                    colours = {
                        to_big(G.GAME.SuitBuffs["bunc_Halberds"].level or 1) < to_big(2) and G.C.BLACK or G.C.HAND_LEVELS[to_number(math.min(7, G.GAME.SuitBuffs["bunc_Halberds"].level or 1))]
                    }
                }
            }
        end,
        in_pool = function(self)
            return BUNCOMOD.funcs.exotic_in_pool()
        end,
        slib_credits = {
            idea = {"Athebyne"}
        },
        demicoloncompat = true,
        force_use = function(self, card)
            self:use(card)
        end
    }
end