is_number = is_number or function(x) return type(x) == "number" end

local card_drawref = Card.draw
function Card:draw(layer)
    local ref = card_drawref(self, layer)
    if self.config and self.config.center then
        if self.config.center.key == "c_entr_fervour" and G.GAME.entropy and G.GAME.entropy > 100 then
            self.children.center:draw_shader('entr_rainbow', nil, self.ARGS.send_to_shader)
        end
        if self.config.center.set == "Rune" and Entropy.providence_ui_active(self) then
            self.children.center:draw_shader('entr_providence', nil, self.ARGS.send_to_shader)
            if self.children.floating_sprite then
                local scale_mod = 0.07 + 0.02*math.sin(1.8*G.TIMERS.REAL) + 0.00*math.sin((G.TIMERS.REAL - math.floor(G.TIMERS.REAL))*math.pi*14)*(1 - (G.TIMERS.REAL - math.floor(G.TIMERS.REAL)))^3
                local rotate_mod = 0.05*math.sin(1.219*G.TIMERS.REAL) + 0.00*math.sin((G.TIMERS.REAL)*math.pi*5)*(1 - (G.TIMERS.REAL - math.floor(G.TIMERS.REAL)))^2
                self.children.floating_sprite:draw_shader('dissolve',0, nil, nil, self.children.center,scale_mod, rotate_mod,nil, 0.1 + 0.03*math.sin(1.8*G.TIMERS.REAL),nil, 0.6)
                self.children.floating_sprite:draw_shader('dissolve', nil, nil, nil, self.children.center, scale_mod, rotate_mod)
            end
        end
        if self.config.center.tsoul_pos then
            local scale_mod2 = 0.07 -- + 0.02*math.cos(1.8*G.TIMERS.REAL) + 0.00*math.cos((G.TIMERS.REAL - math.floor(G.TIMERS.REAL))*math.pi*14)*(1 - (G.TIMERS.REAL - math.floor(G.TIMERS.REAL)))^3
            local rotate_mod2 = 0 --0.05*math.cos(1.219*G.TIMERS.REAL) + 0.00*math.cos((G.TIMERS.REAL)*math.pi*5)*(1 - (G.TIMERS.REAL - math.floor(G.TIMERS.REAL)))^2
            if self.config.center.tsoul_pos.extra then
                self.children.floating_sprite2:draw_shader(
                    "dissolve",
                    0,
                    nil,
                    nil,
                    self.children.center,
                    scale_mod2,
                    rotate_mod2,
                    nil,
                    0.1 --[[ + 0.03*math.cos(1.8*G.TIMERS.REAL)--]],
                    nil,
                    0.6
                )
                self.children.floating_sprite2:draw_shader(
                    "dissolve",
                    nil,
                    nil,
                    nil,
                    self.children.center,
                    scale_mod2,
                    rotate_mod2
                )
            end
            local scale_mod = 0.05
                + 0.05 * math.sin(1.8 * G.TIMERS.REAL)
                + 0.07
                    * math.sin((G.TIMERS.REAL - math.floor(G.TIMERS.REAL)) * math.pi * 14)
                    * (1 - (G.TIMERS.REAL - math.floor(G.TIMERS.REAL))) ^ 3
            local rotate_mod = 0.1 * math.sin(1.219 * G.TIMERS.REAL)
                + 0.07
                    * math.sin(G.TIMERS.REAL * math.pi * 5)
                    * (1 - (G.TIMERS.REAL - math.floor(G.TIMERS.REAL))) ^ 2
    
            self.children.floating_sprite.role.draw_major = self
            self.children.floating_sprite:draw_shader(
                "dissolve",
                0,
                nil,
                nil,
                self.children.center,
                scale_mod,
                rotate_mod,
                nil,
                0.1 + 0.03 * math.sin(1.8 * G.TIMERS.REAL),
                nil,
                0.6
            )
            self.children.floating_sprite:draw_shader(
                "dissolve",
                nil,
                nil,
                nil,
                self.children.center,
                scale_mod,
                rotate_mod
            )
        end
    end
    return ref
end

local set_spritesref = Card.set_sprites
function Card:set_sprites(_center, _front)
	set_spritesref(self, _center, _front)
    if _center then
        if _center.tsoul_pos then
            self.children.floating_sprite = Sprite(
                self.T.x,
                self.T.y,
                self.T.w * (self.no_ui and 1.1*1.2 or 1),
                self.T.h * (self.no_ui and 1.1*1.2 or 1),
                G.ASSET_ATLAS[_center.atlas or _center.set],
                _center.tsoul_pos
            )
            self.children.floating_sprite.role.draw_major = self
            self.children.floating_sprite.states.hover.can = false
            self.children.floating_sprite.states.click.can = false
            if _center.tsoul_pos.extra then
                self.children.floating_sprite2 = Sprite(
                    self.T.x,
                    self.T.y,
                    self.T.w * (self.no_ui and 1.1*1.2 or 1),
                    self.T.h * (self.no_ui and 1.1*1.2 or 1),
                    G.ASSET_ATLAS[_center.atlas or _center.set],
                    _center.tsoul_pos.extra
                )
                self.children.floating_sprite2.role.draw_major = self
                self.children.floating_sprite2.states.hover.can = false
                self.children.floating_sprite2.states.click.can = false
            end
        end
    end
end

local e_round = end_round
function end_round()
    e_round()
    G.GAME.round_resets.path_toggled = nil
    local remove_temp = {}
    for i, v in pairs({G.jokers, G.hand, G.consumeables, G.discard, G.deck}) do
        for ind, card in pairs(v.cards) do
            if card.ability then
                if card.ability.entr_marked then card.ability.entr_marked = nil end
                if card.ability.entr_hotfix then
                    card.ability.entr_hotfix_rounds = (card.ability.entr_hotfix_rounds or 5) - 1
                    if to_big(card.ability.entr_hotfix_rounds) <= to_big(0) then
                        card.ability.entr_hotfix = false
                        
                        Cryptid.manipulate(card, {min=0.1, max=10})
                    end
                end
                if card.ability.temporary or card.ability.temporary2 or card.ability.void_temporary then
                    if card.area ~= G.hand and card.area ~= G.play and card.area ~= G.jokers and card.area ~= G.consumeables then card.states.visible = false end
                    card:remove_from_deck()
                    G.entr_bypass_rebirth = true
                    card:start_dissolve()
                    G.entr_bypass_rebirth = nil
                    if card.ability.temporary then remove_temp[#remove_temp+1]=card end
                end
                if card.ability.entr_yellow_sign then card.ability.entr_yellow_sign = nil end
                if card.ability.superego then
                    card.ability.superego_copies = (card.ability.superego_copies or 0) + 0.5
                end
                card.perma_debuff = nil
                if card.ability.entr_pseudorandom then
                    card.ability.entr_pseudorandom = false
                    card.ability.cry_rigged = false
                end
                if card.ability.debuff_timer then
                    card.ability.debuff_timer = card.ability.debuff_timer - 1
                    if card.ability.debuff_timer <= 0 then
                        card.ability.debuff_timer = nil
                        card.ability.debuff_timer_max = nil
                        card:set_debuff(false)
                        card_eval_status_text(
                            card,
                            "extra",
                            nil,
                            nil,
                            nil,
                            { message = localize("k_undebuffed_ex"), colour = G.C.RED }
                        )
                    else
                        card_eval_status_text(
                            card,
                            "extra",
                            nil,
                            nil,
                            nil,
                            { message = number_format(card.ability.debuff_timer_max-card.ability.debuff_timer).."/"..number_format(card.ability.debuff_timer_max), colour = G.C.RED }
                        )
                    end
                end
            end
        end
    end
    if #remove_temp > 0 then
        SMODS.calculate_context({remove_playing_cards = true, removed=remove_temp})
    end
    if G.GAME.blind_on_deck == "Boss" then
        G.GAME.entr_princess = nil
    end
    G.GAME.entr_antithesis_active = nil
    G.GAME.antithesis_index = nil
end

local set_debuffref = Card.set_debuff

function Card:set_debuff(should_debuff)
    if (self.perma_debuff or self.ability.superego or self.ability.debuff_timer) and not self.dissolved then should_debuff = true end
    if self.ability.entr_hotfix or G.GAME.nodebuff then should_debuff = false end
    set_debuffref(self, should_debuff)
end

create_UIBox_your_collection_seals = function()
    return SMODS.card_collection_UIBox(G.P_CENTER_POOLS.Seal, {6,6}, {
        snap_back = true,
        infotip = localize('ml_edition_seal_enhancement_explanation'),
        hide_single_page = true,
        collapse_single_page = true,
        center = 'c_base',
        h_mod = 1.03,
        modify_card = function(card, center)
           card:set_seal(center.key, true)
        end,
    })
end

local add_stickerref = Card.add_sticker
function Card:add_sticker(sticker, bypass_check)
    add_stickerref(self, sticker, bypass_check)
    SMODS.calculate_context({card_modified = true, other_card = self})
    local link = self and self.ability and self.ability.link
    if link then
        Entropy.iter_for({G.hand.cards, G.discard.cards, G.deck.cards}, function(i, v)
            if v.ability.link == link then
                add_stickerref(v, sticker, bypass_check)
                SMODS.calculate_context({card_modified = true, other_card = v})
                v.ability.link = link 
            end
        end)
    end
end

local set_sealref = Card.set_seal
function Card:set_seal(_seal, silent, immediate)
    set_sealref(self, _seal, silent, immediate)
    SMODS.calculate_context({card_modified = true, other_card = self})
    local link = self and self.ability and self.ability.link
    if link then
        Entropy.iter_for({G.hand.cards, G.discard.cards, G.deck.cards}, function(i, v)
            if v.ability.link == link then
                set_sealref(v, _seal, silent, immediate)
                SMODS.calculate_context({card_modified = true, other_card = v})
                v.ability.link = link 
            end
        end)
    end
end

function Entropy.is_disavowed(card)
    return card.config.center ~= "m_entr_disavowed" or G.GAME.modifiers.entr_gfb
end

local set_abilityref = Card.set_ability
function Card:set_ability(center, initial, delay)
    local link = self and self.ability and self.ability.link
    if (self.config and Entropy.is_disavowed(self) and (not self.entr_aleph or self.ability.bypass_aleph)) or G.SETTINGS.paused then
        set_abilityref(self, center, initial, delay)
        if self.config.center.set == "Default" or self.config.center.set == "Enhanced" then
            SMODS.calculate_context({card_modified = true, other_card = self})
        end
    end
    if self.ability then
        self.ability.link = link
        if link and not initial then
            Entropy.iter_for({G.hand.cards, G.discard.cards, G.deck.cards}, function(i, v)
                if v.ability.link == link then
                    if (v.config and Entropy.is_disavowed(self) and (not v.entr_aleph or v.ability.bypass_aleph)) or G.SETTINGS.paused then
                        set_abilityref(v, center, initial, delay)
                        if v.config.center.set == "Default" or v.config.center.set == "Enhanced" then
                            SMODS.calculate_context({card_modified = true, other_card = v})
                        end
                    end
                    v.ability.link = link 
                end
            end)
        end
    end
    if type(center) == "string" then center = G.P_CENTERS[center] end
    if center and center.key == "m_stone" then
        self.ability.bonus = 50
    end
end

local set_editionref = Card.set_edition
function Card:set_edition(edition, immediate, silent)
    set_editionref(self, edition, immediate, silent)
    SMODS.calculate_context({card_modified = true, other_card = self})
    if self.ability.link then
        Entropy.iter_for({G.hand.cards, G.discard.cards, G.deck.cards}, function(i, v)
            if v.ability.link == self.ability.link then
                set_editionref(v, edition, immediate, silent) 
                SMODS.calculate_context({card_modified = true, other_card = v})
            end
        end)
    end
    if self:is_sunny() and self.area == G.jokers then 
        check_for_unlock({ type = "sunny_joker" })
    end
end

local set_base_ref = Card.set_base
function Card:set_base(card, initial, manual_sprites)
    set_base_ref(self, card, initial, manual_sprites)
    SMODS.calculate_context({card_modified = true, other_card = self})
    if self.ability and self.ability.link and G.hand then
        Entropy.iter_for({G.hand.cards, G.discard.cards, G.deck.cards}, function(i, v)
            if v.ability.link == self.ability.link then
                set_base_ref(v, card, initial, manual_sprites) 
                SMODS.calculate_context({card_modified = true, other_card = v})
            end
        end)
    end
end

local ref = Card.get_other_side_dummy
function Card:get_other_side_dummy()
    local val = ref(self)
    if val then
        val.is_sunny = function(_, ...)
            return self:is_sunny(...)
        end
    end
    return val
end

local start_dissolveref = Card.start_dissolve
function Card:start_dissolve(...)
    start_dissolveref(self, ...)
    if self.ability.link then
        for i, v in pairs(G.hand.cards) do
            if v.ability.link == self.ability.link then
                SMODS.calculate_context({remove_playing_cards = true, removed={v}})
                start_dissolveref(v, ...) 
                v.ability.temporary2 = true
            end
        end
        for i, v in pairs(G.discard.cards) do
            if v.ability.link == self.ability.link then
                SMODS.calculate_context({remove_playing_cards = true, removed={v}})
                start_dissolveref(v, ...) 
                v.ability.temporary2 = true
            end
        end
        for i, v in pairs(G.deck.cards) do
            if v.ability.link == self.ability.link then
                SMODS.calculate_context({remove_playing_cards = true, removed={v}})
                start_dissolveref(v, ...) 
                v.ability.temporary2 = true
            end
        end
    end
    if self.config.center_key == "j_entr_prismatic_shard" and G.GAME.pool_flags then
        G.GAME.pool_flags.prismatic_shard_gone = true
    end
end

local is_suitref = Card.is_suit
function Card:is_suit(suit, bypass_debuff, flush_calc)
    if self.base.suit == "entr_nilsuit" and not next(SMODS.find_card("j_entr_opal")) then
        return false
    else
        if next(SMODS.find_card("j_entr_inkbleed")) and self.area then
            local highlighted = self.highlighted
            for i, v in pairs(highlighted and self.area.highlighted or self.area.cards) do
                if v.base.suit == suit and Entropy.shares_aspect(self, v) then
                    return true
                end
            end
        end
        return is_suitref(self, suit, bypass_debuff, flush_calc)
    end
end
local ref = Card.get_id
function Card:get_id()
    if (self.ability.effect == 'Stone Card' and not self.vampired) or self.base.value == "entr_nilrank" then
        return -math.random(100, 1000000)
    end
    return ref(self)
end

G.FUNCS.can_toggle_xekanos = function(e)
    if
        e.config.ref_table.ability.turned_off
    then
        e.config.colour = G.C.GREEN
        e.config.button = "toggle_xekanos"
    else
        e.config.colour = G.C.RED
        e.config.button = "toggle_xekanos"
    end
end
G.FUNCS.toggle_xekanos = function(e)
    local c1 = e.config.ref_table
    c1.ability.turned_off = not (c1.ability.turned_off or false)
    local text = ({
        [true] = localize("b_on"),
        [false] = localize("b_off")
    })[c1.ability.turned_off]
    e.parent.UIBox:get_UIE_by_ID("on_offswitch").config.text = text
    e.parent.UIBox:get_UIE_by_ID("on_offswitch").config.text_drawable:set(text)
    e.parent.UIBox:get_UIE_by_ID("on_offswitch").UIBox:recalculate()
end

G.FUNCS.can_cycle_apeirostemma = function(e)
    local c1 = e.config.ref_table
    e.config.colour = G.C.GREEN
    e.config.button = "cycle_apeirostemma"
end
G.FUNCS.cycle_apeirostemma = function(e)
    local c1 = e.config.ref_table
    c1.ability.immutable.dice_effect = c1.ability.immutable.dice_effect + 1
    if c1.ability.immutable.dice_effect > 6 then
        c1.ability.immutable.dice_effect = 1
    end
end

G.FUNCS.can_buy_slot = function(e)
    if
        to_big(G.GAME.dollars-G.GAME.bankrupt_at) > to_big(e.config.ref_table.ability.buycost) and not G.CONTROLLER.locked
    then
        e.config.colour = G.C.GREEN
        e.config.button = "buy_slot"
    else
        e.config.colour = G.C.UI.BACKGROUND_INACTIVE
        e.config.button = nil
    end
end
G.FUNCS.buy_slot = function(e)
    local c1 = e.config.ref_table
    ease_dollars(-e.config.ref_table.ability.buycost)
    Entropy.handle_card_limit(G.jokers, 1)
end

G.FUNCS.can_sell_slot = function(e)
    if
        G.jokers.config.card_limit > #G.jokers.cards
    then
        e.config.colour = G.C.GREEN
        e.config.button = "sell_slot"
    else
        e.config.colour = G.C.UI.BACKGROUND_INACTIVE
        e.config.button = nil
    end
end
G.FUNCS.sell_slot = function(e)
    local c1 = e.config.ref_table
    ease_dollars(e.config.ref_table.ability.sellcost)
    Entropy.handle_card_limit(G.jokers, -1)
end

--som
local G_UIDEF_use_and_sell_buttons_ref = G.UIDEF.use_and_sell_buttons
function G.UIDEF.use_and_sell_buttons(card)
	local abc = G_UIDEF_use_and_sell_buttons_ref(card)
    if (card.area == G.jokers and G.jokers and card.config.center.key == "j_entr_akyros") and not card.debuff then
        sell = {n=G.UIT.C, config={align = "cr"}, nodes={
            {n=G.UIT.C, config={ref_table = card, align = "cr",padding = 0.1, r=0.08, minw = 1.25, hover = true, shadow = true, colour = G.C.UI.BACKGROUND_INACTIVE, one_press = true, button = 'sell_card', func = 'can_sell_card', handy_insta_action = 'sell'}, nodes={
              {n=G.UIT.B, config = {w=0.1,h=0.6}},
              {n=G.UIT.C, config={align = "tm"}, nodes={
                {n=G.UIT.R, config={align = "cm", maxw = 1.25}, nodes={
                  {n=G.UIT.T, config={text = localize('b_sell'),colour = G.C.UI.TEXT_LIGHT, scale = 0.4, shadow = true}}
                }},
                {n=G.UIT.R, config={align = "cm"}, nodes={
                  {n=G.UIT.T, config={text = localize('$'),colour = G.C.WHITE, scale = 0.4, shadow = true}},
                  {n=G.UIT.T, config={ref_table = card, ref_value = 'sell_cost_label',colour = G.C.WHITE, scale = 0.55, shadow = true}}
                }}
              }}
            }},
          }}
        buyslot = {n=G.UIT.C, config={align = "cr"}, nodes={
            {n=G.UIT.C, config={ref_table = card, align = "cr",padding = 0.1, r=0.08, minw = 1.25, hover = true, shadow = true, colour = G.C.UI.BACKGROUND_INACTIVE, button = 'buy_slot', func = 'can_buy_slot'}, nodes={
              {n=G.UIT.B, config = {w=0.1,h=0.6}},
              {n=G.UIT.C, config={align = "tm"}, nodes={
                {n=G.UIT.R, config={align = "cm", maxw = 1.25}, nodes={
                  {n=G.UIT.T, config={text = localize('b_buy_slot'),colour = G.C.UI.TEXT_LIGHT, scale = 0.4, shadow = true}}
                }},
                {n=G.UIT.R, config={align = "cm"}, nodes={
                  {n=G.UIT.T, config={text = localize('$'),colour = G.C.WHITE, scale = 0.4, shadow = true}},
                  {n=G.UIT.T, config={ref_table = card.ability, ref_value = 'buycost',colour = G.C.WHITE, scale = 0.55, shadow = true}}
                }}
              }}
            }},
          }}
          sellslot = {n=G.UIT.C, config={align = "cr"}, nodes={
            {n=G.UIT.C, config={ref_table = card, align = "cr",padding = 0.1, r=0.08, minw = 1.25, hover = true, shadow = true, colour = G.C.UI.BACKGROUND_INACTIVE, button = 'sell_slot', func = 'can_sell_slot'}, nodes={
              {n=G.UIT.B, config = {w=0.1,h=0.6}},
              {n=G.UIT.C, config={align = "tm"}, nodes={
                {n=G.UIT.R, config={align = "cm", maxw = 1.25}, nodes={
                  {n=G.UIT.T, config={text = localize('b_sell_slot'),colour = G.C.UI.TEXT_LIGHT, scale = 0.4, shadow = true}}
                }},
                {n=G.UIT.R, config={align = "cm"}, nodes={
                  {n=G.UIT.T, config={text = localize('$'),colour = G.C.WHITE, scale = 0.4, shadow = true}},
                  {n=G.UIT.T, config={ref_table = card.ability, ref_value = 'sellcost',colour = G.C.WHITE, scale = 0.55, shadow = true}}
                }}
              }}
            }},
          }}
        return {
            n=G.UIT.ROOT, config = {padding = 0, colour = G.C.CLEAR}, nodes={
              {n=G.UIT.C, config={padding = 0, align = 'cl'}, nodes={
                {n=G.UIT.R, config={align = 'cl'}, nodes={
                  sell
                }},
                {n=G.UIT.R, config={align = 'cl'}, nodes={
                  buyslot
                }},
                {n=G.UIT.R, config={align = 'cl'}, nodes={
                    sellslot
                  }},
              }},
          }}
    end
    if (card.area == G.jokers and G.jokers and card.config.center.key == "j_entr_apeirostemma") then
        sell = {n=G.UIT.C, config={align = "cr"}, nodes={
            {n=G.UIT.C, config={ref_table = card, align = "cr",padding = 0.1, r=0.08, minw = 1.25, hover = true, shadow = true, colour = G.C.UI.BACKGROUND_INACTIVE, one_press = true, button = 'sell_card', func = 'can_sell_card', handy_insta_action = 'sell'}, nodes={
              {n=G.UIT.B, config = {w=0.1,h=0.6}},
              {n=G.UIT.C, config={align = "tm"}, nodes={
                {n=G.UIT.R, config={align = "cm", maxw = 1.25}, nodes={
                  {n=G.UIT.T, config={text = localize('b_sell'),colour = G.C.UI.TEXT_LIGHT, scale = 0.4, shadow = true}}
                }},
                {n=G.UIT.R, config={align = "cm"}, nodes={
                  {n=G.UIT.T, config={text = localize('$'),colour = G.C.WHITE, scale = 0.4, shadow = true}},
                  {n=G.UIT.T, config={ref_table = card, ref_value = 'sell_cost_label',colour = G.C.WHITE, scale = 0.55, shadow = true}}
                }}
              }}
            }},
          }}
        onoff = {n=G.UIT.C, config={align = "cr"}, nodes={
            {n=G.UIT.C, config={ref_table = card, align = "cr",padding = 0.1, r=0.08, minw = 1.25, hover = true, shadow = true, colour = G.C.UI.BACKGROUND_INACTIVE, button = 'cycle_apeirostemma', func = 'can_cycle_apeirostemma', handy_insta_action = 'use'}, nodes={
              {n=G.UIT.B, config = {w=0.1,h=0.3}},
              {n=G.UIT.C, config={align = "tm"}, nodes={
                {n=G.UIT.R, config={align = "cm", maxw = 1.25}, nodes={
                  {n=G.UIT.T, config={text = localize('b_cycle'),colour = G.C.UI.TEXT_LIGHT, scale = 0.4, shadow = true, id ="cycle"}}
                }},
              }}
            }},
          }}
        return {
            n=G.UIT.ROOT, config = {padding = 0, colour = G.C.CLEAR}, nodes={
              {n=G.UIT.C, config={padding = 0, align = 'cl'}, nodes={
                {n=G.UIT.R, config={align = 'cl'}, nodes={
                  sell
                }},
                {n=G.UIT.R, config={align = 'cl'}, nodes={
                  onoff
                }},
              }},
          }}
    end
    if (card.area == G.jokers and G.jokers and card.config.center.key == "j_entr_xekanos") and not G.GAME.modifiers.entr_reverse_redeo then
        sell = {n=G.UIT.C, config={align = "cr"}, nodes={
            {n=G.UIT.C, config={ref_table = card, align = "cr",padding = 0.1, r=0.08, minw = 1.25, hover = true, shadow = true, colour = G.C.UI.BACKGROUND_INACTIVE, one_press = true, button = 'sell_card', func = 'can_sell_card', handy_insta_action = 'sell'}, nodes={
              {n=G.UIT.B, config = {w=0.1,h=0.6}},
              {n=G.UIT.C, config={align = "tm"}, nodes={
                {n=G.UIT.R, config={align = "cm", maxw = 1.25}, nodes={
                  {n=G.UIT.T, config={text = localize('b_sell'),colour = G.C.UI.TEXT_LIGHT, scale = 0.4, shadow = true}}
                }},
                {n=G.UIT.R, config={align = "cm"}, nodes={
                  {n=G.UIT.T, config={text = localize('$'),colour = G.C.WHITE, scale = 0.4, shadow = true}},
                  {n=G.UIT.T, config={ref_table = card, ref_value = 'sell_cost_label',colour = G.C.WHITE, scale = 0.55, shadow = true}}
                }}
              }}
            }},
          }}
        onoff = {n=G.UIT.C, config={align = "cr"}, nodes={
            {n=G.UIT.C, config={ref_table = card, align = "cr",padding = 0.1, r=0.08, minw = 1.25, hover = true, shadow = true, colour = G.C.UI.BACKGROUND_INACTIVE, button = 'toggle_xekanos', func = 'can_toggle_xekanos', handy_insta_action = 'use'}, nodes={
              {n=G.UIT.B, config = {w=0.1,h=0.3}},
              {n=G.UIT.C, config={align = "tm"}, nodes={
                {n=G.UIT.R, config={align = "cm", maxw = 1.25}, nodes={
                  {n=G.UIT.T, config={text = card.ability.turned_off and localize('b_on') or localize('b_off'),colour = G.C.UI.TEXT_LIGHT, scale = 0.4, shadow = true, id ="on_offswitch"}}
                }},
              }}
            }},
          }}
        return {
            n=G.UIT.ROOT, config = {padding = 0, colour = G.C.CLEAR}, nodes={
              {n=G.UIT.C, config={padding = 0, align = 'cl'}, nodes={
                {n=G.UIT.R, config={align = 'cl'}, nodes={
                  sell
                }},
                {n=G.UIT.R, config={align = 'cl'}, nodes={
                  onoff
                }},
              }},
          }}
    end
	return abc
end

local sell_ref = G.FUNCS.sell_card
G.FUNCS.sell_card = function(e)
    if e.config.ref_table.ability.superego_copies then
        for i = 1, e.config.ref_table.ability.superego_copies do
            local card2 = copy_card(e.config.ref_table)
            card2:add_to_deck()
            card2.ability.superego = nil
            card2.ability.superego_copies = nil
            card2:set_debuff(false)
            card2.sell_cost = 0
            e.config.ref_table.area:emplace(card2)
        end
    end
    sell_ref(e)
end

local scie = SMODS.calculate_individual_effect
function SMODS.calculate_individual_effect(effect, scored_card, key, amount, from_edition, ...)
    if Entropy.blind_is("bl_entr_theta") and not G.GAME.blind.disabled then
        --hacky solution
        --probably want a whitelist of effects in the future
        --but should work fine if everyone uses standard capitalisation
        key = key:gsub("mult_mod", "chip_mod")
        key = key:gsub("mult", "chips")
    end
    local ret
    if next(SMODS.find_card("j_entr_error")) and type(amount) == "number" then
        local mult = 1
        for i, v in pairs(SMODS.find_card("j_entr_error")) do
            mult = mult + pseudorandom("entr_error", 95000, 120000)/100000 - 1
            if not Entropy.should_skip_animations() then
                v:juice_up()
            end
        end
        amount = amount * mult
    end
    if G.message_card then
        effect.message_card = G.message_card
        scored_card = G.message_card
    end
    if (G.GAME.modifiers.entr_gfb and string.find(key, "mult") or string.find(key, "chip")) and next(SMODS.find_card("j_entr_yogurt")) then
        SMODS.calculate_context({entr_chips_calculated = true, other_card = scored_card or effect.card})
    end
    if scored_card and scored_card.ability and scored_card.ability.entr_value_fac and type(amount) == "number" then
        amount= amount * scored_card.ability.entr_value_fac
    end
    if key == "e_chips" or key == "echips" or key == "Echip_mod" then
        for i, v in pairs(G.jokers.cards) do
            if v.config.center_key == "j_entr_unstable_rift" then
                v.ability.extra.chips = v.ability.extra.chips ^ (1 + (amount - 1) * 0.2)
            end
        end
    end
    if key == "e_mult" or key == "emult" or key == "Emult_mod" then
        for i, v in pairs(G.jokers.cards) do
            if v.config.center_key == "j_entr_unstable_rift" then
                v.ability.extra.mult = v.ability.extra.mult ^ (1 + (amount - 1) * 0.2)
            end
        end
    end
    ret = scie(effect, scored_card, key, amount, from_edition, ...)
    if scored_card and next(SMODS.find_card("j_entr_mutagenesis")) and scored_card.is_playing_card and scored_card:is_playing_card() and (not effect.message_card or effect.message_card == scored_card) and key ~= "message" and key ~= "colour" then
        for i, v in pairs(SMODS.find_card("j_entr_mutagenesis")) do
            if Entropy.add_perma_bonus(v, key, amount) then
                if not Entropy.should_skip_animations() then
                    G.E_MANAGER:add_event(Event{
                        trigger = "after",
                        func = function()
                            play_sound("entr_void_generic")
                            return true
                        end
                    })
                end
                delay(0.1)
                SMODS.calculate_effect({message = localize("k_upgrade_ex"), colour = Entropy.void_gradient, card = v})
            end
        end
    end
    if (key == 'mult' or key == 'h_mult' or key == 'mult_mod') and amount then
        for i, v in pairs(G.jokers.cards) do
            if v.config.center_key == "j_entr_unstable_rift" then
                v.ability.extra.mult = v.ability.extra.mult + amount * 0.2
                SMODS.calculate_effect({card = v, message = localize("k_upgrade_ex"), colour = G.C.RED})
            end
        end
    end
    if (key == 'x_mult' or key == 'xmult' or key == 'Xmult' or key == 'x_mult_mod' or key == 'Xmult_mod') and amount ~= 1 then
        for i, v in pairs(G.jokers.cards) do
            if v.config.center_key == "j_entr_unstable_rift" then
                v.ability.extra.mult = v.ability.extra.mult * (1 + (amount - 1) * 0.2)
                SMODS.calculate_effect({card = v, message = localize("k_upgrade_ex"), colour = G.C.RED})
            end
        end
    end
    if (key == 'chips' or key == 'h_chips' or key == 'chip_mod') and amount then
        for i, v in pairs(G.jokers.cards) do
            if v.config.center_key == "j_entr_unstable_rift" then
                v.ability.extra.chips = v.ability.extra.chips + amount * 0.2
                SMODS.calculate_effect({card = v, message = localize("k_upgrade_ex"), colour = G.C.BLUE})
            end
        end
    end
    if (key == 'x_chips' or key == 'xchips' or key == 'Xchip_mod') and amount ~= 1 then
        for i, v in pairs(G.jokers.cards) do
            if v.config.center_key == "j_entr_unstable_rift" then
                v.ability.extra.chips = v.ability.extra.chips * (1 + (amount - 1) * 0.2)
                SMODS.calculate_effect({card = v, message = localize("k_upgrade_ex"), colour = G.C.BLUE})
            end
        end
    end
    if ret then
        return ret
    end
end

local entr_define_dt = 0
local entr_antireal_dt = 0
local entr_xekanos_dt = 0
local entr_grahkon_dt = 0
local bdt = 0
local entr_prismatic_dt = 0
local update_ref = Game.update
Entropy.last_csl = nil
Entropy.last_slots = nil
local cdt = 0

function Game:update(dt)
    if entr_xekanos_dt > 0.05 then
        entr_xekanos_dt = 0
    end
    if entr_grahkon_dt > 0.1 then
        entr_grahkon_dt = 0
    end
    if bdt > 0.15 then
        bdt = 0
    end
    update_ref(self, dt)
    entr_define_dt = entr_define_dt + dt
    entr_prismatic_dt = entr_prismatic_dt + dt
    if G.P_CENTERS and G.P_CENTERS.c_entr_define and entr_define_dt > 0.5 then
		entr_define_dt = 0
		local pointerobj = G.P_CENTERS.c_entr_define
		pointerobj.pos.x = (pointerobj.pos.x == 4) and 5 or 4
	end
    if G.P_CENTERS and G.P_CENTERS.j_entr_prismatic_shard and entr_prismatic_dt > 0.05 then
		entr_prismatic_dt = 0
		local pointerobj = G.P_CENTERS.j_entr_prismatic_shard
		pointerobj.pos.x = pointerobj.pos.x + 1
        if pointerobj.pos.x > 10 then
            pointerobj.pos.x = 0
        end
        local crimsonobj = G.P_CENTERS.j_entr_blooming_crimson
        crimsonobj.pos.x = crimsonobj.pos.x + 1
        if crimsonobj.pos.x > 7 then
            crimsonobj.pos.x = 0
        end
	end
    entr_antireal_dt = entr_antireal_dt + dt
    if G.P_CENTERS and G.P_CENTERS.j_entr_antireal and entr_antireal_dt > 0.05 then
		entr_antireal_dt = 0
		local obj = G.P_CENTERS.j_entr_antireal
		obj.pos.x = obj.pos.x + 1 
        if obj.pos.x > 11 then
            obj.pos.x = 0
            obj.pos.y = obj.pos.y + 1
        end
        if obj.pos.y > 9 then
            obj.pos.y = 0
            obj.pos.x = 0
        end
	end
    if G.runes then
        for i, v in pairs(G.runes) do
            if Entropy.providence_ui_active(v) and v.shader ~= "entr_providence" and v.HUD_sprite then 
                v.shader = "entr_providence" 
                v.HUD_sprite:define_draw_steps({
                    {shader = 'dissolve', shadow_height = 0.05},
                    {shader = v.shader},
                })
            elseif not Entropy.providence_ui_active(v) and v.shader ~= "dissolve" and v.HUD_sprite then
                 v.shader = "dissolve" 
                 v.HUD_sprite:define_draw_steps({
                    {shader = 'dissolve', shadow_height = 0.05},
                    {shader = v.shader},
                })
            end
        end
    end
    if G.your_collection_runes then
        for i, v in pairs(G.your_collection_runes) do
            if Entropy.providence_ui_active(v.tag) and v.tag.shader ~= "entr_providence" then 
                v.tag.shader = "entr_providence" 
                v.sprite:define_draw_steps({
                    {shader = 'dissolve', shadow_height = 0.05},
                    {shader = v.tag.shader},
                })
            elseif not Entropy.providence_ui_active(v.tag) and v.tag.shader ~= "dissolve" then
                 v.tag.shader = "dissolve" 
                 v.sprite:define_draw_steps({
                    {shader = 'dissolve', shadow_height = 0.05},
                    {shader = v.tag.shader},
                })
            end
        end
    end
    entr_xekanos_dt = entr_xekanos_dt + dt
    entr_grahkon_dt = entr_grahkon_dt + dt
    bdt = bdt + dt
    cdt = cdt + dt
    if Entropy.deck_or_sleeve("ambisinister") and cdt > 0.05 and G.jokers then
        if not Entropy.last_csl then Entropy.last_csl = G.hand.config.highlighted_limit end
        if not Entropy.last_slots then Entropy.last_slots = (G.jokers.config.card_limit - #G.jokers.cards) end
        local slots_diff = (G.jokers.config.card_limit - #G.jokers.cards) - Entropy.last_slots
        local csl_diff = (G.hand.config.highlighted_limit) - Entropy.last_csl
        if csl_diff ~= 0 then
            Entropy.handle_card_limit(G.jokers, csl_diff)
        end
        if slots_diff ~= 0 then
            G.hand.config.highlighted_limit = G.hand.config.highlighted_limit + slots_diff
            G.GAME.starting_params.discard_limit = G.GAME.starting_params.discard_limit + slots_diff
            G.GAME.starting_params.play_limit = G.GAME.starting_params.play_limit + slots_diff
        end
        Entropy.last_slots = G.jokers.config.card_limit - #G.jokers.cards
        G.hand.config.highlighted_limit = (G.jokers.config.card_limit - #G.jokers.cards)
        G.GAME.starting_params.play_limit = (G.jokers.config.card_limit - #G.jokers.cards)
        G.GAME.starting_params.discard_limit = (G.jokers.config.card_limit - #G.jokers.cards)
        SMODS.hand_limit_strings.discard = G.GAME.starting_params.discard_limit ~= 5 and localize('b_limit') .. G.GAME.starting_params.discard_limit or ''
        SMODS.hand_limit_strings.play = G.GAME.starting_params.play_limit ~= 5 and localize('b_limit') .. G.GAME.starting_params.play_limit or ''
        Entropy.last_csl = G.hand.config.highlighted_limit
    end
    if not Entropy.deck_or_sleeve("ambisinister") and cdt > 0.05 then
        Entropy.last_csl = nil
        Entropy.last_slots = nil
        cdt = 0
    end

    if G.GAME.blind and G.GAME.blind.config.blind.is_ee
    or G.GAME.EE_SCREEN
    then
        G.GAME.EE_FADE = G.GAME.EE_FADE or 0
        G.GAME.EE_FADE = G.GAME.EE_FADE + dt * 0.5 * (G.GAME.EE_FADE_SPEED or 4)
    end
    if G.GAME.EE_FADE then
        G.entr_rand_text = Entropy.string_random(6)
        G.entr_rand_text2 = Entropy.string_random(6)
    end
    if G.GAME.EE_R and G.GAME.EE_FADE then
        if G.GAME.EE_FADE > 10 then
            G.GAME.EE_FADE = 10
        end
        G.GAME.EE_FADE = G.GAME.EE_FADE - dt * 3 * (G.GAME.EE_FADE_SPEED or 1)
        if G.GAME.EE_FADE <= 0 then
            G.GAME.EE_R = nil
        end
    end
end

local card_drawref = Card.draw
function Card:draw(layer)
    if self.config.center.key == "j_entr_xekanos" then
        if entr_xekanos_dt > 0.05 then
            local v = self
            local obj = {pos = v.children.floating_sprite2.sprite_pos}
            obj.pos.x = obj.pos.x + 1 
            if obj.pos.x > 4 then
                obj.pos.x = 0
                obj.pos.y = obj.pos.y + 1
            end
            if obj.pos.y > 2 then
                obj.pos.y = 0
                obj.pos.x = 0
            end
            v.children.floating_sprite2:set_sprite_pos(obj.pos)
            v.children.floating_sprite:set_sprite_pos({x=1, y=3})
        end
    end
    if self.config.center.key == "j_entr_grahkon" or self.config.center.key == "j_entr_nokharg" then
        if entr_grahkon_dt > 0.1 then
            local v = self
            local obj = {pos = v.children.floating_sprite.sprite_pos}
            obj.pos.x = obj.pos.x + 1 
            if obj.pos.x > 5 then
                obj.pos.x = 1
                obj.pos.y = obj.pos.y + 1
            end
            if obj.pos.y > 3 then
                obj.pos.y = 0
                obj.pos.x = 1
            end
            v.children.floating_sprite:set_sprite_pos(obj.pos)
        end
    end
    if bdt >= 0.15 and self.config.center.set == "CBlind" then
        local obj = {pos = self.children.center.sprite_pos}
        obj.pos.x = obj.pos.x + 1
        if to_number(obj.pos.x) >= to_number(self.children.center.atlas.frames or 21) then
            obj.pos.x = 0
        end
    end
    return card_drawref(self, layer)
end

local ref = level_up_hand
function level_up_hand(card, hand, instant, amount, ...)
    if next(SMODS.find_card("j_entr_strawberry_pie")) and hand ~= "High Card" then
        for i, v in pairs(SMODS.find_card("j_entr_strawberry_pie")) do
            if hand == "Full House" or hand == "Straight" or hand == "Flush" then
                hand = "High Card"
            end
        end 
    end
    local val = ref(card,hand,instant,amount, ...)
    return val
end

local dest_cards = SMODS.destroy_cards
function SMODS.destroy_cards(cards, args, ...)
    for i, v in pairs(cards) do
        if not v.ability.no_destroy then
            SMODS.calculate_context({card_being_destroyed=true, card=v, cardarea=v.area})
        end
    end
    return dest_cards(cards, args, ...)
end

local start_dissolveref = Card.start_dissolve
function Card:start_dissolve(dissolve_colours, silent, dissolve_time_fac, no_juice)
    if self.delay_dissolve then
        local s = self.delay_dissolve
        local d
        if type(s) == "table" then s = s.type; d = s.delay end
        if s == "after_after" then
            G.E_MANAGER:add_event(Event{
                trigger = "after",
                blocking = false,
                func = function()
                    G.E_MANAGER:add_event(Event{
                        trigger = "after",
                        delay = d,
                        func = function()
                            start_dissolveref(self, dissolve_colours, silent, dissolve_time_fac, no_juice)
                            return true
                        end
                    })
                    return true
                end
            })
        else
            G.E_MANAGER:add_event(Event{
                trigger = type(s) == "string" and s or nil,
                delay = d,
                func = function()
                    start_dissolveref(self, dissolve_colours, silent, dissolve_time_fac, no_juice)
                    return true
                end
            })
        end
    else    
        start_dissolveref(self, dissolve_colours, silent, dissolve_time_fac, no_juice)
    end
end

Entropy.ChaosBlacklist.Back = true
Entropy.ChaosBlacklist.Sleeve = true
Entropy.ChaosBlacklist.CBlind = true
Entropy.ChaosBlacklist.Edition = true
Entropy.ChaosBlacklist.Default = true
Entropy.ChaosBlacklist["Content Set"] = true
Entropy.ParakmiBlacklist["Content Set"] = true
Entropy.ParakmiBlacklist.Edition = true
Entropy.ParakmiBlacklist.Default = true
Entropy.ParakmiBlacklist.Tag = true
Entropy.ParakmiBlacklist.Seal = true
Entropy.ParakmiBlacklist.Stake = true
Entropy.ParakmiBlacklist.Unique = true
Entropy.ParakmiBlacklist.sleeve_casl_none = true
Entropy.ParakmiBlacklist["Rune Tag"] = true
Entropy.ParakmiBlacklist.DescriptionDummy = true
Entropy.ChaosConversions.Command = "Twisted"
Entropy.ChaosConversions.Star = "Twisted"
Entropy.ChaosConversions.Omen = "Twisted"
Entropy.ChaosConversions.Pact = "Twisted"
local ref = create_card
function create_card(_type, area, legendary, _rarity, skip_materialize, soulable, forced_key, key_append, ...)
    if not _rarity and not legendary and (next(find_joker("j_entr_chaos")) or next(find_joker("j_entr_parakmi")) or G.GAME.modifiers.entr_parakmi) and not forced_key and not G.GAME.entr_parakmi_bypass then
        _type = Entropy.get_random_set(next(find_joker("j_entr_parakmi")) or G.GAME.modifiers.entr_parakmi)
    end
    if _type == "BlindTokens" then
        _type = "CBlind"
    end
    if SMODS.ConsumableTypes[_type] then
        skip_materialize = true
    end
    if area == G.pack_cards and not G.entr_dont_calculate then
        if soulable and not forced_key and Entropy.has_rune("rune_entr_oss") then
            local valid = {}
            for _, v in ipairs(SMODS.Consumable.legendaries) do
                if (_type == v.type.key or _type == v.soul_set) and not (G.GAME.used_jokers[v.key] and not SMODS.showman(v.key) and not v.can_repeat_soul) and SMODS.add_to_pool(v, {}) then
                    valid[#valid+1] = v
                end
            end
            if (_type == 'Tarot' or _type == 'Spectral' or _type == 'Tarot_Planet') and
            not (G.GAME.used_jokers['c_soul'] and not SMODS.showman('c_soul')) then
                valid[#valid+1] = G.P_CENTERS.c_soul
            end
            if (_type == 'Planet' or _type == 'Spectral') and
            not (G.GAME.used_jokers['c_black_hole'] and not SMODS.showman('c_black_hole')) then
                valid[#valid+1] = G.P_CENTERS.c_black_hole
            end
            if #valid > 0 then
                Entropy.has_rune("rune_entr_oss").triggered = true
                local card =  ref(_type, area, legendary, _rarity, skip_materialize, false, pseudorandom_element(valid, pseudoseed("rune_entr_oss")).key, key_append, dont_calculate, ...)
                Entropy.post_create_card(card, area == G.pack_cards, forced_key)
                return card
            end
        elseif not forced_key then
            if Entropy.has_rune("rune_entr_mannaz") and (Entropy.has_rune("rune_entr_mannaz").num_triggered or 0) <= 1 then
                Entropy.has_rune("rune_entr_mannaz").num_triggered = (Entropy.has_rune("rune_entr_mannaz").num_triggered or 0) + 1
                if Entropy.has_rune("rune_entr_mannaz").num_triggered > 1 or not G.GAME.providence then
                    Entropy.has_rune("rune_entr_mannaz").num_triggered = 2
                    Entropy.has_rune("rune_entr_mannaz").triggered = true
                end
                local card = ref("Spectral", area or G.pack_cards, nil, nil, true, true, nil, "rune_entr_mannaz", ...)
                Entropy.post_create_card(card, area == G.pack_cards, forced_key)
                return card
            end
        end
    end
    local card = ref(_type, area, legendary, _rarity, skip_materialize, soulable, forced_key, key_append, ...)
    if card and card.ability and card.ability.name == "entr-solarflare" then
		card:set_edition("e_entr_solar", true, nil, true)
	end
    if card and card.ability and card.ability.name == "entr-trapezium_cluster" then
		card:set_edition("e_entr_fractured", true, nil, true)
	end
    if card and card.ability and card.ability.name == "entr-eden" then
		card:set_edition("e_entr_sunny", true, nil, true)
	end
    if card and card.ability and card.ability.name == "entr-ridiculus_absens" then
		card:set_edition("e_cry_glitched", true, nil, true)
        card.ability.cry_prob = 1
        card.ability.extra.odds = 2 
	end
    if (next(find_joker("j_entr_chaos")) or next(find_joker("j_entr_parakmi")) or G.GAME.modifiers.entr_parakmi) and not forced_key and not _rarity and not G.GAME.entr_parakmi_bypass then 
        if not G.SETTINGS.paused and not G.GAME.akyrs_any_drag then
            card.fromdefine = true
        end
    end
    if card and card.config and card.config.center and card.config.center.key == "c_base" and Entropy.deck_or_sleeve("crafting") then
        if pseudorandom("crafting") < 0.5 then
            card:set_ability(SMODS.poll_enhancement({guaranteed = true, key = "entr_crafting"}))
        end
	end
    if card and card.ability and card.ability.consumeable then
        for i, a in pairs(SMODS.get_card_areas('jokers')) do
            for _, c in pairs(a.cards) do
                if c.config.center.calculate then
                    local ret = c.config.center:calculate(c, {
                        get_consumable_type = true,
                        set = card.config.center.set,
                        hidden = card.config.center.hidden,
                        other_card = card
                    })
                    if ret and (ret.set or ret.key) then
                        card:set_ability(G.P_CENTERS[ret.key or SMODS.poll_object{set = ret.set}])
                        SMODS.calculate_context{post_trigger = true, other_card = c, other_context = {
                            get_consumable_type = true,
                            set = card.config.center.set,
                            hidden = card.config.center.hidden,
                            other_card = card
                        }, other_ret = ret}
                        break
                    end
                end
            end
        end
    end
    if card and card.ability and card.ability.consumeable then
        SMODS.calculate_context{entr_consumable_created = true, other_card = card}
    end
    if next(SMODS.find_card("j_entr_kitchenjokers")) and card:is_food() then
        card:set_edition("e_entr_lowres")
    end
    Entropy.post_create_card(card, area == G.pack_cards, forced_key)
    G.entr_dont_calculate = nil
    return card
end

local pokerhandinforef = G.FUNCS.get_poker_hand_info
function G.FUNCS.get_poker_hand_info(cards,...)
    local _cards = {}
    for _, card in pairs(cards) do
        _cards[#_cards+1] = card
    end
    for _, card in pairs(G.I.CARD) do
        if card.ability and card.ability.entr_marked and not card.ability.entr_marked_bypass then
            if not card.highlighted and not Entropy.in_table(cards, card) then
                _cards[#_cards+1] = card
            end
        end
    end
    G.GAME.current_round.current_hand.cry_asc_num = 0
    local text, loc_disp_text, poker_hands, scoring_hand, disp_text = pokerhandinforef(_cards,...)
    if text and G.GAME.badarg and G.GAME.badarg[text] and text ~= "NULL" then
        G.boss_throw_hand = true
        G.bad_arg = true
        G.E_MANAGER:add_event(Event({
        func = function()
            update_hand_text_random({delay = 0}, {chips="bad", mult="arg", handname = ""})
            return true
        end}))
    else
        G.bad_arg = nil
    end
    local all_flesh = true
    for i, v in pairs(scoring_hand) do
        if type(v) == "table" and v.config and v.config.center and v.config.center.key ~= "m_entr_flesh" then all_flesh = false end
    end
    if all_flesh then
        if text == "Flush" then 
            disp_text = "entr-Flesh"
			loc_disp_text = localize(disp_text, "poker_hands")
        end
        if text == "Flush House" then 
            disp_text = "entr-Flesh_House"
			loc_disp_text = localize(disp_text, "poker_hands")
        end
        if text == "Flush Five" then 
            disp_text = "entr-Flesh_Five"
			loc_disp_text = localize(disp_text, "poker_hands")
        end
        if text == "Straight Flush" then 
            disp_text = "entr-Straight_Flesh"
			loc_disp_text = localize(disp_text, "poker_hands")
        end
    end
    return text, loc_disp_text, poker_hands, scoring_hand, disp_text
end

local ease_anteref = ease_ante
function ease_ante(mod)
    local mult = 1
    if to_big(mod) ~= to_big(0) then
        if next(SMODS.find_card("j_entr_xekanos")) then
            for i, v in pairs(G.jokers.cards) do
                if v.config.center.key == "j_entr_xekanos" and not v.debuff and not v.ability.turned_off and not G.GAME.modifiers.ReverseRedeo then
                    mult = mult * to_number(-v.ability.ante_mod)
                    if not v.ability.entr_pure then
                        v.ability.ante_mod = v.ability.ante_mod - v.ability.ante_mod_mod
                    end
                end
            end
        end
        local t
        for i, v in pairs(G.runes or {}) do
            if G.P_RUNES[v.key].calculate then
                local ret = G.P_RUNES[v.key]:calculate(v, {entr_ante_change = mod})
                if ret then
                    v:yep("+", G.C.PURPLE, function()
                        return true
                    end)
                    if ret.ante_mod then
                        mod = ret.ante_mod
                        t = v
                    end
                end
            end
        end
        if next(SMODS.find_card("j_entr_record_disc")) then
            t = true
            play_sound("entr_record_scratch")
        end
        if t then
            SMODS.calculate_context({rune_triggered = true, rune = v})
        end
        ease_anteref(mod * mult, a)
    end
end

local is_jollyref = Card.is_jolly
function Card:is_jolly()
	if next(SMODS.find_card("j_entr_dekatria")) then return true end
    return is_jollyref and is_jollyref(self) or nil
end

local AscendantTags = {
    tag_uncommon="tag_entr_ascendant_rare",
    tag_rare= (SMODS.Mods["Cryptid"] or {}).can_load and "tag_entr_ascendant_epic" or "tag_entr_ascendant_rare",
    tag_negative="tag_entr_ascendant_negative",
    tag_foil="tag_entr_ascendant_foil",
    tag_holo="tag_entr_ascendant_holo",
    tag_polychrome="tag_entr_ascendant_poly",
    tag_investment="tag_entr_ascendant_stock",
    tag_voucher="tag_entr_ascendant_voucher",
    tag_boss="tag_entr_ascendant_blind",
    tag_standard="tag_entr_ascendant_twisted",
    tag_charm="tag_entr_ascendant_twisted",
    tag_meteor="tag_entr_ascendant_twisted",
    tag_buffoon="tag_entr_ascendant_ejoker",
    tag_handy="tag_entr_ascendant_stock",
    tag_garbage="tag_entr_ascendant_stock",
    tag_ethereal="tag_entr_ascendant_twisted",
    tag_coupon="tag_entr_ascendant_credit",
    tag_double="tag_entr_ascendant_copying",
    tag_juggle="tag_entr_ascendant_effarcire",
    tag_d_six="tag_entr_ascendant_credit",
    tag_top_up="tag_entr_ascendant_topup",
    tag_skip="tag_entr_ascendant_stock",
    tag_economy="tag_entr_ascendant_stock",
    tag_orbital="tag_entr_ascendant_universal",
    tag_cry_epic="tag_entr_ascendant_epic",
    tag_cry_glitched="tag_entr_ascendant_glitched",
    tag_cry_mosaic="tag_entr_ascendant_mosaic",
    tag_cry_oversat="tag_entr_ascendant_oversat",
    tag_cry_glass="tag_entr_ascendant_glass",
    tag_cry_gold="tag_entr_ascendant_gold",
    tag_cry_blur="tag_entr_ascendant_blurry",
    tag_cry_astral="tag_entr_ascendant_astral",
    tag_cry_m="tag_entr_ascendant_m",
    tag_cry_double_m="tag_entr_ascendant_m",
    tag_cry_cat="tag_entr_ascendant_cat",
    tag_cry_gambler="tag_entr_ascendant_unbounded",
    tag_cry_empowered="tag_entr_ascendant_unbounded",
    tag_cry_better_voucher="tag_entr_ascendant_better_voucher",
    tag_cry_memory="tag_entr_ascendant_copying",
    tag_cry_better_top_up="tag_entr_ascendant_better_topup",
    tag_cry_bundle="tag_entr_ascendant_ebundle",
    tag_cry_gourmand="tag_entr_ascendant_saint",
    tag_cry_triple="tag_entr_ascendant_copying",
    tag_cry_quadruple="tag_entr_ascendant_copying",
    tag_cry_quintuple="tag_entr_ascendant_copying",
    tag_cry_scope="tag_entr_ascendant_infdiscard",
    tag_cry_schematic="tag_entr_ascendant_canvas",
    tag_cry_loss="tag_entr_ascendant_reference",
    tag_cry_banana="tag_entr_ascendant_cavendish",
    tag_cry_booster="tag_entr_ascendant_booster",
    tag_cry_console="tag_entr_ascendant_twisted",
    tag_entr_dog="tag_entr_ascendant_dog",
    tag_entr_solar="tag_entr_ascendant_solar",
    tag_entr_ascendant_rare=(SMODS.Mods["Cryptid"] or {}).can_load and "tag_entr_ascendant_epic" or nil,
    tag_entr_ascendant_epic="tag_entr_ascendant_legendary",
    --tag_entr_ascendant_legendary="tag_entr_ascendant_exotic",
    --tag_entr_ascendant_exotic="tag_entr_ascendant_entropic",
    tag_entr_sunny = "tag_entr_ascendant_sunny",
    tag_entr_freaky = "tag_entr_ascendant_freaky",
    tag_entr_fractured = "tag_entr_ascendant_fractured",
    tag_valk_kitty = "tag_entr_ascendant_kitty",
    tag_valk_negativeeternal = "tag_entr_ascendant_negative_eternal",

    tag_entr_fractured = "tag_entr_ascendant_fractured",
    tag_entr_freaky = "tag_entr_ascendant_freaky",
    tag_entr_kaleidoscopic = "tag_entr_ascendant_kaleidoscopic",
    tag_entr_neon = "tag_entr_ascendant_neon",
    tag_entr_lowres = "tag_entr_ascendant_lowres",
    tag_entr_arcane = "tag_entr_ascendant_arcane",
    tag_entr_gilded = "tag_entr_ascendant_gilded"
}
for i, v in pairs(AscendantTags) do Entropy.AscendedTags[i]=v end

local ref = Tag.init
function Tag:init(_tag, for_collection, _blind_type, ...)
    if next(SMODS.find_card("j_entr_ruby")) and not for_collection then
        local roll = pseudorandom("ruby_asc")
        if roll < 0.15 and Entropy.AscendedTags[_tag] then
            _tag = Entropy.AscendedTags[_tag]
        end
    end
    if next(SMODS.find_card("j_entr_exousia")) and Entropy.AscendedTags[_tag] and not for_collection then 
        _tag = Entropy.AscendedTags[_tag]
        local procs = 1
        while pseudorandom("exousia") < 0.1 and procs < #SMODS.find_card("j_entr_exousia") and Entropy.AscendedTags[_tag] and not for_collection do
            _tag = Entropy.AscendedTags[_tag]
        end
    end
    local ret = ref(self, _tag, for_collection, _blind_type, ...)
    tag = self
    if G.P_TAGS[tag.key] and G.P_TAGS[tag.key].set_ability then
        G.P_TAGS[tag.key]:set_ability(tag)
    end
    return ret
end

G.FUNCS.has_inversion = function(e) 
    if G.GAME.last_inversion and G.GAME.last_inversion.key ~= "c_entr_master" then 
        e.config.colour = mix_colours(G.C.GREEN, G.C.JOKER_GREY, 0.8)
    else
        e.config.colour = mix_colours(G.C.RED, G.C.JOKER_GREY, 0.8)
    end
 end

 G.FUNCS.has_fraud = function(e) 
    if G.GAME.last_fraud and G.GAME.last_fraud ~= "c_entr_prophecy" then 
        e.config.colour = mix_colours(G.C.GREEN, G.C.JOKER_GREY, 0.8)
    else
        e.config.colour = mix_colours(G.C.RED, G.C.JOKER_GREY, 0.8)
    end
 end
local ref = G.FUNCS.use_card
G.FUNCS.use_card = function(e, mute, nosave)
    local twis = G.GAME.modifiers.entr_twisted
    G.GAME.modifiers.entr_twisted = nil
    local card = e.config.ref_table
    if card.ability.consumeable then
        local center = card.config.center
        if center and center.calculate then
            center:calculate(card, {pre_using_self = true, consumeable = card, area = card.from_area})
        end
        local edition = card.edition and G.P_CENTERS[card.edition.key]
        if edition and edition.calculate then
            edition:calculate(card, {pre_using_self = true, consumeable = card, area = card.from_area})
        end
        SMODS.calculate_context({pre_using_consumeable = true, consumeable = card, area = card.from_area})
    end
    card.ability.bypass_aleph = true
    ref(e, mute, nosave)
    G.GAME.modifiers.entr_twisted = twis
    G.E_MANAGER:add_event(Event{
        trigger = "after",
        delay = 2,
        blocking = false,
        blockable = true,
        func = function()
        if Entropy.is_inverted(card.config.center) and not card.config.center.hidden and card.config.center.set ~= "Joker" then
                G.GAME.last_inversion = {
                    key = card.config.center.key,
                    set = card.config.center.set
                }
            elseif not card.config.center.hidden and next(SMODS.find_card("j_entr_enlightenment")) then
                G.GAME.last_tarot_planet = card.config.center.key
            end
            if card.config.center.set == "Fraud" and (card.config.center.key ~= "c_entr_prophecy" or not G.GAME.last_fraud) then
                G.GAME.last_fraud = {
                    key = card.config.center.key,
                    set = card.config.center.set
                }
            end
            G.GAME.entr_used_cards = G.GAME.entr_used_cards or {}
            G.GAME.entr_used_cards[card.config.center.key] = (G.GAME.entr_used_cards[card.config.center.key] or 0) + 1
            return true
        end
    })
    for i, v in pairs(SMODS.find_card("j_entr_shadow_crystal")) do
        if SMODS.pseudorandom_probability(card, 'shadow_crystal', 1, v.ability.extra.odds) and Entropy.inversion(card) and not card.config.center.hidden then
            local dummy = Entropy.get_dummy(G.P_CENTERS[Entropy.inversion(card)], card.area, card)
            Spectrallib.forcetrigger({
                card = dummy,
                context = context,
                silent = true
            })
            break
        end
    end
end

local main_ref = evaluate_play_main
function evaluate_play_main(text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta)
    local m = G.GAME.hands[text].mult
    local c = G.GAME.hands[text].chips
    if G.GAME.Bootstrap then
        if poker_hands[text] then
            poker_hands[text].mult = G.GAME.Bootstrap.Mult
            poker_hands[text].chips = G.GAME.Bootstrap.Chips
        end
        G.GAME.hands[text].mult = G.GAME.Bootstrap.Mult
        G.GAME.hands[text].chips = G.GAME.Bootstrap.Chips
    end
    main_ref(text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta)
    if G.GAME.UsingBootstrap then
        G.GAME.Bootstrap = {
            Mult = mult,
            Chips = hand_chips
        }
        G.GAME.UsingBootstrap = nil
    end
    if G.GAME.Bootstrap then
        G.GAME.hands[text].mult = m
        G.GAME.hands[text].chips = c
        if poker_hands[text] then
            poker_hands[text].mult = m
            poker_hands[text].chips = c
        end
        G.GAME.Bootstrap = nil
    end
    return text, disp_text, poker_hands, scoring_hand, non_loc_disp_text, percent, percent_delta
end
local set_abilityref = Card.set_ability
function Card:set_ability(center, f, s)
    if type(center) == "string" then center = G.P_CENTERS[center] end
    if center and center.set == "Joker" and G.GAME.magic_skin_prob and pseudorandom("entr_magic_skin") < G.GAME.magic_skin_prob then
        set_abilityref(self, G.P_CENTERS.j_entr_magic_skin, initial, delay_sprites)
        return
    end
    if (self.config and self.config.center and Entropy.is_disavowed(self) and (not self.entr_aleph or self.ability.bypass_aleph)) or G.SETTINGS.paused then
        set_abilityref(self, center, f, s)
    else
        if not self.entr_aleph and not G.SETTINGS.paused then
            set_abilityref(self, G.P_CENTERS.m_entr_disavowed, f, s)
        else
            set_abilityref(self, self.config.center, f, s)
        end
    end
    if (G.GAME.modifiers.entr_reverse_redeo or G.GAME.ReverseRedeo) and self.config.center.key == "j_cry_redeo" then
        self.ability.extra.ante_reduction = -1
    end
    if self.ability and self.ability.consumeable and Entropy.has_rune("rune_entr_gluttony") then
        self:add_sticker("eternal", true)
    end
end

local function hash(str)
    local h = 5381

    for i = 1, #str do
       h = h*32 + h + str:byte(i)
    end
    return h
end

local set_abilityref = Card.set_ability
function Card:set_ability(center, ...)
    if type(center) == "string" then center = G.P_CENTERS[center] end
    if not center then return end
    if center and Entropy.is_inverted(center) and G.GAME.next_inversions_prophecy and not G.SETTINGS.paused and center.set ~= "Joker" then
        set_abilityref(self, G.P_CENTERS[G.GAME.next_inversions_prophecy], ...)
        G.GAME.inversions_prophecy_counter = (G.GAME.inversions_prophecy_counter or 2) - 1
    else
        set_abilityref(self, center, ...)
    end
    if G.GAME.inversions_prophecy_counter and to_big(G.GAME.inversions_prophecy_counter) <= to_big(0) then
        G.GAME.next_inversions_prophecy = nil
        G.GAME.inversions_prophecy_counter = nil
    end
    if G.GAME.modifiers.entr_gfb then
        local fixed_sizes = {
            j_brainstorm = {
                x = 1.1, y = 1.1
            },
            j_blueprint = {
                x = 0.909, y = 0.909,
            },
            j_wee = {
                x = 0.75, y = 0.75
            },
            j_gluttenous_joker = {
                x = 1.25, y = 1
            },
            j_half = {
                x = 1, y = 0.5
            },
            j_entr_chair = {
                x = 0.909, y = 0.909
            },
            j_gros_michel = {
                x = 0.8, y = 0.8
            },
            j_cavendish = {
                x = 1.2, y = 1.2
            }
            --TARGET: fixed sizes for gfb
        }
        math.randomseed(hash(self.config.center.key))
        local min = 0.875
        local max = 1.125
        self.T.h = self.T.h * ((fixed_sizes[self.config.center.key] or {}).y or (min + math.random() * (max-min)))
        self.T.w = self.T.w * ((fixed_sizes[self.config.center.key] or {}).x or (min + math.random() * (max-min)))
    end
end

local use_cardref = G.FUNCS.use_card
G.FUNCS.use_card = function(e, mute, nosave)
	local card = e.config.ref_table
    if card.ability.glitched_crown then
        card:set_ability(G.P_CENTERS[card.ability.glitched_crown[card.glitched_index]])
        card.ability.glitched_crown = nil
    end
	if card.config.center.set ~= "Booster" and Entropy.deck_or_sleeve("doc") then
    local num = 1
    for i, v in pairs(G.GAME.entr_bought_decks or {}) do if v == "b_entr_doc" or v == "sleeve_entr_doc" then num = num + 1 end end
		if Entropy.is_inverted(card.config.center) then
			ease_entropy(2*num*Entropy.deck_or_sleeve("doc"))
		else
			ease_entropy(1*num*Entropy.deck_or_sleeve("doc"))
		end
	end
	use_cardref(e, mute, nosave)
end
SMODS.Booster:take_ownership_by_kind('Spectral', {
	create_card = function(self, card, i)
		G.GAME.entropy = G.GAME.entropy or 0
		if to_big(pseudorandom("doc")) < to_big(1 - 0.997^(G.GAME.entropy/2)) and Entropy.deck_or_sleeve("doc") then
            return create_card("Omen", G.pack_cards, nil, nil, true, true, "c_entr_beyond")
		elseif to_big(pseudorandom("doc")) < to_big(1 - 0.996^(G.GAME.entropy/2)) and Entropy.deck_or_sleeve("doc") then
            if G.P_CENTERS.c_cry_gateway and Cryptid.enabled("c_cry_gateway") == true then
			    return create_card("Spectral", G.pack_cards, nil, nil, true, true, "c_cry_gateway")
            else
                return create_card("Spectral", G.pack_cards, nil, nil, true, true, "c_soul")
            end
		end
		return create_card("Spectral", G.pack_cards, nil, nil, true, true, nil, "spe")
	end
},true)
SMODS.Consumable:take_ownership("cry_gateway",{
	use = function(self, card, area, copier)
		if not Entropy.deck_or_sleeve("doc") and (#SMODS.find_card("j_jen_saint") + #SMODS.find_card("j_jen_saint_attuned")) <= 0 then
			local deletable_jokers = {}
			for k, v in pairs(G.jokers.cards) do
				if not SMODS.is_eternal(v) then
					deletable_jokers[#deletable_jokers + 1] = v
				end
			end
			local _first_dissolve = nil
			G.E_MANAGER:add_event(Event({
				trigger = "before",
				delay = 0.75,
				func = function()
					for k, v in pairs(deletable_jokers) do
						if v.config.center.rarity == "cry_exotic" then
							check_for_unlock({ type = "what_have_you_done" })
						end
						v:start_dissolve(nil, _first_dissolve)
						_first_dissolve = true
					end
					return true
				end,
			}))
		end
		G.E_MANAGER:add_event(Event({
			trigger = "after",
			delay = 0.4,
			func = function()
				play_sound("timpani")
				local card = create_card("Joker", G.jokers, nil, "cry_exotic", nil, nil, nil, "cry_gateway")
				card:add_to_deck()
				G.jokers:emplace(card)
				card:juice_up(0.3, 0.5)
				return true
			end,
		}))
		delay(0.6)
    if Entropy.deck_or_sleeve("doc") then
      ease_entropy(-math.min(G.GAME.entropy, 5))
    end
	end
},true)
local uibox_ref = create_UIBox_HUD
function create_UIBox_HUD()
  local orig = uibox_ref()
	if not Entropy.deck_or_sleeve("doc") then return orig end
    local scale = 0.4
    local stake_sprite = get_stake_sprite(G.GAME.stake or 1, 0.5)

    local contents = {}

    local spacing = 0.13
    local temp_col = G.C.DYN_UI.BOSS_MAIN
    local temp_col2 = G.C.DYN_UI.BOSS_DARK
    
    contents.buttons = {
      {n=G.UIT.C, config={align = "cm", r=0.1, colour = G.C.CLEAR, shadow = true, id = 'button_area',padding=0.33}, nodes={
        {n=G.UIT.R, config={id = 'run_info_button', align = "cm", minh = 1, minw = 1.5,padding = 0.05, r = 0.1, hover = true, colour = G.C.RED, button = "run_info", shadow = true}, nodes={
        {n=G.UIT.R, config={align = "cm", padding = 0, maxw = 2}, nodes={
          {n=G.UIT.T, config={text = localize('b_run_info_1'), scale = 1.2*scale, colour = G.C.UI.TEXT_LIGHT, shadow = true}}
        }},
        {n=G.UIT.R, config={align = "cm", padding = 0, maxw = 2}, nodes={
          {n=G.UIT.T, config={text = localize('b_run_info_2'), scale = 1*scale, colour = G.C.UI.TEXT_LIGHT, shadow = true, focus_args = {button = G.F_GUIDE and 'guide' or 'back', orientation = 'bm'}, func = 'set_button_pip'}}
        }}
        }},
        {n=G.UIT.R, config={align = "cm", minh = 1, minw = 2,padding = 0.05, r = 0.1, hover = true, colour = G.C.ORANGE, button = "options", shadow = true}, nodes={
        {n=G.UIT.C, config={align = "cm", maxw = 1.4, focus_args = {button = 'start', orientation = 'bm'}, func = 'set_button_pip'}, nodes={
          {n=G.UIT.T, config={text = localize('b_options'), scale = scale, colour = G.C.UI.TEXT_LIGHT, shadow = true}}
        }},
        }},
        {n=G.UIT.R, config={align = "cm", minh = 1, minw = 2,padding = 0.05, r = 0.1, hover = true, colour=G.C.DYN_UI.BOSS_MAIN,emboss=0.05}, nodes={
        {n=G.UIT.R, config={align = "cm", maxw = 1.35}, nodes={
          {n=G.UIT.T, config={text = localize('k_entropy'), minh = 0.33, scale = 0.85*scale, colour = G.C.UI.TEXT_LIGHT, shadow = true}},
        }},
        {n=G.UIT.R, config={align = "cm", r = 0.1, minw = 1.8, colour = temp_col2, id = 'row_entropy_text'}, nodes={
          {n=G.UIT.O, config={object = DynaText({string = {{ref_table = G.GAME, ref_value = 'entropy'}}, colours = {G.C.IMPORTANT},shadow = true, scale = 2*scale}),id = 'entropy_UI_count'}},
        }},
        }}
      }}
    }
    --heres the one bit of compat ill do on my end
    if SMODS.Mods.jen and SMODS.Mods.jen.can_load then
      orig.nodes[1].nodes[1].nodes[5].nodes[1].nodes[6] = {n=G.UIT.R, config={align = "cm"}, nodes={
        {n=G.UIT.C, config={id = 'hud_tension',align = "cm", padding = 0.05, minw = 1.45, minh = 1, colour = temp_col, emboss = 0.05, r = 0.1}, nodes={
          {n=G.UIT.R, config={align = "cm", minh = 0.33, maxw = 1.35}, nodes={
            {n=G.UIT.T, config={text = 'Tension', scale = 0.85*scale, colour = G.C.UI.TEXT_LIGHT, shadow = true}},
          }},
          {n=G.UIT.R, config={align = "cm", r = 0.1, minw = 1.2, colour = temp_col2}, nodes={
            {n=G.UIT.O, config={object = DynaText({string = {{ref_table = G.GAME, ref_value = 'tension'}}, colours = {G.C.CRY_EMBER},shadow = true, font = G.LANGUAGES['en-us'].font, scale = scale_number(G.GAME.tension, 2*scale, 100)}),id = 'tension_UI_count'}},
          }},
        }},
        {n=G.UIT.C, config={minw = spacing},nodes={}},
        {n=G.UIT.C, config={id = 'hud_relief',align = "cm", padding = 0.05, minw = 1.45, minh = 1, colour = temp_col, emboss = 0.05, r = 0.1}, nodes={
          {n=G.UIT.R, config={align = "cm", minh = 0.33, maxw = 1.35}, nodes={
            {n=G.UIT.T, config={text = 'Relief', scale = 0.85*scale, colour = G.C.UI.TEXT_LIGHT, shadow = true}},
          }},
          {n=G.UIT.R, config={align = "cm", r = 0.1, minw = 1.2, colour = temp_col2}, nodes={
            {n=G.UIT.O, config={object = DynaText({string = {{ref_table = G.GAME, ref_value = 'relief'}}, colours = {G.C.CRY_VERDANT},shadow = true, font = G.LANGUAGES['en-us'].font, scale = scale_number(G.GAME.relief, 2*scale, 100)}),id = 'relief_UI_count'}},
          }},
        }},
        {n=G.UIT.C, config={minw = spacing},nodes={}},
        {n=G.UIT.C, config={id = 'hud_entropy',align = "cm", padding = 0.05, minw = 1.45, minh = 1, colour = temp_col, emboss = 0.05, r = 0.1}, nodes={
          {n=G.UIT.R, config={align = "cm", minh = 0.33, maxw = 1.35}, nodes={
            {n=G.UIT.T, config={text = localize('k_entropy'), scale = 0.85*scale, colour = G.C.UI.TEXT_LIGHT, shadow = true}},
          }},
          {n=G.UIT.R, config={align = "cm", r = 0.1, minw = 1.2, colour = temp_col2}, nodes={
            {n=G.UIT.O, config={object = DynaText({string = {{ref_table = G.GAME, ref_value = 'entropy'}}, colours = {G.C.IMPORTANT},shadow = true, font = G.LANGUAGES['en-us'].font, scale = 2*scale}),id = 'entropy_UI_count'}},
          }},
        }},
      }}
    else  
      orig.nodes[1].nodes[1].nodes[5].nodes[1].nodes = contents.buttons
    end
    return orig
end


function ease_entropy(mod)
    G.E_MANAGER:add_event(Event({
      trigger = 'immediate',
      func = function()
          local round_UI = G.HUD:get_UIE_by_ID('entropy_UI_count')
          mod = mod or 0
          local text = '+'
          local col = G.C.IMPORTANT
          if to_big(mod) < to_big(0) then
              text = ''
              col = G.C.RED
          end
          G.GAME.entropy = (G.GAME.entropy or 0) + mod
          if round_UI then
            G.HUD:recalculate()
            if not Entropy.should_skip_animations() then
              attention_text({
                text = text..tostring(math.abs(mod)),
                scale = 1, 
                hold = 0.7,
                cover = round_UI.parent,
                cover_colour = col,
                align = 'cm',
              })
            end
          end
          --Play a chip sound
          if not Entropy.should_skip_animations() then
            play_sound('timpani', 0.8)
            play_sound('generic1')
          end
          return true
      end
    }))
end


local apply_ref = Cryptid.antimatter_apply
function Cryptid.antimatter_apply(skip)
  apply_ref(skip)
  if (Cryptid.safe_get(G.PROFILES, G.SETTINGS.profile, "deck_usage", "b_entr_ccd2", "wins", 8) or 0 ~= 0) or skip then
    G.GAME.modifiers.ccd2 = true
  end
  if (Cryptid.safe_get(G.PROFILES, G.SETTINGS.profile, "deck_usage", "b_entr_doc", "wins", 8) or 0 ~= 0) or skip then
    G.GAME.modifiers.doc_antimatter = true
  end
  if (Cryptid.safe_get(G.PROFILES, G.SETTINGS.profile, "deck_usage", "b_entr_twisted", "wins", 8) or 0 ~= 0) or skip then
    G.GAME.modifiers.entr_twisted = true
  end
  if (Cryptid.safe_get(G.PROFILES, G.SETTINGS.profile, "deck_usage", "b_entr_butterfly", "wins", 8) or 0 ~= 0) or skip then
    G.GAME.modifiers.butterfly_antimatter = true
  end
end

local uibox_ref = create_UIBox_blind_select
function create_UIBox_blind_select()
    if G.GAME.USING_BREAK then
        G.E_MANAGER:add_event(Event({
			trigger = "after",
            blocking = false,
            delay = 3,
			func = function()
                G.STATE = 7
                --G.blind_select:remove()
                --G.blind_prompt_box:remove()
                G.FUNCS.draw_from_hand_to_deck()
				return true
			end,
		}))
        G.GAME.USING_BREAK = nil
    end
    if G.GAME.round_resets.red_room then
        G.GAME.blind_on_deck = "Red"
        if not G.GAME.round_resets.blind_choices["Red"] then
            G.GAME.round_resets.blind_choices["Red"] = "bl_entr_red"
        end
        if not G.GAME.round_resets.blind_states['Red'] then
            G.GAME.round_resets.blind_states['Red'] = "Select"
        end
        G.GAME.RedBlindStates = {}
        for i, v in pairs(G.GAME.round_resets.blind_states) do G.GAME.RedBlindStates[i] = v end
        G.GAME.round_resets.loc_blind_states.Red = "Select"
        G.blind_select_opts.red = G.GAME.round_resets.blind_states['Red'] ~= 'Hide' and UIBox{definition = {n=G.UIT.ROOT, config={align = "cm", colour = G.C.CLEAR}, nodes={UIBox_dyn_container({create_UIBox_blind_choice('Red')},false,get_blind_main_colour('Red'))}}, config = {align="bmi", offset = {x=0,y=0}}} or nil
        local t = {n=G.UIT.ROOT, config = {align = 'tm',minw = width, r = 0.15, colour = G.C.CLEAR}, nodes={
            {n=G.UIT.R, config={align = "cm", padding = 0.5}, nodes={
            G.GAME.round_resets.blind_states['Red'] ~= 'Hide' and {n=G.UIT.O, config={align = "cm", object = G.blind_select_opts.red}} or nil,
            }}
        }}
        G.GAME.round_resets.red_room = nil
        return t 
    else
        if to_big(G.GAME.round_resets.ante) < to_big(32) then G.GAME.EEBeaten = false end
        if Entropy.can_ee_spawn() and Entropy.is_ee_or_buildup() then
            return Entropy.spawn_ee_ui()
        else
            if next(SMODS.find_card("j_entr_voidheart")) and not G.GAME.round_resets.red_room then
                G.GAME.round_resets.blind_choices["Boss"] = "bl_entr_abyss"
                G.GAME.blind_on_deck = "Boss"
                G.GAME.round_resets.blind_states.Small = "Defeated"
                G.GAME.round_resets.blind_states.Big = "Defeated"
                G.GAME.round_resets.blind_states.Boss = "Select"
                G.blind_select_opts = {}
                G.blind_select_opts.boss = UIBox{definition = {n=G.UIT.ROOT, config={align = "cm", colour = G.C.CLEAR}, nodes={UIBox_dyn_container({create_UIBox_blind_choice('Boss')},false,get_blind_main_colour('Boss'), mix_colours(G.C.BLACK, get_blind_main_colour('Boss'), 0.8))}}, config = {align="bmi", offset = {x=0,y=0}}} or nil
                
                local t = {n=G.UIT.ROOT, config = {align = 'tm',minw = width, r = 0.15, colour = G.C.CLEAR}, nodes={
                    {n=G.UIT.R, config={align = "cm", padding = 0.5}, nodes={
                        {n=G.UIT.O, config={align = "cm", object = G.blind_select_opts.boss}},
                    }}
                }}
                return t
            end
        end
        if G.GAME.modifiers.zenith then
            for i, v in pairs(G.GAME.round_resets.blind_choices) do
                G.GAME.round_resets.blind_choices[i] = "bl_entr_brimstone"
            end
        end
        if G.GAME.curse == "entr_maze" and not G.GAME.entr_maze_applied then
            local choices = {}
            for i, v in pairs(G.GAME.round_resets.blind_choices) do
                choices[#choices+1] = v
            end
            pseudoshuffle(choices, pseudoseed("entr_maze"))
            G.GAME.round_resets.blind_choices.Small = choices[1]
            G.GAME.round_resets.blind_choices.Big = choices[2]
            G.GAME.round_resets.blind_choices.Boss = choices[3]
            G.GAME.entr_maze_applied = true
        end
        return uibox_ref()
    end
end

local set_textref = Blind.draw
function Blind:draw()
    if G.GAME.Interfered then
        G.GAME.blind.chip_text = G.GAME.InterferedText
    end
    set_textref(self)
end
local hand_dt = 0
local hand_dt2 = 0
local update_ref = Game.update
function Game:update(dt)
    update_ref(self, dt)
    hand_dt = (hand_dt or 0) + dt
    if G.hand_text_area and hand_dt > 0.05 and G.GAME.Interfered then
        G.TAROT_INTERRUPT_PULSE = true
        G.TAROT_INTERRUPT = true
        update_hand_text_random(
        { nopulse = true, immediate=true },
        { handname = Entropy.srandom(math.random(5,15)), mult = Entropy.srandom(3), chips = Entropy.srandom(3)}
        )
        G.TAROT_INTERRUPT_PULSE = false
        G.TAROT_INTERRUPT = false
        G.GAME.InterferedText = Entropy.srandom(math.random(3,5))
        hand_dt = 0
    end
    hand_dt2 = hand_dt2 + dt
    G.EE_HEALTH = 100*(math.sin(hand_dt2)+1)/2
end

function update_hand_text_random(config, vals)
    G.E_MANAGER:add_event(Event({--This is the Hand name text for the poker hand
    trigger = 'before',
    blockable = not config.immediate,
    delay = config.delay or 0.8,
    func = function()
        local col = G.C.GREEN
        if vals.chips and G.GAME.current_round.current_hand.chips ~= vals.chips then
            local delta = (is_number(vals.chips) and is_number(G.GAME.current_round.current_hand.chips)) and (vals.chips - G.GAME.current_round.current_hand.chips) or 0
            if to_big(delta) < to_big(0) then delta = number_format(delta); col = G.C.RED
            elseif to_big(delta) > to_big(0) then delta = '+'..number_format(delta)
            else delta = number_format(delta)
            end
            if type(vals.chips) == 'string' then delta = vals.chips end
            G.GAME.current_round.current_hand.chips = vals.chips
            G.hand_text_area.chips:update(0)
        end
        if vals.mult and G.GAME.current_round.current_hand.mult ~= vals.mult then
            local delta = (is_number(vals.mult) and is_number(G.GAME.current_round.current_hand.mult))and (vals.mult - G.GAME.current_round.current_hand.mult) or 0
            if to_big(delta) < to_big(0) then delta = number_format(delta); col = G.C.RED
            elseif to_big(delta) > to_big(0) then delta = '+'..number_format(delta)
            else delta = number_format(delta)
            end
            if type(vals.mult) == 'string' then delta = vals.mult end
            G.GAME.current_round.current_hand.mult = vals.mult
            G.hand_text_area.mult:update(0)
        end
        if vals.handname and G.GAME.current_round.current_hand.handname ~= vals.handname then
            G.GAME.current_round.current_hand.handname = vals.handname
        end
        return true
    end}))
end

local evaluate_poker_hand_ref = evaluate_poker_hand
function evaluate_poker_hand(hand)
    local newhand = {}
    for i, v in pairs(hand) do
        newhand[#newhand+1] = v
    end
    for i, v in pairs(SMODS.find_card("j_entr_planetarium")) do
        if v.ability.extra.hand == "Two Pair" then
            local c1 = newhand[1]
            local c2 = newhand[2]
            newhand[#newhand+1] = c1 
            newhand[#newhand+1] = c2
        end
    end
    local results = evaluate_poker_hand_ref(newhand)
    for i, v in ipairs(G.handlist) do
        if G.GAME.Interfered then
            results[v] = results[pseudorandom_element(G.handlist, pseudoseed("interfered"))]
        end
    end
    for i, v in pairs(results) do
        if G.GAME.atomikos_deleted and G.GAME.atomikos_deleted[i] then results[i] = {} end
        if G.GAME.SudoHand and G.GAME.SudoHand[i] and #results[i] > 0 and Entropy.no_recurse_scoring(results) == i then results[G.GAME.SudoHand[i]] = results[i] end
    end
    local top
    if results.bld_blind_high and next(results.bld_blind_high) then
        results["High Card"] = {}
    end
    if G.GAME.overload then
        for i, v in pairs(G.handlist) do
            if not top and results[v] and results[v][1] then
                top = {results[v][1]}
                top.text = v
                break
            end
        end
        for i, v in pairs(G.handlist) do
            if top then
                results[v][1] = top[1]
            end
        end
    end
    if G.GAME.randomised_hand_map then
        local results_copy = {}
        for i, v in pairs(results) do
            results_copy[i] = v
        end
        for i, v in pairs(G.GAME.randomised_hand_map) do
            results[i] = results_copy[v]
        end
    end
    results.top = top
    return results
end

local update_round_evalref = Game.update_round_eval
function Game:update_round_eval(dt)
    update_round_evalref(self, dt)
    if G.GAME.Overflow then
        Entropy.change_selection_limit(-G.GAME.Overflow)
        G.GAME.Overflow = nil
    end
    if G.GAME.Interfered then
        G.TAROT_INTERRUPT_PULSE = true
        G.TAROT_INTERRUPT = true
        update_hand_text_random(
        { nopulse = true, immediate=true },
        { handname = "", mult = 0, chips=0}
        )
        G.TAROT_INTERRUPT_PULSE = false
        G.TAROT_INTERRUPT = false
        G.GAME.Interfered = nil
    end
    if G.GAME.IncrementAnte and G.GAME.IncrementAnte ~= G.GAME.round_resets.ante then
        G.GAME.IncrementAnte = nil
        if G.GAME.Increment then
            G.E_MANAGER:add_event(Event({
                func = function() --card slot
                    -- why is this in an event?
                    change_shop_size(-G.GAME.Increment)
                    G.GAME.Increment = nil
                    return true
                end,
            }))
        end
    end
    if dt > 60 * 30 then
        Entropy.update_daily_seed()
    end
end

local create_cardref = create_card_for_shop
function create_card_for_shop(area)
    local card = create_cardref(area)
    if card and card.ability.set == "Joker" and next(SMODS.find_card("j_entr_ieros")) then
        for i, v2 in pairs(G.jokers.cards) do
            if v2.config.center.key == "j_entr_ieros" then
                local rare = nil
                if card.config.center.rarity ~= "j_entr_entropic" then
                    rare = Entropy.get_next_rarity(card.config.center.rarity or 1) or card.config.center.rarity
                end
                local new_card = Entropy.get_random_rarity_card(rare)
                card:set_ability(G.P_CENTERS[new_card])
            end
        end
    end 
    return card
end


local gba = get_blind_amount
function get_blind_amount(ante)
    if not ante then return 0 end
    local actual = to_big(ante) <= to_big(8) and to_number(ante) or to_big(ante)
    if to_big(math.abs(ante - math.floor(ante))) > to_big(0.01) then

        local p = (ante - math.floor(ante))
        return get_blind_amount(math.floor(ante) + (to_big(ante) < to_big(0) and -1 or 0))*(1-p) + get_blind_amount(math.floor(ante)+1 + (to_big(ante) < to_big(0) and -1 or 0))*p
    end
    if to_big(ante) < to_big(0) then
        return 100 * (0.95^(-ante))
    end
    return gba(to_number(actual)) or 100
end
function lerp(f1,f2,p)
    p = p * p
    return f1 * (1-p) + f2*p
end

local use_cardref= G.FUNCS.use_card
G.FUNCS.use_card = function(e, mute, nosave)
    local card = e.config.ref_table
    if card.ability.entr_death_mark and card.ability.consumeable then
        card:start_dissolve()
        SMODS.calculate_context({using_consumeable = true, consumeable = card, area = card.from_area})
        if G.STATE == G.STATES.SMODS_BOOSTER_OPENED and card.area == G.pack_cards then
            G.E_MANAGER:add_event(Event{
                trigger = "after",
                delay = 0.5,
                func = function()
                    G.GAME.pack_choices = G.GAME.pack_choices - 1 
                    if G.GAME.pack_choices <= 0 then
                        G.FUNCS.end_consumeable(nil, delay_fac)
                    end
                    return true
                end 
            })
        end
    else
        local val = use_cardref(e, mute, nosave)
        if e.config.ref_table.ability.entr_pinned then
            for i, v in pairs(G.GAME.entr_pinned_cards or {}) do
                if v.card == e.config.ref_table.config.center.key then 
                    G.GAME.entr_pinned_cards[i] = nil
                    return val 
                end
            end
        end
    end
    return val
end

local htuis = G.FUNCS.hand_text_UI_set
G.FUNCS.hand_text_UI_set = function(e)
    htuis(e)
    if G.GAME.cry_exploit_override then
        e.config.object.colours = { G.C.SET.Command }
    else
        e.config.object.colours = { G.C.UI.TEXT_LIGHT }
    end
    e.config.object:update_text()
end

local add_tagref = add_tag
function add_tag(_tag, ...)
    if type(_tag) == "table" then
        if not _tag.ability.added_to_deck then
            for i, v in pairs(SMODS.get_card_areas('jokers')) do
                for a, card in pairs(v.cards) do
                    local res = card:calculate_joker({tag_create = true, tag = _tag})
                    if res and res.tag then
                        _tag = res.tag
                    end
                end
            end
        end
        add_tagref(_tag, ...)
        _tag.ability.added_to_deck = true
        if not G.GAME.autostart_tags then G.GAME.autostart_tags = {} end
    else    
        add_tagref(_tag, ...)
    end
    G.GAME.last_tag = _tag.key
end

local upd = Game.update
local ee2dt = 0
local cdt = 0
function Game:update(dt)
	upd(self, dt)
	cdt = cdt + dt
	if cdt > 0.01 then
		if G.jokers and G.GAME.blind and G.GAME.blind.config.blind.entr_lose_instead then
			G.HUD_blind:get_UIE_by_ID("score_at_least").config.text = localize("ph_blind_score_less_than")
			for i, v in pairs(G.jokers.cards) do
				v:set_debuff(false)
			end
            for i = 1, math.ceil(math.max(G.jokers.config.card_limit, #G.jokers.cards)/5) do
                if G.jokers.cards[i] then
                    G.jokers.cards[i].debuff = true
                end
            end
        end
        if G.jokers and G.GAME.blind and not G.GAME.blind.config.blind.entr_lose_instead then
            G.HUD_blind:get_UIE_by_ID("score_at_least").config.text = localize("ph_blind_score_at_least")
        end
		cdt = 0
	end
    local ferv 
    for i, v in pairs((G.pack_cards or {cards = {}}).cards or {}) do
        if v.config.center.key == "c_entr_fervour" then ferv = true; break end
    end
    if ferv and G.GAME.entropy and G.GAME.entropy > 100 and 10^300 then
        if not G.GAME.entr_vignette_power then G.GAME.entr_vignette_power = 100 end
        G.GAME.entr_vignette_power = G.GAME.entr_vignette_power * 0.9 + 0.2 * 0.1
    elseif G.GAME.entr_vignette_power then
        G.GAME.entr_vignette_power = G.GAME.entr_vignette_power * 0.999 + 100 * 0.001
        if G.GAME.entr_vignette_power > 75 then G.GAME.entr_vignette_power = nil end
    end
    if G.GAME.ee_rot_debuff and G.jokers then
        local c = G.jokers.cards[#G.jokers.cards]
        if c then
            if not c.debuff then
                c.debuff = true
                c.debuff_from_rot = true
            end
            for i, v in pairs(G.jokers.cards) do
                if v ~= G.jokers.cards[#G.jokers.cards] and v.debuff_from_rot then
                    v.debuff = nil
                    v.debuff_from_rot = nil
                end
            end
        end
    end
end

local orig = create_UIBox_blind_popup
function create_UIBox_blind_popup(blind, discovered, vars)
	local blind_text = {}
	
	local _dollars = blind.dollars
	local target = {type = 'raw_descriptions', key = blind.key, set = 'Blind', vars = vars or blind.vars}
	if blind.collection_loc_vars and type(blind.collection_loc_vars) == 'function' then
		local res = blind:collection_loc_vars() or {}
		target.vars = res.vars or target.vars
		target.key = res.key or target.key
	end
	local loc_target = localize(target)
	local loc_name = localize{type = 'name_text', key = blind.key, set = 'Blind'}
  
	if discovered then 
	  local ability_text = {}
	  if loc_target then 
		for k, v in ipairs(loc_target) do
		  ability_text[#ability_text + 1] = {n=G.UIT.R, config={align = "cm"}, nodes={{n=G.UIT.T, config={text = v, scale = 0.35, shadow = true, colour = G.C.WHITE}}}}
		end
	  end
	  local stake_sprite = get_stake_sprite(G.GAME.stake or 1, 0.4)
	  if blind.exponent then
		  local exponents = ""
		  local exponents2 = ""
		  for i = 1, blind.exponent[1] do
			exponents = exponents .. "^"
		  end
		  if blind.exponent[1] > 5 then
			exponents = ""
			exponents2 = "{" .. blind.exponent[1] .. "}"
		  end
		  blind_text[#blind_text + 1] =
			{n=G.UIT.R, config={align = "cm", emboss = 0.05, r = 0.1, minw = 2.5, padding = 0.07, colour = G.C.WHITE}, nodes={
			  {n=G.UIT.R, config={align = "cm", maxw = 2.4}, nodes={
				{n=G.UIT.T, config={text = localize('ph_blind_score_at_least'), scale = 0.35, colour = G.C.UI.TEXT_DARK}},
			  }},
			  {n=G.UIT.R, config={align = "cm"}, nodes={
				{n=G.UIT.O, config={object = stake_sprite}},
				{n=G.UIT.T, config={text = exponents .. blind.exponent[2].. exponents2 .." "..localize('k_entr_base'), scale = 0.4, colour = G.C.RED}},
			  }},
			  {n=G.UIT.R, config={align = "cm"}, nodes={
				{n=G.UIT.T, config={text = localize('ph_blind_reward'), scale = 0.35, colour = G.C.UI.TEXT_DARK}},
				{n=G.UIT.O, config={object = DynaText({string = {_dollars and string.rep(localize('$'),_dollars) or '-'}, colours = {G.C.MONEY}, rotate = true, bump = true, silent = true, scale = 0.45})}},
			  }},
			  ability_text[1] and {n=G.UIT.R, config={align = "cm", padding = 0.08, colour = mix_colours(blind.boss_colour, G.C.GREY, 0.4), r = 0.1, emboss = 0.05, minw = 2.5, minh = 0.9}, nodes=ability_text} or nil
			}}
	  else
            blind_text[#blind_text + 1] =
                {n=G.UIT.R, config={align = "cm", emboss = 0.05, r = 0.1, minw = 2.5, padding = 0.07, colour = G.C.WHITE}, nodes={
                {n=G.UIT.R, config={align = "cm", maxw = 2.4}, nodes={
                    {n=G.UIT.T, config={text = localize(blind.key == "bl_entr_nadir" and 'ph_blind_score_less_than' or 'ph_blind_score_at_least'), scale = 0.35, colour = G.C.UI.TEXT_DARK}},
                }},
                {n=G.UIT.R, config={align = "cm"}, nodes={
                    {n=G.UIT.O, config={object = stake_sprite}},
                    {n=G.UIT.T, config={text = blind.mult..localize('k_x_base'), scale = 0.4, colour = G.C.RED}},
                }},
                {n=G.UIT.R, config={align = "cm"}, nodes={
                    {n=G.UIT.T, config={text = localize('ph_blind_reward'), scale = 0.35, colour = G.C.UI.TEXT_DARK}},
                    {n=G.UIT.O, config={object = DynaText({string = {_dollars and string.rep(localize('$'),_dollars) or '-'}, colours = {G.C.MONEY}, rotate = true, bump = true, silent = true, scale = 0.45})}},
                }},
                ability_text[1] and {n=G.UIT.R, config={align = "cm", padding = 0.08, colour = mix_colours(blind.boss_colour, G.C.GREY, 0.4), r = 0.1, emboss = 0.05, minw = 2.5, minh = 0.9}, nodes=ability_text} or nil
            }}
		end
	else
	  blind_text[#blind_text + 1] =
		{n=G.UIT.R, config={align = "cm", emboss = 0.05, r = 0.1, minw = 2.5, padding = 0.1, colour = G.C.WHITE}, nodes={
		  {n=G.UIT.R, config={align = "cm"}, nodes={
			{n=G.UIT.T, config={text = localize('ph_defeat_this_blind_1'), scale = 0.4, colour = G.C.UI.TEXT_DARK}},
		  }},
		  {n=G.UIT.R, config={align = "cm"}, nodes={
			{n=G.UIT.T, config={text = localize('ph_defeat_this_blind_2'), scale = 0.4, colour = G.C.UI.TEXT_DARK}},
		  }},
		}}
		return orig(blind, discovered, vars)
	end
   return orig(blind, discovered, vars)
end 

local dft = Blind.defeat
function Blind:defeat(s)
    if not self.config.blind.key then self.config.blind.key = "bl_small" end
    dft(self, s)
end

local ref = update_hand_text

function update_hand_text(config, vals)
    if not G.GAME.current_round.current_hand.cry_asc_num_text then G.GAME.current_round.current_hand.cry_asc_num_text = '' end
    if (type(vals.mult) == "number" or type(vals.mult) == "table") and next(SMODS.find_card("j_entr_tesseract")) and math.abs(to_big(vals.mult)) > to_big(0.001) then
        local total_angle = 0
        for i, v in pairs(G.jokers.cards) do
            if v.config.center.key == "j_entr_tesseract" then
                total_angle = total_angle + v.ability.degrees
            end
        end
        total_angle = (total_angle/360)*2*3.141592
        local base = {r=math.cos(total_angle),c=math.sin(total_angle)}
        local str = Entropy.what_the_fuck(base, vals.mult)
        vals.mult = str
    end
    if (type(vals.chips) == "number" or type(vals.chips) == "table") and next(SMODS.find_card("j_entr_tesseract")) and math.abs(to_big(vals.chips)) > to_big(0.001) then
        local total_angle = 0
        for i, v in pairs(G.jokers.cards) do
            if v.config.center.key == "j_entr_tesseract" then
                total_angle = total_angle + v.ability.degrees
            end
        end
        total_angle = -(total_angle/360)*2*3.14159265
        local base = {r=math.cos(total_angle),c=math.sin(total_angle)}
        local str = Entropy.what_the_fuck(base, vals.chips)
        vals.chips = str
    end
    ref(config, vals)
end
function Entropy.get_recipe_result(val,jokerrares,seed)
    local rare = 1
    local cost=0
    for i, v in pairs({
        [1]=0,
        [2]=6,
        [3]=12,
        cry_epic=(SMODS.Mods["Cryptid"] or {}).can_load and 20 or nil,
        [4]=30,
        cry_exotic=(SMODS.Mods["Cryptid"] or {}).can_load and 45 or nil,
        entr_entropic = (SMODS.Mods["Cryptid"] or {}).can_load and 70 or nil,
    }) do
        if (v or -9999) >= (cost or -1) and (val or -9999) >= (v or -1) then
            rare = i;cost=v
        end
    end
    return pseudorandom_element(jokerrares[rare] or {}, pseudoseed(seed)) or "j_joker"
end

function Entropy.get_recipe(cards)
    if #cards == 5 then
        local enhancements = Entropy.EnhancementPoints
        local rares = {}
        for i, v in pairs(G.P_CENTER_POOLS.Joker) do
            if not rares[v.rarity] then rares[v.rarity] = {} end
            rares[v.rarity][#rares[v.rarity]+1] = v.key
        end
        local enh = {}
        for i = 1, 5 do
            local card = cards[i]
            if card then
                enh[#enh+1]=card.config.center.key
            end
        end
        local sum = 0
        for i, v in pairs(enh) do
            if not enhancements[v] then
                enhancements[v] = 4.5 + math.random()*0.1-0.05
            end
            sum = sum + (enhancements[v] or 4.5) 
        end
        table.sort(enh, function(a,b)return (enhancements[a])>(enhancements[b]) end)
        G.GAME.JokerRecipes = G.GAME.JokerRecipes or {}
        if not G.GAME.JokerRecipes[Entropy.concat_strings(enh)] then
            G.GAME.JokerRecipes[Entropy.concat_strings(enh)]=Entropy.get_recipe_result(sum, rares,Entropy.concat_strings(enh))
        end
        return Entropy.FixedRecipes[Entropy.concat_strings(enh)] or G.GAME.JokerRecipes[Entropy.concat_strings(enh)]
    end
    return "j_joker"
end

Entropy.discard_specific = function(cards)
    for i, v in pairs(cards) do
        draw_card(G.hand, G.discard, i*100/#cards, 'down', false, v)
        v:calculate_seal({discard = true})
        local removed = false
        local effects = {}
        SMODS.calculate_context({discard = true, other_card =  v, full_hand = cards, ignore_other_debuff = true}, effects)
        SMODS.trigger_effects(effects)
        for _, eval in pairs(effects) do
            if type(eval) == 'table' then
                for key, eval2 in pairs(eval) do
                    if key == 'remove' or (type(eval2) == 'table' and eval2.remove) then removed = true end
                end
            end
        end
        destroyed_cards = {}
        if removed then
            destroyed_cards[#destroyed_cards + 1] = G.hand.highlighted[i]
            if SMODS.shatters(G.hand.highlighted[i]) then
                G.hand.highlighted[i]:shatter()
            else
                G.hand.highlighted[i]:start_dissolve()
            end
        end
        if destroyed_cards[1] then
            SMODS.calculate_context({remove_playing_cards = true, removed = destroyed_cards})
        end
    end
end 

local draw_card_ref = draw_card
function draw_card(from, to, i, face, _, card)
    if not card or not card.entr_no_discard then
        draw_card_ref(from, to, i, face, _, card)
    else
        card.entr_no_discard = nil
    end
end

local card_addref = Card.add_to_deck
function Card:add_to_deck(...)
    card_addref(self, ...)
    if self.ability.set == "Joker" and not self.original_card and self:is_food() then
        SMODS.calculate_context{entr_food_added = true, other_card = self}
    end
    if self.ability.set == "Joker" or self.ability.consumeable and self.config.center.key ~= "c_entr_detour" then
        G.GAME.detour_set = self.ability.set
    end
    if self:is_sunny() and self.area == G.jokers then 
        check_for_unlock({ type = "sunny_joker" })
    end
end

local card_redeem = Card.redeem
function Card:redeem(...)
    card_redeem(self, ...)
    G.GAME.detour_set = self.ability.set
end

local card_open = Card.open
function Card:open(...)
    card_open(self, ...)
    G.GAME.detour_set = self.ability.set
    if Entropy.has_rune("rune_entr_naudiz") then
        calculate_runes({
            buying_card = true,
            card = self
        })
    end
end

function Card:calculate_banana()
	if not self.ability.extinct then
		if self.ability.banana and (pseudorandom("banana") < G.GAME.probabilities.normal / 10) and not self.ability.cry_absolute then
			self.ability.extinct = true
			G.E_MANAGER:add_event(Event({
				func = function()
					play_sound("tarot1")
					self.T.r = -0.2
					self:juice_up(0.3, 0.4)
					self.states.drag.is = true
					self.children.center.pinch.x = true
					G.E_MANAGER:add_event(Event({
						trigger = "after",
						delay = 0.3,
						blockable = false,
						func = function()
							if self.area then
								self.area:remove_card(self)
							end
							self:remove()
							self = nil
							return true
						end,
					}))
					return true
				end,
			}))
			card_eval_status_text(self, "jokers", nil, nil, nil, { message = localize("k_extinct_ex"), delay = 0.1 })
			return true
		elseif self.ability.banana then
			card_eval_status_text(self, "jokers", nil, nil, nil, { message = localize("k_safe_ex"), delay = 0.1 })
			return false
		end
	end
	return false
end

local debuff_handref = Blind.debuff_hand
function Blind:debuff_hand(cards, hand, handname, check)
    if G.GAME.badarg and G.GAME.badarg[handname] then 
        return true
    else
        return debuff_handref(self, cards, hand, handname, check)
    end
end

local add_ref = CardArea.emplace
function CardArea:emplace(card, location, stay_flipped)
    if card and not card.set_card_area then
        card.set_card_area = function(card, self)
            card.area = self
        end
    end
    if self == G.hand or self == G.deck then
        if not card.base.suit or not card.base.id then
            G.E_MANAGER:add_event(Event({
                func = function()
                    SMODS.change_base(card, card.base.suit or "entr_nilsuit", card.base.value or "entr_nilrank")
                    return true
                end
            }))
        end
    end
    if card and card.area and (card.area.config.type == "shop" or card.base.suit) then
        card.bypass_selfdestruct = true
    end
    if card then add_ref(self, card, location, stay_flipped) end
    if self == G.consumeables then
        calculate_runes({consumable_emplaced = true, consumeable=card})
    end
    if card.ability.glitched_crown and self.config.type ~= "shop" then
        card:set_ability(G.P_CENTERS[card.ability.glitched_crown[card.glitched_index]])
        card.ability.glitched_crown = nil
    end
end

local end_roundref = end_round
function end_round()
    if G.GAME.blind_on_deck == "Boss" then
        G.GAME.entr_vouchers_set = nil
    end
    if Entropy.is_EE() and not (G.GAME.blind and G.GAME.blind.config and G.GAME.blind.config.blind.key == "bl_entr_endless_entropy") then
		if (G.GAME.blind and G.GAME.blind.config and ((G.GAME.blind.config.blind.entr_lose_instead and to_big(G.GAME.chips) < to_big(G.GAME.blind.chips)) or (G.GAME.blind.config.blind.key ~= "bl_entr_nadir" and to_big(G.GAME.chips) >= to_big(G.GAME.blind.chips)))) then
			G.GAME.chips = 0
			G.GAME.round_resets.lost = true
			G.E_MANAGER:add_event(Event({
				func = function()
					G.GAME.blind:set_blind(G.P_BLINDS[G.GAME.blind.config.blind.next_phase])
					Entropy.change_phase()
					G.GAME.blind:juice_up()
					ease_hands_played(G.GAME.round_resets.hands-G.GAME.current_round.hands_left)
					ease_discard(
						math.max(0, G.GAME.round_resets.discards + G.GAME.round_bonus.discards) - G.GAME.current_round.discards_left
					)
					G.FUNCS.draw_from_discard_to_deck()
					return true
				end
			}))
		else
            end_roundref()
        end
    else    
        end_roundref()
    end
    if G.GAME.candle_hand_size then 
        Entropy.handle_card_limit(G.hand, -G.GAME.candle_hand_size)
        G.GAME.candle_hand_size = nil
    end
    if G.GAME.vanish_selection_limit then
        Entropy.change_selection_limit(-G.GAME.vanish_selection_limit)
        G.GAME.vanish_selection_limit = nil
    end
end

function G.UIDEF.usage_tabs()
    return create_UIBox_generic_options({back_func = 'high_scores', contents ={create_tabs(
      {tabs = {
          {
            label = localize('b_stat_jokers'),
            chosen = true,
            tab_definition_function = create_UIBox_usage,
            tab_definition_function_args = {'joker_usage'},
          },
          {
            label = localize('b_stat_consumables'),
            tab_definition_function = create_UIBox_usage,
            tab_definition_function_args = {'consumeable_usage'},
          },
          {
            label = localize('b_stat_tarots'),
            tab_definition_function = create_UIBox_usage,
            tab_definition_function_args = {'consumeable_usage', 'Tarot'},
          },
          {
            label = localize('b_stat_planets'),
            tab_definition_function = create_UIBox_usage,
            tab_definition_function_args = {'consumeable_usage', 'Planet'},
          },
          {
            label = localize('b_stat_spectrals'),
            tab_definition_function = create_UIBox_usage,
            tab_definition_function_args = {'consumeable_usage', 'Spectral'},
          },
          {
            label = localize('b_stat_vouchers'),
            tab_definition_function = create_UIBox_usage,
            tab_definition_function_args = {'voucher_usage', 'Voucher'},
          },
      },
      tab_h = 8,
      snap_to_nav = true}),
      UIBox_button({
        button = "usage_plus",
        label = { ">" },
      })}})
  end

function create_usage_tabspage(args)
    local old = G.USAGE_PAGE
    local page = args
    local per_page = 6
    local types = {}
    local blacklist = {
        Unique = true,
        Food = true,
        Meme = true,
        Tier3 = true,
        M = true
    }
    for i, v in ipairs(SMODS.ConsumableType.obj_buffer) do
        if SMODS.ConsumableType.obj_table[v].original_mod and not blacklist[v] then types[#types+1] = v end
    end
    G.USAGE_PAGE = page
    if not types[1+(page*per_page)] then
        G.USAGE_PAGE = old
        page = old
    end
    local options = {
    }
    for i = 1+(page*per_page), math.min(math.max(1+(page*per_page)+per_page, #types-1), per_page) do
        local key = types[i]
        if key then
            options[#options+1] = {
                label = localize("b_stat_"..(key or "")) == "ERROR" and key or localize("b_stat_"..(key or "")),
                tab_definition_function = create_UIBox_usage,
                tab_definition_function_args = {'consumeable_usage', key},
                chosen = i == 1+(page*per_page),
            }
        end
    end
    return create_UIBox_generic_options({back_func = 'high_scores', contents ={create_tabs(
      {tabs = options,
      tab_h = 8,
      snap_to_nav = true}),  
      {n=G.UIT.R, config={minw = 5, align='cm', padding = 0.1}, nodes = {    
      UIBox_button({
        button = "usage_minus",
        label = { "<" },
        col = true
      }),
      ((G.USAGE_PAGE or -1) + 1) < (math.ceil(#types/per_page) - 1) and UIBox_button({
        button = "usage_plus",
        label = { ">" },
        align = 'cl',
        col=true
      }) or nil
    }}}})
end

G.FUNCS.usage_plus = function(e)
    G.SETTINGS.paused = true
    if G.OVERLAY_MENU then G.OVERLAY_MENU:remove(); G.OVERLAY_MENU = nil end
    G.FUNCS.overlay_menu{
      definition = create_usage_tabspage((G.USAGE_PAGE or -1)+1)
    }
end
G.FUNCS.usage_minus = function(e)
    G.SETTINGS.paused = true
    if G.OVERLAY_MENU then G.OVERLAY_MENU:remove(); G.OVERLAY_MENU = nil end
    if (G.USAGE_PAGE or 0)-1 < 0 then
        G.USAGE_PAGE = nil
    end
    G.FUNCS.overlay_menu{
      definition = (G.USAGE_PAGE or 0)-1 < 0 and G.UIDEF.usage_tabs() or create_usage_tabspage((G.USAGE_PAGE or 0)-1)
    }
end



local ref = G.UIDEF.run_setup
function G.UIDEF.run_setup(from_game_over)
    Entropy.update_daily_seed()
    return ref(from_game_over)
end

local draw_ref = G.FUNCS.draw_from_deck_to_hand
G.FUNCS.draw_from_deck_to_hand = function(e)
    e = e or G.hand.config.card_limit - #G.hand.cards
    if Entropy.blind_is("bl_entr_pandora") then
        local am = 0
        for i = 1, e do
            if pseudorandom("bl_entr_pandora") < 0.33 then
                am = am + 1
            end
        end
        local actual = e - am
        e = am
        if actual > 0 then
            for i = 1, actual do
                local card = SMODS.create_card{
                    key = SMODS.poll_enhancement({guaranteed = true, key = "entr_pandora"}),
                    set = "Enhanced",
                    area = G.hand
                  }
                Entropy.randomize_rank_suit(card, true, true, "pandora")
                card.ability.temporary = true
                G.hand:emplace(card)
            end
        end
    end
    draw_ref(e)
end


local ref = create_shop_card_ui
function create_shop_card_ui(card, type, area)
    if (card.config.center.set == "Voucher" or card.config.center.set == "Booster" or type == "Voucher" or type == "Booster") and next(SMODS.find_card("j_entr_pound_of_flesh")) then
        card.ability.beast_mark =(card.ability.set == "Voucher" or type == "Voucher") and 3 or true
    end
    if G.GAME.SHOVEL_SHOP then
        card.ability.beast_mark =(card.ability.set == "Voucher" or type == "Voucher") and 3 or true
    end
    ref(card, type, area)
end

if SMODS.Mods.Multipack and SMODS.Mods.Multipack.can_load then
    SMODS.Booster:take_ownership("p_mupack_favoritepack", {
        create_card = function(self, card, i)
            local used_cards = {}
            local max_amt = 0
            for k, v in pairs(G.PROFILES[G.SETTINGS.profile]['joker_usage']) do
                if G.P_CENTERS[k] and G.P_CENTERS[k].discovered and not G.P_CENTERS[k].no_doe and not G.P_CENTERS[k].no_collection then
                used_cards[#used_cards + 1] = {count = v.count, key = k}
                if v.count > max_amt then max_amt = v.count end
                end
            end
    
            table.sort(used_cards, function (a, b) return a.count > b.count end )
            
            local _card
            local v = used_cards[i]
                if v then 
                    _card = {set = "Joker", area = G.pack_cards, skip_materialize = true, soulable = false, key = v.key, key_append = "fav1"}
                else
                    _card = {set = "Joker", area = G.pack_cards, skip_materialize = true, soulable = false, key_append = "fav2"}
                end
            return _card
        end,
    }, true)
end

local card_flipref = Card.flip_side
function Card:flip_side(...)
    local mod = G.GAME.modifiers.entr_twisted
    G.GAME.modifiers.entr_twisted = nil
    card_flipref(self, ...)
    G.GAME.modifiers.entr_twisted = mod
end

local exit_ref = G.FUNCS.exit_overlay_menu_code
function G.FUNCS.exit_overlay_menu_code()
    exit_ref()
    G.GAME.USING_INHERIT = nil
    G.GAME.USING_SUDO = nil
    G.GAME.USING_DEFINE = nil
end

local htref = create_UIBox_hand_tip
function create_UIBox_hand_tip(handname)
	if G.GAME.USING_SUDO then
		G.GAME.USING_SUDO_HAND = handname
	end
	return htref(handname)
end

local lcpref = Controller.L_cursor_press
function Controller:L_cursor_press(x, y)
	lcpref(self, x, y)
	if G and G.GAME and G.GAME.hands and G.GAME.USING_SUDO_HAND then
		if G.CONTROLLER.cursor_hover and G.CONTROLLER.cursor_hover.target and G.CONTROLLER.cursor_hover.target.config and
		G.CONTROLLER.cursor_hover.target.config.on_demand_tooltip and G.CONTROLLER.cursor_hover.target.config.on_demand_tooltip.filler and 
		G.CONTROLLER.cursor_hover.target.config.on_demand_tooltip.filler.args and G.GAME.hands[G.CONTROLLER.cursor_hover.target.config.on_demand_tooltip.filler.args] then
			if G.GAME.CODE_DESTROY_CARD then
				G.GAME.CODE_DESTROY_CARD:start_dissolve()
				G.GAME.CODE_DESTROY_CARD = nil
			end
            local text, loc_disp_text, poker_hands, scoring_hand, disp_text =
            G.FUNCS.get_poker_hand_info(G.hand.highlighted)
            if not G.GAME.SudoHand then G.GAME.SudoHand = {} end
            G.GAME.SudoHand[text] = G.GAME.USING_SUDO_HAND
			G.FUNCS.exit_overlay_menu_code()
		end
	end
end


local visible_ref = SMODS.is_poker_hand_visible
function SMODS.is_poker_hand_visible(handname)
    if G.GAME.atomikos_deleted and G.GAME.atomikos_deleted[handname] then return end
    return visible_ref(handname)
end

local parse_ref = CardArea.parse_highlighted
function CardArea:parse_highlighted()
    G.GAME.asc_power_hand = 0
    parse_ref(self)
    local text,disp_text,poker_hands = G.FUNCS.get_poker_hand_info(self.highlighted)
    if not G.GAME.old_operator then G.GAME.old_operator = G.GAME.current_scoring_calculation_key or "multiply" end
    if G.GAME.hands[text] and G.GAME.hands[text].operator then
        SMODS.set_scoring_calculation(G.GAME.hands[text].operator)
    elseif G.GAME.old_operator then
        SMODS.set_scoring_calculation(G.GAME.old_operator)
        G.GAME.old_operator = nil
    else
        SMODS.set_scoring_calculation("multiply")
    end
end

local set_scoring_calculation_funcref = G.FUNCS.SMODS_scoring_calculation_function
G.FUNCS.SMODS_scoring_calculation_function = function(e)
    if e then set_scoring_calculation_funcref(e) end
end

local ref = SMODS.set_scoring_calculation
function SMODS.set_scoring_calculation(key, ...)
    G.GAME.current_scoring_calculation_key = key
    if ref then
        return ref(key, ...)
    end
end

local play_ref = G.FUNCS.evaluate_play
G.FUNCS.evaluate_play = function(e)
    local old_op = G.GAME.old_operator
    play_ref(e)
    G.GAME.old_op = old_op
    G.E_MANAGER:add_event(Event{
        func = function()
            if G.GAME.old_operator then
                SMODS.set_scoring_calculation(G.GAME.old_operator)
                G.GAME.old_operator = nil
            end
            return true
        end,
        trigger = "after"
    })
    G.GAME.overload = nil
    G.E_MANAGER:add_event(Event{
        trigger = "after",
        func = function()
            ease_colour(G.C.UI_CHIPS, G.C.BLUE, 0.3)
            ease_colour(G.C.UI_MULT, G.C.RED, 0.3)
            G.GAME.current_round.current_hand.cry_asc_num = 0
            G.GAME.current_round.current_hand.cry_asc_num_text = ""
            return true
        end
    })
end

local use_ref = Card.use_consumeable 
function Card:use_consumeable(...)
    self.entr_being_used = true
    if G.GAME.modifiers.entr_gfb then
        self.ENTR_TAPPED_R = math.pi/2
    end
    if Entropy.deck_or_sleeve("gemstone") and SMODS.pseudorandom_probability(nil, "entr_gemstone_deck", 1, 3) and self.config.center.set ~= "Rune" then
        G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.4, func = function()
            attention_text({
                text = localize('k_nope_ex'),
                scale = 1.3, 
                hold = 1.4,
                major = self,
                backdrop_colour = G.C.PURPLE,
                align = 'cm',
                offset = {x = 0, y = (G.STATE == G.STATES.TAROT_PACK or G.STATE == G.STATES.SPECTRAL_PACK) and -0.2 or 0},
                silent = true
                })
                G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.06*G.SETTINGS.GAMESPEED, blockable = false, blocking = false, func = function()
                    play_sound('tarot2', 0.76, 0.4);return true end}))
                play_sound('tarot2', 1, 0.4)
                self:juice_up(0.3, 0.5)
        return true end }))
        return
    else
        local ret = use_ref(self, ...)
        if not self.bypass_echo then
            if G.GAME.entr_echo and G.GAME.entr_echo[self.config.center.key] and #G.GAME.entr_echo[self.config.center.key] > 0 then
                for i, v in pairs(G.GAME.entr_echo[self.config.center.key]) do
                    local dum = Entropy.get_dummy(G.P_CENTERS[v], self.area, self)
                    dum.bypass_echo = true
                    Spectrallib.forcetrigger({
                        card = dum,
                        context = context,
                        silent = true
                    })
                    dum.bypass_echo = nil
                end
            end
        end
        self.used = true
        return ret
    end
end

local ref = Cryptid.handle_other_localizations
function Cryptid.handle_other_localizations()
    ref()
	SMODS.handle_loc_file(Entropy.path)
end

SMODS.Booster:take_ownership_by_kind('Arcana', {
	create_card = function(self, card, i)
        local rune
        local rare_rune
        if pseudorandom("entr_generate_rune") < 0.06 then rune = true end
		if G.GAME.entr_diviner then
            if pseudorandom("entr_generate_rune") < 0.06 then rune = true end
        end
        if not G.SETTINGS.entropy_tutorial_complete then
            rune = nil
        end
        if rune then
            return create_card("Rune", G.pack_cards, nil, nil, true, true, nil, "spe")
        end
        local _card
        if G.GAME.used_vouchers.v_omen_globe and pseudorandom('omen_globe') > 0.8 then
            _card = {set = "Spectral", area = G.pack_cards, skip_materialize = true, soulable = true, key_append = "ar2"}
        else
            _card = {set = "Tarot", area = G.pack_cards, skip_materialize = true, soulable = true, key_append = "ar1"}
        end
        return _card
	end
},true)


SMODS.Booster:take_ownership_by_kind('Celestial', {
	create_card = function(self, card, i)
        local rune
        local rare_rune
        if pseudorandom("entr_generate_rune") < 0.06 then rune = true end
		if G.GAME.entr_diviner then
            if pseudorandom("entr_generate_rune") < 0.06 then rune = true end
        end
        if G.GAME.round_resets.ante == 2 and G.GAME.round_resets.blind_states["Small"] == "Defeated" and not G.SETTINGS.entropy_tutorial_complete then 
            if i == 1 then
                return create_card("Rune", G.pack_cards, nil, nil, true, true, "c_entr_jera", "spe")
            else
                rune = nil
            end
        end
        if not G.SETTINGS.entropy_tutorial_complete then
            rune = nil
        end
        if rune and (i ~= 1 or not G.GAME.used_vouchers.v_telescope) then
            return create_card("Rune", G.pack_cards, nil, nil, true, true, nil, "spe")
        end
        local _card
        if G.GAME.used_vouchers.v_telescope and i == 1 then
            local _planet, _hand, _tally = nil, nil, 0
            for k, v in ipairs(G.handlist) do
                if SMODS.is_poker_hand_visible(v) and G.GAME.hands[v].played > _tally then
                    _hand = v
                    _tally = G.GAME.hands[v].played
                end
            end
            if _hand then
                for k, v in pairs(G.P_CENTER_POOLS.Planet) do
                    if v.config.hand_type == _hand then
                        _planet = v.key
                    end
                end
            end
            _card = {set = "Planet", area = G.pack_cards, skip_materialize = true, soulable = true, key = _planet, key_append = "pl1"}
        else
            _card = {set = "Planet", area = G.pack_cards, skip_materialize = true, soulable = true, key_append = "pl1"}
        end
        return _card
	end
},true)


local get_probability_varsref = SMODS.get_probability_vars
function SMODS.get_probability_vars(trigger_obj, base_numerator, base_denominator, identifier, from_roll)
    if trigger_obj and trigger_obj.config and trigger_obj.config.center and not Entropy.probability_cards[trigger_obj.config.center.key] then
        Entropy.probability_cards[trigger_obj.config.center.key] = true
    end
    local numerator, denominator = get_probability_varsref(trigger_obj, base_numerator, base_denominator, identifier, from_roll)
    if type(numerator) == "string" or numerator == nil then numerator = 1 end
    if type(denominator) == "string" or denominator == nil then denominator = 1 end
    local any_active
    for i, v in pairs(SMODS.find_card("j_entr_d1")) do
        if not v.ability.triggered then any_active = true end
    end
    if Entropy.has_rune("rune_entr_ingwaz") then
        any_active = true
    end
    if any_active then
        numerator = denominator
    end
    if (numerator or -1) < 0 then numerator = 0 end
    if (denominator or 0) < 1 then denominator = 1 end
    return numerator, denominator
end

Entropy.probability_cards = {}
local probability_ref = SMODS.pseudorandom_probability
function SMODS.pseudorandom_probability(trigger_obj, seed, base_numerator, base_denominator, identifier)
    if trigger_obj and trigger_obj.config and trigger_obj.config.center and not Entropy.probability_cards[trigger_obj.config.center.key] then
        Entropy.probability_cards[trigger_obj.config.center.key] = true
    end
    SMODS.calculate_context({pre_probability = true})
    for i, v in pairs(SMODS.find_card("j_entr_d1")) do
        if v.ability.triggered ~= true then
            v.ability.triggered = true
            return probability_ref(trigger_obj, seed, base_denominator, base_denominator, identifier)
        else
            v.ability.triggered = true
        end
    end
    for i, v in pairs(SMODS.find_card("j_entr_d4")) do
        local res = probability_ref(trigger_obj, seed, base_numerator, base_denominator, identifier) 
        if res then return res end
    end
    if next(SMODS.find_card("j_entr_heimartai")) and not next(SMODS.find_card("j_entr_d0")) then
        local res = probability_ref(trigger_obj, seed, base_numerator, base_denominator, identifier) 
        local rolls = 1
        while not res do
            res = probability_ref(trigger_obj, seed, base_numerator, base_denominator, identifier) 
            card_eval_status_text(
                trigger_obj,
                "extra",
                nil,
                nil,
                nil,
                { message = not res and localize("k_again_ex") or "Success!", colour = G.C.GREEN }
            )
            rolls = rolls + 1
        end
        for i, v in pairs(SMODS.find_card("j_entr_heimartai")) do
            SMODS.scale_card(v, {
                ref_table = v.ability,
                ref_value = "echips",
                scalar_table = {val = rolls / base_denominator},
                scalar_value = "val"
            })
        end
        return res
    end
    return probability_ref(trigger_obj, seed, base_numerator, base_denominator, identifier)
end

local has_no_suitref = SMODS.has_no_suit
function SMODS.has_no_suit(card, bypass)
    if card.config.center.key == "j_entr_false_vacuum_collapse" or card.config.center.key == "phoenix_a" then return true end
    if next(SMODS.find_card("j_entr_opal")) and not bypass then
        return false
    end
    if card.base.suit == "entr_nilsuit" then return true end
    return has_no_suitref(card)
end

local has_no_rankref = SMODS.has_no_rank
function SMODS.has_no_rank(card, bypass)
    if card.config.center.key == "j_entr_false_vacuum_collapse" or card.config.center.key == "phoenix_a" then return true end
    if card.base.value == "entr_nilrank" and not next(SMODS.find_card("j_entr_opal")) then return true end
    return has_no_rankref(card)
end

local in_scoringref = SMODS.in_scoring
function SMODS.in_scoring(card, ...)
    if card.config.center.key == "j_entr_false_vacuum_collapse" or card.config.center.key == "phoenix_a" then return true end
    return in_scoringref(card, ...)
end

local get_idref = Card.get_id
function Card:get_id(...)
    local id = get_idref(self, ...)
    if next(SMODS.find_card("j_entr_opal")) then
        if id ~= get_idref(self, ...) then return 15 end
    end
    return id
end

local rate_ref = Cryptid.interest_rate
function Cryptid.interest_rate()
    local rate = Entropy.has_rune("rune_entr_loyalty") and math.max(5 - (Entropy.has_rune("rune_entr_loyalty").ability.count or 1), 1)
    if rate then return rate end
	return rate_ref and rate_ref() or G.GAME.modifiers.cry_interest_rate or 5
end

local interest_ref = Cryptid.get_interest
function Cryptid.get_interest(add_rows)
    local cap = G.GAME.interest_cap
    G.GAME.interest_cap = G.GAME.interest_cap +(G.GAME.companion_interest_cap or 0)
    if interest_ref then
        local interest = interest_ref(add_rows)
        G.GAME.interest_cap = cap
        return interest
    else    
        local rate = Cryptid.interest_rate()
        local interest = math.min(math.floor(G.GAME.dollars / rate), G.GAME.interest_cap / 5)
        interest = interest * G.GAME.interest_amount
        for _, a in pairs(SMODS.get_card_areas("jokers")) do
            for i, c in pairs(a.cards) do
                if c.config.center.cry_calc_interest then
                    interest = c.config.center:cry_calc_interest(c, interest)
                end
            end
        end
        G.GAME.interest_cap = cap
        return interest
    end
end

local at2 = add_tag
function add_tag(tag, from_skip, no_copy)
    at2(tag, from_skip, no_copy)
	if no_copy then
		return
	end
	SMODS.calculate_context({ entr_add_tag = true, tag = tag })
end

local ref = G.FUNCS.exit_overlay_menu_code
G.FUNCS.exit_overlay_menu_code = function(e)
	if G.GAME.CODE_DESTROY_CARD then
        G.GAME.CODE_DESTROY_CARD.ability.bypass_aleph = true
    end
    G.your_collection_runes = nil
    ref(e)
end

local is_eternalref = SMODS.is_eternal
function SMODS.is_eternal(c, ...)
    if c and c.ability and c.ability.entr_aleph then return true end
    if c and (c.area == G.play or c.area == G.hand or c.area == G.deck) and (c.ability.eternal or c.ability.entr_aleph) then
        return true
    end
    if c then
        return is_eternalref(c, ...)
    end
end

local open_ref = Card.open
function Card:open(...)
    if next(SMODS.find_card("j_entr_enlightenment")) then
        if self.config.center.kind == "Inverted" then
            G.GAME.last_inversion = {
                key = self.config.center.key,
                set = self.config.center.set
            }
        else
            G.GAME.last_tarot_planet = self.config.center.key
        end
    end
    open_ref(self, ...)
    G.E_MANAGER:add_event(Event{
        trigger = "after",
        blocking = false,
        func = function()
            G.E_MANAGER:add_event(Event{
                trigger = "after",
                blocking = false,
                func = function()
                    SMODS.calculate_context{post_open_booster = true, card = self}
                    return true
                end
            })
            return true
        end
    })
    if Entropy.deck_or_sleeve("crafting") then
        G.hand.config.highlighted_limit = math.max(G.hand.config.highlighted_limit, 5)
    end
end

local new_round_ref = new_round
function new_round(...)
    new_round_ref(...)
    if Entropy.deck_or_sleeve("crafting") then
        G.hand.config.highlighted_limit = math.max(G.hand.config.highlighted_limit, 5)
    end
end

local copy_cardref = copy_card
function copy_card(old, new, ...)
    local tw = G.GAME.modifiers.entr_twisted
    G.GAME.modifiers.entr_twisted = nil
    local copy = copy_cardref(old, new, ...)
    if G.deck and not G.SETTINGS.paused then
        SMODS.calculate_context{copying_card = true, original_card = old, new_card = copy}
    end
    for i, v in pairs(G.play and G.play.cards or {}) do
        eval_card(v, {copying_card = true, original_card = old, new_card = copy})
    end
    if old.base and old.base.nominal then copy.base.nominal = old.base.nominal end
    G.GAME.modifiers.entr_twisted = tw
    if copy.config and copy.config.center_key == "j_entr_unstable_rift" then
        math.randomseed(os.time())
        copy.ability.extra.val = math.random() --gay ass woke transgender math.random because syncing is for losers
    end
    if not G.SETTINGS.paused and G.deck and G.GAME.modifiers.entr_copper and pseudorandom("entr_copper_stake") < 0.33 and (copy.config.center.set == "Default" or copy.config.center.set == "Enhanced") then
        copy:set_ability(G.P_CENTERS.m_entr_disavowed)
    end
    return copy
end

local defeat_ref = Blind.defeat
function Blind:defeat(silent, ...)
    if G.GAME.blind_on_deck == "Boss" then
        G.GAME.round_resets.blind_states.Boss = "Defeated"
    end
    local ret = defeat_ref(self, silent, ...)
    return ret
end

for i, v in pairs(SMODS.JimboQuips or {}) do
    if not v.extra or not v.extra.center or v.extra.center == "j_joker" then
        local extra = copy_table(v.extra)
        extra = extra or {}
        extra.center = "j_entr_surreal_joker"
        SMODS.JimboQuip:take_ownership(v.key, {
            extra = extra
        }, true)
    end
end

--Init stuff at the start of the game
local gigo = Game.init_game_object
function Game:init_game_object()
	local g = gigo(self)
	g.jokers_sold = {}
	return g
end


local sell_card_stuff = Card.sell_card
function Card:sell_card()
	if self.config.center.set == "Joker" then
		if not (SMODS.Mods["Cryptid"] or {}).can_load then
			local contained = false
			for _, v in ipairs(G.GAME.jokers_sold) do
				if v == self.config.center.key then
					contained = true
					break
				end
			end
			if not contained then
				table.insert(G.GAME.jokers_sold, self.config.center.key)
			end
		end
	end
	sell_card_stuff(self)
end 

SMODS.Consumable:take_ownership("fool", {
    loc_vars = function(self, info_queue, card)
        local fool_c = G.GAME.last_tarot_planet and G.P_CENTERS[G.GAME.last_tarot_planet] or nil
        local last_tarot_planet = fool_c and localize { type = 'name_text', key = fool_c.key, set = fool_c.set == "Booster" and "Other" or fool_c.set } or
            localize('k_none')

        if last_tarot_planet == "ERROR" then
            local nodes = {}
            localize{type = 'name', set = "Other", key = fool_c.key, nodes = nodes}
            if not nodes[1] then
                localize{type = 'name', set = "Other", key = string.gsub(fool_c.key, "_[0-9]*$", ""), nodes = nodes}
            end
            last_tarot_planet = nodes[1][1].nodes[1].config.object.string
        end
        local colour = (not fool_c or fool_c.name == 'The Fool') and G.C.RED or G.C.GREEN

        if not (not fool_c or fool_c.name == 'The Fool') then
            info_queue[#info_queue + 1] = fool_c
        end

        local main_end = {
            {
                n = G.UIT.C,
                config = { align = "bm", padding = 0.02 },
                nodes = {
                    {
                        n = G.UIT.C,
                        config = { align = "m", colour = colour, r = 0.05, padding = 0.05 },
                        nodes = {
                            { n = G.UIT.T, config = { text = ' ' .. last_tarot_planet .. ' ', colour = G.C.UI.TEXT_LIGHT, scale = 0.3, shadow = true } },
                        }
                    }
                }
            }
        }

        return { vars = { last_tarot_planet }, main_end = main_end }
    end,
    use = function(self, card, area, copier)
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            func = function()
                if G.consumeables.config.card_limit > #G.consumeables.cards then
                    play_sound('timpani')
                    SMODS.add_card({ key = G.GAME.last_tarot_planet, area = G.consumeables })
                    card:juice_up(0.3, 0.5)
                end
                return true
            end
        }))
        delay(0.6)
    end,
    can_use = function(self, card)
        local fac = card.area == G.consumeables and -1 or 0
        return G.consumeables.config.card_limit > #G.consumeables.cards + fac and G.GAME.last_tarot_planet and
            G.GAME.last_tarot_planet ~= 'c_fool'
    end
}, true)

if HotPotato then
    function PissDrawer.Shop.main_shop()
        -- Reroll button for unknown goddamn reason just stuck, so I'll unstuck it
        G.E_MANAGER:add_event(Event({
            blocking = false,
            no_delete = true,
            func = function()
                local reroll = G.shop and G.shop:get_UIE_by_ID('shop_reroll')
                    if reroll and reroll.UIBox then
                    reroll.UIBox:recalculate()
                end
                return true
            end,
        }))
        return
        {n=G.UIT.C, nodes = {
            {n=G.UIT.R, config={align = "cm", padding = 0.05}, nodes={
                {n=G.UIT.C, config={align = "cm", padding = 0.1}, nodes={
                    {n=G.UIT.R,config={id = 'next_round_button', align = "cm", minw = 1.8, minh = Entropy.can_switch_alt_path() and 1 or 1.3, r=0.15,colour = G.C.RED, one_press = true, button = 'toggle_shop', hover = true,shadow = true}, nodes = {
                        {n=G.UIT.R, config={align = "cm", padding = 0.07, focus_args = {button = 'y', orientation = 'cr'}, func = 'set_button_pip'}, nodes={
                            {n=G.UIT.R, config={align = "cm", maxw = 1.3}, nodes={
                                {n=G.UIT.T, config={text = localize('b_next_round_1'), scale = 0.4, colour = G.C.WHITE, shadow = true}}
                            }},
                            {n=G.UIT.R, config={align = "cm", maxw = 1.3}, nodes={
                                {n=G.UIT.T, config={text = localize('b_next_round_2'), scale = 0.4, colour = G.C.WHITE, shadow = true}}
                            }}
                        }},
                    }},
                    (Entropy.can_switch_alt_path() and {n=G.UIT.R,config={id = 'change_path_button', align = "cm", minw = 1.8, minh = 1, r=0.15,colour = G.C.PURPLE, button = 'toggle_path', hover = true,shadow = true, func='can_toggle_path'}, nodes = {
                        {n=G.UIT.R, config={align = "cm", padding = 0.07, focus_args = {button = 'leftshoulder', orientation = 'cr'}, func = 'set_button_pip'}, nodes={
                            {n=G.UIT.R, config={align = "cm", maxw = 1.3}, nodes={
                            {n=G.UIT.T, config={text = localize(G.GAME.entr_alt and 'b_change_path_3' or 'b_change_path_1'), scale = 0.4, colour = G.C.WHITE, shadow = true}}
                            }},
                            {n=G.UIT.R, config={align = "cm", maxw = 1.3}, nodes={
                            not G.GAME.entr_alt and {n=G.UIT.T, config={text = localize('b_change_path_2'), scale = 0.4, colour = G.C.WHITE, shadow = true}} or nil
                            }}
                        }},              
                    }} or nil),
                    {n=G.UIT.R, config={id = 'shop_reroll', align = "cm", minw = 1.8, minh = Entropy.can_switch_alt_path() and 1 or 1.3, r=0.15,colour = G.C.GREEN, button = 'reroll_shop', func = 'can_reroll', hover = true,shadow = true}, nodes = {
                        {n=G.UIT.R, config={align = "cm", padding = 0.07, focus_args = {button = 'x', orientation = 'cr'}, func = 'set_button_pip'}, nodes={
                            {n=G.UIT.R, config={align = "cm", maxw = 1.3}, nodes={
                                {n=G.UIT.T, config={text = localize('k_reroll'), scale = 0.4, colour = G.C.WHITE, shadow = true}},
                            }},
                            {n=G.UIT.R, config={align = "cm", maxw = 1.3, minw = 1}, nodes={
                                {n=G.UIT.T, config={text = localize('$'), scale = 0.7, colour = G.C.WHITE, shadow = true}},
                                {n=G.UIT.T, config={ref_table = G.GAME.current_round, ref_value = 'reroll_cost', scale = 0.75, colour = G.C.WHITE, shadow = true}},
                            }}
                        }}
                    }},
                }},
                {n=G.UIT.C, config={align = "cm", padding = 0.2, r=0.2, colour = G.C.L_BLACK, emboss = 0.05, minw = 8.0}, nodes={
                    {n=G.UIT.O, config={object = G.shop_jokers}},
                }},
                {n=G.UIT.C, config = {align='cm', padding = 0.1}, nodes = {
                    {n=G.UIT.R, config={align = "cm", minw = 0.5, maxw = 0.7, minh = 0.8, r=0.15,colour = G.C.CLEAR, id = "show_plinko_button", button = 'open_plinko', shadow = true}, nodes = {
                        {n=G.UIT.O, config = {object = Sprite(0, 0, 0.9, 0.9, G.ASSET_ATLAS['hpot_pissdrawer_shop'], { x = 0, y = 0 }), shadow = true, hover = true, button_dist = 0.63}},
                    }},

                    {n=G.UIT.R, config={align = "cm", minw = 0.5, maxw = 0.7, minh = 0.8, r=0.15,colour = G.C.CLEAR, id = "show_wheel_button", button = 'open_wheel', shadow = true}, nodes = {
                        {n=G.UIT.O, config = {object = Sprite(0, 0, 0.9, 0.9, G.ASSET_ATLAS['hpot_pissdrawer_shop'], { x = 1, y = 0 }), shadow = true, hover = true, button_dist = 0.63}},
                    }},

                    {n=G.UIT.R, config={align = "cm", minw = 0.5, maxw = 0.7, minh = 0.8, r=0.15,colour = G.C.CLEAR, id = "show_nursery_button", button = 'open_nursery', shadow = true}, nodes = {
                        {n=G.UIT.O, config = {object = Sprite(0, 0, 0.9, 0.9, G.ASSET_ATLAS['hpot_pissdrawer_shop'], { x = 2, y = 0 }), shadow = true, hover = true, button_dist = 0.63}},
                    }},
                }}
            }},
            -- spacer
            {n=G.UIT.R, config={minh = 0.1}},
            -- bottom shop row
            {n=G.UIT.R, config={align = "cm", padding = 0.1}, nodes={
                {n=G.UIT.C, config={align = "cm", padding = 0.15, r=0.2, colour = G.C.L_BLACK, emboss = 0.05}, nodes={
                    {n=G.UIT.C, config={align = "cm", padding = 0.2, r=0.2, colour = G.C.BLACK, maxh = G.shop_vouchers.T.h+0.4}, nodes={
                        {n=G.UIT.T, config={text = localize{type = 'variable', key = 'ante_x_voucher', vars = {G.GAME.round_resets.ante}}, scale = 0.45, colour = G.C.L_BLACK, vert = true}},
                        {n=G.UIT.O, config={object = G.shop_vouchers}},
                    }},
                }},
                {n=G.UIT.C, config={align = "cm", padding = 0.15, r=0.2, colour = G.C.L_BLACK, emboss = 0.05}, nodes={
                    {n=G.UIT.O, config={object = G.shop_booster}},
                }},
            }}
        }}
    end
end

local gcp = get_current_pool
function get_current_pool(_type, _rarity, _legendary, _append, override_equilibrium_effect)
    if next(SMODS.find_card("j_entr_kitchenjokers")) and _type == "Joker" then
        for i, v in pairs(SMODS.find_card("j_entr_kitchenjokers")) do
            if pseudorandom("kitchenjokers_check") < 0.25 then
                _type = "Food"
                break
            end
        end
    end
    local ret, ret2 = gcp(_type, _rarity, _legendary, _append, override_equilibrium_effect)
    return ret, ret2
end

local calc_main_scoring = SMODS.calculate_main_scoring
function SMODS.calculate_main_scoring(context, scoring_hand)
    local fvc_cards = {}
    local added_cards = {}
    for i, v in pairs(G.play.cards) do if v.config.center.key == "j_entr_false_vacuum_collapse" and not v.debuff then fvc_cards[#fvc_cards+1] = v end end
    for i, v in pairs(G.jokers.cards) do if v.config.center.key == "j_entr_false_vacuum_collapse" and not v.debuff then fvc_cards[#fvc_cards+1] = v end end
    for _, card in pairs(G.I.CARD) do
        if card.ability and card.ability.entr_marked and not card.ability.entr_marked_bypass and not card.highlighted and not Entropy.in_table(scoring_hand or context.scoring_hand, card) then
            fvc_cards[#fvc_cards+1] = card
            added_cards[#added_cards+1] = card
        end
    end
    for i, v in pairs(G.play.cards) do if v.config.center.key == "j_entr_phoenix_a" and not v.debuff then fvc_cards[#fvc_cards+1] = v end end
    for i, v in pairs(G.jokers.cards) do if v.config.center.key == "j_entr_phoenix_a" and not v.debuff then fvc_cards[#fvc_cards+1] = v end end
    local ff_planetarium
    for i, v in pairs(SMODS.find_card("j_entr_planetarium")) do
        if v.ability.extra.hand == "Flush Five" then ff_planetarium = true break end
    end
    if context.cardarea ~= G.play or (not next(SMODS.find_card('j_entr_rubber_ball')) and not next(fvc_cards) and not ff_planetarium) then
	    calc_main_scoring(context, scoring_hand)
    end
	if context.cardarea == G.play and (next(SMODS.find_card('j_entr_rubber_ball')) or next(fvc_cards) or ff_planetarium) then
        if not G.rubber_cards or #G.rubber_cards.cards == 0 then
            G.rubber_cards = {cards = Entropy.rubber_ball_scoring(scoring_hand)}
        end
        for i, v in pairs(added_cards) do G.rubber_cards.cards[#G.rubber_cards.cards+1] = v end
		context.cardarea = G.rubber_cards
        context.scoring_hand = G.rubber_cards.cards
        for i, v in pairs(G.rubber_cards.cards) do
            if not SMODS.in_scoring(v, scoring_hand) then
                local c = v
                G.E_MANAGER:add_event(Event{
                    func = function()
                        c:highlight(true)
                        return true
                    end
                })
            end
        end
		calc_main_scoring(context, G.rubber_cards.cards)
		context.cardarea = G.play
        for i, v in pairs(G.rubber_cards.cards) do
            if not SMODS.in_scoring(v, scoring_hand) then
                local c = v
                G.E_MANAGER:add_event(Event{
                    trigger = "after",
                    blocking = false,
                    delay = 3,
                    func = function()
                        c:highlight()
                        return true
                    end
                })
            end
        end
        G.rubber_cards = nil
	end
	return
end

local base_shader_ref = Card.should_draw_base_shader
function Card:should_draw_base_shader(...)
    return base_shader_ref(self, ...) and not (self.debuff and Entropy.is_EE())
end

function Entropy.ee_taunt(taunt)
    local quip = taunt
    local extra = {
        center = SMODS.JimboQuips[taunt].extra.center
    }
    extra.x = 0
    extra.y = 5
    Jimbo = Card_Character(extra)
    local spot = G.HUD:get_UIE_by_ID('hand_text_area')
    spot.config.object = Jimbo
    Jimbo.ui_object_updated = true
    Jimbo:add_speech_bubble(quip, nil, {quip = true}, extra)
    Jimbo:say_stuff((extra and extra.times) or 5, false, quip)
    G.E_MANAGER:add_event(Event{
        trigger = "after",
        blocking = false,
        func = function()
            if not Jimbo.talking then
                G.E_MANAGER:add_event(Event{
                    trigger = "after",
                    delay = 4,
                    func = function()
                        Jimbo:remove()
                        return true
                    end
                })
                return true
            end
        end
    })
end

function Entropy.is_number(x)
    return type(x) == "number" or (type(x) == "table" and is_number(x)) or (is_big and is_big(x))
end
function Entropy.is_big(x)
    return (type(x) == "table" and is_number(x)) or (is_big and is_big(x))
end

function hotpot_horsechicot_market_section_init_cards()
  G.GAME.shop.market_joker_max = G.GAME.shop.market_joker_max or 2
  if G.GAME.market_table then
    G.market_jokers:load(G.GAME.market_table)
    G.GAME.market_table = nil
  else
    if not G.GAME.market_filled then
      G.GAME.market_filled = {}
      for i = 1, G.GAME.shop.market_joker_max - #G.market_jokers.cards do
        local new_shop_card
        if G.GAME.modifiers.no_shop_jokers then
            new_shop_card = SMODS.create_card { set = "BlackMarketJokerless", area = G.market_jokers, bypass_discovery_ui = true, bypass_discovery_center = true }
            if G.GAME.modifiers.glitched_items then
                local gc = {new_shop_card.config.center.key}
                for i = 1, G.GAME.modifiers.glitched_items - 1 do
                gc[#gc+1] = SMODS.poll_object{set = "BlackMarketJokerless"}
                end
                new_shop_card.ability.glitched_crown = gc
            end
        else
            new_shop_card = SMODS.create_card { set = "BlackMarket", area = G.market_jokers, bypass_discovery_ui = true, bypass_discovery_center = true }
            if G.GAME.modifiers.glitched_items then
                local gc = {new_shop_card.config.center.key}
                for i = 1, G.GAME.modifiers.glitched_items - 1 do
                gc[#gc+1] = SMODS.poll_object{set = "BlackMarket"}
                end
                new_shop_card.ability.glitched_crown = gc
            end
        end
        G.market_jokers:emplace(new_shop_card)
        create_market_card_ui(new_shop_card)
        new_shop_card:juice_up()
        G.GAME.market_filled[#G.GAME.market_filled + 1] = new_shop_card.config.center.key
      end
      -- save_run()
    else
      for i, v in pairs(G.GAME.market_filled) do
        local c = SMODS.create_card {
          key = v,
          bypass_discovery_ui = true,
          bypass_discovery_center = true
        }
        create_market_card_ui(c)
        G.market_jokers:emplace(c)
      end
      for i, v in pairs(G.market_jokers.cards) do
        create_market_card_ui(v)
      end
    end
  end
  G.harvest_cost = G.harvest_cost or 0
end


local forcetrigger_ref = Spectrallib.forcetrigger
function Spectrallib.forcetrigger(args, ...)
    local card = args.card
    if card.ability.consumeable then
        local center = card.config.center
        if center and center.calculate then
            center:calculate(card, {pre_using_self = true, consumeable = card, area = card.from_area})
        end
        local edition = card.edition and G.P_CENTERS[card.edition.key]
        if edition and edition.calculate then
            edition:calculate(card, {pre_using_self = true, consumeable = card, area = card.from_area})
        end
    end
    return forcetrigger_ref(args, ...)
end

local gnv_ref = SMODS.get_next_vouchers
function SMODS.get_next_vouchers(vouchers)
    local ret = gnv_ref(vouchers)
    if G.GAME.deck_voucher_rate and (G.GAME.deck_voucher_round or 0) % G.GAME.deck_voucher_rate == 0 then
        local center = SMODS.poll_object{set = "Back"}
        ret[#ret+1] = center
        ret.spawn[center] = true
    end
    G.GAME.deck_voucher_round = (G.GAME.deck_voucher_round or -1) + 1
    return ret
end

local buy_ref = G.FUNCS.buy_from_shop
function G.FUNCS.buy_from_shop(e)
    local card = e.config.ref_table
    if card.area == G.shop_vouchers then
        G.GAME.current_round.voucher.spawn[card.config.center_key] = nil
    end
    return buy_ref(e)
end

local blind_calc_ref = Blind.calculate
function Blind:calculate(context, ...)
    local obj = self.config.blind
    if obj then
        return blind_calc_ref(self, context, ...)
    end
end

local four_fingers_ref = SMODS.four_fingers
function SMODS.four_fingers(type, ...)
    local ret = four_fingers_ref(type, ...) or 5
    for i, v in pairs(SMODS.find_card("j_entr_planetarium")) do
        if v.ability.extra.hand == "Straight Flush" then
            local level = (G.GAME.hands[G.calced_hand or ""] or {}).level 
            if level then
                ret = ret - math.floor(level/ 3)
            end
        end
    end
    return ret
end

local get_x_sameref = get_X_same
function get_X_same(x, hand,...)
    for i, v in pairs(SMODS.find_card("j_entr_planetarium")) do
        if v.ability.extra.hand == "Straight Flush" then
            local level = (G.GAME.hands[G.calced_hand or ""] or {}).level 
            if level then
                x = x - math.floor(level/ 3)
            end
        end
    end
    if x < 1 then x = 1 end
    return get_x_sameref(x, hand,...)
end

local scale_cardref = SMODS.scale_card
function SMODS.scale_card(card, tbl, ...)
    if card.ability.entr_pure then
        SMODS.calculate_effect({card = card, message = localize("k_nope_ex"), colour = G.C.RED})
    else    
        return scale_cardref(card, tbl, ...)
    end
end

local return_to_deck_ref = Spectrallib.return_to_deck
function Spectrallib.return_to_deck(...)
    return return_to_deck_ref(...) or Spectrallib.blind_is("bl_entr_cassandra") or Spectrallib.blind_is("bl_entr_pi")
end

local get_bg_ref = Spectrallib.get_bg_colour
function Spectrallib.get_bg_colour(...)

    if TDECKS then
        local ret = TDECKS.get_bg_colour()
        if ret then return ret end
    end
    return G.GAME.entr_alt and G.C.ALTBG or get_bg_ref(...)
end

function Entropy.require(key)
    key = string.gsub(key, "%.", "/")
    local func = SMODS.load_file("lib/" ..key..".lua", "entr") or SMODS.load_file("lib/" ..key.."/init.lua", "entr")
    return func and func()
end

local row_ref = add_round_eval_row
function add_round_eval_row(config)
    if string.find(config.name, "void_joker") then
        local config = config or {}
        local width = G.round_eval.T.w - 0.51
        local num_dollars = config.dollars or 1
        local scale = 0.9
        total_cashout_rows = (total_cashout_rows or 0) + 1
        if total_cashout_rows > 7 then
            return
        end
        if config.name ~= 'blind1' then
            if not G.round_eval.divider_added then 
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',delay = 0.25,
                    func = function() 
                        local spacer = {n=G.UIT.R, config={align = "cm", minw = width}, nodes={
                            {n=G.UIT.O, config={object = DynaText({string = {'......................................'}, colours = {G.C.WHITE},shadow = true, float = true, y_offset = -30, scale = 0.45, spacing = 13.5, font = G.LANGUAGES['en-us'].font, pop_in = 0})}}
                        }}
                        G.round_eval:add_child(spacer,G.round_eval:get_UIE_by_ID(config.bonus and 'bonus_round_eval' or 'base_round_eval'))
                        return true
                    end
                }))
                delay(0.6)
                G.round_eval.divider_added = true
            end
        else
            delay(0.2)
        end

        delay(0.2)
        G.E_MANAGER:add_event(Event({
            trigger = 'before',delay = 0.5,
            func = function()
                --Add the far left text and context first:
                local left_text = {}
                table.insert(left_text, {n=G.UIT.O, config={object = DynaText({string = localize{type = 'name_text', set = config.card.config.center.set, key = config.card.config.center.key}, colours = {Entropy.void_gradient}, shadow = true, pop_in = 0, scale = 0.6*scale, silent = true})}})
                full_row = {n=G.UIT.R, config={align = "cm", minw = 5}, nodes={
                    {n=G.UIT.C, config={padding = 0.05, minw = width*0.55, minh = 0.61, align = "cl"}, nodes=left_text},
                    {n=G.UIT.C, config={padding = 0.05,minw = width*0.45, align = "cr"}, nodes={{n=G.UIT.C, config={align = "cm", id = 'void_joker_'..config.name},nodes={}}}}
                }}
                G.round_eval:add_child(full_row,G.round_eval:get_UIE_by_ID(config.bonus and 'bonus_round_eval' or 'base_round_eval'))
                play_sound('cancel', config.pitch or 1)
                play_sound('highlight1',( 1.5*(config.pitch or 1)) or 1, 0.2)
                if config.card then config.card:juice_up(0.7, 0.46) end
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            trigger = 'before',delay = 0.38,
            func = function()
                G.round_eval:add_child(
                    {n=G.UIT.R, config={align = "cm", id = 'void_row'..'_'..config.name}, nodes={
                        {n=G.UIT.O, config={object = DynaText({string = {"X"..number_format(config.void_multiplier)}, colours = {Entropy.void_gradient}, shadow = true, pop_in = 0, scale = 0.65, float = true})}}
                    }},
                    G.round_eval:get_UIE_by_ID('void_joker_'..config.name))
                play_sound('entr_void_generic')
                return true
            end
        }))
    else
        row_ref(config)
    end
end

local add_to_pool = SMODS.add_to_pool
function SMODS.add_to_pool(obj, ...)
    if G.P_BLINDS[obj.key] and not G.GAME.entr_bypass_alt then
        return (G.GAME.entr_alt and obj.altpath) or (not G.GAME.entr_alt and not obj.altpath and add_to_pool(obj, ...))
    end
    return add_to_pool(obj, ...)
end

local get_new_blind = SMODS.get_new_blind
function SMODS.get_new_blind(type)
    if G.GAME.modifiers.entr_gfb then
        type = ({
            small = "boss",
            boss = "small",
            big = "big"
        })[type]
    end
    local ret = get_new_blind(type)
    if G.GAME.entr_alt then
        if type == "small" then
            ret = "bl_entr_small"
        end
        if type == "big" then
            ret = "bl_entr_big"
        end
    end
    return ret
end

local blind_get_type = Blind.get_type
function Blind:get_type()
    if self.small then return 'Small'
    elseif self.big then return 'Big'
    else return blind_get_type(self) end
end

local draw_ref = love.draw
function love.draw(...)
    draw_ref(...)
    if Entropy.do_fake_crash then
        Entropy.fake_crash(Entropy.do_fake_crash)
    elseif Entropy.crash_volume then
        G.SETTINGS.SOUND.volume = Entropy.crash_volume
        Entropy.crash_volume = nil
    end
end

local add_v_ref = SMODS.add_voucher_to_shop
function SMODS.add_voucher_to_shop(key, ...)
    local card = add_v_ref(key, ...)
    if (next(find_joker("j_entr_chaos")) or next(find_joker("j_entr_parakmi")) or G.GAME.modifiers.entr_parakmi) then
        G.E_MANAGER:add_event(Event{
            trigger = "before",
            func = function()
                SMODS.calculate_context({modify_shop_voucher = true, card = card, first_of_ante = not G.GAME.entr_vouchers_set})
                G.GAME.entr_vouchers_set = true
                return true
            end
        })
    else    
        SMODS.calculate_context({modify_shop_voucher = true, card = card, first_of_ante = not G.GAME.entr_vouchers_set})
        G.GAME.entr_vouchers_set = true
    end
    return card
end

local asc_col_ref = Spectrallib.get_asc_colour
function Spectrallib.get_asc_colour(amount, text) 
    if(G.GAME.Overflow or (G.GAME.badarg and G.GAME.badarg[text])) then return HEX("FF0000") end
    return to_big(amount) >= to_big(0) and asc_col_ref(amount,  text) or G.C.Entropy.DARK_GRAY
end

local reset_ref = Cryptid.reset_to_none
function Cryptid.reset_to_none()
    if reset_ref then
        reset_ref()
    else
        update_hand_text({delay = 0}, {mult = 0, chips = 0, handname = '', level = ''})
    end
    update_hand_text({ delay = 0.1 }, {
        level = "",
    })
end

local card_eval_status_text_ref = card_eval_status_text
function card_eval_status_text(card, ...)
    if not card or card.silent then return end
    if G.deck and card and card.area == G.butterfly_jokers and G.deck.cards[1] then
        return card_eval_status_text_ref(G.deck.cards[1], ...)
    else    
        return card_eval_status_text_ref(card, ...)
    end
end

local sell_cardref = Card.sell_card
function Card:sell_card()
    if self.ability.set == "Joker" then
        if Entropy.deck_or_sleeve("butterfly") then
            local bcard = copy_card(self)
            bcard.states.visible = false
            G.jokers:remove_card(bcard)
            bcard:remove_from_deck()
            G.butterfly_jokers:emplace(bcard)
            bcard:add_to_deck()
        end
    end
    sell_cardref(self)
end

local get_next_tagref = Cryptid.get_next_tag
function Cryptid.get_next_tag(override)
    local ref = get_next_tagref and get_next_tagref(override)
    if next(SMODS.find_card('j_entr_dog_chocolate')) then 
        if not G.GAME.dog_tags then G.GAME.dog_tags = {} end
        if G.GAME.dog_tags[(override or G.GAME.blind_on_deck)..G.GAME.round_resets.ante] == nil then
            for i = 1, #SMODS.find_card('j_entr_dog_chocolate') do
                if G.GAME.dog_tags[(override or G.GAME.blind_on_deck)..G.GAME.round_resets.ante] ~= true then
                    G.GAME.dog_tags[(override or G.GAME.blind_on_deck)..G.GAME.round_resets.ante] = pseudorandom_element({true, false, false, false, false}, pseudoseed("dog_chocolate"))
                end
            end
        end
        if G.GAME.dog_tags[(override or G.GAME.blind_on_deck)..G.GAME.round_resets.ante] then return 'tag_entr_dog' end
    end
    if ref then return ref end
end

local orig_ref = Spectrallib.card_eval_status_text_eq
function Spectrallib.card_eval_status_text_eq(card, eval_type, amt, percent, dir, extra, pref, col, sound, vol, ta)
    if card.area == G.butterfly_jokers and G.deck.cards[1] then
        Spectrallib.card_eval_status_text_eq(G.deck.cards[1], eval_type, amt, percent, dir, extra, pref, col, sound, vol, true)
        return
    end
    orig_ref(card, eval_type, amt, percent, dir, extra, pref, col, sound, vol, ta)
end

local destroy_cards = SMODS.destroy_cards
function SMODS.destroy_cards(c, ...)
    if getmetatable(c) == Card then c = {c} end
    for i, v in pairs(c) do
        v.ability.temporary2 = true
    end
    return destroy_cards(c, ...)
end