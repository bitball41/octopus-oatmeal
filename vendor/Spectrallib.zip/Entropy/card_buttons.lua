-------------------
-- SUPPLEMENTARY --
-------------------

local function card_in_sets(card, sets)
    for _,set_name in ipairs(sets) do
        if (
            card.config.center.set == set_name
            or card.ability.set == set_name
        ) then return true end
    end
    return false
end

local function card_in_areas(card, areas)
    for _,area in ipairs(areas) do
        if card.area == area then return true end
    end
    return false
end

local function use_only_button(card, use_draw, use_click, text)
    local use_button_cfg = {
        ref_table = card,
        align = "bm",
        padding = 0.1, r = 0.08,
        minw = 0.5*card.T.w - 0.15, minh = 0.3*card.T.h,
        maxw = 0.9*card.T.w - 0.15,
        hover = true, shadow = true,
        colour = G.C.UI.BACKGROUND_INACTIVE,
        button = use_click, func = use_draw, handy_insta_action = 'buy_or_sell',
        one_press = true,
    }

    return
    {n=G.UIT.ROOT, config = {padding = 0, colour = G.C.CLEAR}, nodes={
        {n=G.UIT.R, config=use_button_cfg, nodes={
            {n=G.UIT.T, config={text = text, colour = G.C.UI.TEXT_LIGHT, scale = 0.45, shadow = true}}
        }},
    }}
end

local function sell_and_use_buttons(card, use_draw, use_click, text)
    local sell_button_cfg = {
        ref_table = card,
        align = "cr",
        padding = 0.1, r = 0.08,
        minw = 1.25,
        hover = true, shadow = true,
        colour = G.C.UI.BACKGROUND_INACTIVE,
        button = 'sell_card', func = 'can_sell_card', handy_insta_action = 'sell',
        one_press = true,
    }

    local use_button_cfg = {
        ref_table = card,
        align = "cr",
        padding = 0.1, r = 0.08,
        minw = 1.25, minh = (card.area and card.area.config.type == 'joker') and 0 or 1,
        maxw = 1.25,
        hover = true, shadow = true,
        colour = G.C.UI.BACKGROUND_INACTIVE,
        button = use_click, func = use_draw, handy_insta_action = 'use',
        one_press = true,
    }

    local sell_button =
    {n=G.UIT.C, config={align = "cr"}, nodes={
        {n=G.UIT.C, config=sell_button_cfg, nodes={
            {n=G.UIT.B, config = {w=0.1,h=0.6}},
            {n=G.UIT.C, config={align = "tm"}, nodes={
                {n=G.UIT.R, config={align = "cm", maxw = 1.25}, nodes={
                    {n=G.UIT.T, config={text = localize('b_sell'),colour = G.C.UI.TEXT_LIGHT, scale = 0.4, shadow = true}}
                }},
                {n=G.UIT.R, config={align = "cm"}, nodes={
                    {n=G.UIT.T, config={text = localize('$'),colour = G.C.WHITE, scale = 0.4, shadow = true}},
                    {n=G.UIT.T, config={ref_table = card, ref_value = 'sell_cost_label',colour = G.C.WHITE, scale = 0.55, shadow = true}}
                }}
            }}
        }},
    }}

    local use_button =
    {n=G.UIT.C, config={align = "cr"}, nodes={
        {n=G.UIT.C, config=use_button_cfg, nodes={
            {n=G.UIT.B, config = {w=0.1,h=0.6}},
            {n=G.UIT.T, config={text = text, colour = G.C.UI.TEXT_LIGHT, scale = 0.55, shadow = true}}
        }}
    }}

    local root =
    {n=G.UIT.ROOT, config = {padding = 0, colour = G.C.CLEAR}, nodes={
        {n=G.UIT.C, config={padding = 0.15, align = 'cl'}, nodes={
            {n=G.UIT.R, config={align = 'cl'}, nodes={
                sell_button
            }},
            {n=G.UIT.R, config={align = 'cl'}, nodes={
                use_button
            }},
        }},
    }}

    return root
end

---------------------------
-- CARD BUTTON EXTENSION --
---------------------------

---@type {condition: fun(card): boolean; uidef: fun(card): table}[]
local extended_card_button_definitions = {
    {
        condition = function (card)
            local in_set  = card_in_sets(card, {"Voucher"})
            local in_area = card_in_areas(card, {G.consumeables, G.jokers})
            return in_area and in_set
        end,
        uidef = function (card)
            local root = sell_and_use_buttons(card, "can_open_voucher", "open_voucher", localize('b_redeem'))
            return root
        end
    },
    {
        condition = function (card)
            local in_set  = card_in_sets(card, {"Back", "Sleeve"})
            local in_area = card_in_areas(card, {G.hand, G.pack_cards})
            return in_area and in_set
        end,
        uidef = function (card)
            local root = use_only_button(card, "can_buy_deckorsleeve", "buy_deckorsleeve", localize('b_redeem'))
            return root
        end
    },
    {
        condition = function (card)
            local in_set  = card_in_sets(card, {"Back", "Sleeve"})
            local in_area = card_in_areas(card, {G.consumeables, G.jokers})
            return in_area and in_set
        end,
        uidef = function (card)
            local root = sell_and_use_buttons(card, "can_buy_deckorsleeve", "buy_deckorsleeve", localize('b_redeem'))
            return root
        end
    },
    {
        condition = function (card)
            -- why check G.consumeables? this isn't being checked in some of the other conditions
            if not G.consumeables then return false end
            local in_set  = card_in_sets(card, {"Booster"})
            local in_area = card_in_areas(card, {G.consumeables, G.jokers})
            return in_area and in_set
        end,
        uidef = function (card)
            local root = sell_and_use_buttons(card, "can_open_booster", "open_booster", localize('b_redeem'))
            return root
        end
    },
    {
        condition = function (card)
            if not G.hand then return false end
            local in_set  = card_in_sets(card, {"Joker"})
            local in_area = card_in_areas(card, {G.hand})
            return in_area and in_set
        end,
        uidef = function (card)
            local root = use_only_button(card, "can_reserve_joker", "reserve_joker", localize('b_select'))
            return root
        end
    },
    {
        condition = function (card)
            if not G.hand then return false end
            local in_set  = card_in_sets(card, {"Booster"})
            local in_area = card_in_areas(card, {G.hand})
            return in_area and in_set
        end,
        uidef = function (card)
            local root = use_only_button(card, "can_open_booster", "open_booster", localize('b_open'))
            return root
        end
    },
    {
        condition = function (card)
            if not G.hand then return false end
            local in_set  = card_in_sets(card, {"Voucher"})
            local in_area = card_in_areas(card, {G.hand})
            return in_area and in_set
        end,
        uidef = function (card)
            local root = use_only_button(card, "can_open_voucher", "open_voucher", localize('b_redeem'))
            return root
        end
    },
    {
        condition = function (card)
            if not G.pack_cards then return false end
            -- let boosters not be recursive
            local in_set  = card_in_sets(card, {"Booster"})
            local in_area = card_in_areas(card, {G.pack_cards})
            return in_area and in_set and not Spectrallib.ConsumablePackBlacklist[SMODS.OPENED_BOOSTER.config.center.key]
        end,
        uidef = function (card)
            local root = use_only_button(card, "can_reserve_booster", "reserve_booster", localize('b_select'))
            return root
        end
    },
    {
        condition = function (card)
            if not G.jokers then return false end
            local in_set  = card_in_sets(card, {"Joker"})
            local in_area = card_in_areas(card, {G.jokers, G.consumeables})
            local use_button_config = Spectrallib.gather_button_config(card.config.center, card)
            local use = false
            for i, v in pairs(use_button_config) do
                if card.config.center[v.use_func] then use = true end
            end
            local needs_use_button = (
                not card.debuff
                and use
                and (
                    not card.config.center.needs_use_button
                    or card.config.center:needs_use_button(card)
                )
            )
            return in_area and in_set and needs_use_button
        end,
        uidef = function (card)
            local sell_button =
            {n=G.UIT.C, config={align = "cr"}, nodes={
                {n=G.UIT.C, config={ref_table = card, align = "cr",padding = 0.1, r=0.08, minw = 1.25, hover = true, shadow = true, colour = G.C.UI.BACKGROUND_INACTIVE, one_press = true, button = 'sell_card', func = 'can_sell_card', handy_insta_action = 'sell'}, nodes={
                    {n=G.UIT.B, config = {w=0.1,h=0.6}},
                    {n=G.UIT.C, config={align = "tm"}, nodes={
                        {n=G.UIT.R, config={align = "cm", maxw = 1.25}, nodes={
                            {n=G.UIT.T, config={text = localize('b_sell'),colour = G.C.UI.TEXT_LIGHT, scale = 0.4, shadow = true}}
                        }},
                        {n=G.UIT.R, config={align = "cm"}, nodes={
                            {n=G.UIT.T, config={text = localize('$'),colour = G.C.WHITE, scale = 0.4, shadow = true}},
                            {n=G.UIT.T, config={ref_table = card, ref_value = 'sell_cost_label',colour = G.C.WHITE, scale = 0.55, shadow = true}}
                        }}
                    }}
                }},
            }}

            local use_button_config = Spectrallib.gather_button_config(card.config.center, card)
            local buttons = {}
            for i, v in pairs(use_button_config) do
                card["_spectrallib_use_key"..i] = localize(v.key)
                buttons[#buttons+1] = {n=G.UIT.R, config={align = 'cl'}, nodes={
                     {n=G.UIT.C, config={align = "cr"}, nodes={
                        {n=G.UIT.C, config={ref_table = card, align = "cm",padding = 0.1, r=0.08, minw = 1.25, minh = 0.8, hover = true, shadow = true, colour = G.C.UI.BACKGROUND_INACTIVE, button = 'use_joker', func = v.func, use_func = v.use_func, condition_func = v.condition_func, use_key_key = "_spectrallib_use_key"..i, use_key = v.key, button_colour = v.colour,  handy_insta_action = 'use'}, nodes={
                            {n=G.UIT.B, config = {w=0.1,h=v.h}},
                            {n=G.UIT.C, config={align = "cm"}, nodes={
                                {n=G.UIT.R, config={align = "cm", maxw = 1.25}, nodes={
                                    {n=G.UIT.T, config={ref_table = card, ref_value = "_spectrallib_use_key"..i, colour = G.C.UI.TEXT_LIGHT, scale = 0.55, shadow = true}}
                                }},
                            }},
                        }},
                     }}
                }}
            end
            
            return
            {n=G.UIT.ROOT, config = {padding = 0, colour = G.C.CLEAR}, nodes={
                {n=G.UIT.C, config={padding = 0.15, align = 'cl'}, nodes={
                    {n=G.UIT.R, config={align = 'cl'}, nodes={
                        sell_button
                    }},
                    unpack(buttons)
                }},
            }}
        end
    },
    {
        condition = function (card)
            if not G.pack_cards then return false end
            local in_set  = card_in_sets(card, {"Joker"})
            local in_area = card_in_areas(card, {G.pack_cards})
            local needs_use_button = Spectrallib.needs_use_button(card)
            local poopshit = (
                Spectrallib.needs_pull_button(card)
                or (
                    not SMODS.OPENED_BOOSTER
                    or not SMODS.OPENED_BOOSTER.draw_hand
                    and card.children.front
                    and (card.ability.consumeable)
                )
            )
            return in_area and in_set and needs_use_button and poopshit
        end,
        uidef = function (card)
            return
            {n = G.UIT.ROOT, config = { padding = -0.1, colour = G.C.CLEAR }, nodes = {
                {n = G.UIT.R, config = { ref_table = card, r = 0.08, padding = 0.1, align = "bm", minw = 0.5 * card.T.w - 0.15, minh = 0.1 * card.T.h or 0.7 * card.T.h, maxw = 0.7 * card.T.w - 0.15, hover = true, shadow = true, colour = G.C.UI.BACKGROUND_INACTIVE, one_press = true, button = "use_card", func = card:is_playing_card() and "can_reserve_card_to_deck" or "can_reserve_card", handy_insta_action = 'use'}, nodes = {
                    {n = G.UIT.T,config = {text = Spectrallib.needs_pull_button(card),colour = G.C.UI.TEXT_LIGHT,scale = 0.55,shadow = true}},
                }},
                {n = G.UIT.R, config = { ref_table = card, r = 0.08, padding = 0.1, align = "bm", minw = 0.5 * card.T.w - 0.15, maxw = 0.9 * card.T.w - 0.15, minh = 0.1 * card.T.h, hover = true, shadow = true, colour = G.C.UI.BACKGROUND_INACTIVE, one_press = true, button = "Do you know that this parameter does nothing?", func = "can_use_consumeable", handy_insta_action = 'use'}, nodes = {
                    {n = G.UIT.T,config = { text = localize("b_use"), colour = G.C.UI.TEXT_LIGHT, scale = 0.45, shadow = true}}
                }},
                {n = G.UIT.R, config = { align = "bm", w = 7.7 * card.T.w }},
                {n = G.UIT.R, config = { align = "bm", w = 7.7 * card.T.w }},
                {n = G.UIT.R, config = { align = "bm", w = 7.7 * card.T.w }},
                {n = G.UIT.R, config = { align = "bm", w = 7.7 * card.T.w }},
            }}
            -- Betmma can't explain it, neither can I
        end
    },
    {
        condition = function (card)
            if not G.pack_cards then return false end
            local in_area = card_in_areas(card, {G.pack_cards})
            local needs_use_button = Spectrallib.needs_use_button(card)
            local poopshit = (
                Spectrallib.needs_pull_button(card)
                or (
                    not SMODS.OPENED_BOOSTER
                    or not SMODS.OPENED_BOOSTER.draw_hand
                    and card.children.front
                    and (card.ability.consumeable)
                )
            )
            return in_area and needs_use_button and poopshit
        end,
        uidef = function (card)
            return
            {n = G.UIT.ROOT, config = { padding = -0.1, colour = G.C.CLEAR }, nodes = {
                {n = G.UIT.R, config = {ref_table = card, r = 0.08, padding = 0.1, align = "bm", minw = 0.5 * card.T.w - 0.15, minh = 0.7 * card.T.h, maxw = 0.7 * card.T.w - 0.15, hover = true, shadow = true, colour = G.C.UI.BACKGROUND_INACTIVE, one_press = true, button = "Do you know that this parameter does nothing?", func = card:is_playing_card() and "can_reserve_card_to_deck" or "can_reserve_card", handy_insta_action = 'use' }, nodes = {
                    {n = G.UIT.T, config = {text = Spectrallib.needs_pull_button(card), colour = G.C.UI.TEXT_LIGHT, scale = 0.55, shadow = true} }
                }},
            }}
            -- Betmma can't explain it, neither can I
        end
    }
}

local G_UIDEF_use_and_sell_buttons_ref = G.UIDEF.use_and_sell_buttons
function G.UIDEF.use_and_sell_buttons(card)
	local abc = G_UIDEF_use_and_sell_buttons_ref(card)
    for _,buttondef in ipairs(extended_card_button_definitions) do
        if buttondef.condition(card) then
            return buttondef.uidef(card)
        end
    end
    return abc
end

---------------------------
-- CARD BUTTON FUNCTIONS --
---------------------------

G.FUNCS.can_reserve_joker = function(e)
    local c1 = e.config.ref_table
    if
        #G.jokers.cards
        < G.jokers.config.card_limit + (Spectrallib.safe_get(c1, "edition", "negative") and 1 or 0)
    then
        e.config.colour = G.C.GREEN
        e.config.button = "reserve_joker"
    else
        e.config.colour = G.C.UI.BACKGROUND_INACTIVE
        e.config.button = nil
    end
end
G.FUNCS.reserve_joker = function(e)
    local c1 = e.config.ref_table
    G.E_MANAGER:add_event(Event({
        trigger = "after",
        delay = 0.1,
        func = function()
            local c2 = copy_card(c1, nil, nil, true, false)
            c1:remove()
            c2:add_to_deck()
            G.jokers:emplace(c2)
            SMODS.calculate_context({ pull_card = true, card = c1 })
            return true
        end,
    }))
end

G.FUNCS.can_open_booster = function(e)
    if
        G.STATE == G.STATES.SELECTING_HAND or G.STATE == G.STATES.SHOP
    then
        e.config.colour = G.C.GREEN
        e.config.button = "open_booster"
    else
        e.config.colour = G.C.UI.BACKGROUND_INACTIVE
        e.config.button = nil
    end
end
G.FUNCS.open_booster = function(e)
    local c1 = e.config.ref_table
    G.GAME.slib_booster_state = G.STATE
    delay(0.1)
    local area = c1.area
    if area == G.shop_vouchers then
        G.GAME.current_round.voucher.spawn[c1.config.center_key] = nil
    end
    if c1.ability.booster_pos then G.GAME.current_round.used_packs[c1.ability.booster_pos] = 'USED' end
    --draw_card(G.hand, G.play, 1, 'up', true, card, nil, true)
    if not c1.from_tag then
      G.GAME.round_scores.cards_purchased.amt = G.GAME.round_scores.cards_purchased.amt + 1
    end
    if c1.RPerkeoPack then
        G.RPerkeoPack = true
    end
    if G.blind_select then
        G.blind_select:remove()
        G.blind_prompt_box:remove()
    end
    e.config.ref_table.cost = 0
    e.config.ref_table:open()
    if c1.ability.slib_infinite_use then
        local card = c1
        card.ability.slib_no_sell_value = true
        card:set_cost()
        delay(0.4)

        card:juice_up()
        play_sound('generic1')
        local c2 = copy_card(c1)
        c2:add_to_deck()
        area:emplace(c2)
    elseif c1.ability.cry_multiuse and to_big(c1.ability.cry_multiuse) > to_big(1) then
        local card = c1
        card.ability.cry_multiuse = card.ability.cry_multiuse - 1
        card.ability.slib_no_sell_value = true
        card:set_cost()
        delay(0.4)

        -- i make my own card eval status text :D

        card:juice_up()
        play_sound('generic1')
        attention_text({
            text = format_ui_value(card.ability.cry_multiuse),
            scale = 1.1,
            hold = 0.6,
            major = card,
            backdrop_colour = get_type_colour(card.config.center, card),
            align = 'bm',
            offset = {x = 0, y = 0.2}
        })
        local c2 = copy_card(c1)
        c2:add_to_deck()
        area:emplace(c2)

    end
    --c1:remove()
end

G.FUNCS.can_open_voucher = function(e)
    local c1 = e.config.ref_table
    e.config.colour = G.C.GREEN
    e.config.button = "open_voucher"
end
G.FUNCS.open_voucher = function(e)
    local state = G.STATE
    local c1 = e.config.ref_table
    c1.cost = 0
    local area = c1.area
    c1:redeem()
    c1:start_dissolve()
    c1:remove()
    if c1.ability.slib_infinite_use then
        local card = c1
        card.ability.slib_no_sell_value = true
        card:set_cost()
        delay(0.4)

        card:juice_up()
        play_sound('generic1')
        local c2 = copy_card(c1)
        c2:add_to_deck()
        area:emplace(c2)
    elseif c1.ability.cry_multiuse and to_big(c1.ability.cry_multiuse) > to_big(1) then
        local card = c1
        card.ability.cry_multiuse = card.ability.cry_multiuse - 1
        card.ability.slib_no_sell_value = true
        card:set_cost()
        delay(0.4)

        -- i make my own card eval status text :D

        card:juice_up()
        play_sound('generic1')
        attention_text({
            text = format_ui_value(card.ability.cry_multiuse),
            scale = 1.1,
            hold = 0.6,
            major = card,
            backdrop_colour = get_type_colour(card.config.center, card),
            align = 'bm',
            offset = {x = 0, y = 0.2}
        })
        local c2 = copy_card(c1)
        c2:add_to_deck()
        area:emplace(c2)

    end
    G.STATE = state
end

G.FUNCS.can_reserve_booster = function(e)
    local c1 = e.config.ref_table
    if
        G.consumeables.config.card_count
        < G.consumeables.config.card_limit + (Cryptid.safe_get(c1, "edition", "negative") and 1 or 0)
    then
        e.config.colour = G.C.GREEN
        e.config.button = "reserve_booster"
    else
        e.config.colour = G.C.UI.BACKGROUND_INACTIVE
        e.config.button = nil
    end
end
G.FUNCS.reserve_booster = function(e)
    local c1 = e.config.ref_table
    --G.GAME.slib_booster_state = G.STATE
    --c1:open()
    G.pack_cards:remove_card(c1)
    G.consumeables.cards[#G.consumeables.cards + 1] = c1
    c1.area = G.consumeables
    c1.parent = G.consumeables
    c1.layered_parallax = G.consumeables.layered_parallax
    G.consumeables:set_ranks()
    G.consumeables:align_cards()

    SMODS.calculate_context({ pull_card = true, card = c1 })
    G.GAME.pack_choices = G.GAME.pack_choices - 1
    if G.GAME.pack_choices <= 0 then
        G.FUNCS.end_consumeable(nil, delay_fac)
    end
    if c1.ability.glitched_crown then
        local center = G.P_CENTERS[c1.ability.glitched_crown[c1.glitched_index]]
        c1:set_ability(center)
        c1.ability.glitched_crown = nil
    end
    --c1:remove()
end

G.FUNCS.can_buy_deckorsleeve = function(e)
    local c1 = e.config.ref_table
    e.config.colour = G.C.GREEN
    e.config.button = "buy_deckorsleeve_2"
end
G.FUNCS.can_buy_deckorsleeve_from_shop = function(e)
    local c1 = e.config.ref_table
    if to_big(G.GAME.dollars+G.GAME.bankrupt_at) >= to_big(c1.cost) or Entropy.has_rune and Entropy.has_rune("rune_entr_naudiz") then --should probably have a hookable function similar to SMODS.showman instead of a hardcoded rune check
        e.config.colour = G.C.GREEN
        e.config.button = "buy_deckorsleeve_from_shop"
    else
        e.config.colour = G.C.UI.BACKGROUND_INACTIVE
        e.config.button = nil
    end
end
G.FUNCS.buy_deckorsleeve_from_shop = function(e)
    local c1 = e.config.ref_table
    --G.GAME.slib_booster_state = G.STATE
    --c1:open()
    ease_dollars(-c1.cost)
    G.FUNCS.redeem_deckorsleeve(e)
end

G.FUNCS.buy_deckorsleeve_2 = function(e)
    local c1 = e.config.ref_table
    --G.GAME.slib_booster_state = G.STATE
    --c1:open()
    G.FUNCS.redeem_deckorsleeve(e)
end

G.FUNCS.redeem_deckorsleeve = function(e)
    G.E_MANAGER:add_event(Event{
        trigger = "after",
        func = function()

            local area
            if G.STATE == G.STATES.HAND_PLAYED then
                if not G.redeemed_vouchers_during_hand then
                    G.redeemed_vouchers_during_hand =
                        CardArea(G.play.T.x, G.play.T.y, G.play.T.w, G.play.T.h, { type = "play", card_limit = 5 })
                end
                area = G.redeemed_vouchers_during_hand
            else
                area = G.play
            end

            local card = e.config.ref_table
            if card.config.center.key == "j_joker" then
                card:set_ability(G.P_CENTERS.b_red)
            end
            card.area:remove_card(card)
            card:add_to_deck()
            area:emplace(card)
            card.cost = 0
            card:redeem_deck()
            return true
        end
    })
end

G.FUNCS.can_reserve_card_to_deck = function(e)
    local c1 = e.config.ref_table
    e.config.colour = G.C.GREEN
    e.config.button = "reserve_card_to_deck"
end
G.FUNCS.reserve_card_to_deck = function(e)
    local c1 = e.config.ref_table
    G.E_MANAGER:add_event(Event({
        trigger = "after",
        delay = 0.1,
        func = function()
            local c2 = copy_card(c1, nil, nil, true, false)
            c1:remove()
            c2:add_to_deck()
			table.insert(G.playing_cards, c2)
			G.deck:emplace(c2)
			playing_card_joker_effects({ c2 })
            SMODS.calculate_context({ pull_card = true, card = c1 })
            return true
        end,
    }))
end

G.FUNCS.can_reserve_card = function(e)
    local c1 = e.config.ref_table
    if
        #G.consumeables.cards
        < G.consumeables.config.card_limit + (Cryptid.safe_get(c1, "edition", "negative") and 1 or 0)
        and Spectrallib.can_be_pulled(c1)
    then
        e.config.colour = G.C.GREEN
        e.config.button = "reserve_card"
    else
        e.config.colour = G.C.UI.BACKGROUND_INACTIVE
        e.config.button = nil
    end
end
G.FUNCS.reserve_card = function(e)
    local c1 = e.config.ref_table
    G.E_MANAGER:add_event(Event({
        trigger = "after",
        delay = 0.1,
        func = function()
            c1.area:remove_card(c1)
            c1:add_to_deck()
            if c1.children.price then
                c1.children.price:remove()
            end
            c1.children.price = nil
            if c1.children.buy_button then
                c1.children.buy_button:remove()
            end
            c1.children.buy_button = nil
            remove_nils(c1.children)
            G.consumeables:emplace(c1)
            SMODS.calculate_context({ pull_card = true, card = c1 })
            G.GAME.pack_choices = G.GAME.pack_choices - 1
            if G.GAME.pack_choices <= 0 then
                G.FUNCS.end_consumeable(nil, delay_fac)
            end
            return true
        end,
    }))
end

G.FUNCS.can_use_joker = function(e)
    local center = e.config.ref_table.config.center
    local card = e.config.ref_table
    card[e.config.use_key_key] = localize(e.config.use_key)
    if
        center.can_use and center[e.config.condition_func](center, e.config.ref_table) and not e.config.ref_table.debuff
        and G.STATE ~= G.STATES.HAND_PLAYED and G.STATE ~= G.STATES.DRAW_TO_HAND and G.STATE ~= G.STATES.PLAY_TAROT
        and not (((G.play and #G.play.cards > 0) or (G.CONTROLLER.locked) or (G.GAME.STOP_USE and G.GAME.STOP_USE > 0)))
    then
        e.config.colour = e.config.button_colour
        e.config.button = "use_joker"
    else
        e.config.colour = G.C.UI.BACKGROUND_INACTIVE
        e.config.button = nil
    end
end
G.FUNCS.use_joker = function(e)
    local int = G.TAROT_INTERRUPT
    G.TAROT_INTERRUPT = true
    local center = e.config.ref_table.config.center
    local card = e.config.ref_table
    local config = Spectrallib.gather_button_config(center, card)
    if center[e.config.use_func] then
        center[e.config.use_func](center, e.config.ref_table)
    end
    e.config.ref_table:juice_up()
    G.TAROT_INTERRUPT = int
    if config.unhighlight then
        card.area:remove_from_highlighted(card)
        card:highlight()
    end
end


function Spectrallib.gather_button_config(center, card)
    local config = center.use_button_config and copy_table(center.use_button_config) or {
        key = center.use_key
    }
    if config[1] then
        for i, c in ipairs(config) do
            for i, v in pairs(c) do
                if type(v) == "function" then c[i] = v(center, card, c) end
            end
            c.key = c.key or "b_use"
            c.colour = c.colour or G.C.RED
            c.h = c.h or 0.6
            c.func = c.func or "can_use_joker"
            c.use_func = c.use_func or "use"
            c.condition_func = c.condition_func or "can_use"
        end
    else
        for i, v in pairs(config) do
            if type(v) == "function" then config[i] = v(center, card, config) end
        end
        config.key = config.key or "b_use"
        config.colour = config.colour or G.C.RED
        config.h = config.h or 0.6
        config.func = config.func or "can_use_joker"
        config.use_func = config.use_func or "use"
        config.condition_func = config.condition_func or "can_use"
        config = {config}
    end
    return config
end

--- Returns whether or not a card should have `G.FUNCS.use_and_sell_buttons` run on it.
--- Can be hooked to let card bypass `G.FUNCS.use_and_sell_buttons`
--- @param card Card Card being checked.
--- @return boolean
function Spectrallib.should_have_use_and_sell_buttons(card)
    return not (card and card.ability and card.ability.set == "elle_Resident" and not (card.area and card.area == G.pack_cards))
end

local gfcfbs = G.FUNCS.check_for_buy_space
G.FUNCS.check_for_buy_space = function(card)
	if
		not card or card.ability.infinitesimal or card.ability.set == "Back" or card.ability.set == "Sleeve"
	then
		return true
	end
	return gfcfbs(card)
end

local ref = create_shop_card_ui
function create_shop_card_ui(card, type, area)
    if card.config.center.set == "Back" or card.config.center.set == "Sleeve" then
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.43,
            blocking = false,
            blockable = false,
            func = (function()
              if card.opening then return true end
              local t1 = {
                  n=G.UIT.ROOT, config = {minw = 0.6, align = 'tm', colour = darken(G.C.BLACK, 0.2), shadow = true, r = 0.05, padding = 0.05, minh = 1}, nodes={
                      {n=G.UIT.R, config={align = "cm", colour = lighten(G.C.BLACK, 0.1), r = 0.1, minw = 1, minh = 0.55, emboss = 0.05, padding = 0.03}, nodes={
                        {n=G.UIT.O, config={object = DynaText({string = {{prefix = localize('$'), ref_table = card, ref_value = 'cost'}}, colours = {G.C.MONEY},shadow = true, silent = true, bump = true, pop_in = 0, scale = 0.5})}},
                      }}
                  }}
              local t2 = {
                n=G.UIT.ROOT, config = {ref_table = card, minw = 1.1, maxw = 1.3, padding = 0.1, align = 'bm', colour = G.C.GOLD, shadow = true, r = 0.08, minh = 0.94, func = 'can_buy_deckorsleeve_from_shop', one_press = true, button = 'buy_deckorsleeve', hover = true}, nodes={
                    {n=G.UIT.T, config={text = localize('b_redeem'),colour = G.C.WHITE, scale = 0.5}}
                }}

              card.children.price = UIBox{
                definition = t1,
                config = {
                  align="tm",
                  offset = {x=0,y=1.5},
                  major = card,
                  bond = 'Weak',
                  parent = card
                }
              }

              card.children.buy_button = UIBox{
                definition = t2,
                config = {
                  align="bm",
                  offset = {x=0,y=-0.3},
                  major = card,
                  bond = 'Weak',
                  parent = card
                }
              }
              card.children.price.alignment.offset.y = card.ability.set == 'Booster' and 0.5 or 0.38

                return true
            end)
          }))
    else
        ref(card, type, area)
    end
end

local generate_uiref = generate_card_ui
function generate_card_ui(_c, full_UI_table, specific_vars, card_type, badges, hide_desc, main_start, main_end, card)
    if card_type == "Back" then
        if card.config and card.config.center and card.config.center.collection_loc_vars then
            specific_vars = (card.config.center:collection_loc_vars({}, card) or {}).vars
        elseif card.config and card.config.center and card.config.center.loc_vars then
            specific_vars = (card.config.center:loc_vars({}, card) or {}).vars
        elseif card.config and card.config.center then
            local loc_args = {}
            local effect_config = card.config.center.config
            local name_to_check = card.config.center.name
            if name_to_check == 'Blue Deck' then loc_args = {effect_config.hands}
            elseif name_to_check == 'Red Deck' then loc_args = {effect_config.discards}
            elseif name_to_check == 'Yellow Deck' then loc_args = {effect_config.dollars}
            elseif name_to_check == 'Green Deck' then loc_args = {effect_config.extra_hand_bonus, effect_config.extra_discard_bonus}
            elseif name_to_check == 'Black Deck' then loc_args = {effect_config.joker_slot, -effect_config.hands}
            elseif name_to_check == 'Magic Deck' then loc_args = {localize{type = 'name_text', key = 'v_crystal_ball', set = 'Voucher'}, localize{type = 'name_text', key = 'c_fool', set = 'Tarot'}}
            elseif name_to_check == 'Nebula Deck' then loc_args = {localize{type = 'name_text', key = 'v_telescope', set = 'Voucher'}, -1}
            elseif name_to_check == 'Ghost Deck' then
            elseif name_to_check == 'Abandoned Deck' then
            elseif name_to_check == 'Checkered Deck' then
            elseif name_to_check == 'Zodiac Deck' then loc_args = {localize{type = 'name_text', key = 'v_tarot_merchant', set = 'Voucher'},
                                localize{type = 'name_text', key = 'v_planet_merchant', set = 'Voucher'},
                                localize{type = 'name_text', key = 'v_overstock_norm', set = 'Voucher'}}
            elseif name_to_check == 'Painted Deck' then loc_args = {effect_config.hand_size,effect_config.joker_slot}
            elseif name_to_check == 'Anaglyph Deck' then loc_args = {localize{type = 'name_text', key = 'tag_double', set = 'Tag'}}
            elseif name_to_check == 'Plasma Deck' then loc_args = {effect_config.ante_scaling}
            elseif name_to_check == 'Erratic Deck' then
            end
            specific_vars = loc_args
        end
    end
    return generate_uiref(_c, full_UI_table, specific_vars, card_type, badges, hide_desc, main_start, main_end, card)
end
local set_cost_ref = Card.set_cost
function Card:set_cost()
    if not self.config then return end
	if self.config.center.set == "Back" or self.config.center.set == "Sleeve" then
		self.config.center.cost = 15
		self.base_cost = 15
	end
	set_cost_ref(self)
end

local update_ref = Game.update
function Game:update(dt)
    update_ref(self, dt)
    if G.STATE == nil and (G.pack_cards == nil or #G.pack_cards == 0) and G.GAME.slib_booster_state then
        G.STATE = G.GAME.slib_booster_state
        G.STATE_COMPLETE = false
        G.GAME.slib_booster_state = nil
    end
    if self.STATE == nil and not G.GAME.slib_booster_state then
        G.STATE = 1
        G.STATE_COMPLETE = false
    end
end

