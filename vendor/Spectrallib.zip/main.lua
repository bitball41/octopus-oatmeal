Spectrallib = {}

SMODS.current_mod.reset_game_globals = function (run_start)
    if run_start then
        -- Value Manipulation API
        Spectrallib.base_values = {}
        ---@type string[] List of deck keys. 
        G.GAME.entr_bought_decks = {}
        G.GAME.last_boss_ante = 0
        G.GAME.current_round.current_hand.cry_asc_num = 0
        G.GAME.current_round.current_hand.cry_asc_num_text = ''
    end
end

SMODS.current_mod.calculate = function (self, context)
    if context.ante_change and context.ante_change then
        G.GAME.last_boss_ante = G.GAME.round_resets.ante
    end
    if context.scoring_name and G.GAME.hands[context.scoring_name] then
        local hand = G.GAME.hands[context.scoring_name]
        for i, v in pairs(Spectrallib.HandBonuses) do
            if hand[v.key] and hand[v.key] ~= v.starting_value then
                local ret = v.calculate and v:calculate(context.scoring_name, context, hand[v.key])
                if ret and next(ret) then
                    ret.message_card = ret.message_card or G.HUD:get_UIE_by_ID('hand_name')
                    ret.card = ret.card or ret.message_card
                    ret.effect_card = ret.effect_card or ret.message_card
                    ret.scored_card = ret.scored_card or ret.message_card
                    SMODS.calculate_effect(ret)
                end
            end
        end
    end
end

local gigo = Game.init_game_object
function Game:init_game_object()
    local ret = gigo(self)
    ret.SuitBuffs = {}
    for k, obj in pairs(SMODS.Suits) do
        ret.SuitBuffs[k] = { level = 1, chips = 0, mult = 0, l_chips = obj.l_chips or 10, l_mult = obj.l_mult or 0 }
    end
    ret.SuitBuffs.suitless = { level = 1, chips = 0, mult = 0 }

    ret.RankBuffs = {}
    for k, obj in pairs(SMODS.Ranks) do
        ret.RankBuffs[k] = { level = 1, chips = 0, mult = 0, l_chips = obj.l_chips or 10, l_mult = obj.l_mult or 0 }
    end
    ret.RankBuffs.rankless = { level = 1, chips = 0, mult = 0 }
    --ascended hand level stuff
    ret.ascension_factor = 1.25 --default factor
    ret.sunlevel = 1
    --identical behaviour to cry_banished_keys in cryptid
    ret.slib_banished_keys = {}
    return ret
end
--[[
SMODS.current_mod.reset_game_globals = function (run_start)
end
]]
local files = {

    {path = "Spectrallib/other_utils"},
    {path = "Spectrallib/misc_ui"},
    {path = "Spectrallib/blind_functions"},
    {path = "Spectrallib/modpage_ui"},
    {path = "Spectrallib/attributes"},
    {path = "Spectrallib/bonus_effects"},
    {path = "Spectrallib/credits"},
    {path = "Spectrallib/hand_stuff"},
    {path = "Spectrallib/context"},
    {path = "Spectrallib/card_protection"},

    {path = "Cryptlib/main", redirect = "Cryptid"},
    {path = "Cryptlib/utilities", redirect = "Cryptid"},
    {path = "Cryptlib/talisman", redirect = "Cryptid"}, -- this is probably not needed with amulet existing but back compat so shrug
    {path = "Cryptlib/manipulate", redirect = "Cryptid"},
    {path = "Cryptlib/forcetrigger", redirect = "Cryptid"},
    {path = "Cryptlib/forcetrigger__vanilladef", redirect = "Cryptid"},
    {path = "Cryptlib/ascended", redirect = "Cryptid"},
    {path = "Cryptlib/unredeem", redirect = "Cryptid"},
    {path = "Cryptlib/unredeem__vanilladef", redirect = "Cryptid"},
    {path = "Cryptlib/colours"}, -- this doesn't have an equivalent in cryptid currently

    {path = "Entropy/main", redirect = "Entropy"},
    {path = "Entropy/utils", redirect = "Entropy"},
    {path = "Entropy/hand_stuff", redirect = "Entropy"},
    {path = "Entropy/suit_levels", redirect = "Entropy"},
    {path = "Entropy/return_values", redirect = "Entropy"},
    {path = "Entropy/deck_redeeming", redirect = "Entropy"},
    {path = "Entropy/deck_redeeming__vanilladef", redirect = "Entropy"},
    {path = "Entropy/card_buttons", redirect = "Entropy"},

    {path = "Lemniscate/utils", redirect = "Lemniscate"},
    {path = "Lemniscate/math", redirect = "Lemniscate"},
    {path = "Lemniscate/stat_mods", redirect = "Lemniscate"},

    {path = "compat/cryptid"},
    {path = "compat/spectrums"},
    {path = "compat/entropy"},
    {path = "compat/misc"},

}
for _, file_def in pairs(files) do
    if file_def.redirect then
        _G[file_def.redirect] = _G[file_def.redirect] or {}
        setmetatable(Spectrallib, {
            __newindex = function(table, key, value)
                rawset(table, key, value)
                if type(value) == "function" then
                    _G[file_def.redirect][key] = function (...)
                        return Spectrallib[key](...)
                    end
                else
                    _G[file_def.redirect][key] = value
                end
            end
        })
    end
    local file, err = SMODS.load_file(file_def.path..".lua")
    if file then file()
    else error(("Error in file: %s %s"):format(file_def.path, err)) end
end
