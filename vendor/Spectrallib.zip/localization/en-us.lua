return {
    descriptions = {
        Other = {
			slib_infoqueue_credit_art = {
                name = "Art Credit",
                text = {"Art By: {C:purple}#1#{}"}
            },
            slib_infoqueue_credit_code = {
                name = "Code Credit",
                text = {"Code By: {C:green}#1#{}"}
            },
            slib_infoqueue_credit_idea = {
                name = "Idea Credit",
                text = {"Idea By: {C:attention}#1#{}"}
            },
            disabled = {
				name = "Disabled",
				text = {
					"No longer appears",
					"during a run",
				},
			},
			slib_perma_plus_asc = {
				text = {
					"{C:gold}#1#{} Ascension Power"
				}
			},
			slib_perma_h_plus_asc = {
				text = {
					"{C:gold}#1#{} Ascension Power while held"
				}
			},
			slib_perma_x_asc = {
				text = {
					"{X:money,C:white}X#1#{} Ascension Power"
				}
			},
			slib_perma_h_asc = {
				text = {
					"{X:money,C:white}X#1#{} Ascension Power while held"
				}
			},
			slib_perma_exp_asc = {
				text = {
					"{X:slib_exp_asc,C:white}^#1#{} Ascension Power" --i have no idea what colour this should be, just guessing
				}
			},
			slib_perma_h_exp_asc = {
				text = {
					"{X:slib_exp_asc,C:white}^#1#{} Ascension Power while held"
				}
			},
			slib_perma_xlog_chips = {
				text = {
					"{X:chips,C:white}Xlog_#1#(Chips){} Chips"
				}
			},
			slib_perma_h_xlog_chips = {
				text = {
					"{X:chips,C:white}Xlog_#1#(Chips){} Chips while held"
				}
			},
			slib_perma_xlog_mult = {
				text = {
					"{X:mult,C:white}Xlog_#1#(Mult){} Mult"
				}
			},
			slib_perma_h_xlog_mult = {
				text = {
					"{X:mult,C:white}Xlog_#1#(Mult){} Mult while held"
				}
			},
			entr_card_suit_level = {
				text = {
					"--------------",
					"{S:0.8,V:1}#1#{} {S:0.8}({S:0.8,V:2}lvl.#4#{})",
					"{C:blue}+#2#{} Chips, {C:mult}+#3#{} Mult",
				}
			},
			entr_card_suit_level_chips = {
				text = {
					"--------------",
					"{S:0.8,V:1}#1#{} {S:0.8}({S:0.8,V:2}lvl.#4#{})",
					"{C:blue}+#2#{} Chips",
				}
			},
			entr_card_suit_level_mult = {
				text = {
					"--------------",
					"{S:0.8,V:1}#1#{} {S:0.8}({S:0.8,V:2}lvl.#4#{})",
					"{C:mult}+#3#{} Mult",
				}
			},
			slib_perma_e_chips = {
				text = {
					"{X:slib_echips,C:white}^#1#{} Chips"
				}
			},
			slib_perma_h_e_chips = {
				text = {
					"{X:slib_echips,C:white}^#1#{} Chips while held"
				}
			},
			slib_perma_e_mult = {
				text = {
					"{X:slib_emult,C:white}^#1#{} Mult"
				}
			},
			slib_perma_h_e_mult = {
				text = {
					"{X:slib_emult,C:white}^#1#{} Mult while held"
				}
			},
			slib_multiuse = {
				text = {
					"Multiuse: {V:1}#1#{} left"
				}
			},
			slib_infiniuse = {
				text = {
					"Multiuse: {E:1,C:legendary}Infinite{} left"
				}
			},
			slib_banned_card = {
				name = "Banished",
				text = {
					"This item has been",
					"{C:red}banished",
				},
			},
			-- BONUS EFFECT LOCS
			sbe_slib_chips = {
				text = {
					"{C:chips}#1#{} Chips"
				}
			},
			sbe_slib_xchips = {
				text = {
					"{X:chips,C:white}X#1#{} Chips"
				}
			},
			sbe_slib_echips = {
				text = {
					"{X:slib_echips,C:white}^#1#{} Chips"
				}
			},
			sbe_slib_eq_chips = {
				text = {
					"{X:slib_eqchips,C:white}=#1#{} Chips"
				}
			},
			sbe_slib_xlog_chips = {
				text = {
					"{X:chips,C:white}Xlog_#1#(Chips){} Chips"
				}
			},
			sbe_slib_mult = {
				text = {
					"{C:mult}#1#{} Mult"
				}
			},
			sbe_slib_xmult = {
				text = {
					"{X:mult,C:white}X#1#{} Mult"
				}
			},
			sbe_slib_emult = {
				text = {
					"{X:slib_emult,C:white}^#1#{} Mult"
				}
			},
			sbe_slib_eq_mult = {
				text = {
					"{X:slib_eqmult,C:white}=#1#{} Mult"
				}
			},
			sbe_slib_xlog_mult = {
				text = {
					"{X:mult,C:white}Xlog_#1#(Mult){} Mult"
				}
			},
			sbe_slib_asc = {
				text = {
					"{C:gold}#1#{} Ascension Power"
				}
			},
			sbe_slib_x_asc = {
				text = {
					"{X:gold,C:white}X#1#{} Ascension Power"
				}
			},
			sbe_slib_exp_asc = {
				text = {
					"{X:slib_exp_asc,C:white}^#1#{} Ascension Power"
				}
			},
			sbe_slib_score = {
				text = {
					"{C:purple}#1#{} Score"
				}
			},
			sbe_slib_xscore = {
				text = {
					"{X:purple,C:white}X#1#{} Score"
				}
			},
			sbe_slib_escore = {
				text = {
					"{X:slib_escore,C:white}^#1#{} Score"
				}
			},
			sbe_slib_blindsize = {
				text = {
					"{C:blind}#1#{} Blind Size"
				}
			},
			sbe_slib_xblindsize = {
				text = {
					"{X:blind,C:white}X#1#{} Blind Size"
				}
			},
			sbe_slib_eblindsize = {
				text = {
					"{X:slib_eblindsize,C:white}^#1#{} Blind Size"
				}
			},
			sbe_slib_swap = {
				text = {
					"Swaps {C:chips}Chips{} and {C:mult}Mult"
				}
			},
			sbe_slib_balance = {
				text = {
					"{C:purple}Balances {C:chips}Chips{} and {C:mult}Mult"
				}
			},
			sbe_slib_partial_swap = {
				text = {
					"Swaps {C:attention}#1#%{} of",
					"{C:chips}Chips{} and {C:mult}Mult"
				}
			},
			sbe_slib_hands = {
				text = {
					"{C:blue}#1#{} Hands"
				}
			},
			sbe_slib_discards = {
				text = {
					"{C:red}#1#{} Discards"
				}
			},
			sbe_slib_h_size = {
				text = {
					"{C:attention}#1#{} Hand Size"
				}
			},
			sbe_slib_consumable_slot = {
				text = {
					"{C:attention}#1#{} Consumable Slots"
				}
			},
			sbe_slib_joker_slot = {
				text = {
					"{C:dark_edition}#1#{} Joker Slots"
				}
			},
			sbe_slib_cashout = {
				text = {
					"Earn {C:money}$#1#{} at",
					"end of round"
				}
			},
			sbe_slib_cashout_loss = {
				text = {
					"Lose {C:red}$#1#{} at",
					"end of round",
				}
			},
			sbe_slib_type_chips = {
				text = {
                    "{C:chips}#1#{} Chips if played",
                    "hand contains",
                    "a {C:attention}#2#",
                },
			},
			sbe_slib_type_mult = {
				text = {
                    "{C:red}#1#{} Mult if played",
                    "hand contains",
                    "a {C:attention}#2#",
                },
			},
			sbe_slib_type_xmult = {
				text = {
                    "{X:mult,C:white}X#1#{} Mult if played",
                    "hand contains",
                    "a {C:attention}#2#",
                },
			},
			sbe_slib_sell_value = {
				text = {
					"Gains {C:money}$#1#{} of",
					"{C:attention}sell value{} at",
					"end of round"
				}
			},
			sbe_slib_sell_value_loss = {
				text = {
					"Loses {C:red}$#1#{} of",
					"{C:attention}sell value{} at",
					"end of round"
				}
			},
			sbe_slib_s_mult = {
				text = {
					"Played cards with",
                    "{V:1}#2#{} suit give",
                    "{C:mult}#1#{} Mult when scored",
				}
			}
        },
		CreditsStyle = {
			creditsstyle_slib_none = { name = "None" },
			creditsstyle_slib_below_badge = { name = "Below Badge"},
			creditsstyle_slib_badge_cycle = { name = "Cycle On Badge"},
			creditsstyle_slib_info_queue = { name = "In Info-Queue"},
			creditsstyle_slib_below_popup = {name = "Below Popup"}
		},
		HandBonus = {
			handbonus_slib_xmult = {
				name = "",
				text = {
					"Mult after hand is played"
				}
			},
			handbonus_slib_xmult_per  = {
				name = "",
				text = {"Mult per scored card"}
			}
		}
    },
    misc = {
        dictionary = {
            cry_gameset_explanation = {
				"Select a gameset config option",
				"to apply to this card.",
			},
            --its breaking and idk why so everything else can be disabled
			cry_gameset_disabled = "Disabled",
			cry_gameset_modest = "Disabled",
			cry_gameset_mainline = "Enabled",
			cry_gameset_madness = "Disabled",
			cry_gameset_custom = "Disabled",
			cry_gameset_exp = "Disabled",

			k_content_set = "Thematic Set",
			b_content_sets = "Thematic Sets",
			cry_view_set_contents = "View Items in Set",
			cry_set_enable_features = "Use this section to enable or disable entire Thematic Sets.",
			cry_family = "Family Friendly Mode",

			slib_exp_colours = "Exponential Chips and Mult colours",
			slib_exp_colour_1 = "Default",
			slib_exp_colour_2 = "Classic (G.C.DARK_EDITION)",

			b_tag = "Tag",
			b_blind = "Blind",
			k_mult = "Mult",
			k_chips = "Chips",

			cry_balanced_q = "Balanced...?",
			slib_forcetrigger_ex = "Forcetrigger!",
			slib_plus_consumable = "+1 Consumable",
			slib_plus_voucher = "+1 Voucher",
			slib_plus_back = "+1 Deck",
			slib_plus_sleeve = "+1 Sleeve",
			slib_plus_booster = "+1 Booster",
			slib_plus_blind = "+1 Blind",
			slib_plus_tag = "+1 Tag", --I know a_tag exists but like this makes sense to have imo

			k_level_chips = "Chips per level",
			k_level_mult = "Mult per level",
			slib_asc_hands = "Ascended Hands", --for leveling up ascended hands

			ph_no_decks = "No decks bought this run",
			ph_decks_bought = "Decks bought this run",

			slib_art = "Art: ",
            slib_code = "Code: ",
            slib_idea = "Idea: ",
			slib_by_art = "Art by",
            slib_by_code = "Code by",
            slib_by_idea = "Idea by",
            k_slib_and = " & ", -- keep the extra spaces
            k_slib_credits_styling = "Position to display card credits",

			slib_per_level = "Per-level Stats: ",
			slib_base_stats = "Base Stats: ",
			k_back = "Deck",
			k_tag = "Tag",
			k_blind = "Blind",
            k_unredeemed_ex="Unredeemed!",
        },
        v_dictionary = {
        	a_xchips = "X#1# Chips",
			a_powmult = "^#1# Mult",
			a_powchips = "^#1# Chips",
			a_powmultchips = "^#1# Mult+Chips",
			a_round = "+#1# Round",
			a_xchips_minus = "-X#1# Chips",
			a_powmult_minus = "-^#1# Mult",
			a_powchips_minus = "-^#1# Chips",
			a_powmultchips_minus = "-^#1# Mult+Chips",
			a_round_minus = "-#1# Round",
			a_tag_minus = "-#1# Tag",
			a_tags_minus = "-#1# Tags",
			a_tag = "+#1# Tag",
			a_tags = "+#1# Tags",
			a_eq_chips = "=#1# Chips",
			a_eq_mult = "=#1# Mult",
			a_xasc = "X#1# Asc",
			a_xasc_minus = "-X#1# Asc",
			a_asc = "+#1# Asc",
			a_asc_minus = "#1# Asc",
			a_exp_asc = "^#1# Asc",
			a_exp_asc_minus = "-^#1# Asc",
			a_escore = "^#1# Score",
			a_eescore = "^^#1# Score",
			a_eblindsize = "^#1# Blind Size",
			a_eeblindsize = "^^#1# Blind Size",
			op_base = "#1##2# Base",

			slib_art = "Art: #1#",
			slib_code = "Code: #1#",
			slib_idea = "Idea: #1#",
		},
		suits_singular = {
			suitless = "Suitless"
		},
		suits_plural = {
			suitless = "Suitless"
		},
		ranks = {
			rankless = "Rankless"
		},
		poker_hand_descriptions = {
			slib_asc_hands = {
				"Poker hands formed with more cards than usual",
				"gain Ascension Power, increasing Chips and Mult",
				"(e.x. a 7-card Straight for 2 Ascension Power)"
			}
		}
    }
}
