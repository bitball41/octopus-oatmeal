# JokerDisplay for Balatro

Balatro mod that displays information such as modifiers or relevant hands, ranks or suits under Jokers.

## Installation

1. Install [Lovely](https://github.com/ethangreen-dev/lovely-injector?tab=readme-ov-file#manual-installation)
2. Download the [latest release](https://github.com/nh6574/JokerDisplay/releases)
3. Extract the zip file into its own folder inside your Balatro mods folder (%appdata%\Balatro\Mods)

Compatible with SMODS >= 1.0.0~BETA-0624a

## Usage

* Right-click the display or a Joker to hide/unhide displays (or use the back button on your controller over a Joker). This will disable all calculations for that joker (in case of crashes).
* Left-click the display to collapse/expand extra rows of text. (or use the up button on your controller over a Joker).
* Go to `Settings > JokerDisplay` (or `Mods > JokerDisplay > Config` with SMODS) for more options.

Feel free to [open an issue](https://github.com/nh6574/JokerDisplay/issues) for suggestions or bug reports.

## Screenshots

<img src="examples/example_1.png" alt="Example 1" width="500">
<img src="examples/example_2.png" alt="Example 2" width="500">
<img src="examples/example_3.png" alt="Example 3" width="500">
<img src="examples/example_4.png" alt="Example 4" width="500">

## Mod Support

This mod only supports vanilla jokers but you can add support for it in your own mod by defining how the display should look.

Check out the [wiki](https://github.com/nh6574/JokerDisplay/wiki) for API documentation.

## Contributing

This mod will probably not get any new features after 1.8, so please feel free to fork or do PRs if you feel like you can improve on this or fix any issues!

Also I would appreciate if people contact me when there are updates to the game or Steamodded that break any features or add content.

### Acknowledgements

Special thanks to Eremel, OppositeWolf770, SleepyG11 and Dilly_the_Dillster for the help!

Also thanks to the following people for the localization:

* Russian: WholeHorse
* French: SDM_0
* Portuguese: naumazeredo
* Italian: fleshness
* German: GunnableScum
* Traditional Chinese: wilfredlam0418
* Dutch: Soulsphere
* Simplified Chinese: ChromaPIE
* Japanese: koukichi_kkc
* Polish: Sagiritarius

## Contact

If you have any issues feel free to contact me on [BlueSky](https://nh6574.com/) or Discord as nh6574

And here's my [ko-fi link](https://ko-fi.com/nh6574) if you feel especially grateful.

Also check out my other Quality of Life mod [PlayLog](https://github.com/nh6574/PlayLog)!
