return {
	descriptions = {
		Mod = {
			JokerDisplay = {
				name = "JokerDisplay",
				text = {
					"Показывает полезную информацию под джокерами",
					" ",
					"{C:attention}Управление:{}",
					"{C:blue}ПКМ или B:{} скрыть/показать",
					"{C:blue}ЛКМ или вверх:{} свернуть/развернуть",
					" ",
					"Особая благодарность {C:green}Eremel{} и {C:green}OppositeWolf770{}",
					" ",
					"{C:green}Localization:",
					"Russian: {C:green}WholeHorse{}  French: {C:green}SDM_0{}",
					"Portuguese: {C:green}naumazeredo{}  Italian: {C:green}fleshness{}",
					"German: {C:green}GunnableScum{}  Traditional Chinese: {C:green}wilfredlam0418{}",
					"Dutch: {C:green}Soulsphere{}  Simplified Chinese: {C:green}ChromaPIE",
					"Japanese: {C:green}koukichi_kkc{}  Polish: {C:green}Sagiritarius{}",
				},
			}
		}
	},
	misc = {
		dictionary = {
			jdis_enabled = "Включено",
			jdis_hide_by_default = "Скрывать по умолчанию",
			jdis_hide_empty = "Скрывать пустые",
			jdis_shift_to_hide = "Shift + ПКМ для скрытия",
			jdis_joker_count = "Показывать слоты джокеров",
			jdis_disable_collapse = "Отключить сворачивание",
			jdis_disable_perishable = "Отключить Временные",
			jdis_disable_rental = "Отключить Арендуемые",
			jdis_modifiers = "Модификаторы",
			jdis_reminders = "Напоминания",
			jdis_extras = "Экстра",
			jdis_default_display = "По умолчанию",
			jdis_small_display = "Свернутый вид",
			jdis_active = "Активно!",
			jdis_inactive = "Неактивно",
			jdis_all_suits = "Все масти",
			jdis_author = 'Автор',
		},
		v_dictionary = {
			jdis_odds = "#1# к #2#",
			jdis_rank_of_suit = "#1# #2#"
		}
	},
}
